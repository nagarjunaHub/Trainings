import os
from conans import ConanFile


_available_qualities = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6']


_default_requirements = (
                        ("my_test_lib1", "[>=0.1.0]"),
                        ("my_test_lib2", "[>=0.2.0]"),
                        ("my_test_lib3", "[>=0.3.0]"),
)


class Complete_uPSoftware(ConanFile):
    license = "BIOSLv4"
    settings = "os", "compiler", "build_type", "arch"
    generators = "cmake"
    short_paths = True

    def requirements(self):
        for name, version in _default_requirements:
            if "OVERRIDE_%s_VERSION" % name.upper() in os.environ or "OVERRIDE_%s_QUALITY" % name.upper() in os.environ:
                if "OVERRIDE_%s_VERSION" % name.upper() not in os.environ or "OVERRIDE_%s_QUALITY" % name.upper() not in os.environ:
                    raise KeyError("OVERRIDE_%s_VERSION and OVERRIDE_%s_VERSION have to be specified both" %
                                   (name.upper(), name.upper()))
                self.requires("%s/%s@%s/%s" % (
                    name,
                    os.environ["OVERRIDE_%s_VERSION" % name.upper()],
                    os.environ["OVERRIDE_%s_PROJECT" % name.upper()] if "OVERRIDE_%s_PROJECT" % name.upper() in os.environ else: self.user,
                    os.environ["OVERRIDE_%s_QUALITY" % name.upper()]
                ))
            else:
                self.requires("%s/%s@%s/%s" % (name, version, self.user, self.channel))

    def imports(self):
        self.copy("*.dll", "", "bin")
