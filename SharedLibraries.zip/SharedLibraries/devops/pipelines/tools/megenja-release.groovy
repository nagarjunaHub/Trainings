@Library('AEBEDevops@unstable_api/0.1.0_with_artifactory_helpers') _

import bosch.aebedo.ArtifactoryHelpers

node('si-z667r_buildslaves') {
    try {
        stage ('Publish MeGenJa Release') {
            cleanWs()
            project = 'MeGenJa_Release'
            timestamp = new Date().format('yyyyMMdd_HHmmss', TimeZone.getTimeZone('Europa/Berlin'))
            dispName = "${project}_${timestamp}"
            currentBuild.displayName = dispName
            releaseStash = 'MeGenJa_release'

            checkout changelog: true,
                     poll: false,
                     scm: [$class: 'RTCScm',
                     avoidUsingToolkit: false,
                     buildTool: 'RTC_BuildToolkit_6_0_4',
                     buildType: [buildWorkspace: '073rcl_rbd_pmt_metrics_1_0_sw_release_BW',
                                 clearLoadDirectory: true,
                                 customizedSnapshotName: '',
                                 loadDirectory: 'JWS',
                                 loadPolicy: 'useLoadRules',
                                 pathToLoadRuleFile: 'rbd.pmt.tools.MeGenJa/megenja_release.loadrule',
                                 value: 'buildWorkspace'],
                     credentialsId: '073rcl_Tech_User',
                     overrideGlobal: true,
                     serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',
                     timeout: 480]

            dir('JWS/MeGenJa') {
                version = bat (returnStdout: true, script: '@For %%i in ("Documentation\\*.docx") do @(For /F "tokens=3 delims=_" %%i in ("%%~ni") do @(echo %%i))').trim()
                bat "7z a ${project}_${version}.zip Documentation Setup"

                artifactory = new ArtifactoryHelpers(this, 'aebe-devops-local')
                artifactory.upload("${project}_${version}.zip", "Tools/MeGenJa/${dispName}",
                                   ['build.number':dispName, 'version':"${version}_${timestamp}"])
                artifactory.publishBuildInfo(dispName)
            }
        }
    } catch (e) {
        currentBuild.result = "FAILURE"
        node('master') {
            emailext attachLog: true, body: '${SCRIPT, template="pipeline.groovy"}', to: 'EsmatMohamedRamadanAly.Hassan@de.bosch.com', subject: '$DEFAULT_SUBJECT'
        }
        throw e
    }
}
