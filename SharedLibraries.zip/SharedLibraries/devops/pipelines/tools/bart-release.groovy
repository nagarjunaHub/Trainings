@Library('AEBEDevops@unstable_api/0.1.0_with_artifactory_helpers') _

import bosch.aebedo.ArtifactoryHelpers

node('si-z667r_buildslaves') {
    try {
        stage ('Publish BART Release') {
            cleanWs()
            project = 'BART_Release'
            timestamp = new Date().format('yyyyMMdd_HHmmss', TimeZone.getTimeZone('Europa/Berlin'))
            dispName = "${project}_${timestamp}"
            currentBuild.displayName = dispName
            releaseStash = 'BART_release'
            bartGitUrl = 'https://sourcecode.socialcoding.bosch.com/scm/bart/bart.git'

            checkout([$class: 'GitSCM',
                       branches: [[name: '*/master']],
                       doGenerateSubmoduleConfigurations: false,
                       extensions: [],
                       gitTool: 'si-z667r_buildslaves',
                       submoduleCfg: [],
                       userRemoteConfigs: [[credentialsId: 'Jenkins_Tech_User',
                                            url: bartGitUrl ]]])

            String rev = readFile "${WORKSPACE}/revision.txt"
            String[] lines = rev.split("\n")
            def versionline = lines.find{ line-> line =~ /Last Version/}
            def version = (versionline =~ /[0-9]+\.[0-9]+/)
            ver = "${version[0]}"
            version = null

            bat "7z a ${project}_${ver}.zip ."

            artifactory = new ArtifactoryHelpers(this, 'aebe-devops-local')
            artifactory.upload("${project}_${ver}.zip", "Tools/BART/${dispName}",
                                   ['build.number':dispName, 'version':"${ver}_${timestamp}"])
            artifactory.publishBuildInfo(dispName)

        }
    } catch (e) {
        currentBuild.result = "FAILURE"
        node('master') {
            emailext attachLog: true, body: '${SCRIPT, template="pipeline.groovy"}', to: 'EsmatMohamedRamadanAly.Hassan@de.bosch.com', subject: '$DEFAULT_SUBJECT'
        }
        throw e
    }
}
