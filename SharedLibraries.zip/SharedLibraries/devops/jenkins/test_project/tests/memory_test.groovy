def run_test(Object env) {
    try {
        echo 'Start Memory Consumption test'
        try{
        env.AEBE_DEVOPS_ARTIFACTORY = 'CI_Artifactory'
        bosch.aebedo.ArtifactoryHelpers artInstance = new bosch.aebedo.ArtifactoryHelpers(this, 'aebe-devops-local')
        def buildinfo = Artifactory.newBuildInfo()
        def pattern = 'Library_Test_Project/Memory'
        def target = 'MemoryAnalyzer_VWGW.xml'
        def props = ['project' : 'Library_Test']
        Boolean flat = true
        artInstance.download(pattern, target, props)
         } catch(e) {
        echo 'Error Memory Consumption Test, Problem with the Artifactory Download'
        echo e.toString()
        currentStage.result = 'FAILURE'
    }
        step([$class: 'MemoryConsumptionPlugin', path: 'MemoryAnalyzer_VWGW.xml\\Library_Test_Project\\Memory\\MemoryAnalyzer_VWGW.xml'])
    } catch(e) {
        echo e.toString()
        currentStage.result = 'FAILURE'
    }
}

def get_node() {
    def test_node = 'si-z666x_buildslaves '
    return test_node
}

return this;