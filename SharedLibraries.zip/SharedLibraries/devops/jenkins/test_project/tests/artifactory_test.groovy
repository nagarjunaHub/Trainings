def run_test(Object env) {
    try{
        echo 'Start Artifactory Test'
        env.AEBE_DEVOPS_ARTIFACTORY = 'CI_Artifactory'
        bosch.aebedo.ArtifactoryHelpers artInstance = new bosch.aebedo.ArtifactoryHelpers(this, 'aebe-devops-local')
        def buildinfo = Artifactory.newBuildInfo()
        def pattern = 'Library_Test_Project'
        def target = 'testfile.txt'
        def props = ['project' : 'Library_Test']
        artInstance.download(pattern, target, props)

        def credentials = 'JEE6LR_Artifactory_API'
        version = artInstance.getLatestVersion(pattern, props, credentials)

        def upload_pattern = 'testfile.txt/Library_Test_Project/testfile.txt'
        def upload_target = 'aebe-devops-local/Library_Test_Project/test2.txt'
        def upload_props = ['project' : 'Library_Test', 'version' : 'test_04092019']
        artInstance.upload(upload_pattern, upload_target, upload_props)
        artInstance.publishBuildInfo('815')
        cleanWs()
    } catch(e){
        echo e.toString()
    }
}

def get_node() {
    def test_node = 'si-z667r_buildslaves'
    return test_node
}

return this;