def run_test(Object env) {
    try{
        echo 'Running Compiler Warnings'
        env.AEBE_DEVOPS_ARTIFACTORY = 'CI_Artifactory'
        bosch.aebedo.ArtifactoryHelpers artInstance = new bosch.aebedo.ArtifactoryHelpers(this, 'aebe-devops-local')
        def buildinfo = Artifactory.newBuildInfo()
        def pattern = 'Library_Test_Project/Compiler'
        def target = "parexec-CompileAction_C_Files.log"
        def props = ['project' : 'Library_Test']
        Boolean flat = true
        artInstance.download(pattern, target, props)
         } catch(e) {
        echo 'Error Compiler Warnings Test. Problem with the Artifactory Download'
        echo e.toString()
        currentStage.result = 'FAILURE'
    }
        recordIssues(
                        tools: [groovyScript(
                                parserId: 'New_GHSParser_VW-GW',
                                pattern: 'parexec-CompileAction_C_Files.log\\Library_Test_Project\\Compiler\\*.log', 
                                reportEncoding: 'UTF-8'
                                )]
                    )
   
}

def get_node() {
    def test_node = 'si-z666x_buildslaves '
    return test_node
}

return this;