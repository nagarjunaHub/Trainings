def run_test(Object env) {
    echo 'Running Checkout RTC'
    try {
        checkout([$class: 'RTCScm', 
                avoidUsingToolkit: false, 
                buildTool: 'RTC_BuildToolkit_6_0_4', 
                buildType: [buildWorkspace: 'rbd_devops_test_int_Jenkins', 
                            componentLoadConfig: 'loadAllComponents', 
                            customizedSnapshotName: '', 
                            loadDirectory: 'JWS', 
                            loadPolicy: 'useComponentLoadConfig', 
                            value: 'buildWorkspace'
                            ], 
                credentialsId: '65b77bea-c0c9-4899-8585-457747f36cde', 
                overrideGlobal: true, 
                serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm', 
                timeout: 480])
        cleanWs()
    } catch(e){
        echo 'RTC Checkout failed'
        echo e.toString()
    }
}
def get_node() {
    def test_node = 'si-z667r_buildslaves'
    return test_node
}

return this;