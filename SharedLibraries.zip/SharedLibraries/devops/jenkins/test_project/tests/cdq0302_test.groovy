def run_test(Object env) {
    echo 'Running CDQ0302 Test'
}

def get_node() {
    def test_node = 'master'
    return test_node
}

return this;