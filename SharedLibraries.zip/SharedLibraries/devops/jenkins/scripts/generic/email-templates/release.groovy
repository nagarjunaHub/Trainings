<STYLE>
  BODY, TABLE, TD, TH, P {
    font-family: Calibri, Verdana, Helvetica, sans serif;
    font-size: 12px;
    color: black;
  }
  .console {
    font-family: Courier New;
  }
  .section {
    width: 100%;
    border: thin black dotted;
  }
  .td-title-main {
    color: white;
    font-size: 200%;
    padding-left: 5px;
	
  }
  .td-title {
    color: white;
    font-size: 120%;
    font-weight: bold;
    padding-left: 5px;
    text-transform: uppercase;
  }
  .td-summary {
	font-size: 120%;
	font-weight: bold;
    padding-left: 5px;
  }
  .tr-title {
    background-color: #2674CE;
  }
</STYLE>
<BODY>
  <!-- RELEASE -->
  <%
   /* The following env variables need to be configured for the release template:
    * VERSION - software version being assigned to the release pack
    * VARIANT - list of variant/s being released as part of the release pack
    * RELEASE_LOC - the shared drive location of the release pack 
    * DIR_PREFIX - the artifactory directory prefix of the release pack
    * REL_TICKET - ticket number being referenced for the intermediate release notes
    * REL_NOTES - additional release notes being displayed on the automated email
    */
	  def envOverrides = it.getAction("org.jenkinsci.plugins.workflow.cps.EnvActionImpl").getOverriddenEnvironment()
    version = envOverrides["VERSION"]
    variant = envOverrides["VARIANT"]
    wDrive = envOverrides["RELEASE_LOC"]
    artifactory = "https://rb-artifactory.bosch.com/artifactory/webapp/#/artifacts/browse/tree/General/" + envOverrides["DIR_PREFIX"]
    release_ticket = "https://rb-alm-11-p.de.bosch.com/ccm/resource/itemName/com.ibm.team.workitem.WorkItem/" + envOverrides["REL_TICKET"]
    notes = envOverrides["REL_NOTES"]
	%>
  <table class="section" cellpadding=5>
    <tr class="tr-title">
      <td class="td-title-main" colspan=2>
        DV5187 SW RELEASE
      </td>
    </tr>
	<tr><td class="td-summary">Software version ${version} has been released and can now be found in the CICD Releases directory.</td></tr>
    <tr><td>
	<table width="100%">
	<tr>
      <td width="15%">Version:</td>
      <td>${version}</td>
    </tr>
    <tr>
      <td width="15%">Variant:</td>
      <td>${variant}</td>
    </tr>
    <tr>
      <td>Date:</td>
      <td>${it.timestampString}</td>
    </tr>
    <tr>
      <td>Location:</td>
      <td><a href="${wDrive}">${wDrive}</a></td>
    </tr>
	<tr>
      <td>Artifactory (SW):</td>
      <td><a href="${artifactory}">${artifactory}</a></td>
	  </tr>
    <tr>
      <td>Release ticket:</td>
      <td><a href="${release_ticket}">${release_ticket}</a></td>
    </tr>
    <tr>
      <td>Notes:</td>
      <td>${notes}</td>
    </tr>
	</table>
	</td>
	</tr>
  </table>
  <br/>
</BODY>