# AE-BE DevOps Docupedia Utility Script

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

Script to upload, get and create page to docupedia.

## Table of Contents

- [Getting Started](#getting-started)
- [Building and Testing](#building-and-testing)
- [Contribution Guidelines](#contribution-guidelines)
- [Feedback](#feedback)
- [About](#about)
  - [Maintainers](#maintainers)
  - [Contributors](#contributors)
  - [3rd Party Licenses](#3rd-party-licenses)
  - [Used Encryption](#used-encryption)
  - [License](#license)

## Getting Started
You need to have API key requested in order to use this utility.

The link to the IT service portal is below :

https://rb-servicecatalog.apps.intranet.bosch.com/RequestCenter/website/Grunt/application/offer.html?id=3725

The base url for the docupedia gateway is https://ews-esz-emea.api.bosch.com/knowledge/docupedia/v1.1 

With this utility there are three operation :

1. createOrUpdateGivenRoot - This is the default behaviour when operation is not being specified. Go through the **targetdir** folder and check if given a **spaceKey** the same page with the title has exist if it does exist create the page if it does exist update the page. If the execution failed during upload due to html parser error or other error it will create the filtered html page and pretified version of the page inside the target directory page. This way it is easy to identify on which column and row the errror does occur.
2. getById - Retrieve the html given a pageid and have the html page on the **targetdir** folder. If **targetdir** folder is not there it will create the folder and put the html document inside the folder.
3. updateById - Update the page given a html document with the same id inside the **targetdir** folder. 

<b>NOTE</b> : Please ensure that within the documentation that uknown html tags are not accidentally being left as part of the html document. This will cause parser error to the destination. 

Page id of a page can be retrieved when editing -> https://inside-docupedia.bosch.com/confluence/pages/editpage.action?pageId=**\<{pageid}>**

The spacekey can be retrieved when accessing a page -> https://inside-docupedia.bosch.com/confluence/display/**<{spacekey}>**/**<{pagetitle}>**

Extra Python Dependency:
* Anaconda Python Baseline
* BeautifulSoup -> python -m pip install beautifulsoup4

## Building and Testing
Below are the Argument list with brief description on how to operate the utility script:
| Type | Args : Short, Long | Description                                                                              |
|:---- |:------------------:|:----------------------------------------------------------------------------------------:|
|String| --operation, -o    | createOrUpdateGivenRoot as default with getById and updateById                           |
|String| --pageid , -i      | Page id to operate on                                                                    |
|String| --baseurl, -b      | Baseurl for the RESTAPI                                                                  |
|String| --targetdir, -t    | Target directory to operate on the directory walk operation                              |
|String| --user, -u         | Username on Docupedia                                                                    |
|String| --pasw, -p         | Password on Docupedia                                                                    |
|String| --targetfile, -f   | Target file to upload arg is required for updateById operation                           |
|String| --spacekey, -s     | spacekey defined as **<{baseurl}>**/confluence/display/**<{spacekey}>**/**<{pagetitle}>**|
|String| --key, -k          | Token for the Docupedia                                                                  |
|String| --postfix, -x      | Postfix for the preview                                                                  |
|String| --config, -c       | Extended json configuration location                                                     |
| Bool | --demo, -d         | If specified the util will promp for auth details hiding your credentials                |

Install Dependency
```python
python -m pip install beautifulsoup4
```
Executing the utility via CLI to execute createOrUpdateGivenRoot when using it on a command promp.
With --demo or -d mode enforced the utility script to promp for your credetials so that your credentials when demoing or using the script.
```python
python docs_util.py -d -o createOrUpdateGivenRoot -i <{ROOT_PAGE_ID}> -s <{spacekey}> -u <{BASE_URL}>
```
Executing the utility via CLI to execute createOrUpdateGivenRoot when using it as a jenkins CLI.
```python
python docs_util.py -o createOrUpdateGivenRoot -i <{ROOT_PAGE_ID}> -s AEBE -b <{BASE_URL}> -u <{username}> -p <{password}> -k <{api_key}>
```
To create a preview you can execute : 
```python
python docs_util.py -d -o createPreview -k AEBE -b <{BASE_URL}> -t <{targetdirectory}> -x <{branch_name}> -i <{ROOT_PAGE_ID}> -s <{spacekey}> -t <{targetdirectory}>
```
To cleanup a preview you can execute : 
```python
python docs_util.py -d -o cleanupPreview -k AEBE -b <{BASE_URL}> -t <{targetdirectory}> -x <{branch_name}> -i <{ROOT_PAGE_ID}> -s AEBE -c ./config.json
```

## Contribution Guidelines

See CONTRIBUTING.md for contribution.

## About

### Maintainers
AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### Contributors

AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### License

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)
