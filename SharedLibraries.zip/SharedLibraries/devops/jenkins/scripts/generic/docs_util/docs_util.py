"""Basic Prototype On The Confluence Utility"""
import os
import getpass
import json
import logging
import argparse
import requests
from bs4 import BeautifulSoup, Doctype


def groovydoc_html_filter(docs_data):
    """
    Filter html data to suit the wiki page
    :param docs_data: unformatted data type
    :return: filterred html data
    """
    html_soup = BeautifulSoup(docs_data, 'html.parser')
    for a_el in html_soup.findAll('a'):
        del a_el['href']
    for div in html_soup.findAll('div', {'class': 'topNav'}):
        div.decompose()
    for div in html_soup.findAll('div', {'class': 'subNav'}):
        div.decompose()
    for div in html_soup.findAll('div', {'class': 'bottomNav'}):
        div.decompose()
    for item in html_soup.contents:
        if isinstance(item, Doctype):
            item.extract()
    return html_soup


def output_report(job_config, file_name, docs_data, data_type):
    """
    In cases of error this function will output to target folder
    :param job_config: configuration for the tools
    :param file_name: the output data file
    :param data_type: docupedia storage representation
    """
    docs_data = data_type_filter(docs_data, data_type)
    extension = data_type_extension(data_type)
    try:
        os.makedirs(job_config['targetdir'])
        logging.debug('Directory %s Created', job_config['targetdir'])
    except FileExistsError:
        logging.debug('Directory %s Already Exist', job_config['targetdir'])
    with open("./%s/%s%s" %
              (job_config['targetdir'], file_name, extension),
              'w', errors="ignore") as f_out:
        f_out.write(docs_data)
    logging.info("Doc can be found under ./%s/%s%s",
                 job_config['targetdir'], file_name, extension)


def get_page(job_config, page_id, auth_module, out_file=False):
    """
    Get the page data given page id and return json data
    :param job_config: configuration for the tools
    :param page_id: unique id of the page
    :param auth_module: authentication module for the job
    :out_file: flag determine if page needed to be
    :return: json dictionary of the query
    """
    get_url = '%s/content/%s?expand=version,body.view'\
              % (job_config['baseurl'], page_id)
    gateway_header = {'KeyId': job_config['key']}
    response = requests.get(get_url, auth=auth_module,
                            verify=False, headers=gateway_header)
    status_code = response.status_code

    if status_code == 200:
        json_response = json.loads(response.text)
        data_type = json_response['body']['view']['representation']
        if out_file:
            html_docs = json_response['body']['view']['value']
            output_report(job_config, page_id, html_docs, data_type)
    elif status_code == 401:
        logging.exception("FAILED -- %s AUTH failed", status_code)
        raise Exception()
    else:
        logging.exception("FAILED -- %s", status_code)
        raise Exception()

    return json_response


def get_page_given_title_space_key(job_config, auth_module,
                                   page_title, space_key):
    """
    Perform search if page already exist given title and spacekey
    :param job_config: configuration for the tools
    :param page_id: unique id of the page
    :param auth_module: authentication module for the job
    :param page_title: title of the page on the wiki
    :param space_key: specified wiki space context being
    :out_file: flag determine if page needed to be
    :return: json dictionary of the query
    """
    gateway_header = {'KeyId': job_config['key']}
    gateway_header['Content-Type'] = 'application/json'
    get_url = '%s/content?title=%s&spaceKey=%s' % (job_config['baseurl'],
                                                   page_title, space_key)
    response = requests.get(get_url, auth=auth_module,
                            verify=False, headers=gateway_header)
    return response


def new_child_pg(job_config, auth_module,
                 docs_data, page_title, space_key, data_type):
    """
    Create a new page given page_id ancestor and a spacekey
    :param auth_module: authentication module for the job
    :param docs_data: unformatted data type
    :param page_title: title of the page on the wiki
    :param space_key: specified wiki space context being
    :param data_type: docupedia storage representation
    :return: json dictionary of the query
    """
    newpage_template = {}
    newpage_template['type'] = 'page'
    newpage_template['title'] = page_title
    newpage_template['space'] = {'key': space_key}
    newpage_template['ancestors'] = [{'id': job_config['pageid']}]
    newpage_template['body'] = {'storage':
                                {'value': docs_data,
                                 'representation': data_type}}
    # create different gateway header
    gateway_header = {'KeyId': job_config['key']}
    gateway_header['Content-Type'] = 'application/json'
    post_url = '%s/content/' % (job_config['baseurl'])
    response = requests.post(post_url, auth=auth_module, verify=False,
                             data=json.dumps(newpage_template),
                             headers=gateway_header)

    if response.status_code == 200 or response.status_code == 201:
        logging.info("SUCCESS -- creating %s", page_title)
    else:
        json_response = json.loads(response.text)
        logging.error(response.status_code, "--",
                      json.dumps(json_response, indent=4))
        output_report(job_config, page_title, docs_data, data_type)
        logging.exception("FAILED -- creating %s", page_title)
        raise Exception()

    json_response = json.loads(response.text)
    return json_response


def update_page(job_config, page_id, auth_module,
                docs_data, response, data_type):
    """
    Update a page given that a page has exist
    :param job_config: configuration for the tools
    :param page_id: unique id of the page
    :param auth_module: authentication module for the job
    :param docs_data: unformatted data type
    :param response: existing page dictionary
    :param data_type: docupedia storage representation
    :return: json dictionary of the query
    """
    response['version']['number'] = response['version']['number'] + 1
    response['body'] = {'storage':
                        {'value': docs_data,
                         'representation': data_type}}
    # update gateway_header for put
    gateway_header = {'KeyId': job_config['key']}
    gateway_header['Content-Type'] = 'application/json'
    put_url = '%s/content/%s' % (job_config['baseurl'], page_id)
    response = requests.put(put_url, auth=auth_module,
                            verify=False, data=json.dumps(response),
                            headers=gateway_header)

    if response.status_code == 200 or response.status_code == 201:
        json_reponse = json.loads(response.text)
        logging.info("SUCCESS -- updating %s", json_reponse['title'])
    else:
        json_reponse = json.loads(response.text)
        logging.error(response.status_code, "--",
                      json.dumps(json_reponse, indent=4))
        output_report(job_config, json_reponse['title'],
                      docs_data, data_type)
        logging.exception("FAILED -- updating %s", json_reponse['title'])
        raise Exception()

    response = json.loads(response.text)
    return response


def create_preview(job_config, auth_module, space_key, postfix):
    """
    Create a preview given root_page id in the job_config
    This method adds a blank page with postfix as the name and 
    populate subpage with the title, separator and the postfix
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :param space_key: specified wiki space context being
    :param postfix: if provided it will add postfix in the end
    """
    response = get_page_given_title_space_key(job_config,
                                              auth_module,
                                              postfix,
                                              space_key)
    # create new blank page underneath the parent page
    response = page_check(job_config, auth_module,
                          space_key, postfix,
                          '', 'storage', response)
    # switch job config page root id to be the new blank page
    job_config['pageid'] = response['id']
    # deploy preview page
    create_update_given_root(job_config, auth_module,
                             space_key, postfix=postfix)


def create_update_given_root(job_config, auth_module, space_key,
                             postfix='', separator='/'):
    """
    Create or update given root_page_id in the job_config
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :param space_key: specified wiki space context being
    :param postfix: if provided postfix will be added to the
                    page title after the separator
    :param separator: separator between page title and postfix
    """
    for root, _, files in os.walk(job_config['targetdir']):
        for file in files:
            data_type = file_type_identifier(file)
            if data_type != '':
                # find the page given a title and space
                page_title = os.path.splitext(file)[0]
                # added postfix if defined
                if postfix != '':
                    page_title += separator + postfix
                response = get_page_given_title_space_key(job_config,
                                                          auth_module,
                                                          page_title,
                                                          space_key)
                # initialization on the variable
                status_code = response.status_code
                docs_data = ''
                # perform response data update
                if status_code == 200:
                    with open(os.path.join(root, file), 'r') as f_out:
                        docs_data = f_out.read()
                    docs_data = data_type_filter(docs_data, data_type)
                page_check(job_config, auth_module, space_key,
                           page_title, docs_data, data_type, response)


def page_check(job_config, auth_module, space_key,
               page_title, docs_data, data_type, response):
    """
    Check if givne page information already exist
    If page exist it will update the page
    If page does not exist it will create a new page
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :param space_key: specified wiki space context being
    :param page_title: title of the page on the wiki
    :param docs_data: unformatted data type
    :param data_type: docupedia storage representation
    :param response: response from get_page_given_title_space_key
    """
    status_code = response.status_code
    response_length = 0
    json_response = {'results': []}

    if status_code == 200:
        json_response = json.loads(response.text)
        response_length = len(json_response['results'])

    if response_length == 1 and status_code == 200:
        # page has exist update the page
        page_id = json_response['results'][0]['id']
        json_response = get_page(job_config, page_id,
                                 auth_module, False)
        json_response = update_page(job_config, page_id,
                                    auth_module, docs_data,
                                    json_response, data_type)
    elif response_length == 0 and status_code == 200:
        json_response = new_child_pg(job_config, auth_module,
                                     docs_data, page_title,
                                     space_key, data_type)
    elif status_code == 401:
        logging.exception("FAILED -- %s AUTH failed", status_code)
        raise Exception()
    elif status_code != 200:
        logging.exception("FAILED -- %s", status_code)
        raise Exception()
    else:
        logging.exception("Page exist -- Title %s in %s",
                          page_title, space_key)
        raise Exception()
    return json_response


def cleanup_preview(job_config, auth_module, space_key):
    """
    Cleanup preview page given branch list extracted from job_config
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :param space_key: specified wiki space context being
    :return: json dictionary of the query
    """
    response = get_page(job_config, job_config['pageid'], auth_module)
    response = get_children_hierarchy(job_config, auth_module)
    branch_list = job_config['jsonconfig']['validbranch']
    for data in response['results']:
        if data['title'] not in branch_list:
            delete_page_given_title(job_config, auth_module,
                                    data['title'], space_key)


def get_children_hierarchy(job_config, auth_module):
    """
    Get the page data given page id and return json data
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :return: json dictionary with lists of page from the parent
    """
    get_url = '%s/content/%s/child/page'\
              % (job_config['baseurl'], job_config['pageid'])
    gateway_header = {'KeyId': job_config['key']}
    response = requests.get(get_url, auth=auth_module,
                            verify=False, headers=gateway_header)
    status_code = response.status_code

    if status_code == 200:
        json_response = json.loads(response.text)
    elif status_code == 401:
        logging.exception("FAILED -- %s AUTH failed", status_code)
        raise Exception()
    else:
        logging.exception("FAILED -- %s", status_code)
        raise Exception()

    return json_response


def delete_page_given_title(job_config, auth_module, page_title, space_key):
    """
    Delete a page given a page title
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :param page_title: title of the page on the wiki
    :param space_key: specified wiki space context being 
    """
    response = get_page_given_title_space_key(job_config, auth_module,
                                              page_title, space_key)
    status_code = response.status_code
    json_response = {'results': []}
    response_length = 0
    if status_code == 200:
        json_response = json.loads(response.text)
        response_length = len(json_response['results'])
    if response_length == 1 and status_code == 200:
        page_id = json_response['results'][0]['id']
        logging.info('REMOVING : %s' % page_title)
        delete_page_given_id(job_config, auth_module, page_id)


def delete_page_given_id(job_config, auth_module, page_id):
    """
    Delete a page given a page_id
    :param job_config: configuration for the tools
    :param auth_module: authentication module for the job
    :param page_id: unique page id to delete
    """
    gateway_header = {'KeyId': job_config['key']}
    gateway_header['Content-Type'] = 'application/json'
    delete_url = '%s/content/%s' % (job_config['baseurl'], page_id)
    response = requests.delete(delete_url, auth=auth_module,
                               verify=False, headers=gateway_header)
    status_code = response.status_code
    if status_code == 204:
        logging.info("SUCCESS -- REMOVED : PAGE id %s", page_id)
    elif status_code == 404:
        logging.info("Preview page no longer exist")


def data_type_filter(docs_data, data_type):
    """
    Provide formatted docs_data suitable for the wiki
    :param docs_data: unformatted data type
    :param data_type: docupedia storage representation
    :return: reformatted docs based on the data_type
    """
    data_value = ''
    if data_type == 'storage':
        data_value = groovydoc_html_filter(docs_data).prettify()
    elif data_type == 'wiki':
        data_value = docs_data
    return data_value


def file_type_identifier(file_name):
    """
    Provide expected representation given a file name
    :param file_name: file name to be uploaded
    :return: the expected storage representation
    """
    data_type = ''
    if file_name.endswith('.html'):
        data_type = 'storage'
    elif file_name.endswith('.md'):
        data_type = 'wiki'
    return data_type


def data_type_extension(data_type):
    """
    Provide expected file extension given a data type
    :param data_type: docupedia storage representation
    :return: the expected file extension
    """
    extension = ''
    if data_type == 'storage':
        extension = '.html'
    elif data_type == 'wiki':
        extension = '.md'
    return extension


def main():
    """Main function"""
    logging.basicConfig(format='%(asctime)s  %(levelname)s: %(message)s',
                        level=logging.INFO)
    # main start here
    desc = 'Docupedia util to upload your docs.'
    parser = argparse.ArgumentParser(description=desc)
    op_list = ['getById', 'updateById', 'createOrUpdateGivenRoot',
               'cleanupPreview', 'createPreview']
    parser.add_argument('--operation', '-o', default=op_list[2],
                        choices=op_list, help='operation to execute')
    parser.add_argument('--pageid', '-i', required=True,
                        help='Page id to operate on')
    parser.add_argument('--baseurl', '-b', required=True,
                        help='Baseurl for the API entry')
    parser.add_argument('--targetdir', '-t', required=True,
                        help='Target directory to operate on')
    parser.add_argument('--demo', '-d', action='store_true',
                        help='If specified will prompt for auth details')
    parser.add_argument('--spacekey', '-s', help='spacekey defined as\
                        ${baseurl}/confluence/display/`${spacekey}`\
                        /`${pagetitle}`')
    parser.add_argument('--targetfile', '-f', help='Target file to upload\
                            , this option is required for updateById')
    parser.add_argument('--user', '-u', help='Username on Docupedia')
    parser.add_argument('--pasw', '-p', help='Password on Docupedia')
    parser.add_argument('--key', '-k', help='Token for the Docupedia')
    parser.add_argument('--postfix', '-x', help='postfix for the preview')
    parser.add_argument('--config', '-c', help='Json configuration location')
    args_in = parser.parse_args()
    # check for username and password if typed on cli or
    job_config = {}

    if args_in.demo:
        user_name = getpass.getpass('Username:')
        pass_word = getpass.getpass('Password:')
        job_config['key'] = getpass.getpass('Key:')
    else:
        user_name = args_in.user
        pass_word = args_in.pasw
        if args_in.key:
            job_config['key'] = args_in.key
        else:
            parser.error('--key / -k needed to be provided as args')

    if args_in.config:
        try:
            config_data = open(args_in.config, 'r')
        except FileNotFoundError:
            raise Exception('Unable to open config file %s' % args_in.config)
        job_config['jsonconfig'] = json.load(config_data)
        config_data.close()

    # load required args
    job_config['pageid'] = args_in.pageid
    job_config['baseurl'] = args_in.baseurl
    job_config['targetdir'] = args_in.targetdir
    # header update given the gateway
    auth_module = requests.auth.HTTPBasicAuth(user_name, pass_word)

    if args_in.operation == 'getById':
        get_page(job_config, job_config['pageid'], auth_module, True)
    elif args_in.operation == 'updateById':
        if args_in.targetfile:
            job_config['matchflag'] = False
            json_response = get_page(job_config, job_config['pageid'],
                                     auth_module, False)
            for root, _, files in os.walk(job_config['targetdir']):
                for file in files:
                    if file == args_in.targetfile:
                        job_config['matchflag'] = True
                        data_type = file_type_identifier(file)
                        with open(os.path.join(root, file), 'r') as f_out:
                            docs_data = f_out.read()
                        formatted_data = data_type_filter(docs_data, data_type)
                        json_response = update_page(job_config,
                                                    job_config['pageid'],
                                                    auth_module,
                                                    formatted_data,
                                                    json_response, data_type)
            if not job_config['matchflag']:
                logging.warning('%s did not exist inside target folder',
                                args_in.targetfile)
        else:
            parser.error('--targetfile / -t argument required')
    elif args_in.operation == 'createOrUpdateGivenRoot':
        # Go through the input dir and retrieve metrics
        if args_in.spacekey:
            create_update_given_root(job_config, auth_module,
                                     args_in.spacekey)
        else:
            parser.error('--spacekey / -s argument required')
    elif args_in.operation == 'createPreview':
        if args_in.spacekey and args_in.postfix:
            create_preview(job_config, auth_module,
                           args_in.spacekey, args_in.postfix)
        else:
            parser.error('--spacekey / -s and --postfix / -x required')
    elif args_in.operation == 'cleanupPreview':
        if args_in.spacekey:
            cleanup_preview(job_config, auth_module,
                            args_in.spacekey)
        else:
            parser.error('--spacekey / -s argument required')


if __name__ == "__main__":
    main()
