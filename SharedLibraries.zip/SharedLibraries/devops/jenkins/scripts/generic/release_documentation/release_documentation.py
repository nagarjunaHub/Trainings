import docx
import logging
import argparse
import json
import sys


"""
This script is substituting the given information by the configuration with
the values fetched from various sources in a given template.

The main input for this script is a configuration given in json format and
a template given in docx format.

For information of the configuration format look at the ConfigParser.

Note, that in this version of the script the substitution of text is supported.

"""


class InvalidConfigException(Exception):
    pass


class ConfigSourceArguments:

    DESCRIPTION = 'arguments'

    def __init__(self, args):
        self.__args = args

    def get_elements(self):
        return self.__args


class ConfigSourceBauhaus:

    DESCRIPTION = 'bauhaus'

    def __init__(self, args):
        self.__args = args

    def get_elements(self):
        return self.__args


def text_substitution(eye_catcher, substitution_text, paragraph, new_val):
    """
        The function is basically an implementation and prototype for
        an abstraction of the substitution functions.

        All following substitution functions shall take the same parameters.

        Subsitute on the given paragraph or run the eye catcher with the
        substitution text and the new value.
    """
    paragraph.text = substitution_text.replace(
        eye_catcher, new_val if new_val else ''
    )


class ConfigParser:
    """
The configuration is seperated in a "sources" section and "substitution"
section. Sources contains information where the substitution step can fetch
the information. The substitution section contains information what is searched
in the template and how it is substituted and which source is taken.

If not specified differently, the configuration is validated on creation
of the ConfigParser wrt to the connection of wanted source and provided
sources.

The ConfigParser is used to parse a json file with the format:

Example configuration:

{
    "sources": {
        "arguments": {
            "snapshotname": {
                "name": "snapshotname",
                "short_name": "s",
                "help": "The snapshotname for the release"
            },
            "baselineset" : {
                "name": "baselineset",
                "short_name": "b",
                "help": "The Specification Baseline Set for the release"
            }
        },
        "bauhaus": {
            "misra": {
                "url": "URL",
                "API_KEY": "KEY"
            }
        }
    },
    "substitutions": {
        "snapshotname": {
            "eye_catcher": "<<snapshotname>>",
            "substitution_text": "<<snapshotname>>",
            "source": "arguments/snapshotname",
            "type": "text"
        },
        "baselineset": {
            "eye_catcher": "<<baselineset>>",
            "substitution_text": "<<baselineset>>",
            "source": "arguments/snapshotname",
            "type": "text"
        }
    }
}

    """
    def __init__(self, file_name, logger=None, validate=True):
        self.__logger = logger if logger else logging.getLogger()
        self.__logger.debug('Open config file: %s' % file_name)
        with open(file_name, 'r') as read_file:
            self.__data = json.load(read_file)
        self._source_handler_classes = {
            ConfigSourceArguments.DESCRIPTION: ConfigSourceArguments,
            ConfigSourceBauhaus.DESCRIPTION: ConfigSourceBauhaus
        }
        self._source_handler = []
        for sourcename, content in self.__data['sources'].items():
            cs = self._source_handler_classes[sourcename](content)
            self.__logger.debug('Add source: %s' % sourcename)
            self._source_handler.append(cs)
        if validate:
            self.validate()

    @property
    def available_sources(self):
        return (s for s in self._source_handler_classes)

    @property
    def wanted_substitutions(self):
        return self.__data['substitutions'].keys()

    def validate(self):
        for substitution in self.__data['substitutions'].values():
            if len(substitution['source'].split('/')) < 2:
                raise InvalidConfigException(
                    'Not valid: %s ' % substitution['source'])
            source_type = substitution['source'].split('/')[0]
            source_detail = substitution['source'].split('/')[1]
            if source_type not in self.available_sources:
                raise InvalidConfigException(
                    'Missing config source: %s' % source_type)
            if source_detail not in self.source(source_type).get_elements():
                raise InvalidConfigException(
                    'Missing specific source detail %s' % source_detail)

    def source(self, sname):
        for s in self._source_handler:
            if s.DESCRIPTION == sname:
                return s

    def substition_data(self, sub_name):
        return self.__data['substitutions'][sub_name]

    def extend_argumentparser(self, argparser):
        for name, detail in self.source('arguments').get_elements().items():
            self.__logger.debug('Adding argument to parser: %s' % name)
            argparser.add_argument('--%s' % detail['name'],
                                   '-%s' % detail['short_name'],
                                   help=detail['help'])


class ArgumentGatherer:
    def __init__(self, cmd_parser, arg_config):
        self.__cmd_parser = cmd_parser
        self.__arg_config = arg_config

    def get_value(self):
        return self.__cmd_parser.__dict__[self.__arg_config['name']]


class ReleaseDocumentation:

    def __init__(self, file_name, config_parser,
                 cmd_parser_args=None, logger=None):

        self.__config = config_parser
        self.__document = docx.Document(file_name)
        if not logger:
            logging.basicConfig(level=logging.DEBUG)
        self.__logger = logger if logger else logging.getLogger()
        self.__sub_handler = {
            'text': text_substitution,
        }
        self.__source_gatherer = {}
        temp = self.__config.source('arguments').get_elements().items()
        for arg_name, arg_val in temp:
            self.__source_gatherer['arguments/' + arg_name] = ArgumentGatherer(
                cmd_parser_args, arg_val)

    def find_template_paragraph(self, paragraph_name):
        runs = list()
        for paragraph in self.__document.paragraphs:
            for run in paragraph.runs:
                self.__logger.debug('Go through para: "%s" ' % run.text)
                if run.text == paragraph_name:
                    runs.append(run)
        return runs

    def substitute_templates(self):
        for sub_name in self.__config.wanted_substitutions:
            data = self.__config.substition_data(sub_name)
            for paragraph in self.find_template_paragraph(data['eye_catcher']):
                self.__logger.debug('Before substitution: %s' % paragraph.text)
                self.__sub_handler[data['type']](
                    data['eye_catcher'], data['substitution_text'],
                    paragraph,
                    self.__source_gatherer[data['source']].get_value())
                self.__logger.debug('After substitution: %s' % paragraph.text)

    def save(self, file_name):
        self.__document.save(file_name)


if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING)
    parser = argparse.ArgumentParser()
    help_text = 'The config file used for gathering substitition information'
    parser.add_argument(
        'config', help=help_text)
    if len(sys.argv) < 2:
        parser.print_help()
        parser.exit(-1, '')
    args = parser.parse_args(sys.argv[1:2])
    config = ConfigParser(args.config, validate=False)
    parser.add_argument(
        'file', help='The template file used for substitution')
    parser.add_argument(
        '--output', '-o', help='The output file for the pre-filled template')
    config.extend_argumentparser(parser)
    args = parser.parse_args()

    config = ConfigParser(args.config)
    temp_rel = ReleaseDocumentation(
        args.file, config, args)
    temp_rel.substitute_templates()
    if not args.output:
        args.output = args.file.split('.docx')[0] + '_pre-filled.docx'
    temp_rel.save(args.output)
