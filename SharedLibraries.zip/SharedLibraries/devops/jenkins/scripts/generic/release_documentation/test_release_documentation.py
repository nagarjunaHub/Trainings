#! /usr/bin/python

import unittest
import json
import os
import argparse
import logging

from release_documentation import ReleaseDocumentation, ConfigParser
from release_documentation import InvalidConfigException


class TestConfigParserBase(unittest.TestCase):

    _TEST_FILE_NAME = 'test_template_config.json'
    _TEST_FILE_CONTENT = """
{
    "sources": {
        "arguments": {
            "snapshotname": {
                "name": "snapshotname",
                "short_name": "s",
                "help": "The snapshotname for the release"
            },
            "baselineset" : {
                "name": "baselineset",
                "short_name": "b",
                "help": "The Specification Baseline Set for the release"
            }
        },
        "bauhaus": {
            "misra": {
                "url": "URL",
                "API_KEY": "KEY"
            }
        }
    },
    "substitutions": {
        "snapshotname": {
            "eye_catcher": "<<snapshotname>>",
            "substitution_text": "<<snapshotname>>",
            "source": "arguments/snapshotname",
            "type": "text"
        },
        "baselineset": {
            "eye_catcher": "<<baselineset>>",
            "substitution_text": "<<baselineset>>",
            "source": "arguments/snapshotname",
            "type": "text"
        }
    }
}"""

    def setUp(self):
        super().setUp()
        logging.basicConfig(level=logging.INFO)
        with open(self._TEST_FILE_NAME, 'w') as write_file:
            write_file.write(self._TEST_FILE_CONTENT)

    def tearDown(self):
        os.remove(self._TEST_FILE_NAME)
        super().tearDown()


class TestConfigParser(TestConfigParserBase):

    def test_available_sources(self):
        config = ConfigParser(self._TEST_FILE_NAME)
        self.assertIn('arguments', config.available_sources)

    def test_arguments(self):
        config = ConfigParser(self._TEST_FILE_NAME)
        self.assertIsNotNone(config.source('arguments'))
        self.assertIn('snapshotname', config.source(
            'arguments').get_elements())

    def test_substitions(self):
        config = ConfigParser(self._TEST_FILE_NAME)
        self.assertIn('snapshotname', config.wanted_substitutions)
        self.assertIn('baselineset', config.wanted_substitutions)

    def test_argparse_extender(self):
        logger = logging.getLogger('TestConfigParser')
        logger.setLevel(logging.DEBUG)
        config = ConfigParser(self._TEST_FILE_NAME, logger)
        parser = argparse.ArgumentParser()
        args = parser.parse_args()
        self.assertNotIn('snapshotname', args.__dict__)
        self.assertNotIn('baselineset', args.__dict__)
        config.extend_argumentparser(parser)
        args = parser.parse_args()
        self.assertIn('snapshotname', args.__dict__)
        self.assertIn('baselineset', args.__dict__)


class TestMissingArgumentConfigParser(TestConfigParserBase):

    _TEST_FILE_CONTENT = """
{
    "sources": {
        "arguments": {
            "snapshotname": {
                "name": "snapshotname",
                "short_name": "s",
                "help": "The snapshotname for the release"
            }
        }
    },
    "substitutions": {
        "snapshotname": {
            "eye_catcher": "<<snapshotname>>",
            "substitution_text": "<<snapshotname>>",
            "source": "arguments/missing_argument",
            "type": "text"
        }
    }
}"""

    def test_missing_argument(self):
        self.assertRaises(InvalidConfigException,
                          ConfigParser, self._TEST_FILE_NAME)


class TestReleaseDocumentation(TestConfigParserBase):

    def test_read_template(self):
        config = ConfigParser(self._TEST_FILE_NAME)
        temp_rel = ReleaseDocumentation(
            'SW_Release_Note_template.docx', config)

    def test_find_section_by_name(self):
        config = ConfigParser(self._TEST_FILE_NAME)
        temp_rel = ReleaseDocumentation(
            'SW_Release_Note_template.docx', config)
        self.assertListEqual(
            [], temp_rel.find_template_paragraph('NoParameter'))
        self.assertIsNotNone(
            temp_rel.find_template_paragraph('<<snapshotname>>'))
        self.assertEqual(
            2, len(temp_rel.find_template_paragraph('<<snapshotname>>')))

    def test_substitute(self):
        parser = argparse.ArgumentParser()
        parser.add_argument(
            '--snapshotname',
            dest='snapshotname',
            default='test_snapshot_name')
        args = parser.parse_args()
        config = ConfigParser(self._TEST_FILE_NAME)
        temp_rel = ReleaseDocumentation(
            'SW_Release_Note_template.docx', config, args)
        self.assertEqual(
            2, len(temp_rel.find_template_paragraph('<<snapshotname>>')))
        self.assertEqual(
            1, len(temp_rel.find_template_paragraph('<<baselineset>>')))
        self.assertListEqual(
            [], temp_rel.find_template_paragraph('test_snapshot_name'))
        temp_rel.substitute_templates()
        self.assertListEqual(
            [], temp_rel.find_template_paragraph('<<snapshotname>>'))
        self.assertEqual(
            3, len(temp_rel.find_template_paragraph('test_snapshot_name')))


if __name__ == '__main__':
    unittest.main()
