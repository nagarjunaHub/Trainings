# AE-BE DevOps BlackDuck copy script

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

Script to identify the files that has to be scanned by Blackduck and copies them in a target directory	

## Table of Contents

- [Getting Started](#getting-started)
- [Building and Testing](#building-and-testing)
- [Contribution Guidelines](#contribution-guidelines)
- [Feedback](#feedback)
- [About](#about)
  - [Maintainers](#maintainers)
  - [Contributors](#contributors)
  - [3rd Party Licenses](#3rd-party-licenses)
  - [Used Encryption](#used-encryption)
  - [License](#license)

## Getting Started

The project.clf file is used to identify the files. This file is in the root directory of an project and defines the project including the files that has to be ignored. here an example of the project.clf from teh CAL project:

package CAL_Project

{
	    class   = PVER
    	domain  = VC-CAL
    	
    	package-includes = CAL_GlobalRules, CAL_Linker
    
    	ignore-rule 
    {
        // ********** CONFIGURATION ********** 
        path = **/rte_generate.bamf
		path = Configuration\Flash\**\*.*
		path = Configuration\Tools\**\*.*
        
        // ********** APPLICATION PART ********** 
		path = MM\MasterCore\APP\AILC_VO\tst\**\*.*
        path = MM\MasterCore\APP\AILC_VO\mdl\**\*.*
        
        

The following wildcards can be used in the project.clf file:

xxx/**			everything under xxx will be ignored

xxx/*			every file under xxx will be ignored, folders under xxx will be scanned and files in the folders will be processed

xxx/file*.c		file[any character(s)].c will be excluded


Usage of the script:

black_duck_copy_code.py TARGET_DIR SOURCE_DIR IGNORE_FILE


TARGET_DIR:		The directory the code is copied to and scanned by Black Duck

SOURCE_DIR: 	The project directory

IGNORE_FILE:	The project.clf file with path


A file ignore.log with every ignored file is created

## Building and Testing



## Contribution Guidelines

See CONTRIBUTING.md for contribution.

## About

### Maintainers
AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### Contributors

AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### License

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)
