import os
import sys
import shutil
import fnmatch
import logging
import argparse

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
# create a file handler
handler = logging.FileHandler('ignore.log')
handler.setLevel(logging.INFO)

# create a logging format
formatter = logging.Formatter('%(asctime)s  %(levelname)s: %(message)s')
handler.setFormatter(formatter)

# add the handlers to the logger
logger.addHandler(handler)

arg_parser = argparse.ArgumentParser(description='List the content of a folder')

arg_parser.add_argument('SOURCE_DIR', metavar='SOURCE_DIR', type=str, help='Project Directory')
arg_parser.add_argument('TARGET_DIR', metavar='TARGET_DIR', type=str, help='Directory to copy the code')
arg_parser.add_argument('IGNORE_FILE', metavar='IGNORE_FILE', type=str, help='Project ignore file')

args = arg_parser.parse_args()


def readIgnoreFile(IGNORE_FILE):
    paths = []
    with open(IGNORE_FILE, 'r') as ignore:
        paths = [line.split('= ')[1].strip().replace('/', '\\') for line in ignore.readlines() if 'path' in line]
    return paths


def ignorePath(paths):
    def ignoref(directory, contents):
        ignored_names = []
        for f in contents:
            for p in paths:
                # Test if the directory + filename matches an exclude string
                if fnmatch.fnmatch(os.path.relpath(os.path.join(directory, f)), p):
                    # dir\* or dir\*.* only exludes the files in the directory. Subdirectories are included
                    if p.endswith("\*") or p.endswith("\*.*"):
                        if not fnmatch.fnmatch(os.path.relpath(os.path.join(directory, f)), p + "\*"):
                            if os.path.isfile(os.path.relpath(os.path.join(directory, f))):
                                ignored_names.append(f)
                                logger.info("ignore path: {} | ignore file: {} | ignore reason: {}".format(directory, f, p))
                else:
                    logger.info("ignore path: {} | ignore file: {} | ignore reason: {}".format(directory, f, p))
                    ignored_names.append(f)
        return set(ignored_names)
    return ignoref


if os.path.exists(args.TARGET_DIR):
    shutil.rmtree(args.TARGET_DIR)

paths = readIgnoreFile(args.IGNORE_FILE)
shutil.copytree(args.SOURCE_DIR, args.TARGET_DIR, ignore=ignorePath(paths))

