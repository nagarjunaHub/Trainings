# AE-BE DevOps
## License header check
[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

This project shall be used to share all scripts that are provided by the AE-BE DevOps Team and needed in the AE-BE DevOps area.

## Table of Contents

- [Getting Started](#getting-started)
  - [Structure](#Structure)
- [Building and Testing](#building-and-testing)
- [About](#about)
  - [Maintainers](#maintainers)
  - [Contributors](#contributors)
  - [License](#license)

## Getting Started

The purpose of the license header check is, that we want to share our code with other Businesss Units under BIOSL. 
Therefore all files need a specific header containing copyright information.

templateBioslHeader.py will check the file for header and especially for copyright information.
Therefore we can divide the file in 3 parts:
1. Header identification and separation
    - The input file has to be read and according to the config.json the header has to be identified.
2. Checking provided information
    - The separated header will be checked against the provided data in header_config.json (mandatory)
3. Generate new header if necessary
    - In case there is no header or it can not be identified, the script will provide a sample header, generated from the data in the header_config.json and the format of the struct file. This header has to be added and **adapted**.


### Structure

The check-license-header folder contains two files and a subfolder headerConfig.
```bash
    check-license-header
    |   |__headerConfig
    |       |__header_config.json
    |       |__struct.txt
    |       |__testfileForUnittest.txt
    |__templateBioslHeader.py
    |__unittest-biosl-header.py
```

In **headerConfig** there is a struct file (struct.txt) for the header, a config file (header_config.json), which can be customized and a testfile (testfileForUnittest.txt) for the unittest.
The header_config.json includes the values of the header and divides it into a mandatory and optional part. According to that information a new header will be ganerated.</br>
The **testfileForUnitttest.tx** is a test file for the unittest, which is located one layer above in unittest-biosl-header.py. </br>
And the **struct.txt** is important for the header separation and generation. 

## Building and Testing

If you want to run it separat open your Powershell and run: </br> 
```python .\templateBioslHeader.py``` </br>
and for the unitttest: </br> 
```python .\unittest-biosl-header.py```

Otherwise the script will be executed automatically by using gradlew.bat </br>
```.\gradlew.bat headerReport```</br>
The script triggers a download from artifactory. Therefore you need to type in your credentials (only the first time). </br> After that, your file will be checked and a logfile.log output created. This shows the logging statements from the header check and shows where adjustments are needed.

As already mentioned in the [Structure](#Structure), there is a unittest for the templateBioslHeader.py. </br>
The unittest contains: </br>
*_test_header* : Checks if there is a header in the file </br>
*_test_copyright_header* : Checks if the header is equal to a defined samlpe header </br>
*_testing_header* : Checks the found header against several examples, where exactly one should match.

## Contribution Guidelines

See CONTRIBUTING.md for contribution.

## About

### Maintainers

AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### Contributors

AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### License

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

