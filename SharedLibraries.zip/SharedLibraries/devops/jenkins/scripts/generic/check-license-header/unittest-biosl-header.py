import unittest
from string import Template
import templateBioslHeader
import argparse


class Testing(unittest.TestCase):

    """check for header existance"""
    def test_header_(self):
        t = templateBioslHeader.LicenseChecker(args)
        t.find_header()
        self.assertTrue(t.check_if_header_exists(),
                        'Header information provided')

    """check the provided header information"""
    def test_copyright_header(self):
        t = templateBioslHeader.LicenseChecker(args)

        t.find_header()
        a = """Copyright (c) 2019, 2019 Robert Bosch GmbH and its\
            subsidiaries. This program and the accompanying\
            materials are made available under the terms of the\
            Bosch Internal Open Source License v4 which accompanies\
            this distribution, and is available at"""
        b = t.clean_header()
        self.assertMultiLineEqual(' '.join(a.split()), b,
                                  'Header information not correct')

    """check provided header against different example header"""
    def testing_header(self):
        t = templateBioslHeader.LicenseChecker(args)
        test_header = ["swcomponent Example_Component file example.h \
brief This is a brief description of the file. \
copyright (C) 2016 Robert Bosch GmbH. The reproduction, \
distribution and utilization of this file as well as \
the communication of its contents to others without \
express authorization is prohibited. Offenders will \
be held liable for the payment of damages. All rights \
reserved in the event of the grant of a patent, \
utility model or design.", "Copyright (c) 2009, \
2019 Robert Bosch GmbH and its subsidiaries. \
This program and the accompanying \
materials are made available under the terms of the \
Bosch Internal Open Source License v4 which accompanies \
this distribution, and is available at", "Copyright \
(c) 2019, 2019 Robert Bosch GmbH and its \
subsidiaries. This program and the accompanying \
materials are made available under the terms of the \
Bosch Internal Open Source License v4 which accompanies \
this distribution, and is available at", "FILE: \
example.cpp SW-COMPONENT: Example component \
DESCRIPTION: Serves as an example for copyright \
comments COPYRIGHT: (c) 2019 Robert Bosch GmbH The \
reproduction, distribution and utilization of this \
file as well as the communication of its contents \
to others without express authorization is prohibited. \
Offenders will be held liable for the payment of \
damages. All rights reserved in the event of the \
grant of a patent, utility model or design.", "\
swcomponent Example_Component file example.h brief \
This is a brief description of the file. copyright \
(C) 2016 Robert Bosch GmbH. The reproduction, \
distribution and utilization of this file as well \
as the communication of its contents to others \
without express authorization is prohibited. \
Offenders will be held liable for the payment of \
damages. All rights reserved in the event of the \
grant of a patent, utility model or design."]
        header = t.clean_header()
        clean_test_header = [x.strip(' ') for x in test_header]
        header_count = clean_test_header.count(header)
        if header_count == 1:
            self.assertTrue('Header found')
        else:
            self.assertFalse("No header matches")


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--configFilename', dest='configFilename',
                        default='headerConfig/header_config.json')
    parser.add_argument('--structFilename', dest='structFilename',
                        default='headerConfig/struct.txt')
    parser.add_argument('--testFilename', dest='testFilename',
                        default='headerConfig/testfileForUnittest.txt')
    parser.add_argument('--file_handler_path', dest='file_handler_path',
                        default='logfile.log')
    args = parser.parse_args()

    unittest.main()
