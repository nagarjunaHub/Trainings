from string import Template
from datetime import date
import json
import logging
import random
import argparse
import sys

# get current year for copyright year comparison
CURRENTYEAR = date.today().year


class LicenseChecker:

    def __init__(self, args, logger=None):
        self._configFilename = args.configFilename
        self._structFilename = args.structFilename
        self._testFilename = args.testFilename
        self._file_handler_path = args.file_handler_path
        if not logger:
            self._logger = logging.getLogger(__name__)
            self._logger.setLevel(logging.WARNING)

            # create file handler + set formatter
            file_handler = logging.FileHandler(self._file_handler_path,
                                               mode='w')
            formatter = logging.Formatter(
                '%(asctime)s : %(levelname)s : %(name)s : %(message)s')
            file_handler.setFormatter(formatter)
            self._logger.addHandler(file_handler)
        else:
            self._logger = logger

        with open(self._configFilename, 'r') as data:
            self._value = json.load(data)
            self._logger.info("Config data loaded successfully")

        # get mandatory values form config.json
        self._copyright = self._value['mandatory']['copyright']

        # read format text.txt
        with open(self._structFilename, 'r') as filein:
            self._src = filein.read()

        # read the file you want to check the header information
        with open(self._testFilename, 'r') as readfile:
            self._teststring = readfile.read()

    """find header and clean ignored items up"""
    def find_header(self):
        full_header = self._value['header']
        start = self._teststring.find(full_header['start'])
        end = self._teststring.find(full_header['end'])
        self._header = self._teststring[start: end]
        self._logger.info("Header found and separated from code")
        return self._header

    """Warning when more than oneheader provided"""
    def check_if_header_exists(self):
        self._count_header = self._teststring.count(self._header)
        if self._count_header == 1:
            self._logger.info("Header information provided")
        else:
            self._logger.error(
                "More than one header or none found. Please check your file")
        return self._count_header

    def clean_header(self):
        _header = self.find_header()
        # get ignored values from config.json
        ignored = self._value['header']['ignored']
        # iterate through ignored items
        for i in range(len(ignored)):
            self._header = self._header.replace(ignored[i], ' ')
        self._cleanheader = ' '.join(self._header.split())
        self._logger.info("Header cleaned up")
        return self._cleanheader

    """separate the copyright information from heder"""
    def copyright_separat(self):
        _cleanheader = self.clean_header()
        start = self._cleanheader.find(self._copyright['keyword'])
        end = self._cleanheader.find(self._copyright['link'])
        self._copyright_header = self._cleanheader[start: end]
        self._logger.info("Separated copyright information from header")
        return self._copyright_header

    """split copyright information from header"""
    def plain_copyright(self):
        _copyright_header = self.copyright_separat()
        self._copyrightStr = _copyright_header.split(' ')
        return self._copyrightStr

    """generate example header"""
    def generate_header(self):
        def check(val): return val[random.randrange(
            len(val))] if isinstance(val, list) else val
        source = Template(self._src)
        dict = {
            'copyright': check(self._copyright['keyword']),
            'symbol': check(self._copyright['symbol']),
            'year_begin': CURRENTYEAR, 'year': CURRENTYEAR,
            'bosch': check(self._copyright['bosch']),
            'copyright_text': check(self._copyright['copyright_text']),
            'link': check(self._copyright['link'])
        }
        self._generated_header = source.substitute(dict)
        return self._generated_header

    """check if any header inforamtion is provided"""
    def test_header_availability(self):
        _copyright_header = self.copyright_separat()
        _generated_header = self.generate_header()
        if not _copyright_header:
            self._logger.error("Please add a header \nExample:\n" +
                               self._generated_header + '\nin :' +
                               self._testFilename)
            raise RuntimeError('Header inforamtion is missing or false in: '
                               + self._testFilename +
                               ' Please consolidate: ' +
                               self._file_handler_path)
        else:
            self._logger.info("Header information available")
            return False

    def _get_logger(self):
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        # create file handler + set formatter
        file_handler = logging.FileHandler('logfile.log')
        formatter = logging.Formatter(
            '%(asctime)s : %(levelname)s : %(name)s : %(message)s')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        return logger

    def main(self):
        self._copyrightStr = self.plain_copyright()
        try:
            self._logger.info(
                "############### testing_start ##################")
            if self.test_header_availability() is False:
                # check copyright year, company and legal text and symbol
                for i in range(len(self._copyright['bosch'])):
                    if self._copyright['bosch'][i] in self._copyright_header:
                        break
                    else:
                        self._logger.error(
                            "Copyright company missing or false in: " +
                            self._testFilename)
                        raise RuntimeError('Copyright company' +
                                           ' missing or false in: ' +
                                           self._testFilename)
                if (self._copyright['copyright_text'] in self._cleanheader and
                        self._copyrightStr[1] in self._copyright['symbol']):
                    self._logger.info(
                        "The copyright text and the symbol are correct")
                    if (CURRENTYEAR >= int(self._copyrightStr[3]) and
                            int(self._copyrightStr[2].replace(',', ''))
                            <= int(self._copyrightStr[3])):
                        self._logger.info("Header data checked and correct")
                        self._logger.info(
                            "############### testing_end ####################")
                    else:
                        self._logger.error(
                            "Copyright year missing or false in: " +
                            self._testFilename
                        )
                        raise RuntimeError('Copyright year' +
                                           ' missing or false in: ' +
                                           self._testFilename)
                else:
                    self._logger.error(
                        "Copyright text/symbol missing or false in: " 
                        + self._testFilename
                    )
                    raise RuntimeError('Copyright text/symbol' +
                                       ' is missing or false in: ' +
                                       self._testFilename)
            else:
                self._logger.info(
                    "############### testing_end ####################")
        except Exception as e:
            sys.stderr.write('ERROR: %s' % str(e))
            return 1


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('--configFilename', dest='configFilename',
                        default='headerConfig/header_config.json')
    parser.add_argument('--structFilename', dest='structFilename',
                        default='headerConfig/struct.txt')
    parser.add_argument('--testFilename', dest='testFilename',
                        default='headerConfig/testfileForUnittest.txt')
    parser.add_argument('--file_handler_path', dest='file_handler_path',
                        default='logfile.log')
    args = parser.parse_args()

    sys.exit(LicenseChecker(args).main())
