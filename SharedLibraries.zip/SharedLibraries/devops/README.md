# AE-BE DevOps

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

This project shall be used to share all scripts that are provided by the AE-BE DevOps Team and needed in the AE-BE DevOps area.

## Table of Contents

- [Getting Started](#getting-started)
- [Building and Testing](#building-and-testing)
- [BMI Metric](#bmi-metric)
- [Contribution Guidelines](#contribution-guidelines)
- [Feedback](#feedback)
- [About](#about)
  - [Maintainers](#maintainers)
  - [Contributors](#contributors)
  - [3rd Party Licenses](#3rd-party-licenses)
  - [Used Encryption](#used-encryption)
  - [License](#license)


## Building and Testing

Build / Test is described for each script on its own.

## BMI Metric
The following flow chart shows how the BMI metric is collected and used: </br>
Grey= part of jenkins_libraries

```plantuml
@startuml
    skinparam backgroundColor #snow
    skinparam handwritten false
        
    agent Jenkins_Pipeline #lightgrey
    rectangle Stage0{
        agent calc_script #lightgrey[
        calculation trigger script
        ---
        trigger BMI calculation
        ]
    }
        rectangle Stage1{
            agent analyze_script #lightgrey[
                analyze script
                ---
                BMI in range = build Successfull
                BMI out of range = build failure
                result Success/Failure       
            ]
            agent Script2 #lightgrey[
                deliver result script
                ---
                Success/Failure
                link with information
            ]
        }
    agent Bauhaus_Job #light[
        Bauhaus Job
    ]
    agent Event #light[
        Event:
        ---
        commit+ push
        time
    ]
    database Artifactory #light[
        Artifactory 
        ---
        Release Information MeGenJa 
        metric data sorted(csv) 
    ]
    database Bauhaus #light[
        Bauhaus
        ---
        metric database (unsorted)
    ]
    rectangle <<CDQ>>{
        agent MeGenJa #light[
            MeGenJa
            ---
            calc BMI
        ]
        agent CDQ0302Dashboard #lightgrey[
            CDQ0302Dashboard
            ---
            calc metrics
            collect metrics
            generate dashboard
        ]
    }
    interface file1 #Salmon [ 
        branch
        stream
        local copy 
        ]
   
    Event --> file1
    file1 --> Jenkins_Pipeline :0.triggers
    calc_script --> Bauhaus_Job : 2.exec Bauhaus Job
    Bauhaus_Job --> Bauhaus :3.build delivers input
    calc_script --> MeGenJa : 4.exec
    MeGenJa --> Bauhaus : 5. pull metrics
    MeGenJa --> CDQ0302Dashboard : 6.delivers BMI metrics + generate CDQ
    CDQ0302Dashboard --> Artifactory : 7.delivers metrics 
    analyze_script ---> Artifactory : 9.pull BMI
    Jenkins_Pipeline -down-> analyze_script :8.triggers
    Jenkins_Pipeline --> calc_script : 1.triggers
    Script2 <-up- Jenkins_Pipeline : 10.triggers

@enduml
```

More detailed Sequence diagram

```plantuml
@startuml component
skinparam sequence{
    ParticipantBackgroundColor WhiteSmoke
}
autonumber
activate Jenkins
Jenkins -> calc_script ++ #crimson : start
calc_script -> Bauhaus_Job -- #crimson : trigggers
activate Bauhaus_Job #crimson
Bauhaus_Job -> calc_script -- #crimson : done
activate calc_script #crimson
calc_script -> MeGenJa -- #crimson: triggers
activate MeGenJa #crimson
MeGenJa -> Jenkins -- #crimson: done
Jenkins -> analyze_script ++ #crimson : start
analyze_script -> Artifactory : pull
Artifactory -> analyze_script -- #crimson: done
analyze_script -> Jenkins -- #crimson : Success/Failure
Jenkins -> deliver_result_script ++ #crimson : start
deliver_result_script -> Jenkins -- #crimson : build Success/Failure
@enduml
```

## Contribution Guidelines

See CONTRIBUTING.md for contribution.

## About

### Maintainers
Florian Merkert (florian.merkert@de.bosch.com)

### Contributors

AE-BE DevOps Team (AE-BEDevOps@bosch.com)

### License

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

