
@Library('AE-BE_DevOps_SharedLibraries') _
import bosch.aebedo.GitHelpers
import bosch.aebedo.CustomStage

void overrideBuild(env) {
	aeeePro = pipelineConfig.validation.swBuild.aeeePro
	buildVariant = pipelineConfig.validation.swBuild.buildVariant
	if(pipelineConfig.validation.swBuild.buildScript) {
		//bat "${pipelineConfig.validation.swBuild.buildScript}
		echo "executing swBuild batch file"
	} else {
		//bat "call texec aeee_pro/${aeeePro} -cdgb rebuild -m ${buildVariant} -p . > ${buildVariant}_build.log"
		echo "executing cdgb with ${aeeePro} and ${buildVariant}"
	}
}


void overrideSetupSCA(env) {
	echo "executing SetupSCA"
}

void overrideExecuteSCA(env) {
	echo "executing executeSCA"
}

void overrideQsurgeSCA(env) {
	echo "executing teardownSCA"
}

node(env.buildNode ?: 'nbd5kor_slave-machine') {
    timestamps {
        cleanWs()
		try {
			Project_root = "${env.WORKSPACE}"	
			git = new GitHelpers(this)
			git.checkoutUsingGittool(env.gitCredentials, env.gitUrl, env.gitBranch, env.gitBranch, false, false, false)			
			pipelineConfig = readYaml file: env.pipelineConfigLocation
			CustomStage skippedStage = new CustomStage(skip: true)
			exec_module_on_merge this, [setupEnvironment: skippedStage, \
						   build: new  CustomStage(stageMethod:this.&overrideBuild), \
						   buildPackage: skippedStage, \
						   unittest: skippedStage, \
						   extraTests: skippedStage, \
						   staticCodeAnalysis: (pipelineConfig.validation.SCA.execute) ? new CustomStage(setup: (pipelineConfig.validation.SCA.builArtifactXml.execute) ? this.&overrideSetupSCA : null, stageMethod: (pipelineConfig.validation.SCA.codeGuildReportGen.execute) ? this.&overrideExecuteSCA : null, teardown: (pipelineConfig.validation.SCA.qSurge.execute) ? this.&overrideQsurgeSCA : null) : skippedStage, \
						   uploadMetrics: skippedStage, \
						   uploadPackage: skippedStage \
						  ]
		}catch (e) {
			echo 'Build failed with Error: ' + e.toString()
			throw e
		}
		
	}
}