AEBE Devops Jenkins Library
---------------------------

Version: 21.05 (Ishigarei)
---------------------------
Changes:
* Added methode `getLatestReleaseSnapshot` in `RtcHelpers` to find the latest release snapshot from a given stream. ([AEBEOD-819](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-819)
* Added possibility to `ArtifactoryHelpers` for validation pipelines (such as nightly) to validate the latest build of the day and add to its artefact metadata, rather than creating a new entry in Artifactory ([AEBEDO-714](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-714))
* Added option to `FossidHelpers` to reuse identifications from previous scans ([AEBEDO-791](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-791))
* Added option to `CDQ0302Dashboard` to also get data from DNG (Doors Next Generation) ([AEBEDO-692](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-692))
* Fixed Bug in `FossidHelpers` that the sleep function is not working as intented ([AEBEDO-755](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-755))
* Fixed python certificate problem in library build run ([AEBEDO-866](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-866))
* Fixed build on Windows machine for Jenkins library ([AEBEDO-523](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-523))

Version: 20.40 (Hammerhead)
---------------------------
Changes:
* Add the capability to `RtcHelpers` class to check the promotion to stream by specifying optional teamArea argument. ([AEBEDO-741](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-741))
* Add a parameter to `VectorCast` class to override the default VectorCast workspace by adding the capability to the class to pass vcastWorkspaceOverride whilst preserving the backward compatibility. Improve `runVcast` script to allow option worksapce parameter. ([AEBEDO-732](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-732))
* Remove `ArtifactoryHelpers` dependency from `FossidHelpers` class, Artifactory upload of the Fossid report should be handled by the pipeline, rather than from the class. Add FossID scan option to scan unchanged files. Add option to filter FossID report selection. Change FossID report default to include all licenses. ([AEBEDO-687](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-687))
* Add a method `compare` in `RtcHelpers` class which allows the comparison of a snapshot and a workspace. Add a method `findChangesets` in `RtcHelpers` class which finds the affected files from `compare`. Improve testing for `compareFindings` method. ([AEBEDO-649](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-649))

Version: 20.30 (Great_White_Shark)
---------------------------
Changes:
* Added a `FossidHelpers` class to provide a pipeline implementation of the FossID open source scan tool API. ([AEBEDO-623](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-623))
* Added a `ReportHelpers` class to aid parsing of RQM test case data for the pipeline. ([AEBEDO-621](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-621))
* Added a `WarningsHelpers` class that provides an interface to the Jenkins Warning Next Generation plugin for parsing warning data. ([AEBEDO-568](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-568))
* Added methods to `ArtifactoryHelpers` that increase artefact properties functionality to promote atomic artefact storage. ([AEBEDO-500](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-500))
* Added mocking library Mockito to increase unit test mocking functionality, including Jenkins timeout mocking. ([AEBEDO-659](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-659))
* Fixed bugs in `Cdq0302Dashboard` class, including corrected exception handling, multiple credential support, linting fixes and git branch overrides. ([AEBEDO-671](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-671))
* Added unit tests for `ArtifactoryHelpers` class to increase test coverage. ([AEBEDO-672](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-672))

Version: 20.23 (Flying_Fish)
---------------------------
Changes:
* Implemented a GitHelpers option to set poll and changelog flags when calling SCM checkout. ([AEBEDO-622](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-622))

Version: 20.18 (Electric_Eel)
---------------------------
Changes:
* Add a method `teamAreaTearDown` in `RtcHelpers` to delete temporary stream. An initial implementation includes optional snapshot migration and streamBkup parameter. ([AEBEDO-628](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-628))
* Add a method `prRebase` in `RtcHelpers` to deliver changes from one stream to another through staging workspaces. It can be used for pull requests as well as rebases. ([AEBEDO-594](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-594))
* Implemented `BMIHelpers` class, a utility that executes a python script and return the status according to the BMI value to the pipeline. ([AEBEDO-540](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-540))
* Abstract `Cdq0302Dashboard` class to support RTC as configuration source. Add constructor to include authentication method as a parameter.([AEBEDO-551](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-551))

Version: V20.14 (Dory)
---------------------------
Changes:
* Add a feature to create jenkins job via the `JobHelpers` class. Base for this job is a yaml file. ([AEBEDO-579](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-579) + [AEBEDO-588](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-588))
* Add a method `teamAreaSetup` in `RtcHelpers` to create a new stream based on a certain snapshot name ([AEBEDO-578](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-578))
* Abstract `TestCoverage` class. This change will generalize the use of the `TestCoverage` class to all projects by adapting the BART config directory no to be project specific. This change will also allow the upload of BART csv output files to artifactory ([AEBEDO-569](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-563))

Version: 20.04 (Clownfish)
---------------------------
Changes:
* Bugfix ([AEBEDO-563](https://rb-tracker.bosch.com/tracker01/browse/AEBEDO-563)): The `test_coverage` step can now handle `CustomStages` overrides correctly
* Improved Artifactory Server handling in `ArtifactoryHelpers` to be more independent from the global Jenkins configuration
* Add [BIOSL](http://bios.intranet.bosch.com/bioslv4.txt) header information in each groovy file for compliance

Version: 19.51 (Barracuda)
---------------------------
Changes:
* Preview documentation changes for all pull-requests at https://inside-docupedia.bosch.com/confluence/display/AEBE/Pre-Release
* Add a helper class to deal with RTC changes
* Add a helper class to include Vector Cast Unittest in the pipeline
* Fail build if code narc issues are found

Version: 19.47 (Alligator)
--------------------------
Changes:
* First Release of the AE-BE Jenkins Library. With this Librarie Jenkins Piplines can be created und run.
* It supports the use of Artifactory, the creation of CDQ0302 Metrics, Test Coverage with the Tool BART and Bauhaus Single File Analysies
Classes that assist the usage of git and Conan packaging are also included.
* A Documentation can be found at: https://inside-docupedia.bosch.com/confluence/display/AEBE/Jenkins+Library
