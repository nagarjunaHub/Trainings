#!/usr/bin/env groovy
/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

class VectorCast {

    Object jenkins = null
    ArtifactoryHelpers artifactory = null
    String reportResults = ''

    VectorCast(Object jenkins, ArtifactoryHelpers artifactory=null) {
        this.jenkins = jenkins
        this.reportResults = this.jenkins.env.reportResults ?: 'UnitTest_Metrics.zip'
        this.artifactory = artifactory ?: new ArtifactoryHelpers(this.jenkins, this.jenkins.env.repo,
                                                                 this.jenkins.env.artifactoryProject)
    }

    void setupVcast() {
        // Vcast setup, define project location and environment variables
        this.jenkins.step([$class: 'VectorCASTSetup', environmentSetupUnix: '',
                           environmentSetupWin: '', environmentTeardownUnix: '', environmentTeardownWin: '',
                           executePreambleUnix: '', executePreambleWin: '', jobName: '',
                           manageProjectName: "\"${this.jenkins.env.vcastWorkspaceOverride ?: '%workspace%'}/" +
                                              "${this.jenkins.env.scmPath}/${this.jenkins.env.vcastProj}.vcm\"",
                           nodeLabel: "${this.jenkins.env.NODE_NAME}", optionClean: false,
                           optionErrorLevel: 'Unstable', optionExecutionReport: true, optionHtmlBuildDesc: 'HTML',
                           optionUseReporting: true, waitLoops: 1, waitTime: 30,])

        if (this.jenkins.env.vcastWorkspaceOverride == null) {
            this.jenkins.bat "call \"%workspace%/${this.jenkins.env.scmPath}/${this.jenkins.env.importScript}\""
        }
    }

    void runVcast() {
        // Run Vcast
        this.jenkins.writeFile file: 'runVcast.bat', text: this.jenkins.libraryResource('bosch/aebedo/runVcast.bat')
        String combinedArgs = "${this.jenkins.env.dirVCAST} ${this.jenkins.env.scmPath} " +
                              "${this.jenkins.env.vcastProj}"
        if (this.jenkins.env.vcastWorkspaceOverride != null) {
            combinedArgs += " ${this.jenkins.env.vcastWorkspaceOverride}"
        }
        this.jenkins.bat "call ./runVcast.bat ${combinedArgs}"

        // Archive Results
        this.jenkins.archiveArtifacts '*_rebuild*, *_report.html, execution/**, management/**, xml_data/**'

        this.jenkins.step([$class: 'XUnitPublisher', testTimeMargin: '3000', thresholdMode: 1, thresholds: [],
                           tools: [this.jenkins.JUnit(deleteOutputFiles: true, failIfNotNew: false,
                                                      pattern: '**/test_results_*.xml',
                                                      skipNoTestFiles: true, stopProcessingIfError: true)]])

        this.jenkins.zip dir: '', glob: '*_rebuild*,*_report.html,execution/**,management/**,xml_data/**',
                         zipFile: this.reportResults
    }

    void uploadVcast() {
        this.artifactory.upload(this.reportResults, this.jenkins.env.uploadDir ?:
                                "${this.jenkins.env.project}/${this.jenkins.env.dispName}/VCast",
                                ['build.number': "${this.jenkins.env.dispName}"])
        this.artifactory.publishBuildInfo(this.jenkins.env.dispName)
    }

    void executeVcast() {
        this.runVcast()
        this.uploadVcast()
    }

    void cleanVcast() {
        ['*_rebuild*', '*_report*', '*_results*', '*_count*', '*.zip'].each { delFile ->
            this.jenkins.fileOperations(
                [this.jenkins.fileDeleteOperation(includes: delFile, excludes: '')]
            )
        }
        ['execution', 'management', 'xml_data', 'vc_scripts', 'generatedJUnitFiles'].each { delDir ->
            this.jenkins.dir(delDir) {
                this.jenkins.deleteDir()
            }
        }
    }

}
