#! /usr/bin/env groovy
 /**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import groovy.util.slurpersupport.GPathResult
import java.util.regex.Matcher
import org.codehaus.groovy.control.ConfigurationException

/**
 * Library to aid data fetching operations to the RTC report builder data.
 * The library will handle the data fetching and authentication to its most original form.
 * However any post data processing e.g format transformation is also available as a wrapper in this utility.
 */
class JrsHelpers {

    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null

    /**
     * Constructor for the reportHelpers class
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     */
    JrsHelpers(Object jenkins) {
        this.jenkins = jenkins
    }

    /**
     * Creates an XmlSlurper given a report builder url
     * @param reportUrl String report builder data that
     * @param creds String Jenkins credential ID to access the workspace or stream with. Will use the class.
     * @return Object xmlSlurper object being initialized from the xml response of the report URL.
     */
    GPathResult fetchReportData(String reportUrl, String creds) {
        Matcher baseUrlMatch = reportUrl =~ /https:\/\/.+?[^\/:](?=[?\/]|$)\/rs/
        String baseUrl = ''
        if (baseUrlMatch) {
            baseUrl = baseUrlMatch.group(0)
        } else {
            throw new ConfigurationException("${reportUrl} has invalid baseUrl")
        }
        baseUrlMatch = null
        String output = ''
        this.jenkins.withCredentials([this.jenkins
            .usernameColonPassword(credentialsId: creds, variable: 'userpass'),]) {
            output = this.jenkins.powershell returnStdout: true,
                     script: """irm -Uri '${baseUrl}' -SessionVariable 'websession' `
                             -Method 'GET' -Headers @{Authorization=('Basic {0}' -f `
                             '${this.jenkins.env.userpass.bytes.encodeBase64()}')} | Out-Null
                             (irm -Uri '${reportUrl}' -Method 'GET' -WebSession \$websession).InnerXml"""
        }
        return new XmlSlurper().parseText(output)
    }

    /**
     * Creates a Map object given a report builder url.
     * For raw GPathResult object see fetchReportData function.
     * @param reportUrl String report builder data that
     * @param creds String Jenkins credential ID to access the workspace or stream with. Will use the class.
     * @return Map data being transformed from the xml GPathResult object to Map.
     */
    Map xmlMapWorkflow(String reportUrl, String creds) {
        AebeDevOps devOpsUtil = new AebeDevOps(this.jenkins)
        GPathResult xmlObject = this.fetchReportData(reportUrl, creds)
        return devOpsUtil.gpathMapTransformer(xmlObject)
    }

}
