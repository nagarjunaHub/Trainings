#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

/**
 * Library which aids generation of CDQ0302 Dashboard.
 * <h3>Motivation</h3>
 * The Jenkins Library provides functionality to automate CDQ0302 report generation from project metrics.<br/>
 * By default this is achieved by interfacing with the MeGenJa tool, however with CustomStages,<br/>
 * any other report generation tool is able to be run instead.
 * <h3>Usage</h3>
 * In order to use the CDQ0302 object and it's default methods,<br/>
 * the following list of environment variables must be passed in (unless otherwise specified):
 * <ul>
 *      <li>artifactoryProject - Project specific Artifactory server name as per Jenkins configuration</li>
 *      <li>dispName - Name of the pipeline build to be displayed</li>
 *      <li>repo - Name of Artifactory repository to be used</li>
 *      <li>domain - Project high level name, e.g. "PK"</li>
 *      <li>project - Project within the domain, e.g. "SVW"</li>
 *      <li>stream - Name of the RTC stream within the project to be used, e.g "dev"</li>
 *      <li>api - Artifactory API credential of the technical user</li>
 *      <li>configCred - Credential of the technical user for SCM where config is kept</li>
 *      <li>configRepo - SCM repository name where config is kept</li>
 *      <li>mgjCred - Credential to run MeGenJa (only required if MeGenJa is used)</li>
 *      <li>failMail - Optional: list of email address(es) to be notified if the pipeline fails</li>
 *      <li>configSCM - SCM where the config files are stored  GitSCM or RTCscm</li>
 *      <li>configBranch - Branch / Buildworkspace of SCM where config is kept to be used (in case of git master)</li>
 *      <li>configPass - Authentication method of the Tool, Passphrase or Credentials are possible:
 *          <ul>
 *              <li>Passphrase: Credentials are hashed and stored in the configfile</li>
 *              <li>Credentials: Credentials are passed as parameter with the command</li>
 *     </li>
 * </ul>
 * When calling the default methods,<br/>
 * the following parameters may be optionally passed in to further <br/>
 * tailor the pipeline to the project: (brackets denote default setting) <br/>
 * <ul>
 *      <li>toolVersion - Version of MeGenJa to use (latest release)</li>
 *      <li>downloadProps - Map of download properties for build metrics (stream property)</li>
 *      <li>dataVersion - Version of build to analyse metrics of (latest)</li>
 *      <li>configBranch - Branch of SCM where config is kept to be used (master) or workspace in case of RTC</li>
 *      <li>configGitTool - Jenkins Git tool to use (Default)</li>
 *      <li>configDir - Path to config in SCM repository (Metrics/MeGenJa/Config/<project>)</li>
 *      <li>loadRulePath - path to the loadrulefile in case of RTC</li>
 *      <li>dxlDir - Path to dxl in SCM repository (Metrics/MeGenJa/dxl/<project>)</li>
 *      <li>rtcCredentials - SCM credentials in case of RTC </li>
 *      <li>doorsCredentials - In case of Credentials method the Doors credentials for the tool </li>
 *      <li>metricType - the property of the build metrics in Artifactory, default 'metrics'</li>
 * </ul>
 * <h3>Stages</h3>
 * <h5>Setup</h5>
 * Unless overridden, the setup function downloads the latest version of MeGenJa from Artifactory,
 * then downloads the metrics data from the project's Artifactory repository directly into the tool.<br/>
 * The SCM where the config is kept is then checked out in a temporary directory and the specified
 * config file and associated dxl script is copied into the tool.
 *
 * <h5>Stage Method</h5>
 * By default the stage method calls the executeMegenja function, which and executes MeGenJa tool.<br/>
 * The report folder is compressed upon completion.
 *
 * <h5>Teardown</h5>
 * The teardown function uploads the compressed report folder to Artifactory.
 */

class Cdq0302Dashboard {

    static final List ALLOWED_KEY_WORDS = ['megenja']
    Object jenkins = null
    ArtifactoryHelpers artifactory = null
    RtcHelpers rtcHelpers = null
    GitHelpers gitHelpers = null
    String reportFile = ''
    String configStash = 'config'
    String dxlStash = 'dxl'
    String configPass = ''
    List authMethod = ['Passphrase', 'Credentials']
    ReqTools tool = null
    enum ReqTools {

        DNG,
        DOORS

    }

    Cdq0302Dashboard(Object jenkins, String configPass, ArtifactoryHelpers artifactory=null,
                     ReqTools t = ReqTools.DOORS) {
        this.jenkins = jenkins
        this.artifactory = artifactory ?: new ArtifactoryHelpers(this.jenkins, this.jenkins.env.repo,
                                                                 this.jenkins.env.artifactoryProject)
        this.reportFile = this.jenkins.env.reportName ?: "${this.jenkins.env.dispName}_CDQ0302_Metrics.zip"
        this.tool = t
        if (!(authMethod.contains(configPass))) {
            throw new IllegalArgumentException("configPass has to be 'Passphrase' or 'Credentials'")
        }
    }

    /**
    * Function to load the latest MeGenJa zip file from Artifactory.
    * Inside the zip, you can find your cfg and your dxl/xml file.
    * Careful- because this files will be overwritten by AEEE (Projects
    * have to take care of their configuration)
    **/
    List<String> loadTool() {
        ArtifactoryHelpers toolArtifactory = new ArtifactoryHelpers(this.jenkins, 'aebe-devops-local', 'CI_Artifactory')
        String toolDir = 'Tools/MeGenJa'
        String toolVersion = this.jenkins.env.toolVersion ?: toolArtifactory.getLatestVersion(toolDir, [:],
                                                                                              this.jenkins.env.api)
        toolArtifactory.download(toolDir, './', ['version':toolVersion], true, true, true, '', true)

        return [toolArtifactory, toolDir, toolVersion]
    }

    /**
    * Function which is only neccessary if the project has/needs memory analyzer
    * Then there will be files inside the build folder to use for RAM/ROM analysis.
    **/
    List<String> downloadBuildData() {
        Map metricDownloadProps = this.jenkins.env.downloadProps ?: ['stream': this.jenkins.env.stream]
        String dataVersion = this.jenkins.env.dataVersion ?: this.artifactory.getLatestVersion(this.jenkins.env.project,
                                                                                               metricDownloadProps,
                                                                                               this.jenkins.env.api)
        String metricType = this.jenkins.env.metricType ?: 'metrics'
        String folderDir = "SetUp/Source/Data/BUILD/AE-BE_${this.jenkins.env.domain}/" +
                           "${this.jenkins.env.project}/CDQ0302/*.cfg"
        //check if file exists, otherwise skip memory analyzer
        if (this.jenkins.fileExists(folderDir)) {
            try {
                this.artifactory.download(this.jenkins.env.project,
                                        "SetUp/Source/Data/BUILD/AE-BE_${this.jenkins.env.domain}/" +
                                        "${this.jenkins.env.project}/CDQ0302/",
                                        ['version':dataVersion, 'type':metricType], true, true, true)
            } catch (e) {
                this.jenkins.echo 'No metrics from Artifactory available'
                this.jenkins.echo e.toString()
                throw e
            }
        } else {
            this.jenkins.echo 'Folder empty --- skipping download Build Data..'
        }
        return [metricDownloadProps, dataVersion]
    }

    /**
    * Function to move the actual cfg and dxl/xml files from AEEE onto the
    * right place for MeGenJa execution.
    **/
    List<String> loadConfig() {
        String tmpDir = 'tmp/config'
        this.jenkins.dir(tmpDir) {
            this.downloadConfigSCM()
        }

        String configSrc = this.jenkins.env.configDir ?: "Metrics/MeGenJa/Config/${this.jenkins.env.project}"
        String dxlSrc = this.jenkins.env.dxlDir ?: "Metrics/MeGenJa/dxl/${this.jenkins.env.project}"
        this.jenkins.dir('SetUp/Config') {
            this.jenkins.bat "move ../../${tmpDir}/${configSrc} AE-BE_${this.jenkins.env.domain}"
        }
        //move xml/dxl file to CDQ0302 folder
        this.jenkins.dir('SetUp/Source/Data/' + this.tool +
                         "/AE-BE_${this.jenkins.env.domain}/${this.jenkins.env.project}") {
            this.jenkins.bat "move ../../../../../../${tmpDir}/${dxlSrc} CDQ0302"
        }
        return [tmpDir, configSrc, dxlSrc]
    }

    /**
    * Function to download the latest project code from Git or RTC
    * Usually this code includes the cfg and dxl/xml file which will be
    * used to overwrite the template ones downloaded with the CDQ zip from Artifacoty.
    **/
    void downloadConfigSCM() {
        if (this.jenkins.env.configScm == 'GitSCM') {
            gitHelpers = new GitHelpers(this.jenkins)
            String gitBranch = this.jenkins.env.configBranch ?: '*/master'
            gitHelpers.checkoutUsingGittool(this.jenkins.env.configCred, this.jenkins.env.configRepo,
                                            gitBranch, gitBranch, false)
        }
        if (this.jenkins.env.configScm == 'RTCscm') {
            rtcHelpers = new RtcHelpers(this.jenkins)
            rtcHelpers.checkoutRtc(rtcHelpers.getBuildTypeWorkspaceMap(this.jenkins.env.configBranch))
        }
    }

    /**
    * This function contains the actual bat command to execute Mengenja.
    * The outcome is a zip file wich contains the CDQ diagramms as well as several csv files.
    * For manual testig you can copy and past it into powershell with
    * adapted credentials and paths.
    **/
    void setupMegenjaEnvironment() {
        this.loadTool()
        this.downloadBuildData()
        this.loadConfig()
    }

    void executeMegenja() {
        this.jenkins.dir('SetUp') {
            if (this.jenkins.env.configPass == authMethod[0]) {
                this.jenkins.withCredentials([this.jenkins.usernamePassword(credentialsId: this.jenkins.env.mgjCred,
                                                                            passwordVariable: 'password',
                                                                            usernameVariable: 'username'),]) {
                    this.jenkins.bat "java -jar MeGenJa.jar EXE -config Config/AE-BE_${this.jenkins.env.domain} " +
                    "-result Results -source Source -passphrase ${this.jenkins.env.password}"
                }
            }
            else if (this.jenkins.env.configPass == authMethod[1]) {
                this.jenkins.withCredentials([
                                        this.jenkins.usernamePassword(credentialsId: this.jenkins.env.rtcCredentials,
                                                                      passwordVariable: 'rtc_password',
                                                                      usernameVariable: 'rtc_username'),
                                        this.jenkins.usernamePassword(credentialsId: this.jenkins.env.doorsCred,
                                                                      passwordVariable: 'doors_password',
                                                                      usernameVariable: 'doors_username'),]) {
                    this.jenkins.bat "java -jar MeGenJa.jar EXE -config Config/AE-BE_${this.jenkins.env.domain} " +
                    '-result Results -source Source ' +
                    "-LOGIN \"auth|${this.jenkins.env.rtc_username}|${this.jenkins.env.rtc_password}\" " +
                    "-LOGIN \"authDoors|${this.jenkins.env.doors_username}|${this.jenkins.env.doors_password}\""
                }
            }
            else {
                this.jenkins.env.currentBuild.result = 'FAILURE'
            }
        }
        // Compress results
        this.jenkins.zip dir: 'SetUp/Results', zipFile: this.reportFile
    }

    /**
    * The uploadMetrics function uploads the results to Artifactory.
    * Please consult ArtifactoryHelpers for more details.
    **/
    void uploadMetrics() {
        //Upload report to Artifactory
        String commonUploadPath = "${this.jenkins.env.project}/MeGenJa/${this.jenkins.env.dispName}"
        String artifactoryUploadPath = this.jenkins.env.uploadPath ?: commonUploadPath
        this.artifactory.upload(this.reportFile, "${artifactoryUploadPath}",
                                ['build.number':this.jenkins.env.dispName])
        this.artifactory.publishBuildInfo(this.jenkins.env.dispName)
    }

}
