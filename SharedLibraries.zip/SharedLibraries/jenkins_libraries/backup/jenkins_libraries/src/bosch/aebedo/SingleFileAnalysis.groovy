#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

/**
 * Library for executing Single File Analysis which provides granular code warnings given a code delivery.
 * <h3>Motivation</h3/>
 * Previously static code analysis has been running as part of a daily checkup on a project which gives an insight on
 * code warnings which is very time consuming.<br/>
 * In order to continuously check for defect in a code it will be extremely beneficial on time to run analysis based
 * on whats being delivered to the project.<br/>
 * This process gives a granular breakdown on which files has on which warnings and ultimately developers can divide
 * and conquer on the warnings being analyzed.<br/>
 * Ideally this process then will be beneficial when running as part of onCommit pipeline for a given project.<br/>
 * Below is the high level summary of the SFA Process:<br/>
 * <img src="https://tinyurl.com/y4yu5slc"/>
 *
 * <h3>Design</h3/>
 * In Jenkins through RTC-SCM plugin we are able to extract the component name and the path of the affected for a
 * given change-set.<br/>
 * The SFA only runs on .h or .c file where it is not necessarily the two file gives out the warnings.<br/>
 * However the analysis runs a linker check on other files that might be associated with that file.<br/>
 * In each project we are able to grab the variants associated include file given a generalized glob
 * of _builds/${VARIANTS}/_gen/swb/${ECU_APP_NAME}/app/include/${DESTINATION}.<br/>
 *
 * The include list of a given variants is important as an input parameter to Bauhaus SFA where it then needed to
 * be separated by `-I${include_1} -I${include_2}.<br/>
 * The SFA runs a `cafecc,.exe` from bauhaus which generate the .ir file and from there the `stylecheck.exe` will
 * generate the .csv output for a report.<br/>
 *
 * If cafecc.exe execution failed it will still generate an .ir file and let stylecheck.exe run produce a .csv file
 * given a heading with no result.<br/>
 * If cafecc.exe execute just fine and stylecheck.exe run just fine it will produce .csv file given a heading with a
 * result.<br/>
 *
 * In order to avoid duplicate warnings between variants the .csv will be merged where every single warnings in a
 * merged .csv is unique.<br/>
 * Therefore if the previous variants run already covered the same exact warnings it will not be added to the merged
 * csv.<br/>
 * It will be up to the project on how they deal with the results metrics ideally this will be parsed to a dashboard
 * on the counts of warnings for a given file that were analyzed.<br/>
 * In order to succesfully convert the csv into a usable format please click on A1 when excel opened.<br/>
 * Press Ctrl + Shift + ↓ + → then press Ctrl + T so that developers can filter what the only necessary warnings.<br/>
 * Below is the detail activity diagram given an SFA:<br/>
 * <img src="https://tinyurl.com/y3pcdefj"/>
 *
 * <h3>Usage</h3>
 * The actual library execution has to proceed after after a softrware build and RTCscm checkout.<br/>
 * Build step ensures that include list for a given variant and ecu_type dependency list is updated.<br/>
 * Checkout step ensures that Jenkins variable currentBuild is updated with a given delivery to the stream.<br/>
 * Below is the example usage of SFA:<br/>
 * <code>
 *      // scm checkout here ... -> Update currentBuild var<br/>
 *      // build the software here ... -> Update the generated includes list for each ecu_type<br/>
 *      artInstance = new ArtifactoryHelpers(this, 'mockArtiFactoryLocation', 'mockArtifactoryAuth')<br/>
 *      sfaInstance = new SingleFileAnalysis(this, artInstance)<br/>
 *      this.env.sfaIncludePath = "_builds/${var_key}/_gen/swb/${execType}/app/include/**"<br/>
 *      sfaInstance.setupSingleFa()<br/>
 *      sfaInstance.executeSingleFa()<br/>
 *      sfaInstance.uploadSingleFa()<br/>
 * </code>
 *
 * <h3>Result Example:</h3>
 * Given a sample changesets of : <br/>
 * <code>
 *      fileList.push("rbd\\pk\\pf\\sw\\ASW\\TagCoord\\include\\TagCoord.h")<br/>
 *      fileList.push("rbd\\pk\\pf\\sw\\ASW\\TagCoord\\src\\TagCoord_Authent.c")<br/>
 *      fileList.push("rbd\\pk\\pf\\sw\\ASW\\Whitelist\\src\\Whitelist.c")<br/>
 *      fileList.push("rbd\\pk\\pf\\sw\\ASW\\Whitelist\\src\\Whitelist_cache.c")<br/>
 *      fileList.push("rbd\\pk\\pf\\sw\\MasterMcu\\app\\ASW\\ConfigData\\B2\\include\\CalData_Api.h")<br/>
 *      fileList.push("rbd\\pk\\pf\\sw\\BSW\\DtcMgr\\src\\rbDtcMgr.c")<br/>
 * </code>
 * This will generate an equivalent .ir.csv from a given file once executed.<br/>
 * In order to avoid naming conflict the export of the data also needed
 * to follow the folder where it is being extracted.<br/>
 * Attached in this wiki is the .ir.csv and also the summary report generated from PK.<br/>
 * <a href="https://tinyurl.com/y2wslqwo">Summary.txt</a>
 */
class SingleFileAnalysis {

    final String newLineLiteral = '\n'
    /** Jenkins Environment refference */
    Object jenkins = null
    /** Instance of Aebedevops class */
    RtcHelpers rtc = null
    /** Instance of ArtifactoryHelpers class */
    ArtifactoryHelpers artifactory = null
    /** Map which stores the result of SFA<br/>
        Key is the location of the file<br/>
        Value is a List of String containing the result<br/> */
    Map sfaResultMap = [:]
    /**
     * Constructor for the Single File Analysis.<br/>
     * <b>Required</b> the following env to be set:<br/>
     <table>
        <tr>
            <th>env variable</th>
            <th>Desc</th>
            <th>Example</th>
        </tr>
        <tr>
            <td>repo</td>
            <td>Artifactory repo</td>
            <td>aebe-pk-local<td/>
        </tr>
        <tr>
            <td>artifactoryProject</td>
            <td>Artifactory project configuration</td>
            <td>Artifactory_PK, BDC_Artifactory<td/>
        </tr>
     </table>
     * @param jenkins jenkins workflowscript pointer
     * @param artifactory (optional) artifactory helpers instance to used
     */
    SingleFileAnalysis(Object jenkins, ArtifactoryHelpers artifactory=null) {
        this.jenkins = jenkins
        this.rtc = new RtcHelpers(this.jenkins)
        this.artifactory = artifactory ?: new ArtifactoryHelpers(this.jenkins, this.jenkins.env.repo,
                                                                 this.jenkins.env.artifactoryProject)
    }
    /**
     * Entry Execute method for Single File Analysis.<br/>
     * This will populate the sfaResultMap with a key of the file location<br/>
     * and with a value of the merged csv of the analysis.<br/>
     * <b>Required</b> the following env to be set:<br/>
     <table>
        <tr>
            <th>env variable</th>
            <th>Desc</th>
            <th>Example</th>
        </tr>
        <tr>
            <td>sfaIncludePath</td>
            <td>The glob used to search given a CDG build format</td>
            <td>_builds/${var_key}/_gen/swb/${execType}/app/include/**<td/>
        </tr>
     </table>
     * @param jenkins workflowscript pointer
     * @param artifactory (optional) artifactory helpers instance to used
     */
    void executeSingleFa() {
        List includeFilesList = this.jenkins.findFiles(glob : this.jenkins.env.sfaIncludePath)
        List changeSetFilesList = rtc.parseRtcChanges(this.jenkins.currentBuild.changeSets)
        changeSetFilesList.each { fileAnalysis ->
            List sfaResult = []
            includeFilesList.each { includeFileName ->
                sfaResult = execBauhausSingleFa(sfaResult,
                                                fileAnalysis,
                                                includeFileName.toString())
            }
            /* groovylint-disable-next-line UnnecessaryGetter */
            if ( !sfaResult.isEmpty() && sfaResultMap.containsKey(fileAnalysis) ) {
                List mergedSfaResultList = sfaResultMap[fileAnalysis]
                for (line in sfaResult) {
                    if (!mergedSfaResultList.contains(line)) {
                        mergedSfaResultList.add(line)
                    }
                }
                this.sfaResultMap[fileAnalysis] = mergedSfaResultList
            }
            /* groovylint-disable-next-line UnnecessaryGetter */
            else if ( !sfaResult.isEmpty() ) {
                this.sfaResultMap[fileAnalysis] = sfaResult
            }
        }
    }
    /**
     * Entry Upload method for Single File Analysis.<br/>
     * In this case singleFileFa does not need to publish the buildInfo.<br/>
     * <b>Optional</b> env to be set:<br/>
     <table>
        <tr>
            <th>env variable</th>
            <th>Default</th>
            <th>Desc</th>
        </tr>
        <tr>
            <td>sfaResultDir</td>
            <td>singleFaResult</td>
            <td>Determine on which folder the result will be stored.</td>
        </tr>
        <tr>
            <td>sfaReportLabel</td>
            <td>Bauhaus_Report</td>
            <td>File name being labelled as the report file<td/>
        </tr>
        <tr>
            <td>uploadDest</td>
            <td>"${this.jenkins.env.dispName}/Validation/offTarget"</td>
            <td>File name being labelled as the report file<td/>
        </tr>
        <tr>
            <td>dispName</td>
            <td>"${env.STREAM}_onCommit_${env.TIMESTAMP}"</td>
            <td>Build number being labelled<td/>
        </tr>
     </table>
     */
    void uploadSingleFa() {
        String sfaResultDir = this.jenkins.env.sfaResultDir ?: 'singleFaResult'
        List singleFileAnalysisResults = []
        sfaResultMap.each { unused, singleFileResult ->
            for (line in singleFileResult) {
                if (!singleFileAnalysisResults.contains(line)) {
                    singleFileAnalysisResults.add(line)
                }
            }
        }
        String mergedCsv = 'sep=;\n'
        for (line in singleFileAnalysisResults) {
            mergedCsv += "${line.trim()}\n"
        }
        this.jenkins.dir(sfaResultDir) {
            String reportFile = this.jenkins.env.sfaReportLabel ?: 'Bauhaus_Report'
            this.jenkins.writeFile file: "${reportFile}.csv", text: mergedCsv
            String defaultUploadDest = "${this.jenkins.env.dispName}/Validation/offTarget"
            String singleFaUploadDest = this.jenkins.env.uploadDest ?: defaultUploadDest
            this.artifactory.upload("${reportFile}.csv", singleFaUploadDest,
                                    [ 'build.number' : "${this.jenkins.env.dispName}" ])
        }
    }
    /**
     * Entry Execute method for Single File Analysis.<br/>
     * Required no env to be set before executing.<br/>
     * <b>Optional</b> env to be set:<br/>
     <table>
        <tr>
            <th>env variable</th>
            <th>Default</th>
            <th>Desc</th>
        </tr>
        <tr>
            <td>bauhausRoot</td>
            <td>C:\\Program Files (x86)\\Bauhaus</td>
            <td>Folder location for the bauhaus executable.</td>
        </tr>
        <tr>
            <td>bauhausConfig</td>
            <td>${pwd()}\\rbd\\pk\\tools\\Bauhaus\\ghs-ppc</td>
            <td>Folder location for the bauhaus configuration.</td>
        </tr>
        <tr>
            <td>bauSingleFileConfig</td>
            <td>${pwd()}\\rbd\\pk\\tools\\Bauhaus\\BauhausSingleFile</td>
            <td>Folder location for the sfa configuration.</td>
        </tr>
        <tr>
            <td>sfaPythonPath</td>
            <td>C:\\toolbase\\python\\2.7.9.0</td>
            <td>Python path for the bauhaus.</td>
        </tr>
        <tr>
            <td>excludeList</td>
            <td>['*\\RTE_VM*\\*', '*\\rtegen\\*', '*\\ansi\\*']</td>
            <td>List of exclude param passed to a Bauhaus execution</td>
        </tr>
        <tr>
            <td>typeSystem</td>
            <td>ghsppc</td>
            <td>Type of System being specified for the project</td>
        </tr>
     </table>
     * @param sfaResult List which contains the previously executed single file analysis.
     * @param fileAnalysis The file location which will be analyzed by Bauhaus.
     * @param includeFileName The file location which has all the includes list for a given compilation.
     * @return List A unique list which does not contain repeats between the SFA execution.
     */
    List execBauhausSingleFa(List sfaResult, String fileAnalysis, String includeFileName) {
        final String currentDir = "${this.jenkins.pwd()}"
        String includes = this.getIncludes("${currentDir}\\${includeFileName}")
        List excludeList = this.jenkins.env.excludeList ?: ['*\\RTE_VM*\\*', '*\\rtegen\\*', '*\\ansi\\*']
        String excludeString = ''
        for (type in excludeList) {
            excludeString += "-exclude ${type} "
        }

        String bauhausRoot = this.jenkins.env.bauhausRoot ?: 'C:\\Program Files (x86)\\Bauhaus'
        String defaultBauhausConfig = "${currentDir}\\rbd\\pk\\tools\\Bauhaus\\ghs-ppc"
        String bauhausConfig = this.jenkins.env.bauhausConfig ?: defaultBauhausConfig

        String defaultBauhausSfaLoc = "${currentDir}\\rbd\\pk\\tools\\Bauhaus\\BauhausSingleFile"
        String bauSingleFileConfig = this.jenkins.env.bauSingleFileConfig ?: defaultBauhausSfaLoc

        String pythonPath = this.jenkins.env.sfaPythonPath ?: 'C:\\toolbase\\python\\2.7.9.0'
        String typeSystem = this.jenkins.env.typeSystem ?: 'ghsppc'
        String output = this.jenkins.bat ( script : """
        @echo off
        SET BAUHAUS_CONFIG=${bauhausConfig}
        SET PATH=${pythonPath};%PATH%
        \"${bauhausRoot}\\bin\\cafecc.exe\" --type_system ${typeSystem} -B ^
        ${currentDir} ${includes} -c \"${fileAnalysis}\" -o ^
        \"${fileAnalysis}.ir\" >nul 2>&1
        IF %ERRORLEVEL% EQU 0 (
            set BAUHAUS_CONFIG=${bauSingleFileConfig}
            \"${bauhausRoot}\\bin\\stylecheck.exe\" ${excludeString}^
            -ir \"${currentDir}\\${fileAnalysis}.ir\" ^
            | \"${bauhausRoot}\\bin\\teecap.exe\" -format=axivion ^
            -outfile=\"${currentDir}\\${fileAnalysis}.ir.csv\" >nul 2>&1
            IF %ERRORLEVEL% EQU 0 (
                echo SUCCESS executing : \"${fileAnalysis}\"
            ) ELSE (
                echo FAIL executing : \"${fileAnalysis}\"
            )
        ) ELSE (
            echo FAIL executing : \"${fileAnalysis}\"
        )
        """ , returnStdout : true )
        String lastCommand = output.split(this.newLineLiteral)[output.split(this.newLineLiteral).size() - 1]
        if (!lastCommand.contains('FAIL')) {
            int sepatatorlastIndex = fileAnalysis.lastIndexOf('\\')
            String fileToAnalyze = fileAnalysis[(sepatatorlastIndex + 1)..(fileAnalysis.length() - 1)]
            String filePath = fileAnalysis[0..(sepatatorlastIndex - 1)]
            this.jenkins.dir(filePath) {
                String outputFile = this.jenkins.readFile "${fileToAnalyze}.ir.csv"
                for (line in outputFile.split(this.newLineLiteral)) {
                    if (!sfaResult.contains(line)) {
                        sfaResult.add(line)
                    }
                }
            }
        }
        return sfaResult
    }
    /**
     * Return a single string of includes based on an include file.<br/>
     * @param includeFile The full path of the include file for a given compilation.
     */
    private String getIncludes(String includeFile) {
        List includeList = []
        String includeFileRaw = this.jenkins.readFile includeFile
        List includeFromFile = includeFileRaw.split(this.newLineLiteral)
        for (list in includeFromFile) {
            if (!includeList.contains(list)) {
                includeList.add(list)
            }
        }
        String sfaIncludeString = ''
        for (includeName in includeList) {
            sfaIncludeString = "-I${includeName.trim()} ${sfaIncludeString}"
        }
        return sfaIncludeString
    }

}
