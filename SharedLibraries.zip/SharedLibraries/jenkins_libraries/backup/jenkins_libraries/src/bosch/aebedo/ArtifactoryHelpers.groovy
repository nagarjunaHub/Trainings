#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import groovy.json.JsonSlurper
import groovy.json.JsonSlurperClassic

/**
 * Library which aids general execution of Artifactory actions.
 * <h3>Motivation</h3>
 * In the past the upload stage of an Artifactory upload has differ quite significantly especially the Artifactory.
 * In order to simplify the upload method to Artifactory a `helper` function provides ease on accessing common API.
 * <h3>Usage</h3>
 * Below is the example usage of ArtifactoryHelpers:<br/>
 * <code>
 *      // Current setup of the ArtifactoryHelpers<br/>
 *      env.repo = "aebe-pk-local"<br/>
 *      env.artifactoryProject = "Artifactory_PK"<br/>
 *      ArtifactoryHelpers artInstance = new ArtifactoryHelpers(this, env.repo, env.artifactoryProject)<br/>
 *
 *      Map fbl_version_config = [ "stream" : "${STREAM}"]<br/>
 *      String fbl_version = artInstance.getLatestVersion("xx/xx/yy.zip", fbl_version_config, apiKeyCredential)<br/>
 *      // Download the flash bootloader given the version<br/>
 *      Map fbl_props_config = [ "version" : "${fbl_version}",<br/>
 *                               "type" : "bin",<br/>
 *                               "variant" : "McuFbl_B1" ]<br/>
 *      artInstance.artifactoryDownload("FBL", "McuFbl_B1", fbl_props_config, true, true, "", true, "")<br/>
 *
 *      // Retrieve metrics given the software version<br/>
 *      Map metrics_props_config = [ "version" : "${VERSION}",<br/>
 *                                   "type"    : "metrics",<br/>
 *                                   "stream"  : "${STREAM}" ]<br/>
 *      artInstance_helpers.artifactoryDownload("${PROJECT}", "Build_Metrics", metrics_props_config,<br/>
 *                                              true, true, "", false, "")<br/>
 * </code>
 * <h3>Guidelines</h3>
 * Given an above example it is best to have one instance of the ArtifactoryHelpers for the entire pipeline.<br/>
 * This will avoid confusion on the object management between server object and the buildinfo object.<br/>
 * If more functionality is needed from the helpers (such as manipulating server and buildinfo directly)<br/>
 * please contribute to the helpers so that other projects can also use the same functionality.<br/>
 */

class ArtifactoryHelpers {

    String envArtifactoryRepo = ''
    String envArtifactoryURL = ''
    Object jenkins = null
    Object server = null
    Object buildinfo = null
    private final String defaultAPI = 'api'

    /* groovylint-disable-next-line ParameterCount */
    ArtifactoryHelpers(Object jenkins,
                       final String artifactoryRepo='',
                       final String artifactoryName='',
                       final String artifactoryCred='',
                       final String artifactoryURL='https://rb-artifactory.bosch.com/artifactory',
                       final Boolean bypassProxy=true,
                       final Integer timeout=300) {
        this.jenkins = jenkins
        this.envArtifactoryRepo = artifactoryRepo
        this.envArtifactoryURL = artifactoryURL
        String serverID = this.jenkins.env.AEBE_DEVOPS_ARTIFACTORY ?: artifactoryName
        if (serverID != '') {
            this.server = this.jenkins.Artifactory.server serverID
        }
        else {
            this.server = this.jenkins.Artifactory.newServer url: this.envArtifactoryURL, credentialsId: artifactoryCred
        }
        this.server.bypassProxy = bypassProxy
        this.server.connection.timeout = timeout
        this.buildinfo = this.jenkins.Artifactory.newBuildInfo()
    }

    String getLatestVersion(String dir, Map props=[:], String cred) {
        String url = "${this.jenkins.env.ARTIFACTORY_URL ?: this.envArtifactoryURL}" +
                     "/api/versions/${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${dir}?".toString()
        props.each { k, v ->
            url += "${k}=${v}&"
        }
        url += 'listFiles=0'
        String version = ''
        this.jenkins.withCredentials([this.jenkins.string(credentialsId: "${cred}", variable: this.defaultAPI)]) {
            /* groovylint-disable-next-line UnnecessaryGetter */
            if (this.jenkins.isUnix()) {
                String scriptString = "curl -s -H \"X-JFrog-Art-Api:${this.jenkins.env.api}\" -X GET \"${url}\""
                String jsonString = this.jenkins.sh returnStdout: true, script: scriptString
                version = (new JsonSlurper()).parseText(jsonString).version
            }
            else {
                String scriptString = "(Invoke-RestMethod -Uri \"${url}\" " +
                                      "-Method Get -Headers @{\"X-JFrog-Art-Api\"=\"${this.jenkins.env.api}\"}).version"
                version = this.jenkins.powershell returnStdout: true, script: scriptString
            }
        }
        return "${version}".trim()
    }

    String getProps(String dir, String cred, String propToRetrieve) {
        String url = "${this.jenkins.env.ARTIFACTORY_URL ?: this.envArtifactoryURL}" +
                     "/api/storage/${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${dir}?" +
                     "properties=${propToRetrieve}"
        String property = ''
        this.jenkins.withCredentials([this.jenkins.string(credentialsId: "${cred}", variable: this.defaultAPI)]) {
            /* groovylint-disable-next-line UnnecessaryGetter */
            if (this.jenkins.isUnix()) {
                String scriptString = "curl -s -H \"X-JFrog-Art-Api:${this.jenkins.env.api}\" -X GET \"${url}\""
                String jsonString = this.jenkins.sh returnStdout: true, script: scriptString
                property = (new JsonSlurper()).parseText(jsonString).properties."${propToRetrieve}"
            }
            else {
                String scriptString = "(Invoke-RestMethod -Uri \"${url}\" " +
                                      "-Method Get -Headers @{\"X-JFrog-Art-Api\"=\"${this.jenkins.env.api}\"})" +
                                      ".properties.${propToRetrieve}"
                property = this.jenkins.powershell returnStdout: true, script: scriptString
            }
        }
        return "${property}".trim()
    }

    String getPath(String dir, Map props=[:], String cred) {
        String url = "${this.jenkins.env.ARTIFACTORY_URL ?: this.envArtifactoryURL}" +
                     "/api/versions/${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${dir}?".toString()
        props.each { k, v ->
            url += "${k}=${v}&"
        }
        url += 'listFiles=1'
        String path = ''
        this.jenkins.withCredentials([this.jenkins.string(credentialsId: "${cred}", variable: this.defaultAPI)]) {
            /* groovylint-disable-next-line UnnecessaryGetter */
            if (this.jenkins.isUnix()) {
                String scriptString = "curl -s -H \"X-JFrog-Art-Api:${this.jenkins.env.api}\" -X GET \"${url}\""
                String jsonString = this.jenkins.sh returnStdout: true, script: scriptString
                path = (new JsonSlurper()).parseText(jsonString).artifacts.path
            }
            else {
                String scriptString = "(Invoke-RestMethod -Uri \"${url}\" " +
                                      "-Method Get -Headers @{\"X-JFrog-Art-Api\"=\"${this.jenkins.env.api}\"})" +
                                      '.artifacts.path'
                path = this.jenkins.powershell returnStdout: true, script: scriptString
            }
        }
        return "${path}".trim()
    }

    void publishBuildInfo(String number) {
        this.buildinfo.number = "${number}"
        this.server.publishBuildInfo(this.buildinfo)
    }

    String propertiesMaker(Map props) {
        String properties = ''
        props.each { k, v ->
            properties += "${k}=${v};"
        }
        return properties
    }

    /* groovylint-disable-next-line ParameterCount */
    void upload(String pattern, String target,
                Map props=[:], Boolean opFlag=true, Boolean recursive=true, Boolean flat=true,
                Boolean regexp=false, Boolean explode=false, String excludePatterns='', int retention=30) {
        String properties = propertiesMaker(props)
        String uploadSpec = """{
            "files": [
                {
                    "pattern": "${pattern}",
                    "target": "${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${target}/",
                    "props": "${properties}retention.RetC=${retention}",
                    "recursive": "${recursive}",
                    "flat" : "${flat}",
                    "regexp": "${regexp}",
                    "explode": "${explode}",
                    "excludePatterns": ["${excludePatterns}"]
                }
            ]
        }"""
        this.buildinfo.append(this.server.upload(spec: uploadSpec, failNoOp: opFlag))
    }

    /* groovylint-disable-next-line ParameterCount */
    void download(String pattern, String target='',
                  Map props=[:], Boolean opFlag=true, Boolean recursive=true, Boolean flat=false,
                  String build='', Boolean explode=false, String excludePatterns='') {
        String properties = propertiesMaker(props)
        String downloadSpec = """{
            "files": [
            {
                "pattern": "${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${pattern}/",
                "target": "${target}/",
                "props": "${properties}",
                "recursive": "${recursive}",
                "flat": "${flat}",
                "build": "${build}",
                "explode": "${explode}",
                "excludePatterns": ["${excludePatterns}"]
            }
        ]}"""
        this.server.download(spec: downloadSpec, failNoOp: opFlag)
    }

    void updateProps(String pattern, Map propsOld=[:], Map propsNew=[:]) {
        String propertiesOld = propertiesMaker(propsOld)
        String propertiesNew = propertiesMaker(propsNew)
        String setPropsSpec = """{
            "files": [
            {
                "pattern": "${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${pattern}",
                "props": "${propertiesOld}"
            }
        ]}"""

        /* groovylint-disable-next-line UnnecessarySetter */
        this.server.setProps(spec: setPropsSpec, props: "${propertiesNew}")
    }

    /**
     * Method to get a complete Map of properties for a given artefact. Advantageous over
     * <a href=#method_summary>getProps()</a> when needing to test if a specific property is present.
     * @param artefactPath String of the path to the artefact to get the properties of. Path should start immediately
     * after the repository name.
     * @param cred String credential ID of the Artifactory API key to use.
     * @return Map a map of properties associated with the given artefact.
     */
    Map listProps(String artefactPath, String cred) {
        String url = "${this.jenkins.env.ARTIFACTORY_URL ?: this.envArtifactoryURL}" +
                     "/api/storage/${this.jenkins.env.ARTIFACTORY_REPO ?: this.envArtifactoryRepo}/${artefactPath}?" +
                     'properties'
        String jsonProps = ''
        this.jenkins.withCredentials([this.jenkins.string(credentialsId: "${cred}", variable: this.defaultAPI)]) {
            /* groovylint-disable-next-line UnnecessaryGetter */
            if (this.jenkins.isUnix()) {
                String scriptString = "curl -s -H \"X-JFrog-Art-Api:${this.jenkins.env.api}\" -X GET \"${url}\""
                jsonProps = this.jenkins.sh returnStdout: true, script: scriptString
            }
            else {
                String scriptString = "Invoke-RestMethod -Uri \"${url}\" -Method Get -Headers @{\"X-JFrog-Art-Api\"" +
                                      "=\"${this.jenkins.env.api}\"} | ConvertTo-Json"
                jsonProps = this.jenkins.powershell returnStdout: true, script: scriptString
            }
        }
        return new JsonSlurperClassic().parseText(jsonProps).properties
    }

}
