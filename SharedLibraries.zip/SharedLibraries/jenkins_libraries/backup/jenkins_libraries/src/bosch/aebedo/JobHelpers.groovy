#! /usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import org.ini4j.Ini

/**
 * Library which aids the automation of job creation using a yaml CaC.
 * <h3>Motivation</h3>
 * In order to reliably create jobs based on a project there is the need to streamline the creeation of a job
 * The goal is to identify that configuration during development and have it remain consistent.
 * The idea is then to have the configuration changes as a pull request on a project so that it is easy to review.
 *
 * <h3>Design</h3>
 * A lot of the tool design has been made by the openstack team which utilize python script to create jobs
 * The documentaiton of the tool can be found here : https://docs.openstack.org/infra/jenkins-job-builder/
 * To execute the tool is fairly easy where we need to have blank anaconda python 3.6 and have the repository clone
 * From there we can install the tools dependency using pip and the requirements file within the repository
 * This class ease the build of the .ini configuration which contains the jenkins token credentials
 * This class also in the end streamline the execution of a yaml configruration where the location will be fixed
 * To ensure that the requirements are met it is recommended that setupJobHelpersEnv is ran before executing the tool
 *
 * <h3>Usage</h3>
 * It is fairly easy to execute the class where we may have the baseline yaml defined;
 * <code>
 *      String job_builder_config = "${pwd()}\\pipelines\\_config\\PROJ_job_builder.yml"
 *      job_builder_yaml = readYaml file: "${job_builder_config}"
 *      withEnv(['artifactoryCredId=Jenkins_Tech_User',
 *               'repo=aebe-devops-local',
 *               'jobCreatorArtApi=jev3lr-Art-Api',
 *               'configScm=GitScm',
 *               'scmCredentialId=pk-tech-073rcl',
 *               'scmUrl=https://sourcecode.socialcoding.bosch.com/scm/pk/pk_devops.git',
 *               'configBranch=master',
 *               'jenkinsTokenCredId=jev3lr_jenkins_token']) {
 *           JobHelper = new JobHelpers(this, null, job_builder_yaml)
 *           JobHelper.setupJobHelpersEnv()
 *           JobHelper.executeJobHelpers()
 *      }
 * </code>
 *
 * <h3>Result Example:</h3>
 * By the end of it the total number of jobs that will be created can be shown when executing :
 * <code>
 *     INFO:jenkins_jobs.cli.subcommand.update:Updating jobs in ['final_config.yaml'] ([])
 *     INFO:root:Caching type properties of properties = jenkins_jobs.modules.properties:Properties
 *     INFO:root:Caching type parameters of parameters = jenkins_jobs.modules.parameters:Parameters
 *     INFO:root:Caching type scm of scm = jenkins_jobs.modules.scm:SCM
 *     INFO:root:Caching type triggers of triggers = jenkins_jobs.modules.triggers:Triggers
 *     INFO:jenkins_jobs.builder:Number of jobs generated:  9
 *     ... it will then shows a list of jobs which will be reconfigured
 *     e.g INFO:jenkins_jobs.builder:Reconfiguring jenkins job XYZ ...
 *     ... and ends the execution with a summary on how many number of jobs are actually updated
 *     INFO:jenkins_jobs.cli.subcommand.update:Number of jobs updated: 9
 *     INFO:jenkins_jobs.builder:Number of views generated:  0
 *     INFO:jenkins_jobs.cli.subcommand.update:Number of views updated: 0
 * <code>
 */
class JobHelpers {

    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null
    /** Artifactory folder target where the tool can be found under the devops tools */
    String toolDir = ''
    /** The specific tool version of JJB that will be used */
    String toolVersion = ''
    /** The address on where the jenkins job will be created */
    String jenkinsUrl = ''
    /** Publically available yaml data for injection */
    Object yamlData = null
    /** ArtifactoryHelpers instance to download tool from */
    ArtifactoryHelpers artifactory = null
    /** Public list of jobs to delete */
    List<String> jobListToDelete = []
    /** Jenkins job builder exec script location */
    String scriptLocation = ''
    /** Combined yaml configuration that will be deployed by the job builder */
    final String configurationName = 'final_config.yaml'

    /**
     * Constructor for the JobHelpers class which has the following variable to be set
     * env.repo -> for the artifactory repository for the tools itself
     * env.artifactoryCredId -> for the credentials being used to download the tool
     * env.jobCreatorDir -> determine on which directory the tool is located in artifactory
     * env.jenkinsUrl -> determine on which jenkins instance will be the target (default to rb-jmaas)
     */
    JobHelpers(Object jenkins, ArtifactoryHelpers artifactory=null, Object baseYamlData=null) {
        this.jenkins = jenkins
        this.artifactory = artifactory ?: new ArtifactoryHelpers(this.jenkins, this.jenkins.env.repo,
                                                                 '', this.jenkins.env.artifactoryCredId)
        this.toolDir = this.jenkins.env.jobCreatorDir ?: 'portable/Jenkins_Job_Builder'
        this.jenkinsUrl = this.jenkins.env.jenkinsUrl ?: 'https://rb-jmaas.de.bosch.com/AE-BE'
        this.scriptLocation = this.jenkins.env.scriptLocation ?: 'Jenkins_Job_Builder/Scripts'
        this.yamlData = baseYamlData ?: null
    }

    /**
     * This method download the tool and install the necessary python dependency
     * require toolDir -> Mapped to to where the tool is being stored
     * require toolVersion -> Which version of the tool will be used
     */
    void setupJobHelpersEnv() {
        this.toolVersion = this.jenkins.env.jobCreatorVer ?: this.artifactory.getLatestVersion(this.toolDir, [:],
                                                                              this.jenkins.env.jobCreatorArtApi)
        this.artifactory.download(this.toolDir, './', ['version': this.toolVersion], true, true, true, '', true)
        this.jenkins.dir('Jenkins_Job_Builder') {
            this.jenkins.bat 'python.exe -m pip install -r ./jenkins-job-builder/requirements.txt'
        }
    }

    /**
     * This method will load the project configuration which is a yaml being stored in the project configuration
     * To use the RTCscm mode env.rtcCredentials and the env.configBranch variables needed to be set
     * To use the GitScm mode env.scmCredentialId, env.scmUrl, env.configBranch needed to be set
     * As a common workflow both require jobCreatorYamlCfgLoc, a location of where yaml config will be red as a var
     * If the baseline yaml is not being specified during the class constructor it will read the yaml config as it is
     * otherwise it will add the baseline yaml to the configuration that has been set by the project
     */
    void loadJobHelpersConfig() {
        if (this.jenkins.env.configScm == 'GitScm') {
            GitHelpers gitInstance = new GitHelpers(this.jenkins)
            gitInstance.checkoutUsingGittool(this.jenkins.env.scmCredentialId,
                                             this.jenkins.env.scmUrl, this.jenkins.env.configBranch,
                                             this.jenkins.env.configBranch, false)
        } else if (this.jenkins.env.configScm == 'RTCScm') {
            RtcHelpers rtcHelpers = new RtcHelpers(this.jenkins)
            Map workspacemap = rtcHelpers.getBuildTypeWorkspaceMap(this.jenkins.env.configBranch)
            rtcHelpers.checkoutRtc(workspacemap)
        }
        if (yamlData != null) {
            yamlData += this.jenkins.readYaml file: "${this.jenkins.env.jobCreatorYamlCfgLoc}"
        }
        else {
            yamlData = this.jenkins.readYaml file: "${this.jenkins.env.jobCreatorYamlCfgLoc}"
        }
    }

    /**
     * This method required the class's yamlData to be in a state where it is NOT null.
     * For the execution of job creator .yml file needed to be written which in this case uses the yamlData Object
     * .ini creation will be handled by abstracted execJJB function with the operation `update` using the .yml config
     * which is why it is hardcoded unless specified. By the end of execution jenkins_jobs.ini will be deleted
     * The method will write into a file a final yaml configuration which has all the information and deploy
     * the configuration accordingly this require env variable jenkinsTokenCredId to be set on this end
     */
    void executeJobCreator() {
        this.jenkins.dir(this.scriptLocation) {
            this.jenkins.writeYaml file: this.configurationName, data: this.yamlData
        }
        this.execJJB('update', this.configurationName)
    }

    /**
     * As JJB has numerous functionality this function is the abstracted call to the tool
     * For the execution of the jenkins-jobs-script requires the .ini
     * .ini file contains the username and token and mostly default configuration should not be changed.
     * @param operation currently update and delete are implemented for the operation
     * @param parameter for update it needs the path to the yaml configuration file
     * for delete it needs the absolute path to the job that needed to be deleted
     * e.g execJJB('update', 'YAMLFILELOC'), execJJB('delete', 'PROJECT1/VAR1/onCommit')
     */
    void execJJB(String operation, String parameter='') {
        this.jenkins.dir(this.scriptLocation) {
            Object jenkinsCred = this.jenkins.usernamePassword(credentialsId: this.jenkins.env.jenkinsTokenCredId,
                                                               usernameVariable: 'USER',
                                                               passwordVariable: 'TOKEN')
            this.jenkins.withCredentials([jenkinsCred]) {
                final String commonFalseValue = 'False'
                Ini ini = new Ini(new StringReader(''))
                final Map configData = ['jenkins': ['user': this.jenkins.env.USER
                , 'password': this.jenkins.env.TOKEN, 'url': this.jenkinsUrl, 'query_plugins_info':commonFalseValue]
                , 'job_builder': ['ignore_cache': 'True', 'keep_descriptions': commonFalseValue
                , 'include_path': '.:scripts:~/git/', 'recursive': commonFalseValue, 'update': 'all']]
                configData.each { header, data ->
                    data.each { key, value ->
                        ini.add(header, key, value)
                    }
                }
                Writer copy = new StringWriter()
                ini.store(copy)
                String iniData = copy
                copy = null
                ini = null
                this.jenkins.writeFile file: 'jenkins_jobs.ini', text: "${iniData}"
                this.jenkins.bat """
                ${this.jenkins.env.WORKSPACE}\\Jenkins_Job_Builder\\python.exe ^
                jenkins-jobs-script.py --conf jenkins_jobs.ini ${operation} ${parameter}
                """
                this.jenkins.bat 'del /q jenkins_jobs.ini'
            }
        }
    }

}
