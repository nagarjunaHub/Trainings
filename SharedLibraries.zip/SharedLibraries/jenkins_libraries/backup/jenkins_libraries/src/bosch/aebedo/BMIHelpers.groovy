#!/usr/bin/env groovy
 /**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

/**
 * Download the BMI.csv from your Metrics Repository on Artifactory.
 * Adjust the paths if necessary collect_metrics_path is the path where the
 * collect_metrics.py should be located (from artifactory downloaded)
 * bmifile_path is the path to the BMI file which should as well be downloaded
 * from artifactory
 * This function will execute a python script and return the status according
 * to the BMI value to the pipeline.
 */

class BMIHelpers {

    Object jenkins = null
    BMIHelpers(Object jenkins) {
        this.jenkins = jenkins
    }

    Integer calcBMI(String collectMetricsPath, String bmifilePath) {
        Integer bmiMetric = 0
        this.jenkins.dir("${collectMetricsPath}") {
            bmiMetric = this.jenkins.bat( returnStatus: true, script:
            "python collect_metrics.py --bmifile ${bmifilePath}") as Integer
        }
        return bmiMetric
    }

    String setResult(Integer bmiMetric) {
        if (bmiMetric == -1) {
            this.jenkins.currentBuild.result = 'UNSTABLE'
            } else if (bmiMetric == 1) {
            this.jenkins.currentBuild.result = 'FAILURE'
            } else {
            this.jenkins.currentBuild.result = 'SUCCESS'
            }
        return this.jenkins.currentBuild.result
    }

}
