#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import groovy.util.slurpersupport.GPathResult
import groovy.json.JsonBuilder
import org.codehaus.groovy.control.ConfigurationException

/**
 * Library which aids pipeline execution.
 * <h3>Motivation<h3/>
 * A class with general functions needed in the pipelines
 * <h3>Usage</h3>
 * In this case the library used extensively when preparing parallel stages
 * <code>
 *      parallel_stages_def = [<br/>
 *          'Build Package' : aebe_devops.mergeStageDescriptors([buildStage]),<br/>
 *          'Unittest' : aebe_devops.mergeStageDescriptors([unittestStage]),<br/>
 *          'Extra Tests' : aebe_devops.mergeStageDescriptors([extraTestsStage]),<br/>
 *          'Static Code Analysis': aebe_devops.mergeStageDescriptors([staticCodeAnalysisStage])<br/>
 *      ]<br/>
 *      parallel_stages = aebe_devops.prepareParallelStages('Checks', parallel_stages_def, env)<br/>
 *      parallel(parallel_stages)<br/>
 * </code>
 * wrapStageWithNode
 * Is used to run a stage in a specific node
 *
 * pathJoin
 * Is used to create a string for a path which can be used in Jenkins
 *
 * mergeStageDescriptor
 **
 */

class AebeDevOps {

    static CustomStage mergeStageDescriptors(CustomStage stages) {
        return mergeStageDescriptors([stages])
    }

    static CustomStage mergeStageDescriptors(List<CustomStage> stages) {
        CustomStage merged = new CustomStage()
        stages.each { override ->
            merged.node = override.node ?: merged.node
            merged.skip = override.skip != false
            merged.setup = override.setup ?: merged.setup
            merged.teardown = override.teardown ?: merged.teardown
            merged.stageMethod = override.stageMethod ?: merged.stageMethod
        }
        return merged
    }

    Object jenkins
    AebeDevOps(Object jenkins) {
        this.jenkins = jenkins
    }

    String pathJoin(List<String> directories) {
        String concat = ''
        /* groovylint-disable-next-line UnnecessaryGetter */
        String delimiter = this.jenkins.isUnix() ? '/' : '\\'
        directories.eachWithIndex { dir, index ->
            concat += (index == directories.size() - 1) ? dir : (dir + delimiter)
        }
        return concat
    }

    /**
    * Returns the separator used in $env.PATH to separate the directories.
    * ":" on Unix, ";" on windows slaves.
    */
    String getEnvPathSeparator() {
        /* groovylint-disable-next-line UnnecessaryGetter */
        return this.jenkins.isUnix() ? ':' : ';'
    }

    /**
     * Transform a typical xmlslurper object into a map with list of hasmaps.
     * This puts the data to be easier to parsed and transformed into yml or json.
     * @param reportInst Object an XmlSlurper object to be transformed into a simple List of HashMap
     * @return List easier manipulation of hash map list will be easier to transform.
     */
    Map gpathMapTransformer(GPathResult reportInst) {
        Map finalData = [:]
        reportInst.each { child ->
            List<HashMap> childrenData = []
            child.children().each { element ->
                Map map = [(element.name()) : this.intermediateEntries(element)]
                childrenData += map
            }
            finalData.put(child.name(), childrenData)
        }
        return finalData
    }

    Map intermediateEntries (Object element) {
        Map map = element.children().collectEntries { entry ->
            [(entry.name()) : { -> entry.children() ?.collectEntries(owner) ?: entry.text() } () ]
        }
        return map
    }

    /*
     * Output the the transformed map to the desired configuration file
     * Allows for different format to be output to a specified file
     * @param finalData List data to be written to a file
     * @param format String the desired data format being produced by the function
     *        supported format yaml and json configuration file
     */
    void writeMapToConfig(Map finalData, String fileName='report', String format='yaml') {
        String fileTarget = "${fileName}.${format}"
        switch (format) {
            case 'yaml':
                this.jenkins.writeYaml file: fileTarget, data: finalData
                break
            case 'json':
                Object config = this.jenkins.readJSON text: new JsonBuilder(finalData).toPrettyString()
                this.jenkins.writeJSON json: config, file: fileTarget
                break
            default:
                throw new ConfigurationException("${format} is not supported.")
        }
    }

    // return a map that can be used in a parallel(...) step.
    // This function ensures, that the stages are shown correct in the job view.
    // Input is a map with the name of the stages as key and the groovy script
    // that is loaded dynamically as value.
    Object prepareParallelStages(String parallelStageName, Map<String, CustomStage> customStages) {
        this.jenkins.parallelStages = [:]
        customStages.each { stageName, stageArg ->
            this.jenkins.parallelStages.put stageName, {
                wrapStageWithNode("${parallelStageName}: ${stageName}", stageArg)
            }
        }
        return this.jenkins.parallelStages
    }

    Object wrapStageWithNode(String stageName, CustomStage customStage) {
        if (customStage.skip) {
            return
        }
        if (customStage.node) {
            return this.jenkins.node(customStage.node) {
                this.prepareStage(stageName, customStage)
            }
        }
        return this.prepareStage(stageName, customStage)
    }

    private Object prepareStage(String stageName, CustomStage customStage) {
        return this.jenkins.stage(stageName) {
            if (customStage.setup) {
                try {
                    customStage.setup(this.jenkins.env)
                } catch (NoSuchMethodError | MissingMethodException e) {
                    customStage.setup()
                }
            }
            if (customStage.stageMethod) {
                try {
                    customStage.stageMethod(this.jenkins.env)
                } catch (NoSuchMethodError | MissingMethodException e) {
                    customStage.stageMethod()
                }
            }
            if (customStage.teardown) {
                try {
                    customStage.teardown(this.jenkins.env)
                } catch (NoSuchMethodError | MissingMethodException e) {
                    customStage.teardown()
                }
            }
        }
    }

}
