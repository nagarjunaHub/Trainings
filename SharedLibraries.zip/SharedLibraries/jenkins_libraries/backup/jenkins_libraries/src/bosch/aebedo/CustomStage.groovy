#! /usr/bin/env groovy
/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

/**
 * Library which aids general setup for stages.
 * <h3>Motivation</h3>
 * This class is used as a generic setup for stages.
 * This ensures that the JenkinsFile for the project is compact for a common or well defined stages in a Jenkins job.
 * Custom stage also added customization on the defined stages and introduce override.
 * E.g. When a project would like to run their own teardown method with extra debugging functionality.
 * Thus it is possible to only override the teardown method leave the setup and stage_method to the default function.
 *
 * <h3>Usage</h3>
 * In a project Jenkins file functions for stages can be defined.</br>
 * This function will be used as closures for the stage creation:</br>
 * <code>
 *      CustomStage buildStage = new bosch.aebedo.CustomStage(setup: this.&override_build_setup,<br/>
 *                                                            stageMethod: this.&override_build,<br/>
 *                                                            teardown: this.&override_build_teardown)<br/>
 * <code>
 * Here a buildStage is created with setup, stage an teardown. Its also possible just to use a stage.
 */

class CustomStage implements Serializable {

    private static final long serialVersionUID = 1234L
    boolean skip
    String node
    Closure setup
    Closure teardown
    Closure stageMethod
    final String[] allowedKeyWords = ['skip', 'node', 'setup', 'teardown', 'stageMethod']

    CustomStage(Map params = [:]) {
        params.keySet().each { key ->
            if (!allowedKeyWords.contains(key)) {
                throw new GroovyRuntimeException("'${key}' not a valid parameter")
            }
        }
        String skipStage = allowedKeyWords[0]
        this.node = params.getOrDefault(allowedKeyWords[1], '')
        this.setup = params.getOrDefault(allowedKeyWords[2], null)
        this.teardown = params.getOrDefault(allowedKeyWords[3], null)
        this.stageMethod = params.getOrDefault(allowedKeyWords[4], null)
        if (this.setup == null && this.teardown == null && this.stageMethod == null) {
            this.skip = params.getOrDefault(skipStage, true)
        }
        else {
            this.skip = params.getOrDefault(skipStage, false)
        }
    }

}
