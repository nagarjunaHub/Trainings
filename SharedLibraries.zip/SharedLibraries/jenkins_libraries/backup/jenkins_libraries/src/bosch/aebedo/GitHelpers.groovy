#! /usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import hudson.tools.ToolInstallation
import hudson.tools.ToolDescriptor

class GitHelpers {

    Object jenkins = null
    AebeDevOps aebedoHelpers = null
    private final String gitTool = ''
    /**
    * The class needs an instance of the actual Jenkinsfile
    * (aka WorkflowScript) in which context the code is executed.
    *
    * @see <a href="https://github.com/jenkinsci/workflow-cps-plugin">workflow-cps
        </a>
    */
    GitHelpers(Object jenkins) {
        this.jenkins = jenkins
        /* groovylint-disable-next-line UnnecessaryGetter */
        this.gitTool = this.jenkins.isUnix() ? 'Default' : 'si-z667r_buildslaves'
        this.aebedoHelpers = new AebeDevOps(this.jenkins)
    }

    /**
    * Return the name of the git tool used in Jenkins.
    * The selection of the git tool bases on the node of execution.
    * <br /><br />
    * !<b>FIXME</b>: currently the selection is hardcoded
    */
    String getGitTool() {
        return gitTool
    }

    /**
    * Returns a String with all paths from the environment and the
    * path to the git tool concatenated. Intention is to be used
    * in the withEnv statement like this:
    * <code>
        withEnv(["PATH=${getPathIncludingGit()}"]) { ... }
      </code>
    */
    String getPathIncludingGit() {
        String gitToolPath = "${this.jenkins.env.PATH}"
        for (ToolDescriptor desc : ToolInstallation.all()) {
            desc.installations.each { inst ->
                if (inst.name == this.gitTool) {
                    /* groovylint-disable-next-line UnnecessaryGetter */
                    String gitExecutable = this.jenkins.isUnix() ? 'git' : 'git.exe'
                    // getHome returns the absolute path to the executable.
                    // For the path we have to strip the name of the executable and the
                    // directory concatenator character in a path. Some tools
                    // can't handle the extra character in the path.
                    gitToolPath = inst.home[0 .. inst.home.length() - gitExecutable.length() - 2]
                    gitToolPath += "${this.aebedoHelpers.envPathSeparator}${this.jenkins.env.PATH}"
                }
            }
        }
        return gitToolPath
    }

    /**
    * Get the name of the source branch based on input parameter or jenkinsfile environment.
    * <br /><br />
    * Helper function for {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * to prepare the jenkins checkout step introduced with the
    * {@link <a href="https://plugins.jenkins.io/workflow-scm-step">workflow SCM step</a> plugin.
    * This function can be unit tested, while the function
    * {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * can not be tested easily (due to the plugin step).
    */
    String getFinalSourceBranch(final String branchname = '') {
        return branchname ?: "${this.jenkins.env.CHANGE_BRANCH ?: this.jenkins.env.BRANCH_NAME}"
    }

    /**
    * Get the name of the target branch based on input parameter or jenkinsfile environment.
    * <br /><br />
    * Helper function for {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * to prepare the jenkins checkout step introduced with the
    * {@link <a href="https://plugins.jenkins.io/workflow-scm-step">workflow SCM step</a> plugin.
    * This function can be unit tested, while the function
    * {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * can not be tested easily (due to the plugin step).
    */
    String getFinalTargetBranch(final String branchname = '') {
        return branchname ?: "${this.jenkins.env.TARGET_BRANCH ?: this.jenkins.env.BRANCH_NAME}"
    }

    /**
    * Get the used extensions for the checkout step.
    * <br /><br />
    * Helper function for {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * to prepare the jenkins checkout step introduced with the
    * {@link <a href="https://plugins.jenkins.io/workflow-scm-step">workflow SCM step</a> plugin.
    * This function can be unit tested, while the function
    * {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * can not be tested easily (due to the plugin step).
    */
    List getCheckoutExtensions(final String targetBranch='', boolean mergeWithTargetBranch=true,
                               GitHelpers gitInstance=this) {
        List checkoutExtensions =   [[$class: 'UserIdentity',
                                      email: 'ae-be-jenkins-noreply@bosch.com',
                                      name: 'jenkins automation'],
                                    ]
        if (mergeWithTargetBranch) {
            checkoutExtensions +=   [$class: 'PreBuildMerge',
                                     options: [mergeRemote: 'origin',
                                               mergeTarget: gitInstance.getFinalTargetBranch(targetBranch)
                                              ]
                                    ]
        }
        return checkoutExtensions
    }

    /**
    * Get the used extensions for the checkout step.
    * <br /><br />
    * Helper function for {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * to prepare the jenkins checkout step introduced with the
    * {@link <a href="https://plugins.jenkins.io/workflow-scm-step">workflow SCM step</a> plugin.
    * This function can be unit tested, while the function
    * {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * can not be tested easily (due to the plugin step).
    */
    Map getScmStepParameters(final String credentialsId, final String repositoryURL,
                             boolean mergeWithTargetBranch, GitHelpers gitInstance=this) {
        return gitInstance.getScmStepParameters(credentialsId, repositoryURL,
                                                '', '', mergeWithTargetBranch)
    }
    /**
    * Get the used extensions for the checkout step.
    * <br /><br />
    * Helper function for {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * to prepare the jenkins checkout step introduced with the
    * {@link <a href="https://plugins.jenkins.io/workflow-scm-step">workflow SCM step</a> plugin.
    * This function can be unit tested, while the function
    * {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * can not be tested easily (due to the plugin step).
    */
    Map getScmStepParameters(final String credentialsId, final String repositoryURL,
                             final String sourceBranch, boolean mergeWithTargetBranch,
                             GitHelpers gitInstance=this) {
        return gitInstance.getScmStepParameters(credentialsId, repositoryURL, sourceBranch, '', mergeWithTargetBranch)
    }
    /**
    * Get the used extensions for the checkout step.
    * <br /><br />
    * Helper function for {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * to prepare the jenkins checkout step introduced with the
    * {@link <a href="https://plugins.jenkins.io/workflow-scm-step">workflow SCM step</a> plugin.
    * This function can be unit tested, while the function
    * {@link bosch.aebedo.GitHelpers#checkoutUsingGittool checkoutUsingGittool}
    * can not be tested easily (due to the plugin step).
    */
    /* groovylint-disable-next-line ParameterCount */
    Map getScmStepParameters(final String credentialsId, final String repositoryURL,
                             final String sourceBranch='', final String targetBranch='',
                             boolean mergeWithTargetBranch=true, GitHelpers gitInstance=this) {
        return [$class: 'GitSCM',
                branches: [[name: gitInstance.getFinalSourceBranch(sourceBranch)]],
                extensions: gitInstance.getCheckoutExtensions(targetBranch, mergeWithTargetBranch),
                gitTool: gitInstance.gitTool,
                userRemoteConfigs: [[credentialsId: credentialsId,
                                     url: repositoryURL
                                    ]]
                ]
    }

    /**
    * Perform the checkout scm step of jenkins with
    * the correct git tool in this context. The git tool
    * is selected automatically using the method
    * {@link bosch.aebedo.GitHelpers#getGitTool getGitTool}.
    * @param credentialsId jenkins credentials id being used to authenticate to the repository
    * @param repositoryUrl remote url to the target repository
    * @param sourceBranch branch location used as refference branch when loading
    * @param targetBranch branch location used as the merge target
    * @param mergeWithTargetBranch default true, perform branch from source to target
    *                                       false, not perform branch merge to the specified target
    * @param changelogFlag default true, will show changelog as the repository being checkedout by jenkins
                                   false, does not show changelog as the repository being checkedout by jenkins
    * @param pollingFlag default true, will trigger the pipeline for changes made to the sourceBranch
    *                            false, will not trigger the pipeline for changes made to the sourceBranch
    */
    /* groovylint-disable-next-line ParameterCount */
    void checkoutUsingGittool(final String credentialsId, final String repositoryURL,
                              final String sourceBranch='', final String targetBranch='',
                              boolean mergeWithTargetBranch=true, boolean changelogFlag=true,
                              boolean pollingFlag=true, GitHelpers gitInstance=this) {
        gitInstance.jenkins.checkout changelog: changelogFlag, poll: pollingFlag,
                                     scm: gitInstance.getScmStepParameters(credentialsId, repositoryURL,
                                                                           sourceBranch, targetBranch,
                                                                           mergeWithTargetBranch)
    }

}
