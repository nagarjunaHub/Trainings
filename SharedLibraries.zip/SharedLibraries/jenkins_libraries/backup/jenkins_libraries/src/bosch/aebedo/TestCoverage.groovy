#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import groovy.json.JsonSlurper

/**
 * Library which aids generation of tracebility report.
 * <h3>Motivation</h3>
 * In order to show the traceability between requirements and test results,
 * Test coverage class will generate a report which shows which requirements
 * has been tested based on a test case execution record.<br/>
 * With the current tool-chain this can be reached by having Doors as the
 * central directive for requirement and RQM as the test data result.
 *
 * The Doors requirement link to RQM is linked by a `validatedBy` link.
 * The tools then perform the traceability check which are:<br/>
 * Doors ( whether it is SysRS, SRS, Software Module etc ) → RQM : Test Case →  RQM : Test Case Execution Record (TCER)
 * given a Timeline (Linked Test Plan) and Test environment.
 * This will then give evidence whether the requirements has passed, failed and never tested.
 *
 * <h3>Usage</h3>
 * In order to use the TestCoverage object and it's default methods,<br/>
 * the following list of environment variables must be passed in (unless otherwise specified):
 * <ul>
 *      <li>artifactoryProject - Project specific Artifactory server name as per Jenkins configuration</li>
 *      <li>dispName - Name of the pipeline build to be displayed</li>
 *      <li>repo - Name of Artifactory repository to be used</li>
 *      <li>domain - Project high level name, e.g. "PK"</li>
 *      <li>project - Project within the domain, e.g. "SVW"</li>
 *      <li>api - Artifactory API credential of the technical user</li>
 *      <li>BUILDWORKSPACE - buildworkspace to retrieve for the project configuration
 *      <li>loadRulePath - load rule location to retrieve the project configuration from
 *      <li>rtcCredentials - Credential of the technical user for SCM where config is kept</li>
 *      <li>rqmCredId - SCM repository name where config is kept</li>
 *      <li>drsCredId - Credential to run MeGenJa (only required if MeGenJa is used)</li>
 *      <li>bartJsonCfg - Simple json variable which has key for the export.ini and configFile.ini
                          (without the .ini extension)</li>
 *      <li>tstIter - test iteration to identify when performing the coverage analysis
 *      <li>bartCfgLoc - location where the configuration is located in RTC</li>
 *      <li>failMail - Optional: list of email address(es) to be notified if the pipeline fails</li>
 * </ul>
 * When calling the default methods,<br/>
 * the following parameters may be optionally passed in to further <br/>
 * tailor the pipeline to the project: (brackets denote default setting) <br/>
 * <ul>
 *      <li>toolVersion - Version of BART to use (latest release)</li>
 *      <li>reportName - Report to be zipped and name as (DISP_NAMAE_TestCov_Report.zip)</li>
 *      <li>resultFolder - Folder to store the final result of the analysis will be packaged
                           from (RESULT) where the name does not clash</li>
 * </ul>
 * As explained on the library overview there is always a var hook to a class under test_coverage.groovy
 * As with the library import the call to the test_coverage object only requires a this pointer.
 * From there the standard call within the vars will be able to access the required reference to certain functions
 * such as git , sh , dir etc.
 * <code>
 *      @Library('AEBEDevops') _<br/>
 *      node('...') {<br/>
 *          timepstamps {<br/>
 *              withEnv('...') {<br/>
 *                  TestCoverage testCov = new TestCoverage(this)<br/>
 *              }<br/>
 *          }<br/>
 *      }<br/>
 * </code>
 *
 * <h3>Result Example</h3>
 * One of the important aspect in this report generation is the filtering being set under the corresponding `.ini` file.
 * NOTE : Wrong xx_configFile.ini and xx_export.ini pair CAN lead to wrong count of the metrics.
 * The current result (without exposing the requirements of a project) is a basic graphs showing what feature has been
 * validated by the test case execution record.
 */

class TestCoverage {

    static final List ALLOWED_KEY_WORDS = ['executeTestCov']
    String reportFile = ''
    String resultFolder = ''
    /** ArtifactoryHelpers instance to upload the report to */
    ArtifactoryHelpers artifactory = null
    /** AebeDevOps instance for common utility access */
    AebeDevOps aebedoHelpers = null
    /** RTCHelpers instance for the project configuration */
    RtcHelpers rtcHelpers = null
    /** Map containing the key and value to iterate on the config*/
    Map<String, String> configMap = [:]
    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null

    /**
     * Constructor for the TestCoverage class.
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     * @param artifactory Optional artifactory instance to upload the data to
     */
    TestCoverage(Object jenkins, ArtifactoryHelpers artifactory=null ) {
        this.jenkins = jenkins
        this.artifactory = artifactory ?: new ArtifactoryHelpers(this.jenkins, this.jenkins.env.repo,
                                                                 this.jenkins.env.artifactoryProject)
        this.aebedoHelpers = new AebeDevOps(this.jenkins)
        this.rtcHelpers = new RtcHelpers(this.jenkins)
        this.reportFile = this.jenkins.env.reportName ?: "${this.jenkins.env.dispName}_TestCov_Report.zip"
        this.resultFolder = this.jenkins.env.resultFolder ?: 'RESULT'
    }

    /**
     * Setup method for TestCoverage
     * The method will download the necessary tool and also the configuration from the project
     */
    void setupTestCovEnv() {
        ArtifactoryHelpers toolArtifactory = new ArtifactoryHelpers(this.jenkins, 'aebe-devops-local', 'CI_Artifactory')
        String toolDir = 'Tools/BART'
        String toolVersion = this.jenkins.env.toolVersion ?: toolArtifactory.getLatestVersion(toolDir, [:],
                                                                                              this.jenkins.env.api)
        toolArtifactory.download(toolDir, './', ['version': toolVersion], true, true, true, '', true)
        this.jenkins.bat('mkdir tmp')

        rtcHelpers.checkoutRtc(rtcHelpers.getBuildTypeWorkspaceMap(this.jenkins.env.BUILDWORKSPACE))
        String srcDirectory = this.aebedoHelpers.pathJoin([this.jenkins.pwd(), this.jenkins.env.bartCfgLoc])
        this.jenkins.bat "move ${srcDirectory} ."
    }

    /**
     * Execute method for TestCoverage
     * The method will execute the necessary tool which uses the configuration from the project
     */
    void executeTestCov() {
        this.configMap = new HashMap<>((new JsonSlurper()).parseText(this.jenkins.env.bartJsonCfg))
        for (Map.Entry configPair : this.configMap.entrySet()) {
            executeBartGivenKeyVal(configPair.key, configPair.value)
        }
        this.jenkins.zip dir: resultFolder, zipFile: this.reportFile
    }

    /**
     * Upload method for TestCoverage
     * The method will upload the report file to the desired artifactory destination
     */
    void uploadTestCov() {
        String bartArtUploadDest = "${this.jenkins.env.project}/Bart/${this.jenkins.env.dispName}/"
        String artifactoryUploadPath = this.jenkins.env.uploadPath ?: bartArtUploadDest
        this.artifactory.upload(this.reportFile, artifactoryUploadPath,
                                [ 'build.number' : "${this.jenkins.env.dispName}" ])
        this.artifactory.publishBuildInfo(this.jenkins.env.dispName)
    }

    /**
     * Entry Execute method for TestCoverage analysis using BART tools
     * The method will execcute the analsis based on given export key and configFile value
     * By the end of the execution the report data will be moved into the specified result folder
     * In this case the data neeeded to be moved as the report will be cleared on the next execution
     * @param exportFile export configuration required for analysis e.g (XX_export)
     * @param configFile configFile configuration required for analysis e.g (XX_configFile)
     */
    void executeBartGivenKeyVal(String exportFile, String configFile) {
        Object rqmCred = this.jenkins.usernamePassword(credentialsId: "${this.jenkins.env.rqmCredId}",
                                                        passwordVariable: 'rqmPassword',
                                                        usernameVariable: 'rqmUsername')
        Object drsCred = this.jenkins.usernamePassword(credentialsId: "${this.jenkins.env.drsCredId}",
                                                        passwordVariable: 'drsPassword',
                                                        usernameVariable: 'drsUsername')
        this.jenkins.withCredentials([ rqmCred, drsCred ]) {
            String comnPath = this.jenkins.env.bartConfigDest
            this.jenkins.bat """
            ${this.jenkins.env.bartPythonPath} ./src/general.py export \"${this.jenkins.env.tstIter}\" ^
            \"./${comnPath}/${configFile}.ini\" -exi \"./${comnPath}/${exportFile}.ini\" ^
            -ru ${this.jenkins.env.rqmUsername} -rp ${this.jenkins.env.rqmPassword} ^
            -du ${this.jenkins.env.drsUsername} -dp ${this.jenkins.env.drsPassword} -std-s -cust-s
            """
        }
        String srcDirectory = this.aebedoHelpers.pathJoin([this.jenkins.pwd(), 'output'])
        String tmpDirectory = this.aebedoHelpers.pathJoin([this.jenkins.pwd(), 'tmp'])
        String dstDirectory = this.aebedoHelpers.pathJoin([this.jenkins.pwd(), resultFolder, exportFile])
        this.jenkins.dir("${resultFolder}/${exportFile}") {
            this.jenkins.bat """
            @echo off
            robocopy ${srcDirectory} ${dstDirectory} /s /NFL
            if %errorlevel% geq 8 exit /b 1
            robocopy ${tmpDirectory} ${dstDirectory} /s /NFL
            if %errorlevel% geq 8 exit /b 1
            exit /b 0
            """
        }
    }

}
