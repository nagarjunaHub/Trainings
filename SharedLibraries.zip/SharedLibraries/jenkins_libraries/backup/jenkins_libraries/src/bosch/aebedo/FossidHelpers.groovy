#! /usr/bin/env groovy
/**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import org.codehaus.groovy.control.ConfigurationException
import groovy.json.JsonSlurperClassic
import groovy.json.JsonOutput
import java.text.SimpleDateFormat

/**
 * Library to aid the pipeline automatation for FossID Open Source Software scanning.<br/>
 * Using FossID's REST api, this library provides a means to call common FossID operations from the pipeline,
 * including creating new projects and scans, uploading compressed source code, running scans and generating reports.
 * This library can also upload the reports it generates to Artifactory.
 * A key feature of this library and a main motivation behind its creation is to provide a means to interface the
 * FossID API with powershell. This succeeds alternatives such as using the Jenkins REST plugin or using groovy's
 * URL openConnection which can add dependencies and security vunerabilities to the pipeline.
 */
class FossidHelpers {

    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null
    /** Fossid server to connect to. Will be set to 'https://rb-fossid.de.bosch.com/AE' if the fossidServer
     * variable is not otherwise passed to the constructor.*/
    String server = 'https://rb-fossid.de.bosch.com/AE'
    /** Jenkins credentials ID to connect to the Fossid server with. Must be set with the fossidCredentials
     * variable passed to the constructor.*/
    String credentials = ''
    /** Project Code from the FossID server to use. If one is not set with the fossidProjectCode variable passed to the
    * constructor, the project code 'Auto_upload_project' will be used.*/
    String projectCode = ''
    /** Scan Code from the FossID server to use. If one is not set with the fossidScanCode variable passed to the
    * constructor, the scan code 'Auto_scan' will be used.*/
    String scanCode = ''
    /** Scan Name from the FossID server to use. If one is not set with the fossidScanName variable passed to the
    * constructor, the scanCode variable will be used.*/
    String scanName = ''
    /** Reuse Identification, Boolean value to define if previous identifications should be reused.Default is true.*/
    Boolean reuseIdentification = true
    /** Reuse Identification Type comes along with reuse Identification parameter. Defines where identifications
    * should be reused from. Default is specific_project*/
    String reuseType = 'specific_project'
    /** Specific Project Code from the FossID server to use. Can be set to a specific Project Code. If not set the
    * Project Code variable will be used.*/
    String specificProjectCode = ''

    private final String scanApiGroup = 'scans'
    private final String projectApiGroup = 'projects'
    private final String timeoutUnits = 'MINUTES'
    private final String sleepUnits = 'SECONDS'
    private final String userVar = 'user'
    private final String passVar = 'pass'

    /**
     * @deprecated
     *
     * Constructor for the FossidHelpers class.
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     * (aka WorkflowScript) in which context the code is executed.
     * @param fossidCredentials String Jenkins credentials ID to connect to the Fossid server with.
     * @param fossidProjectCode String Project Code from the FossID server to use.
     * @param fossidScanCode String Scan Code from the FossID server to use.
     * @param fossidScanName String Scan Name from the FossID server to use. Set by default to the fossidScanCode
     * variable.
     * @param fossidServer String Fossid server to connect to. Set by default to 'https://rb-fossid.de.bosch.com/AE'.
     */
    /* groovylint-disable-next-line ParameterCount */
    FossidHelpers(Object jenkins, String fossidCredentials, String fossidProjectCode,
                  String fossidScanCode, String fossidScanName='',
                  String fossidServer='https://rb-fossid.de.bosch.com/AE',
                  String identificationReuseType='specific_project', String specificCode = '') {
        this.jenkins = jenkins
        this.server = fossidServer
        this.credentials = fossidCredentials
        this.projectCode = fossidProjectCode
        this.scanCode = fossidScanCode
        this.scanName = fossidScanName ?: this.scanCode
        this.reuseType = identificationReuseType
        this.specificProjectCode = specificCode ?: this.projectCode
    }

    FossidHelpers(Object jenkins, String fossidCredentials, String fossidProjectCode,
                  String fossidScanCode, Map props) {
        this.jenkins = jenkins
        this.credentials = fossidCredentials
        this.projectCode = fossidProjectCode
        this.specificProjectCode = fossidProjectCode
        this.scanCode = fossidScanCode
        this.scanName = fossidScanCode
        props.each { name, val ->
            this.setProperty(name, val)
        }
    }

    /** Setup a FossID project scan given the projectCode, scanCode and scanName. If the project or scan does not
    * exist it will be created.
    * @param projectName String name of the project. Will be set to the projectCode is not specified.
    */
    void setupProjectScan(String projectName=this.projectCode) {
        String createAction = 'create'
        String errorExc = 'already exists'
        this.fossidIrmApi(this.projectApiGroup, createAction, [project_code: this.projectCode,
                                                     project_name: projectName,], errorExc)

        this.fossidIrmApi(this.scanApiGroup, createAction, [project_code: this.projectCode,
                                                            scan_code: this.scanCode,
                                                            scan_name: this.scanName,], errorExc)
    }

    /** Upload compressed source code and extract it once on the FossID server.
    * @param srcFile String zip file name to upload
    * @param timeoutMin Integer minutes to wait while the compressed source code is extracted. Set to 30 by default.
    * @param sleepSecs Integer seconds to sleep while the compressed source code is extracted. Set to 60 by default.
    */
    void uploadExtractSource(String srcFile, Integer timeoutMin=30, Integer sleepSecs=60) {
        this.jenkins.withCredentials([this.jenkins.usernameColonPassword(credentialsId: this.credentials,
                                                                         variable: 'userpass'),]) {
            String psUpload = "irm -Uri ${this.server}/api_upload_endpoint.php -Method Post -Headers " +
                              "@{Authorization=('Basic {0}' -f '${this.jenkins.env.userpass.bytes.encodeBase64()}');" +
                              "'FOSSID-SCAN-CODE'='${scanCode.bytes.encodeBase64()}';'FOSSID-FILE-NAME'='" +
                              "${srcFile.bytes.encodeBase64()}'} -InFile ${srcFile}"
            this.jenkins.powershell returnStdout: true,
                                    script: psUpload
        }

        this.jenkins.timeout(time: timeoutMin, unit: this.timeoutUnits) {
            String extractApiAction = 'extract_archives'
            Map response = this.fossidIrmApi(this.scanApiGroup, extractApiAction, [project_code: this.projectCode,
                                                                                   scan_code: this.scanCode,
                                                                                   scan_name: this.scanName,])
            while (response.message != 'Archives found: No') {
                this.jenkins.sleep(time: sleepSecs, unit: this.sleepUnits)
                response = this.fossidIrmApi(this.scanApiGroup, extractApiAction, [project_code: this.projectCode,
                                                                                   scan_code: this.scanCode,
                                                                                   scan_name: this.scanName,])
            }
        }
    }

    /** Execute the FossID scan of the uploaded source code given the projectCode, scanCode and scanName.
    * @param autoDeclaration Boolean scan option to automatically detect license declaration inside files. True by
    * default.
    * @param autoCopyright Boolean scan option to automatically detect copyright statements inside files. True by
    * default.
    * @param deltaScan Boolean scan option to scan only newly added files (delta) or all files. True (delta scan) by
    * default.
    * @param timeoutMin Integer minutes to wait while the scan is run. Set to 60 by default.
    * @param sleepSecs Integer seconds to sleep while the scan is run. Set to 60 by default.
    * Inside the scan: reuse_identification Boolean scan option to automatically reuse previous identified files.
    * True by default. This parameter requires two more parameters, identification_reuse_type which is
    * 'specific_project' by default and specific_code which has to be the name of the project (projectCode).
    */
    void runScan(Boolean autoDeclaration=true, Boolean autoCopyright=true, Boolean deltaScan=true,
                 Integer timeoutMin=60, Integer sleepSecs=60) {
        this.fossidIrmApi(this.scanApiGroup, 'run', [project_code: this.projectCode,
                                                     scan_code: this.scanCode,
                                                     scan_name: this.scanName,
                                                     auto_identification_detect_declaration: autoDeclaration ? '1'
                                                                                                             : '0',
                                                     auto_identification_detect_copyright: autoCopyright ? '1' : '0',
                                                     delta_only: deltaScan ? '1' : '0',
                                                     reuse_identification: reuseIdentification ? '1' : '0',
                                                     identification_reuse_type: this.reuseType,
                                                     specific_code: this.specificProjectCode,])

        this.jenkins.timeout(time: timeoutMin, unit: this.timeoutUnits) {
            String statusApiAction = 'check_status'
            String scanType = 'SCAN'
            Map response = this.fossidIrmApi(this.scanApiGroup, statusApiAction, [scan_code: this.scanCode,
                                                                                  type: scanType,])

            while (response.data.is_finished == '0') {
                this.jenkins.sleep(time: sleepSecs, unit: this.sleepUnits)
                response = this.fossidIrmApi(this.scanApiGroup, statusApiAction, [scan_code: this.scanCode,
                                                                                  type: scanType,])
            }
        }
    }

    /** Generate a FossID report for a given scanCode.
    * @param reportFile String file name of the report, including extension and path (if required). Report will be
    * generated in this location.
    * @param reportType String type of report to be generated. Valid options are: html, dynamic, xlsx or spdx.
    * Set to 'xlsx' by default.
    * @param selctionType String scan selection to include in the report. Valid options are: include_foss,
    * include_marked_licenses, include_copyleft or include_all_licenses. Set to 'include_all_licenses' by default.
    * @param selectionFilter Filter what is selected for the report. Valid options are: no filter (empty string),
    * pending_identification or marked_as_identified. Set to no filter (empty string) by default.
    */
    void generateReport(String reportFile, String reportType='xlsx', String selectionType='include_all_licenses',
                        String selectionFilter='') {
        List validReportTypes = ['html', 'dynamic', 'xlsx', 'spdx']
        List validSelectionTypes = ['include_foss', 'include_marked_licenses',
                                    'include_copyleft', 'include_all_licenses']
        List validSelectionFilters = ['', 'pending_identification', 'marked_as_identified']
        if (!(validReportTypes.contains(reportType))) {
            throw new ConfigurationException("'${reportType}' is an invalid handle ${validReportTypes}")
        }
        if (!(validSelectionTypes.contains(selectionType))) {
            throw new ConfigurationException("'${selectionType}' is an invalid handle ${validSelectionTypes}")
        }
        if (!(validSelectionFilters.contains(selectionFilter))) {
            throw new ConfigurationException("'${selectionFilter}' is an invalid handle ${validSelectionFilters}")
        }
        this.fossidIrmApi(this.scanApiGroup, 'generate_report', [scan_code: this.scanCode, report_type: reportType,
                                                                 selection_type: selectionType,
                                                                 selection_view: selectionFilter,], '', reportFile)
    }

    /** Function to list all scan names which are not archived of a given project.
    * Return is a list of scan names to perform further action with.
    * @param projectName String value of the scan name, default is used from constructor.
    * @param projectPattern this defines the pattern to search for the scan names.
    * @param regEx String will help to identify all scans matching the projectPattern (e.g timestamp).
    */
    List listScans(String projectPattern= '',
                   String regEx = '\\w*\\d*_\\d*') {
        String projectAction = 'get_all_scans'
        String errorExc = 'no scans available'
        Map allScans = this.fossidIrmApi(this.projectApiGroup, projectAction, [project_code: this.projectCode,
                                                                               ], errorExc)
        String pattern = projectPattern + regEx
        Map tm = allScans.data.findAll { data ->
            data.value.is_archived == null && data.value.code =~ pattern
        }
        SortedMap<Date, String> x = new TreeMap<Date, String>()
        tm.each { entry ->
            x[new SimpleDateFormat('yyyy-MM-dd H:m:s', Locale.US).parse(entry.value.created)] = entry.value.code
        }
        return x.values() as List
    }

    /** Function to choose a defined list of scan names to perform further action with.
    * Searches for total amount of scans given from listScans and compares this number with the
    * number of keepScans.If keepScans < allScansListed it returns the difference as list.
    * @param allScansListed List contains all scan names of active scans.
    * @param keepScans Integer value of how many scans should be kept. Default is set to 30.
    * If amount of scans is smaller than keepScans an empty list will be returned.
    */
    List selectedScans(List<String> allScansListed, Integer keepScans= 30) {
        Integer amountOfScans = allScansListed.size()
        if (amountOfScans >= keepScans) {
            Integer lastIndex = amountOfScans - keepScans
            /* groovylint-disable-next-line DuplicateNumberLiteral */
            return allScansListed.subList(0, lastIndex)
        }
        this.jenkins.echo 'No scans to archive'
        return []
    }

    /** Archive scans to keep the scan view clean.
    * @param scanNames List of scan names to archive.
    * errorExec given in case a scan is already archived.
    */
    void archiveScans(List<String> scanNames) {
        String archiveAction = 'archive_scan'
        scanNames.each { scanName ->
            this.fossidIrmApi(this.scanApiGroup, archiveAction, [scan_code: "${scanName}",])
        }
    }

    /** Delete scans to keep the scan view clean.
    * @param scanNames List of scan names to be deleted.
    * errorExec given in case the scan does not exist (anymore).
    * Archived scans can be deleted as well.
    */
    void deleteScans(List<String> scanNames) {
        String deleteAction = 'delete'
        scanNames.each { scanName ->
            this.fossidIrmApi(this.scanApiGroup, deleteAction, [scan_code: "${scanName}",])
        }
    }

    /** Private method to provide a generic interface to the FossID REST API. See FossID documentation for details
    * of the call structure. This method uses powershell's Invoke-RestMethod to call the web request. If the FossID
    * response status is not 1 and the error message is not specified to be excluded (see below), then an exception
    * will be raised.
    * @param apiGroup String group of api to call (See FossID documentation).
    * @param apiAction String action within the group to call (See FossID documentation).
    * @param apiData Map data block to send (See FossID documentation for correct structure).
    * @param errorExc String optional error message to exclude from raising an exception. If this string is contained
    * in the error response from FossID then no exception will be raised.
    * @return Map json response from the api call.
    */
    private Map fossidIrmApi(String apiGroup, String apiAction, Map apiData, String errorExc='', String filePath='') {
        Map response = [:]
        this.jenkins.withCredentials([this.jenkins.usernamePassword(credentialsId: this.credentials,
                                                                    usernameVariable: this.userVar,
                                                                    passwordVariable: this.passVar),]) {
            String apiBody = JsonOutput.toJson([group: apiGroup, action: apiAction,
                                                data: [username: this.jenkins.env.user, key: this.jenkins.env.pass]
                                                      + apiData])
            String irmCall = "irm -Uri ${this.server}/api.php -Method Post -Body '${apiBody}' -ContentType " +
                             "'application/json' ${filePath ? "-OutFile ${filePath}" : '| ConvertTo-Json'}"
            String responseJson = this.jenkins.powershell returnStdout: true, script: irmCall
            if (responseJson) {
                response = new JsonSlurperClassic().parseText(responseJson)
                if (response.status != '1' && (errorExc == '' || !response.error.contains(errorExc))) {
                    this.jenkins.error(response.error)
                }
            }
        }
        return response
    }

}
