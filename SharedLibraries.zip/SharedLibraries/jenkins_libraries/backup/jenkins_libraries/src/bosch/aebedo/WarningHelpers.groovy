#!/usr/bin/env groovy
 /* groovylint-disable DuplicateNumberLiteral */
 /**
 * Copyright (C) 2020, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

/*

Parser map:

GHSParser_Elvis: ghsParser202015_1fp_x64
GHSParser_CAL_Z223_V297: ghsParser202015_1fp_x64
GHSParser_PK_McuFbl_B2: deprecated - not used anymore
GHSParser_PK_McuFbl_B2_1: deprecated - not used anymore
GHSParser_RN_SW400_VARIANT_B: ghsParser2015_1_6
*/

import com.cloudbees.groovy.cps.NonCPS
import io.jenkins.plugins.analysis.warnings.groovy.GroovyParser
import io.jenkins.plugins.analysis.warnings.groovy.ParserConfiguration
import edu.hm.hafner.util.TreeStringBuilder
import edu.hm.hafner.util.TreeString

/**
* This class wraps functions for the NGW Jenkins Plugin
* Set the properties `displayName`, `thresholdTotal` and `thresholdNew`
* to publish the warnings with custom values.
* The thresholds are not distinguishing between errors and warnings.
* If you need more customization use the Jenkins steps `publishIssues`
* and `scanForIssues`.
*/
class WarningHelpers {

    static Map<String, Closure> availableParser = ['armcl' : WarningHelpers.&getArmClParser,
                                                 'ghsParser2015_1_6' : WarningHelpers.&getGhsParser2015_1_6,
                                                 'ghsParser202015_1fp_x64' : WarningHelpers.&getGhsParser202015_1fp_x64,
                                                 ]

    Object jenkins = null
    String displayName = ''
    Integer thresholdTotal = -1
    Integer thresholdNew = thresholdTotal
    String publishId = ''

    /**
    * Creates a Groovy Parser used for the next generation warnings Jenkins Plugin.
    * This parser can be used to parse logs from compilations with the ARM CL compiler
    * e.g. used by CodeComposerStudio (CCS).
    */
    @NonCPS
    static GroovyParser getArmClParser() {
        String groovyString = '''
            import edu.hm.hafner.analysis.Severity

            return builder.setFileName(matcher.group(1))
            .setLineStart(Integer.parseInt(matcher.group(2)))
            .setCategory(matcher.group(4))
            .setMessage(matcher.group(5))
            .setSeverity(Severity.guessFromString(matcher.group(3)))
            .buildOptional()
            '''
        String pattern = '^"(.+)", line (\\d+): (warning|error) (#.+): (.+)$'
        @SuppressWarnings('LineLength')
        /* groovylint-disable-next-line LineLength */
        @SuppressWarnings('LineLength')
        String exampleLine = '"../CDD/rbdBleArb/src/rbdBleArb_Gap.c", line 71: warning #225-D: function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly'
        return new GroovyParser('armcl', 'ARM CL (CCS)', pattern, groovyString, exampleLine)
    }

    @NonCPS
    static GroovyParser getGhsParser2015_1_6() {
        String groovyString = '''
                import edu.hm.hafner.analysis.Severity

                builder.setFileName(matcher.group(2))
                        .setLineStart(Integer.parseInt(matcher.group(3)))
                        .setCategory(matcher.group(5))
                        .setMessage(matcher.group(6))
                        .setType("GHS Multi Compiler")
                if ("warning".equalsIgnoreCase(matcher.group(4))) {
                    builder.setSeverity(Severity.WARNING_NORMAL)
                }
                else {
                    builder.setSeverity(Severity.WARNING_HIGH)
                }

                return builder.buildOptional();
        '''
        String pattern = '(InfoLine=.*")?"(.*)",\\s*line\\s*(\\d+):\\s*(warning|error)\\s*([^:]+):\\s*(.*)'
        @SuppressWarnings('LineLength')
        /* groovylint-disable-next-line LineLength */
        String exampleLine = '''InfoLine="MM/MasterCore/AIM/APP/MKE/src/MKE.c"::State="Completed"::ReturnValue="0"::Output=""MM/MasterCore/AIM/APP/MKE/src/MKE.c", line 145: warning #177-D: function "MKE_TestDefines" was declared but never referenced
  static void MKE_TestDefines(void);
              ^'''
        return new GroovyParser('ghsParser2015_1_6', 'GHS Parser (2015_1_6)', pattern, groovyString, exampleLine)
    }

    @NonCPS
    static GroovyParser getGhsParser202015_1fp_x64() {
        String groovyString = '''
                import edu.hm.hafner.analysis.Severity

                return builder.setFileName(matcher.group(2))
                              .setLineStart(Integer.parseInt(matcher.group(3)))
                              .setCategory(matcher.group(6))
                              .setMessage(matcher.group(7))
                              .setType("GHS Multi Compiler")
                              .setSeverity(Severity.guessFromString(matcher.group(5)))
                              .buildOptional();
        '''
        @SuppressWarnings('LineLength')
        /* groovylint-disable-next-line LineLength */
        String pattern = '(InfoLine=.*")?"(.*)",\\s*line\\s*(\\d+)\\s*\\(col.\\s*(\\d+)\\):\\s(warning|error)\\s*([^:]+):\\s*(.*)'
        @SuppressWarnings('LineLength')
        /* groovylint-disable-next-line LineLength */
        String exampleLine = '"..\\BIOS\\UJA113x\\cfg\\rb_Uja113x_Cfg.c", line 1173 (col. 38): warning #550-D: variable "sbcWdtStatus" was set but never used'
        return new GroovyParser('ghsParser202015_1fp_x64', 'GHS Parser (202015_1fp_x64)',
                                pattern, groovyString, exampleLine)
    }

    /**
    * Registers a new GroovyParser according to the mapping in `WarningsHelpers.availableParser`.
    */
    @NonCPS
    static String registerParser(String parserId) {
        if (!ParserConfiguration.instance.contains(parserId)) {
            Object parser = availableParser.get(parserId).call()
            ParserConfiguration.instance.parsers = ParserConfiguration.instance.parsers + parser
            return parser.id
        }
        return parserId
    }

    /**
    * Remove the specific parser from the global configuration.
    */
    @NonCPS
    static void deregisterParser(String parserId) {
        if (ParserConfiguration.instance.contains(parserId)) {
            ParserConfiguration.instance.parsers.each { elem ->
                if (elem.id == parserId) {
                    ParserConfiguration.instance.parsers = ParserConfiguration.instance.parsers - elem
                }
            }
        }
    }

    /**
    * Add a prefix to the filepath for all given record.
    * This can be used to get the same behaviour for legacy
    * WarningsParser, that used to set "JWS" in front of the filenames.
    */
    @NonCPS
    static void prefixFilepathForRecords(Object annotatedReport, String prefix) {
        annotatedReport.report.each { rep ->
            TreeStringBuilder builder = new TreeStringBuilder()
            TreeString fName = builder.intern(prefix + rep.fileName)
            // Explicitly set builder to null, so that TreeStringBuilder is not serialized
            builder = null
            rep.setFileName(rep.path, fName)
        }
    }

    WarningHelpers(Object jenkins, Map props = [:]) {
        this.jenkins = jenkins
        props.each { name, val ->
            this.setProperty(name, val)
        }
    }
    /**
    * A generic function which helps to collect warning parser output. It contains 3
    * separate function calls.
    * Input parameters:
    * @param parserid name of the parser which should be used. Configurable in Jenkins Management
    * @param id describes the explicit name of this record
    * @param path defines the path where the parser should search for warnings
    * @param filename the desired name of the file. Has to be a .txt file
    * @param threshold to be defined as a quality gate
    * @param reportEncoding to define encoding to be used, default value is set to UTF-8.
    * Further details to the Plugin can be found here:
    * https://github.com/jenkinsci/warnings-ng-plugin/blob/master/doc/Documentation.md
    **/

    /* groovylint-disable-next-line ParameterCount */
    String parserOutput(String parserId, String id, String path, String filename,
                        Integer threshold, String encoding = 'UTF-8') {
        Object record = scan(parserId, id, path, encoding)
        this.jenkins.fileInput(record, filename)
        return this.jenkins.output(record, threshold, encoding)
    }

    /**
    * This function scans the provided path for warnings/errors
    * according to the given parser and returns the outcome as a record object.
    * If the parser is unknown in the configuration and was not added globally via
    * Jenkins GUI, this function tries to create it and adds it to the configuration temporarily.
    **/
    Object scan(String parserId, String id, String path, String encoding = 'UTF-8') {
        String tempParserId = parserId
        if (availableParser.containsKey(parserId)) {
            tempParserId = registerParser(parserId)
        }
        Object record = this.jenkins.scanForIssues blameDisabled: true, tool: this.jenkins.groovyScript(
            parserId: tempParserId,
            id: id ?: this.publishId,
            pattern: path,
            reportEncoding: encoding
        )
        return record
    }

    /**
    * This function takes the record from scan function and writes the output to a file.
    * This file can be uploaded to Artifactory.
    **/
    String fileInput(Object record, String filename) {
        String parseroutput = ''
        record.report.each { rep ->
            parseroutput += "\n${rep}"
        }
        this.jenkins.writeFile file: filename, text: parseroutput
        return parseroutput
    }

    /**
    * A function which publishes the output of the Warning Parser functions.
    * and matches them against qualitygates. The threshold here refers only
    * to new Errors. Warnings and old errors are ignored. That differs
    * from the default implementation method `output` due to backwards
    * compatibility.
    **/
    void output(Object record, Integer threshold, String encoding) {
        this.output([record], threshold, encoding)
    }

    /**
    * A function which publishes the output of the Warning Parser functions.
    * and matches them against qualitygates. The threshold here refers only
    * to new Errors. Warnings and old errors are ignored. That differs
    * from the default implementation method `output` due to backwards
    * compatibility.
    **/
    void output(List<Object> records, Integer threshold, String encoding) {
        this.jenkins.publishIssues issues: records,
                                   qualityGates: [[threshold: threshold,
                                                   type: 'NEW_ERROR',
                                                   unstable: false]],
                                   sourceCodeEncoding: encoding
    }

    /**
    * A function which publishes the output of the Warning Parser functions.
    * and matches them against qualitygates as passed in the constructor.
    **/
    void output(Object records) {
        qGates = []
        if (this.thresholdNew >= 0) {
            qGates.add([threshold: this.thresholdNew,
                        type: 'NEW',
                        unstable: false,
                        ])
        }
        if (this.thresholdTotal >= 0) {
            qGates.add([threshold: this.thresholdTotal,
                        type: 'TOTAL',
                        unstable: false,
                        ])
        }
        this.jenkins.publishIssues issues: records,
                                   qualityGates: qGates,
                                   sourceCodeEncoding: 'UTF-8',
                                   name: this.displayName,
                                   id: this.publishId
    }

}
