param([string] $sourceUrl= ${sourceUrl}, [string] $outputFile= ${outputFile}, [string] $file= ${credfile})
# unable to name $file $credfile because of list of searched items of PSScriptAnalyzer

Get-Credential | Export-Clixml -path "$file"
$cred = Import-Clixml -path "$file"
Invoke-WebRequest -Uri "$sourceUrl" -OutFile "$outputFile" -Credential $cred