#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import org.codehaus.groovy.control.ConfigurationException
import bosch.aebedo.CustomStage
import bosch.aebedo.TestCoverage
import bosch.aebedo.AebeDevOps

def call(Object jenkins, Map<String, CustomStage> overrides=[:]) {
    overrides.keySet().each { key ->
        if(!TestCoverage.ALLOWED_KEY_WORDS.contains(key)) {
            throw new ConfigurationException("'${key}' not mentioned as valid overwrite parameter {${TestCoverage.ALLOWED_KEY_WORDS}}")
        }
    }
    try{
        AebeDevOps helpers = new AebeDevOps(jenkins)
        TestCoverage testCov = new TestCoverage(jenkins)
        def merged_exec_bart = helpers.mergeStageDescriptors([ new CustomStage( setup : testCov.&setupTestCovEnv,
                                                                                 stageMethod : testCov.&executeTestCov,
                                                                                 teardown : testCov.&uploadTestCov )] 
                                                              + overrides.getOrDefault('executeTestCov', new CustomStage(skip : false)))
        helpers.wrapStageWithNode('Execute Bart', merged_exec_bart)
    } catch(e) {
        emailext attachLog: true, body: "${BUILD_TAG} pipeline failed. URL: ${BUILD_URL}", 
                 to: "${jenkins.env.failMail}", subject: "${BUILD_TAG} - Failed!"
        throw e
    }
}