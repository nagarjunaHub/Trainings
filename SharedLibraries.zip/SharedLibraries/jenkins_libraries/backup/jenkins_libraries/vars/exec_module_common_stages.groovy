#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import org.codehaus.groovy.control.ConfigurationException
import bosch.aebedo.CustomStage
import bosch.aebedo.AebeDevOps
import bosch.aebedo.VectorCast

@groovy.transform.Field
def allowed_key_words = ['setupEnvironment', 'build', 
                         'buildPackage', 'unittest', 
                         'extraTests', 'staticCodeAnalysis', 
                         'uploadMetrics'].asImmutable()

@groovy.transform.Field
def ENV_MODULE_VERSION = null
@groovy.transform.Field
def ENV_MODULE_NAME = null
@groovy.transform.Field
def ENV_MODULE_QUALITY = ''
@groovy.transform.Field
def ENV_MODULE_PROJECT = ''
@groovy.transform.Field
def ENV_PRE_SUFFIX = '_pre'
@groovy.transform.Field
def ENV_PROJECT_SCM_DIRECTORY = 'JWS'
@groovy.transform.Field
def ENV_PROJECT_PACKAGING_DIRECTORY = 'packaging'
@groovy.transform.Field
String ENV_CONAN_PROFILE = '' 

def checkJobSetup(env) {
  def any_of = {var1, var2, env_var ->
    String exception_txt = "${env_var} has to be set in environment or using 'set_${env_var.toLowerCase()} method in library"
    "${var1?:var2?:{throw new ConfigurationException(exception_txt)}}".toString()
  }
  any_of(conan_helpers.ENV_aebe_dev_ARTIFACTORY_PROJECT, env.aebe_dev_ARTIFACTORY_PROJECT, "aebe_dev_ARTIFACTORY_PROJECT")
  any_of(ENV_MODULE_NAME, env.MODULE_NAME, "MODULE_NAME")
  any_of(ENV_MODULE_PROJECT, env.MODULE_PROJECT, "MODULE_PROJECT")
  any_of(ENV_MODULE_VERSION, env.MODULE_VERSION, "MODULE_VERSION")
  any_of(ENV_MODULE_QUALITY, env.MODULE_QUALITY, "MODULE_QUALITY")
}

def setupEnvironment(env) {
  echo "Setup environment"
}

def build(env) {
  echo "Build"
}

def buildPackage(env) {
  withEnv(conan_helpers.getConanEnvList(env)) {
    dir("${env.PROJECT_SCM_DIRECTORY?:this.ENV_PROJECT_SCM_DIRECTORY}") {
      dir("${env.PROJECT_PACKAGING_DIRECTORY?:this.ENV_PROJECT_PACKAGING_DIRECTORY}") {
        (server, client, serverName) = conan_helpers.getConanObjects(env)
        // Never use conan-center
        client.run(command: "remote remove conan-center")
        String module_sw_name = "${env.MODULE_NAME?:this.ENV_MODULE_NAME}"
        String module_sw_version = "${env.MODULE_VERSION?:this.ENV_MODULE_VERSION}"
        String module_sw_project = "${env.MODULE_PROJECT?:this.ENV_MODULE_PROJECT}"
        String module_sw_quality = "${env.MODULE_QUALITY?:this.ENV_MODULE_QUALITY}${env.PRE_SUFFIX?:this.ENV_PRE_SUFFIX?:''}"
        String module_desc = ''
        if(module_sw_name || module_sw_version) {
          module_desc += "${module_sw_name}/${module_sw_version}@"
        }

        module_desc += "${module_sw_project}/${module_sw_quality}"
        String conan_profile = "${env.CONAN_PROFILE?:this.ENV_CONAN_PROFILE}"
        if(conan_profile) {
          conan_profile = "-pr ${aebe_dev.pathJoin(['..', "${env.PROJECT_SCM_DIRECTORY?:this.ENV_PROJECT_SCM_DIRECTORY}"])}${conan_profile}".toString()
        }
        client.run(command: "create . ${module_desc} ${conan_profile}".toString())
        def build_info = client.run(command: "upload --force --all --confirm -r ${serverName} ${module_desc}".toString())
        server.publishBuildInfo build_info
      }
      conan_helpers.removeConanHomeDir(env)
      deleteDir()
    }
  }
}

def extraTests(env) {
  echo "Extra Tests"
}

def staticCodeAnalysis(env) {
  echo "Static Code Analysis"
}

def uploadMetrics(env) {
  echo "Upload Metrics"
}

def execStages(Object jenkins, Map<String, CustomStage> overrides=[:]) {
  helpers = new AebeDevOps(jenkins)
  
  def merged_setup = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&setupEnvironment)] 
                                                   + overrides.getOrDefault('setupEnvironment', new CustomStage(skip : false)))
  helpers.wrapStageWithNode('Setup Environment', merged_setup)

  def merged_build = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&build)]
                                                   + overrides.getOrDefault('build', new CustomStage(skip : false)))
  helpers.wrapStageWithNode('Build', merged_build)

  def merged_parallel_buildPackage = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&buildPackage)]
                                                                   + overrides.getOrDefault('buildPackage', new CustomStage(skip : false)))

  CustomStage vcastStage = new CustomStage(skip : false)
  if (jenkins.env.scmPath != null && jenkins.env.vcastProj != null && jenkins.env.importScript != null && jenkins.env.dirVCAST != null) {
    vcastobj = new VectorCast(jenkins)
    vcastStage = new CustomStage(setup: vcastobj.&setupVcast, stageMethod: vcastobj.&executeVcast, teardown: vcastobj.&cleanVcast)
  }
  def merged_parallel_unittest = helpers.mergeStageDescriptors([vcastStage] + overrides.getOrDefault('unittest', new CustomStage(skip : false)))

  def merged_parallel_extraTests = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&extraTests)]
                                                                 + overrides.getOrDefault('extraTests', new CustomStage(skip : false)))
  def merged_parallel_staticCodeAnalysis = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&staticCodeAnalysis)]
                                                                         + overrides.getOrDefault('staticCodeAnalysis', new CustomStage(skip : false)))
  parallel_stages_def = [
      'Build Package' : merged_parallel_buildPackage,
      'Unittest' : merged_parallel_unittest,
      'Extra Tests' : merged_parallel_extraTests,
      'Static Code Analysis': merged_parallel_staticCodeAnalysis
  ]
  parallel_stages = helpers.prepareParallelStages('Checks', parallel_stages_def)
  parallel(parallel_stages)

  def merged_upload_metrics = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&uploadMetrics)] 
                                                            + overrides.getOrDefault('uploadMetrics', new CustomStage(skip : false)))
  helpers.wrapStageWithNode('Upload Metrics', merged_upload_metrics)
}
