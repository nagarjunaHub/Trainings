#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import org.codehaus.groovy.control.ConfigurationException
import bosch.aebedo.CustomStage
import bosch.aebedo.AebeDevOps

@groovy.transform.Field
def allowed_key_words = ['uploadPackage']

// Setter functions are only for convenience.
// So that the user does not have to know in which subgroovy script a variable
// is located and can only interact with the imported script:
// Instead of:
// node {
//    conan_helpers.ENV_CONAN_USER_HOME = "my_user_home"
//    exec_module_common_stages.ENV_PROJECT_SCM_DIRECTORY = "JWS"
//    exec_module_common_stages.ENV_SW_NAME = "new_software"
//    conan_helpers.ENV_AEBE_DEVOPS_ARTIFACTORY = "CI_Artifactory_private"
// }
//
// The user can use (note, that the pipeline overall stage is "merge PR for one module"):
// node {
//  exec_module_on_merge.setConanHome("my_user_home")
//  exec_module_on_merge.setProjectScmDirectory("JWS")
//  exec_module_on_merge.setModuleName("new_software")
//  exec_module_on_merge.setArtifactoryName("CI_Artifactory_private")
//}
def setArtifactoryName(String artifactory_name) {
  conan_helpers.ENV_AEBE_DEVOPS_ARTIFACTORY = artifactory_name
}

def setArtifactoryProject(String artifactory_project) {
  conan_helpers.ENV_AEBE_DEVOPS_ARTIFACTORY_PROJECT = artifactory_project
}

def setConanHome(String conan_home) {
  conan_helpers.ENV_CONAN_USER_HOME = conan_home
}

def setConanShortHome(String conan_home) {
  conan_helpers.ENV_CONAN_USER_SHORT_HOME = conan_home
}

def setConanProfile(String conan_profile) {
  exec_module_common_stages.ENV_CONAN_PROFILE = conan_profile
}

def setModuleProject(String module_project) {
  exec_module_common_stages.ENV_MODULE_PROJECT = module_project
}

def setModuleName(String module_name) {
  exec_module_common_stages.ENV_MODULE_NAME = module_name
}

def setModuleVersion(String module_version) {
  exec_module_common_stages.ENV_MODULE_VERSION = module_version
}

def setModuleQuality(String module_quality) {
  exec_module_common_stages.ENV_MODULE_QUALITY = module_quality
}

def setProjectScmDirectory(String project_scm_directory) {
  exec_module_common_stages.ENV_PROJECT_SCM_DIRECTORY = project_scm_directory
}

def setProjectPackagingDirectory(String project_packaging_directory) {
  exec_module_common_stages.ENV_PROJECT_PACKAGING_DIRECTORY = project_packaging_directory
}
// End of convenience functions


def uploadPackage(env) {
  withEnv(conan_helpers.getConanEnvList(env)) {
    dir ('install') {
        (server, client, serverName) = conan_helpers.getConanObjects(env)
        // Never use conan-center
        client.run(command: "remote remove conan-center")
        String module_sw_name = "${env.MODULE_NAME?:exec_module_common_stages.ENV_MODULE_NAME}"
        String module_sw_version = "${env.MODULE_VERSION?:exec_module_common_stages.ENV_MODULE_VERSION}"
        String module_sw_project = "${env.MODULE_PROJECT?:exec_module_common_stages.ENV_MODULE_PROJECT}"
        String module_sw_quality = "${env.MODULE_QUALITY?:exec_module_common_stages.ENV_MODULE_QUALITY}${env.PRE_SUFFIX?:exec_module_common_stages.ENV_PRE_SUFFIX?:''}"
        String module_desc = "${module_sw_name}/${module_sw_version}@${module_sw_project}/${module_sw_quality}"

        String module_new_qual = "${module_sw_project}/${env.MODULE_QUALITY?:exec_module_common_stages.ENV_MODULE_QUALITY}"
        String module_new_desc = "${module_sw_name}/${module_sw_version}@${module_new_qual}"
        client.run(command: "download ${module_desc}".toString())
        client.run(command: "copy --all ${module_desc} ${module_new_qual}".toString())
        def build_info = client.run(command: "upload --all --confirm -r ${serverName} ${module_new_desc}".toString())
        server.publishBuildInfo build_info
        conan_helpers.removeConanHomeDir(env)
        deleteDir()
    }
  }
}

def call(Object jenkins, Map<String, CustomStage> overrides=[:]) {
  overrides.keySet().each { key ->
    if(!(allowed_key_words.contains(key) || exec_module_common_stages.allowed_key_words.contains(key))) {
      throw new ConfigurationException("'${key}' not mentioned as valid overwrite parameter {${allowed_key_words + exec_module_common_stages.allowed_key_words}} ")
    }
  }
  exec_module_common_stages.execStages(jenkins, overrides)
  helpers = new AebeDevOps(jenkins)
  def merged_uploadPackage = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&uploadPackage)]
                                                           + overrides.getOrDefault('uploadPackage', new CustomStage(skip : false)))
  helpers.wrapStageWithNode('Upload Package', merged_uploadPackage)
}
