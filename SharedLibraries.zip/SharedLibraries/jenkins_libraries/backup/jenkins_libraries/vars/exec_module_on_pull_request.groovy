#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import org.codehaus.groovy.control.ConfigurationException
import bosch.aebedo.CustomStage
import bosch.aebedo.AebeDevOps

@groovy.transform.Field
def allowed_key_words = ['approvePullRequest']

// Setter functions are only for convenience.
// So that the user does not have to know in which subgroovy script a variable
// is located and can only interact with the imported script:
// Instead of:
// node {
//    conan_helpers.ENV_CONAN_USER_HOME = "my_user_home"
//    exec_module_common_stages.ENV_PROJECT_SCM_DIRECTORY = "JWS"
//    exec_module_common_stages.ENV_SW_NAME = "new_software"
//    conan_helpers.ENV_AEBE_DEVOPS_ARTIFACTORY = "CI_Artifactory_private"
// }
//
// The user can use (note, that the pipeline overall stage is "merge PR for one module"):
// node {
//  exec_module_on_pull_request.setConanHome("my_user_home")
//  exec_module_on_pull_request.setProjectScmDirectory("JWS")
//  exec_module_on_pull_request.setModuleName("new_software")
//  exec_module_on_pull_request.setArtifactoryName("CI_Artifactory_private")
//}
def setArtifactoryName(String artifactory_name) {
  conan_helpers.ENV_AEBE_DEVOPS_ARTIFACTORY = artifactory_name
}

def setArtifactoryProject(String artifactory_project) {
  conan_helpers.ENV_AEBE_DEVOPS_ARTIFACTORY_PROJECT = artifactory_project
}

def setConanHome(String conan_home) {
  conan_helpers.ENV_CONAN_USER_HOME = conan_home
}

def setConanShortHome(String conan_home) {
  conan_helpers.ENV_CONAN_USER_SHORT_HOME = conan_home
}

def setConanProfile(String conan_profile) {
  exec_module_common_stages.ENV_CONAN_PROFILE = conan_profile
}

def setModuleProject(String module_project) {
  exec_module_common_stages.ENV_MODULE_PROJECT = module_project
}

def setModuleName(String module_name) {
  exec_module_common_stages.ENV_MODULE_NAME = module_name
}

def setModuleVersion(String module_version) {
  exec_module_common_stages.ENV_MODULE_VERSION = module_version
}

def setModuleQuality(String module_quality) {
  exec_module_common_stages.ENV_MODULE_QUALITY = module_quality
}

def setProjectScmDirectory(String project_scm_directory) {
  exec_module_common_stages.ENV_PROJECT_SCM_DIRECTORY = project_scm_directory
}

def setProjectPackagingDirectory(String project_packaging_directory) {
  exec_module_common_stages.ENV_PROJECT_PACKAGING_DIRECTORY = project_packaging_directory
}
// End of convenience functions

def approvePullRequest(env){
  echo "Approve Pull Request"
}

def call(Object jenkins, Map overrides=[:]) {
  helpers = new AebeDevOps(jenkins)
  overrides.keySet().each { key ->
    if(!(allowed_key_words.contains(key) || exec_module_common_stages.allowed_key_words.contains(key))) {
      throw new ConfigurationException("'${key}' not mentioned as valid overwrite parameter {${allowed_key_words + exec_module_common_stages.allowed_key_words}} ")
    }
  }

  exec_module_common_stages.execStages(jenkins, overrides)

  def merged_approvePullRequest = helpers.mergeStageDescriptors([new CustomStage(stageMethod: this.&approvePullRequest)]
                                                                + overrides.getOrDefault('approvePullRequest', new CustomStage(skip: false)))
  helpers.wrapStageWithNode('Approve Pull Request', merged_approvePullRequest)

}
