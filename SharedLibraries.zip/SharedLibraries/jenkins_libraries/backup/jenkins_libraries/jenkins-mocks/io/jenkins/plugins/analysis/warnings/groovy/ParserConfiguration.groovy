package io.jenkins.plugins.analysis.warnings.groovy

class ParserConfiguration {

    static ParserConfiguration privInstance = null
    List parserList = []

    static ParserConfiguration getInstance() {
        if (ParserConfiguration.privInstance == null) {
            ParserConfiguration.privInstance = new ParserConfiguration()
        }
        return ParserConfiguration.privInstance
    }

    boolean contains(String id) {
        boolean found = false
        parserList.each { elem ->
            if (elem.id == id) {
                found = true
            }
        }
        return found
    }

    List getParsers() {
        return parserList
    }

    void setParsers(List parserList) {
        this.parserList = parserList
    }

    Object getParser(String id) {
        parserList.each { elem ->
            if (elem.id == id) {
                return elem
            }
        }
        return null
    }
}
