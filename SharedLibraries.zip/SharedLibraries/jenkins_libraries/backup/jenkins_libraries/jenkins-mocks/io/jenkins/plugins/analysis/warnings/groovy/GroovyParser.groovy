package io.jenkins.plugins.analysis.warnings.groovy

class GroovyParser {

    String id
    String desc
    String pattern
    String groovyString
    String exampleLine

    GroovyParser(String id, String desc, String pattern, String groovyString, String exampleLine) {
        this.id = id
        this.desc = desc
        this.pattern = pattern
        this.groovyString = groovyString
        this.exampleLine = exampleLine
    }
}
