package hudson.tools

class ToolInstallation {

    final String name
    final String home

    static List<ToolDescriptor> all() {
        return [new ToolDescriptor()]
    }

    ToolInstallation(final String name, final String home) {
        this.name = name
        this.home = home
    }
}
