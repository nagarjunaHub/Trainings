package hudson.tools

class ToolDescriptor {
    List<ToolInstallation> getInstallations() {
        return [new ToolInstallation('si-z667r_buildslaves', 'extraGitPath\\git.exe'),
               new ToolInstallation('Default', 'extraLinuxGitPath/git')]
    }
}
