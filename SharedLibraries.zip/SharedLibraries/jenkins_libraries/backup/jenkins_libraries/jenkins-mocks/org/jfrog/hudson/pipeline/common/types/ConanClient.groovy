package org.jfrog.hudson.pipeline.common.types

class ConanClient {

    String userHome

    ConanClient(Map props) {
        this.userHome = props.userHome ?: ''
    }

    Object run(Map commands) {
        return commands.command
    }
}
