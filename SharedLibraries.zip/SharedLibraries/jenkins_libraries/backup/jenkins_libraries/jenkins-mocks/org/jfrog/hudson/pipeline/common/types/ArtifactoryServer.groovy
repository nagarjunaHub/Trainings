package org.jfrog.hudson.pipeline.common.types

class ArtifactoryServer {
    String url
    String credentialsId

    ArtifactoryServer(Map props) {
        this.url = props.url ?: ''
        this.credentialsId = props.credentialsId ?: ''
    }
}
