echo "Please insert the Release Version:"
read release_version
echo "Please insert the Release Name:"
read release_name
#echo "Please insert the Release Branch to compare:"
#read compare_branch
declare -a complete=()
declare -a branch=()
spin='-\|/'
i=0
echo "Gathering Commits"
while read -r commit
do
    if [[ $commit =~ AEBEDO-[0-9]* ]]; then
        i=$(( (i+1) %4 ))
        printf "\r${spin:$i:1}"
        number=(${BASH_REMATCH})
        comment=$(echo $commit | awk -F' AEBEDO-[0-9]*' '{print $2}')
        complete+=("$number$comment")
    fi
done < <(git log --oneline  --decorate --abbrev-commit origin/release/latest_stable_release..origin/master)

if [[ -f "Release_Notes.md" ]]; then
    echo "moving old release notes"
    mv Release_Notes.md Release_Notes.md.old
fi
echo "AEBE Devops Jenkins Library" > Release_Notes.md
echo "---------------------------" >> Release_Notes.md
echo "" >> Release_Notes.md
echo "Version: $release_version ($release_name)" >> Release_Notes.md
echo "---------------------------"
echo "Changes:\n" >> Release_Notes.md
if [[ -f "Commits_in_Release.txt" ]]; then
    rm Commits_in_Release.txt
fi
for number in "${complete[@]}"; do
    echo "$number" >> Commits_in_Release.txt
done
if [[ -f "Release_Notes.md.old" ]]; then
    sed -i '1d' Release_Notes.md.old
    cat Release_Notes.md.old >> Release_Notes.md
    rm Release_Notes.md.old
fi
echo "The Release_notes.md is updated with the new version"
echo "Please add the changes of this Release"
echo "The following commits are included in the Release. You can also find them in the file Commits_in_Release.txt"
cat Commits_in_Release.txt
echo "#########"
echo "Please insert the Changes of the Release in the Release_Notes.md. The commits of the Release are displayed and also stored in Commits_in_release.txt"
