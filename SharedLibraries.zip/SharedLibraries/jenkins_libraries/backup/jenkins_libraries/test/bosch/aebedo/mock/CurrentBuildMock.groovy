/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo.mock

import com.ibm.team.build.internal.hjplugin.RTCChangeLogChangeSetEntry

class CurrentBuildMock {

    List changeSets = [ [new RTCChangeLogChangeSetEntry(), new RTCChangeLogChangeSetEntry()] ]
    String result = ''
    String displayName = '18'

}
