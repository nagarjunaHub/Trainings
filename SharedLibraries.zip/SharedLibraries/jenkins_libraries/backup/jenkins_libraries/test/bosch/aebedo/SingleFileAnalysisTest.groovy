/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import spock.lang.Specification
import bosch.aebedo.SingleFileAnalysis
import bosch.aebedo.mock.JenkinsFileMock
import org.junit.Test

class SingleFileAnalysisTest extends Specification {

    @Test
    void 'test_singleFileAnalysis_execProcess'() {
    setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.sfaReportLabel = 'mock'
        mockPointer.env.repo = 'MockArtifactory'
        mockPointer.env.artifactoryProject = 'MockArtifactory'
        mockPointer.env.sfaIncludePath = ''
        SingleFileAnalysis singleFa = new SingleFileAnalysis(mockPointer)
        String mergedPathHFile = 'this\\is\\an\\rtc\\component\\your\\h\\file.h'
        String mergedPathCFile = 'this\\is\\an\\rtc\\component\\your\\c\\file.c'
    when:
        singleFa.executeSingleFa()
        singleFa.uploadSingleFa()
    then:
        assert singleFa.artifactory.envArtifactoryRepo == 'MockArtifactory'
        assert singleFa.sfaResultMap.containsKey(mergedPathHFile) == true
        assert singleFa.sfaResultMap[mergedPathHFile].contains('Lorem ipsum dolor sit amet') == true
        assert singleFa.sfaResultMap.containsKey(mergedPathCFile) == true
        assert singleFa.sfaResultMap[mergedPathCFile].contains('Lorem ipsum dolor sit amet') == true
    }

}
