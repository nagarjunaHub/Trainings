/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import bosch.aebedo.CustomStage
import spock.lang.Specification
import org.junit.Test

class CustomStageTest extends Specification {

    @Test
    void 'test_customStage_defaultParams'() {
        CustomStage customStage = new CustomStage()
        expect:
        assert customStage.skip == true
        assert customStage.setup == null
        assert customStage.stageMethod == null
        assert customStage.teardown == null
        assert customStage.node == ''
    }
    @Test
    void 'test_customStage_differentConstructors'() {
        setup:
        CustomStage customStage
        Closure usedMethod = { return true }
        Closure unUsedMethod = { return false }
        when:
        customStage = new CustomStage(stageMethod: usedMethod)
        then:
        assert customStage.stageMethod == new CustomStage([stageMethod: usedMethod]).stageMethod
        when:
        customStage = new CustomStage(setup: unUsedMethod, stageMethod: usedMethod)
        then:
        assert customStage.setup == new CustomStage([setup: unUsedMethod, stageMethod: usedMethod]).setup
        assert customStage.stageMethod == new CustomStage([setup: unUsedMethod, stageMethod: usedMethod]).stageMethod
        assert customStage.skip == false
        when:
        new CustomStage(unknownField: true)
        then:
        thrown(GroovyRuntimeException)
        when:
        CustomStage const1 = new CustomStage(setup: unUsedMethod, stageMethod: usedMethod)
        CustomStage const2 = new CustomStage(stageMethod: usedMethod, setup: unUsedMethod)
        then:
        assert const1.setup == const2.setup
        assert const1.stageMethod == const2.stageMethod
        when:
        customStage = new CustomStage(skip : false)
        then:
        assert customStage.skip == false
        assert customStage.setup == null
        assert customStage.stageMethod == null
        assert customStage.teardown == null
        when:
        customStage = new CustomStage(skip : true)
        then:
        assert customStage.skip == true
        assert customStage.setup == null
        assert customStage.stageMethod == null
        assert customStage.teardown == null
    }
    @Test
    void 'test_customStage_equalizer'() {
        setup:
        Closure usedMethod = { return false }
        Closure unUsedMethod = { return true }
        when:
        CustomStage comp = new CustomStage()
        CustomStage test = new CustomStage()
        then:
        assert comp.skip == test.skip
        assert comp.node == test.node
        assert comp.stageMethod == test.stageMethod
        assert comp.setup == test.setup
        when:
        test = new CustomStage([stageMethod: usedMethod])
        then:
        assert comp.skip != test.skip
        assert comp.node == test.node
        assert test.stageMethod == usedMethod
        when:
        comp = new CustomStage([skip: false, stageMethod: usedMethod])
        test = new CustomStage([skip: false, stageMethod: unUsedMethod])
        then:
        assert comp.skip == test.skip
        assert comp.node == test.node
        assert comp.stageMethod != test.stageMethod
        when:
        comp = new CustomStage([skip: false, stageMethod: usedMethod])
        test = new CustomStage([skip: false, stageMethod: usedMethod])
        then:
        assert comp.skip == test.skip
        assert comp.node == test.node
        assert comp.stageMethod == test.stageMethod
        assert comp.setup == test.setup
    }
    @Test
    void 'test_customStage_stageMethod_setup_teardown'() {
        expect:
        Closure testStageMethod = { return true }
        Closure tearDownMethod = { return false }
        CustomStage customStage = new CustomStage([skip: false, stageMethod: testStageMethod])
        assert customStage.skip == false
        assert customStage.setup == null
        assert customStage.stageMethod == testStageMethod
        assert customStage.teardown == null
        assert customStage.node == ''
        assert (new CustomStage([skip: true, stageMethod: testStageMethod])).skip == true
        assert (new CustomStage([skip: true, stageMethod: testStageMethod])).stageMethod != null
        assert (new CustomStage(setup: testStageMethod)).setup == testStageMethod
        assert (new CustomStage(setup: testStageMethod)).skip == false
        assert (new CustomStage(teardown: tearDownMethod)).teardown == tearDownMethod
        assert (new CustomStage(teardown: testStageMethod)).skip == false
    }
    @Test
    void 'test_customStage_nodeOverride' () {
        expect:
        assert (new CustomStage(node: 'master')).skip == true
        assert (new CustomStage(node: 'master')).node == 'master'
        assert (new CustomStage(node: 'master', setup: { return true } )).skip == false
        assert (new CustomStage(node: 'master', setup: { return true } )).node == 'master'
    }

}
