/**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import bosch.aebedo.WarningHelpers
import bosch.aebedo.mock.JenkinsFileMock
import io.jenkins.plugins.analysis.warnings.groovy.ParserConfiguration
import spock.lang.Specification
import org.junit.Test
import java.util.regex.Matcher

class WarningHelpersTest extends Specification {

    @Test
    void 'scan'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        warningHelpers.scan(parserId, id, path, encoding)
        then:
        assert mockPointer.scanForIssuesCall.tool.parserId == 'parser1'
        assert mockPointer.scanForIssuesCall.tool.id == 'test'
        assert mockPointer.scanForIssuesCall.tool == [parserId:'parser1', id:'test',
                                                      pattern:'test_path', reportEncoding:'UTF-8',]
        when:
        parserId = 'armcl'
        warningHelpers.scan(parserId, id, path, encoding)
        then:
        assert mockPointer.scanForIssuesCall.tool.parserId == 'armcl'
        assert mockPointer.scanForIssuesCall.tool.id == 'test'
        assert mockPointer.scanForIssuesCall.tool == [parserId:'armcl', id:'test',
                                                      pattern:'test_path', reportEncoding:'UTF-8',]
    }
    @Test
    void 'fileInput'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        Object record = warningHelpers.scan(parserId, id, path, encoding)
        String filename = 'test_file'
        String output = warningHelpers.fileInput(record, filename)
        then:
        assert output == '\n1\n2'
        assert mockPointer.writeFileCall == [file: filename, text: output]
    }
    @Test
    void 'output'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        Object record = warningHelpers.scan(parserId, id, path, encoding)
        Integer threshold = 30
        warningHelpers.output(record, threshold, encoding)
        then:
        assert mockPointer.publishIssuesCall.qualityGates == [[threshold:30, type:'NEW_ERROR', unstable:false]]
    }
    @Test
    void 'parserOutput'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        String filename = 'test'
        Integer threshold = 30
        warningHelpers.parserOutput(parserId, id, path, filename, threshold, encoding)
        then:
        assert mockPointer.groovyScriptCall != [:]
        assert mockPointer.scanForIssuesCall != [:]
    }

    @Test
    void 'armParser'() {
        String armParserName = 'armcl'
        when:
        WarningHelpers.registerParser(armParserName)
        then:
        assert WarningHelpers.armClParser.id == armParserName
        assert ParserConfiguration.instance.contains(armParserName)
        when:
        WarningHelpers.deregisterParser(armParserName)
        then:
        assert ParserConfiguration.instance.contains(armParserName) == false
    }

    @Test
    @SuppressWarnings('LineLength')
    void 'armParserParse' () {
        when:
        /* groovylint-disable-next-line LineLength */
        Matcher goodLine = '"../CDD/rbdBleArb/src/rbdBleArb_Gap.c", line 71: warning #225-D: function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly' =~ WarningHelpers.armClParser.pattern
        then:
        assert goodLine.find() == true

        when:
        /* groovylint-disable-next-line LineLength */
        Matcher badLine = '"../CDD/rbdBleArb/src/rbdBleArb_Gap.c", line 71: information #225-D: function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly' =~ WarningHelpers.armClParser.pattern
        then:
        assert badLine.find() == false
    }

}
