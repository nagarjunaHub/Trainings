/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.RtcHelpersMock
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test
import org.codehaus.groovy.control.ConfigurationException

class RtcHelpersTest extends Specification {

    private final String snapshotList = '''
                                        {
                                            "snapshots": [
                                                {
                                                    "comment": "Comment_here",
                                                    "creationDate": "29.04.2020 18:17",
                                                    "name": "snapshot_20200429_224414",
                                                    "ownedby": {
                                                        "name": "streamName1",
                                                        "type": "STREAM",
                                                        "url": "https://rb-alm/ccm/",
                                                        "uuid": "XYZABCD1"
                                                    },
                                                    "url": "https://rb-alm/ccm/",
                                                    "uuid": "_iVT6MIoXEeqjdoU1qbl95w"
                                                },
                                                {
                                                    "comment": "Comment_here",
                                                    "creationDate": "29.04.2020 18:10",
                                                    "name": "snapshot_20200429_223710",
                                                    "ownedby": {
                                                        "name": "streamName1",
                                                        "type": "STREAM",
                                                        "url": "https://rb-alm/ccm/",
                                                        "uuid": "XYZABCD1"
                                                    },
                                                    "url": "https://rb-alm/ccm/",
                                                    "uuid": "_kEvF4IoWEeqjdoU1qbl95w"
                                                }
                                            ]
                                        }
                                        '''
    private final String compareResult = '''
                                    {
                                        "direction": [
                                            {
                                                "components": [
                                                    { "added": false,
                                                        "changesets": [
                                                            {
                                                                "author": {
                                                                    "mail": "test.user@de.bosch.com",
                                                                    "userId": "TESTUSE",
                                                                    "userName": "Test User (AE-BE/ESW10-St)",
                                                                    "uuid": "_CBpiMOjMEem8G_L_b9wDAA"
                                                                },
                                                                "comment": "",
                                                                "creationDate": "2020/06/29",
                                                                "item-type": "changeset",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_dw5XHbnSEeqH_cyoxpizmw",
                                                                "versionables": [
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/src/Can_Appl.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_x3yyIDg9EeqUlqhoaLc6MQ"
                                                                    }
                                                                ]
                                                            },
                                                            {
                                                                "author": {
                                                                    "mail": "test.user@de.bosch.com",
                                                                    "userId": "TESTUSER",
                                                                    "userName": "Test User (AE-BE/ESW10-St)",
                                                                    "uuid": "_CBpiMOjMEem8G_L_b9wDAA"
                                                                },
                                                                "comment": "",
                                                                "creationDate": "2020/07/07",
                                                                "item-type": "changeset",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_eLPGULoCEeqH_cyoxpizmw",
                                                                "versionables": [
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/gen/Can_Lcfg.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_aAye4IAJEeqT8PjaVevvfw"
                                                                    },
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/src/Can_Appl.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_x3yyIDg9EeqUlqhoaLc6MQ"
                                                                    }
                                                                ]
                                                            }
                                                        ],
                                                        "item-type": "component",
                                                        "name": "rbd.testproject.version.proj.sw.05_MCAL.ComDrv.Can",
                                                        "removed": false,
                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                        "uuid": "_gTPUIDdqEeqWPremDs7l0g"
                                                    },
                                                    {
                                                        "added": false,
                                                        "baselines": [
                                                            {
                                                                "id": 72,
                                                                "item-type": "baseline",
                                                                "name": "test_snapshot",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_WaeCZLRoEeqH_cyoxpizmw"
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                    '''
    private final String listResult = '''
                                    [
                                        {
                                            "name" : "streamName1",
                                            "owner" : "mock_project",
                                            "url" : "https://rb-alm/ccm/",
                                            "uuid" : "XYZABCD1"
                                        },
                                        {
                                            "name" : "streamName2",
                                            "owner" : "mock_project",
                                            "url" : "https://rb-alm/ccm/",
                                            "uuid" : "XYZABCD2"
                                        },
                                    ]
                                    '''
    private final String jsonString = '''
                                    {
                                        "name" : "streamName1",
                                        "owner" : "mock_project",
                                        "url" : "https://rb-alm/ccm/",
                                        "uuid" : "XYZABCD1"
                                    }
                                    '''
    private final String listComponent = '''
                                   {
                                     "workspaces": [
                                                       {
                                                         "components": [
                                                                          {
                                                                             "contains-subhierarchy-cycle": false,
                                                                             "is-accessible": true,
                                                                             "is-in-cycle": false,
                                                                             "is-in-workspace": true,
                                                                             "is-root": true,
                                                                             "name": "component1",
                                                                             "subcomponents": [
                                                                                                ],
                                                                             "uuid": "_zbtyMCN9EeuLZ5txoDRBZA"
                                                                           },
                                                                           {
                                                                             "contains-subhierarchy-cycle": false,
                                                                             "is-accessible": true,
                                                                             "is-in-cycle": false,
                                                                             "is-in-workspace": true,
                                                                             "is-root": true,
                                                                             "name": "component2",
                                                                             "subcomponents": [
                                                                                               ],
                                                                             "uuid": "_0jQ-QCUsEeuLZ5txoDRBZA"
                                                                            },
                                                                        ],
                                                                        "name": "streamName",
                                                                        "type": "STREAM",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "userId": "TestArea",
                                                                        "uuid": "_m3Q9sCN-EeuLZ5txoDRBZA"
                                                        }
                                                   ]
                                    }
                                    '''

    private final String jsonSnapshot = '''
                                    [
                                        {
                                            "description": "",
                                            "name": "test_ReleaseSnapshot",
                                            "snapshot": "test_ReleaseSnapshot_02_12_2020",
                                            "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                            "uuid": "_wmvfRTSLEeuyh5HGHAZnuA"
                                        }
                                    ]
                                    '''
    private List<Map> batMapCall = []
    private final Answer batOverride = new Answer<String>() {

        String answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.batMapCall += param
            final String lscmTool = 'lscm.bat'
            final String jsonExt = '--json'
            if (param.containsKey('script') && param.containsKey('returnStdout')) {
                if (param.script.contains(lscmTool) && param.script.contains(jsonExt)
                    && param.script.contains('list snapshots')) {
                    return snapshotList
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('compare')) {
                    return compareResult
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('list components')) {
                    return listComponent
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('list')) {
                    return listResult
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('query')) {
                    return jsonSnapshot
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)) {
                    return jsonString
                }
            }
            return 'default'
        }

    }

    @Test
    void 'test_defaultParams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        when:
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        then:
        assert rtcHelpers.server == 'https://rb-alm-11-p.de.bosch.com/ccm'
        assert rtcHelpers.buildToolkit == 'RTC_BuildToolkit_6_0_4'
        assert rtcHelpers.credentials == ''
        assert rtcHelpers.lscmUtil.lscmPath == 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        assert rtcHelpers.lscmUtil.creds == ''
        when:
        mock.env.rtcServer = 'https://my.test.server.com'
        mock.env.rtcBuildToolkit = 'Toolkit_2.0'
        mock.env.rtcCredentials = 'secret_creds'
        mock.env.lscmPath = 'C:\\custom_lscm_path\\lscm.bat'
        RtcHelpers rtcHelpersCustom = new RtcHelpers(mock)
        then:
        assert rtcHelpersCustom.server == 'https://my.test.server.com'
        assert rtcHelpersCustom.buildToolkit == 'Toolkit_2.0'
        assert rtcHelpersCustom.credentials == 'secret_creds'
        assert rtcHelpersCustom.lscmUtil.lscmPath == 'C:\\custom_lscm_path\\lscm.bat'
        assert rtcHelpersCustom.lscmUtil.creds == 'secret_creds'
    }

    @Test
    void 'test_getBuildTypeDefinitionMap'() {
        RtcHelpers rtcHelpers = new RtcHelpers(new JenkinsFileMock())
        when:
        Map buildDef = rtcHelpers.getBuildTypeDefinitionMap('Test_BD')
        then:
        assert buildDef.buildDefinition == 'Test_BD'
        assert buildDef.customizedSnapshotName == ''
        assert buildDef.overrideDefaultSnapshotName == false
        assert buildDef.useDynamicLoadRules == false
        assert buildDef.value == 'buildDefinition'
        when:
        Map buildDefCustom = rtcHelpers.getBuildTypeDefinitionMap('Test_BD',
                                                                  'Test_Snapshot',
                                                                  true)
        then:
        assert buildDefCustom.buildDefinition == 'Test_BD'
        assert buildDefCustom.customizedSnapshotName == 'Test_Snapshot'
        assert buildDefCustom.overrideDefaultSnapshotName == true
        assert buildDefCustom.useDynamicLoadRules == true
    }

    @Test
    void 'test_getBuildTypeWorkspaceMap'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.loadRulePath = 'path/to/loadrule.loadrule'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildDef = rtcHelpers.getBuildTypeWorkspaceMap('Test_WS')
        then:
        assert buildDef.acceptBeforeLoad == true
        assert buildDef.buildWorkspace == 'Test_WS'
        assert buildDef.clearLoadDirectory == false
        assert buildDef.customizedSnapshotName == ''
        assert buildDef.loadDirectory == 'JWS'
        assert buildDef.loadPolicy == 'useLoadRules'
        assert buildDef.overrideDefaultSnapshotName == false
        assert buildDef.pathToLoadRuleFile == 'path/to/loadrule.loadrule'
        assert buildDef.value == 'buildWorkspace'
        when:
        Map buildDefCustom = rtcHelpers.getBuildTypeWorkspaceMap('Test_WS',
                                                                 'different/path.loadrule',
                                                                 false, 'Test_Snapshot',
                                                                 true, 'LoadWS')
        then:
        assert buildDefCustom.acceptBeforeLoad == false
        assert buildDefCustom.buildWorkspace == 'Test_WS'
        assert buildDefCustom.clearLoadDirectory == true
        assert buildDefCustom.customizedSnapshotName == 'Test_Snapshot'
        assert buildDefCustom.loadDirectory == 'LoadWS'
        assert buildDefCustom.overrideDefaultSnapshotName == true
        assert buildDefCustom.pathToLoadRuleFile == 'different/path.loadrule'
    }

    @Test
    void 'test_getBuildTypeSnapshotMap'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildDef = rtcHelpers.getBuildTypeSnapshotMap('Test_Snapshot')
        then:
        assert buildDef.buildSnapshot == 'Test_Snapshot'
        assert buildDef.buildSnapshotContext == [snapshotOwnerType: 'none']
        assert buildDef.clearLoadDirectory == false
        assert buildDef.currentSnapshotOwnerType == 'none'
        assert buildDef.loadDirectory == 'JWS'
        assert buildDef.loadPolicy == 'useLoadRules'
        assert buildDef.pathToLoadRuleFile == ''
        assert buildDef.value == 'buildSnapshot'
        when:
        mock.env.loadRulePath = 'path/to/loadrule.loadrule'
        RtcHelpers rtcHelpers2 = new RtcHelpers(mock)
        Map snapshotOfStream = rtcHelpers2.getSnapshotContextStreamMap('test_stream', 'test_PA')
        Map buildDefStream = rtcHelpers2.getBuildTypeSnapshotMap('Test_Snapshot', snapshotOfStream)
        then:
        assert buildDefStream.buildSnapshot == 'Test_Snapshot'
        assert buildDefStream.buildSnapshotContext == [owningStream: 'test_stream',
                                                       processAreaOfOwningStream: 'test_PA',
                                                       snapshotOwnerType: 'stream',]
        assert buildDefStream.currentSnapshotOwnerType == 'stream'
        assert buildDefStream.pathToLoadRuleFile == 'path/to/loadrule.loadrule'
        when:
        Map snapshotOfWs = rtcHelpers.getSnapshotContextWorkspaceMap('test_workspace')
        Map buildDefCustom = rtcHelpers.getBuildTypeSnapshotMap('Test_Snapshot', snapshotOfWs,
                                                                'different/path.loadrule',
                                                                true, 'LoadWS')
        then:
        assert buildDefCustom.buildSnapshot == 'Test_Snapshot'
        assert buildDefCustom.buildSnapshotContext == [owningWorkspace: 'test_workspace',
                                                       snapshotOwnerType: 'workspace',]
        assert buildDefCustom.clearLoadDirectory == true
        assert buildDefCustom.currentSnapshotOwnerType == 'workspace'
        assert buildDefCustom.loadDirectory == 'LoadWS'
        assert buildDefCustom.pathToLoadRuleFile == 'different/path.loadrule'
    }

    @Test
    void 'test_getBuildTypeStreamMap'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.loadRulePath = 'path/to/loadrule.loadrule'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildDef = rtcHelpers.getBuildTypeStreamMap('Test_Stream', 'Test_PA')
        then:
        assert buildDef.buildStream == 'Test_Stream'
        assert buildDef.clearLoadDirectory == false
        assert buildDef.customizedSnapshotName == ''
        assert buildDef.generateChangelogWithGoodBuild == false
        assert buildDef.loadDirectory == 'JWS'
        assert buildDef.loadPolicy == 'useLoadRules'
        assert buildDef.overrideDefaultSnapshotName == false
        assert buildDef.pathToLoadRuleFile == 'path/to/loadrule.loadrule'
        assert buildDef.processArea == 'Test_PA'
        assert buildDef.value == 'buildStream'
        when:
        Map buildDefCustom = rtcHelpers.getBuildTypeStreamMap('Test_Stream', 'Test_PA',
                                                              'different/path.loadrule',
                                                              'Test_Snapshot', true,
                                                              true, 'LoadWS')
        then:
        assert buildDefCustom.buildStream == 'Test_Stream'
        assert buildDefCustom.clearLoadDirectory == true
        assert buildDefCustom.customizedSnapshotName == 'Test_Snapshot'
        assert buildDefCustom.generateChangelogWithGoodBuild: true
        assert buildDefCustom.loadDirectory == 'LoadWS'
        assert buildDefCustom.overrideDefaultSnapshotName == true
        assert buildDefCustom.pathToLoadRuleFile == 'different/path.loadrule'
        assert buildDefCustom.processArea == 'Test_PA'
    }

    @Test
    void 'test_deliverRtcDefault'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap = rtcHelpers.getNodeByUUIDMap('12345678')
        Map targetNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.deliverRtc(sourceNodeMap, targetNodeMap, '*')
        then:
        assert mock.stepCall.$class == 'RTCDeliverPublisher'
        assert mock.stepCall.entries[0].components == '*'
        assert mock.stepCall.entries[0].includeBaselines == true
        assert mock.stepCall.entries[0].includeChangesets == true
        assert mock.stepCall.entries[0].includeComponents == false
        assert mock.stepCall.entries[0].includeRemovedComponents == false
        assert mock.stepCall.entries[0].includeReplacedComponents == true
        assert mock.stepCall.entries[0].incomingChangesetsHandling == 'ABORT'
        assert mock.stepCall.entries[0].skipAutoBaselines == true
        assert mock.stepCall.entries[0].source == [$class: 'NodeByUUIDIdentifier',
                                                   credentialsID: '',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',
                                                   uuid: '12345678',]
        assert mock.stepCall.entries[0].target == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: '',
                                                   flowNodeName: 'my_node',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',]
        assert mock.stepCall.entries[0].workitemCreationAlgo == [$class: 'CreateWiNeverAlgo']
    }

    @Test
    void 'test_deliverRtcOverride'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap2 = rtcHelpers.getNodeByUUIDMap('12345678', 'src_creds', 'source.com')
        Map targetNodeMap2 = rtcHelpers.getNodeByNameMap('my_node', 'tgt_creds', 'target.com')
        rtcHelpers.deliverRtc(sourceNodeMap2, targetNodeMap2, '*', false, false, false, false,
                              true, true, 'CHECK')
        then:
        assert mock.stepCall.entries[0].includeBaselines == false
        assert mock.stepCall.entries[0].includeChangesets == false
        assert mock.stepCall.entries[0].includeComponents == true
        assert mock.stepCall.entries[0].includeRemovedComponents == true
        assert mock.stepCall.entries[0].includeReplacedComponents == false
        assert mock.stepCall.entries[0].incomingChangesetsHandling == 'CHECK'
        assert mock.stepCall.entries[0].skipAutoBaselines == false
        assert mock.stepCall.entries[0].source == [$class: 'NodeByUUIDIdentifier',
                                                   credentialsID: 'src_creds',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',
                                                   uuid: '12345678',]
        assert mock.stepCall.entries[0].target == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'tgt_creds',
                                                   flowNodeName: 'my_node',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'target.com',]
        when:
        Map sourceNodeMap4 = rtcHelpers.getNodeByUUIDMap('12345678')
        Map targetNodeMap4 = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.deliverRtc(sourceNodeMap4, targetNodeMap4, '*', true, true, true, true,
                              false, false, 'STOP')
        then:
        thrown(ConfigurationException)
    }

    @Test
    void 'test_syncStreams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap = rtcHelpers.getNodeByUUIDMap('12345678')
        Map targetNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.syncStreams(sourceNodeMap, targetNodeMap)
        then:
        assert mock.stepCall.$class == 'RTCDeliverPublisher'
        assert mock.stepCall.entries[0].$class == 'RTCSynchronizeEntry'
        assert mock.stepCall.entries[0].source == [$class: 'NodeByUUIDIdentifier',
                                                   credentialsID: '',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',
                                                   uuid: '12345678',]
        assert mock.stepCall.entries[0].target == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: '',
                                                   flowNodeName: 'my_node',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',]
    }

    @Test
    void 'test_checkoutRtc'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildConfig = rtcHelpers.getBuildTypeDefinitionMap('Test_BD')
        rtcHelpers.checkoutRtc(buildConfig)
        then:
        assert mock.checkoutCall.changelog == true
        assert mock.checkoutCall.poll == true
        assert mock.checkoutCall.scm == [$class: 'RTCScm',
                                         avoidUsingToolkit: false,
                                         buildTool: 'RTC_BuildToolkit_6_0_4',
                                         buildType: [buildDefinition: 'Test_BD',
                                                     customizedSnapshotName: '',
                                                     overrideDefaultSnapshotName: false,
                                                     useDynamicLoadRules: false,
                                                     value: 'buildDefinition'],
                                         credentialsId: '',
                                         overrideGlobal: true,
                                         serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',
                                         timeout: 480,]
        when:
        Map buildConfig2 = rtcHelpers.getBuildTypeDefinitionMap('Test_BD')
        rtcHelpers.checkoutRtc(buildConfig2, false, false, 'my_creds', 'Toolkit_2.0', 'https://my.test.server.com')
        then:
        assert mock.checkoutCall.changelog == false
        assert mock.checkoutCall.poll == false
        assert mock.checkoutCall.scm == [$class: 'RTCScm',
                                         avoidUsingToolkit: false,
                                         buildTool: 'Toolkit_2.0',
                                         buildType: [buildDefinition: 'Test_BD',
                                                     customizedSnapshotName: '',
                                                     overrideDefaultSnapshotName: false,
                                                     useDynamicLoadRules: false,
                                                     value: 'buildDefinition'],
                                         credentialsId: 'my_creds',
                                         overrideGlobal: true,
                                         serverURI: 'https://my.test.server.com',
                                         timeout: 480,]
    }

    @Test
    void 'test_checkinRtc'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map targetNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        List files = [rtcHelpers.getFileEntryMap('a/b', 'my_file.c', 'c')]
        List components = [rtcHelpers.getComponentEntryMap('my_comp', files, 1234)]
        rtcHelpers.checkinRtc(targetNodeMap, components)
        then:
        assert mock.stepCall.$class == 'RTCCheckinPublisher'
        assert mock.stepCall.componentEntries == [[componentName: 'my_comp',
                                                   fileEntries: [[destPath: 'a/b',
                                                                  filename: 'my_file.c',
                                                                  folderLevel: 'c']],
                                                   workItemIdentifier: [$class: 'WorkItemByIdIdentifier',
                                                                        id: 1234]],]
        assert mock.stepCall.targetNode == [$class: 'NodeByNameIdentifier',
                                            credentialsID: '',
                                            flowNodeName: 'my_node',
                                            nodeType: 'workspaceOrStream',
                                            overrideGlobal: true,
                                            serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',]
    }

    @Test
    void 'test_applySnapshot'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.applySnapshot('my_snapshot', sourceNodeMap)
        then:
        assert mock.stepCall.$class == 'SnapshotCreator'
        assert mock.stepCall.snapshotName == 'my_snapshot'
        assert mock.stepCall.source == [$class: 'NodeByNameIdentifier',
                                        credentialsID: '',
                                        flowNodeName: 'my_node',
                                        nodeType: 'workspaceOrStream',
                                        overrideGlobal: true,
                                        serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',]
    }

    @Test
    void 'test_parseRtcChanges'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        List fileList = rtcHelpers.parseRtcChanges(mock.currentBuild.changeSets)
        then:
        assert fileList == ['this\\is\\an\\rtc\\component\\your\\c\\file.c',
                            'this\\is\\an\\rtc\\component\\your\\h\\file.h']
        when:
        List fileListNull = rtcHelpers.parseRtcChanges(mock.currentBuild.changeSets,
                                                       ['.cpp'])
        then:
        assert fileListNull == []
        when:
        List fileListExclude = rtcHelpers.parseRtcChanges(mock.currentBuild.changeSets,
                                                          ['.c'],
                                                          ['this.is.an.rtc.component'])
        then:
        assert fileListExclude == []
    }

    @Test
    void 'test_getChangeSetData'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        String changes = rtcHelpers.getChangeSetData(mock.currentBuild.changeSets)
        then:
        assert changes == 'techUserDevOps on 1970-01-27T22:20:23.232+01:00[GMT+01:00]: x_delivered\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/c/file.c\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/h/file.h\r\n' +
                          'techUserDevOps on 1970-01-27T22:20:23.232+01:00[GMT+01:00]: x_delivered\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/c/file.c\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/h/file.h\r\n'
    }

    @Test
    void 'lscmFunctionTests'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        rtcHelpers.lscmUtil.login()
        rtcHelpers.lscmUtil.logout()
        rtcHelpers.lscmUtil.login(20)
        rtcHelpers.lscmUtil.acceptFromSourceToTarget('target_stream', 'target_rws')
        rtcHelpers.lscmUtil.acceptFromSourceToTarget('target_stream', 'target_rws', true)
        List<HashMap> streamList = rtcHelpers.lscmUtil.listStreams('test_proj')
        List<HashMap> wsList = rtcHelpers.lscmUtil.listWorkspaces()
        List<HashMap> createdStream = rtcHelpers.lscmUtil.generateStream('test_proj',
                                                                         'snapshot_yy_mm_dd', 'mock_stream')
        rtcHelpers.lscmUtil.deleteStream('mock_stream', '', '')
        List<HashMap> createdRws = rtcHelpers.lscmUtil.generateRws('mock_stream', 'mock_rws')
        rtcHelpers.lscmUtil.deleteRws('mock_rws')
        rtcHelpers.lscmUtil.listSnapshots('test_proj', 'tempStream')
        rtcHelpers.lscmUtil.deleteSnapshot('mock_rws', 'snapshot_yy_mm_dd')
        rtcHelpers.teamAreaSetup('mock_project', 'streamName1', 'snapshot_yy_mm_dd', ['rws1', 'rws2'])
        rtcHelpers.lscmUtil.deleteSnapshot('mock_rws', 'snapshot_yy_mm_dd')
        rtcHelpers.teamAreaTearDown('test_proj', ['rws1', 'rws2'], 'intStrean', 'tempStream', '* !componenttofilter')
        then:
        Map data1 = ['owner': 'mock_project', 'name': 'streamName1', 'uuid': 'XYZABCD1', 'url': 'https://rb-alm/ccm/']
        Map data2 = ['owner': 'mock_project', 'name':'streamName2', 'uuid': 'XYZABCD2', 'url': 'https://rb-alm/ccm/']
        List<HashMap> reff = [data1]
        List<HashMap> reff2 = [data1, data2]
        assert rtcHelpers.lscmUtil.lscmPath == 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        assert streamList == reff2
        assert wsList == reff2
        assert createdStream == reff
        assert createdRws == reff
        assert mock.inputFuncCalled == 1
    }

    @Test
    void 'test_lscmUtilCustom'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        rtcHelpers.lscmUtil.logout()
        rtcHelpers.lscmUtil.login(20)
        rtcHelpers.lscmUtil.acceptFromSourceToTarget('target_stream', 'target_rws', true)
        List<HashMap> streamList = rtcHelpers.lscmUtil.listStreams('test_proj', 1)
        List<HashMap> wsList = rtcHelpers.lscmUtil.listWorkspaces(1)
        List<HashMap> createdStream = rtcHelpers.lscmUtil.generateStream('test_proj', 'snapshot_yy_mm_dd',
                                                                         'mock_stream', false)
        rtcHelpers.lscmUtil.deleteStream('mock_stream', 'backup_stream')
        rtcHelpers.lscmUtil.deleteStream('mock_stream', 'backup_stream', 'test_proj')
        List<HashMap> createdRws = rtcHelpers.lscmUtil.generateRws('mock_stream', 'mock_rws', false)
        rtcHelpers.lscmUtil.deleteRws('mock_rws', false)
        rtcHelpers.lscmUtil.listSnapshots('test_proj', 'tempStream', 2)
        rtcHelpers.teamAreaTearDown('test_proj', ['rws1', 'rws2'], 'intStrean',
                                    'tempStream', '* !componenttofilter', true, true, 'intStream')
        then:
        Map data1 = ['owner': 'mock_project', 'name': 'streamName1', 'uuid': 'XYZABCD1', 'url': 'https://rb-alm/ccm/']
        Map data2 = ['owner': 'mock_project', 'name':'streamName2', 'uuid': 'XYZABCD2', 'url': 'https://rb-alm/ccm/']
        List<HashMap> reff = [data1]
        List<HashMap> reff2 = [data1, data2]
        assert rtcHelpers.lscmUtil.lscmPath == 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        assert streamList == reff2
        assert wsList == reff2
        assert createdStream == reff
        assert createdRws == reff
        assert mock.inputFuncCalled == 1
    }

    @Test
    void 'test_compare'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        this.batMapCall = []
        Map parsedJson = rtcHelpers.lscmUtil.compare('snapshot', 'workspace')
        String script = '@C:\\rtc-scmtools\\eclipse\\lscm.bat compare -r '
        script += 'https://rb-alm-11-p.de.bosch.com/ccm snapshot snapshot ws workspace -I fc --json'
        then:
        assert this.batMapCall[0].script == script
        assert (parsedJson.containsKey('direction'))
        assert parsedJson.direction.components.changesets.versionables.path != []
    }

    @Test
    void 'test_findChangesets'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map changesets = rtcHelpers.lscmUtil.compare('snapshot', 'workspace')
        List<HashMap> changesetFindings = rtcHelpers.lscmUtil.findChangesets(changesets)
        then:
        assert changesetFindings == ['rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/src/Can_Appl.c',
                                     'rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/gen/Can_Lcfg.c']
        when:
        changesets = rtcHelpers.lscmUtil.compare('snapshot', 'workspace')
        changesetFindings = rtcHelpers.lscmUtil.findChangesets(changesets, ['gen/Can_Lcfg.c'])
        then:
        assert changesetFindings == ['rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/src/Can_Appl.c']
    }

    @Test
    void 'test_compareFindings'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        List<String> allFindings = rtcHelpers.lscmUtil.compareFindings('snapshot', 'workspace')
        then:
        assert allFindings == ['rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/src/Can_Appl.c',
                               'rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/gen/Can_Lcfg.c']
    }

    @Test
    void 'test_RTCcompare'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        List<String> allFindings = rtcHelpers.compare('snapshot', 'workspace')
        then:
        assert allFindings == ['rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/src/Can_Appl.c',
                               'rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/gen/Can_Lcfg.c']
        when:
        allFindings = rtcHelpers.compare('snapshot', 'workspace', ['/gen/'])
        then:
        assert allFindings == ['rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/src/Can_Appl.c',]
    }

    @Test
    void 'test_prRebase'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpersMock rtcHelpers = new RtcHelpersMock(mock)
        rtcHelpers.credentials = 'creds'
        rtcHelpers.server = 'source.com'
        when:
        rtcHelpers.prRebase('targetNodeMap', 'sourceNodeMap2', 'sourceNodeMap', 'test')
        then:
        assert rtcHelpers.numOfCalls == 2
        assert rtcHelpers.lastIncomingChangesets[0] == 'REPLACE'
        assert rtcHelpers.lastIncomingChangesets[1] == 'CHECK'
        assert rtcHelpers.lastComponentRule == ['*', 'test']
        assert rtcHelpers.lastSourceNodeMap[0] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'sourceNodeMap2',
                                                   overrideGlobal: true,
                                                   nodeType:'workspaceOrStream',
                                                   serverURI: 'source.com',]
        assert rtcHelpers.lastTargetNodeMap[0] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'targetNodeMap',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',]
        assert rtcHelpers.lastSourceNodeMap[1] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'sourceNodeMap',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',]
        assert rtcHelpers.lastTargetNodeMap[1] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'targetNodeMap',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',]
    }

    @Test
    void 'test_listComponents'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        this.batMapCall = []
        String mockStream = 'mock_str'
        String teamArea = 'mock_area'
        String maxArg = '--maximum all'
        Map componentList = rtcHelpers.lscmUtil.listComponents(mockStream, teamArea)
        rtcHelpers.lscmUtil.listComponents(mockStream, teamArea, 2)
        String script = '@C:\\rtc-scmtools\\eclipse\\lscm.bat list components -r https://rb-alm-11-p.de.bosch.com/ccm '
        script += "--teamarea \"${teamArea}\" \"${mockStream}\" $maxArg --json"
        then:
        assert this.batMapCall[0].script == script
        assert this.batMapCall[0].script.contains('--teamarea "mock_area"') == true
        assert this.batMapCall[0].script.contains('"mock_str" --maximum all --json') == true
        assert componentList.containsKey('workspaces') == true
        assert componentList['workspaces'].first().containsKey('components') == true
        assert componentList['workspaces'].first()['components'].size == 2
        assert componentList['workspaces'].first()['components'].first().containsKey('uuid') == true
        assert componentList['workspaces'].first()['name'] == 'streamName'
    }

    @Test
    void 'test_promoteSnapshotToStream'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        rtcHelpers.lscmUtil.promoteSnapshotToStream('streamName1', 'snapshot1')
        then:
        assert this.batMapCall[0].script.contains('--ownedby "streamName1"')
        assert this.batMapCall[0].script.contains('-s "snapshot1"')
        when:
        this.batMapCall = []
        rtcHelpers.lscmUtil.promoteSnapshotToStream('streamName1', 'snapshot1', 'mock_project')
        then:
        assert this.batMapCall[0].script.contains('--teamarea "mock_project"') == true
        assert this.batMapCall[0].script.contains('list streams') == true
        assert this.batMapCall[1].script.contains('--ownedby "XYZABCD1"')
        assert this.batMapCall[1].script.contains('-s "snapshot1"')
    }

    @Test
    void 'test_getLatestReleaseSnapshot'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        this.batMapCall = []
        String searchStream = 'streamName1'
        String teamarea = 'mock_project'
        String nameContains = 'test_Name'
        String releaseSnapshot = rtcHelpers.lscmUtil.getLatestReleaseSnapshot(
                                       searchStream, teamarea, nameContains)
        String script = '@C:\\rtc-scmtools\\eclipse\\lscm.bat query -r https://rb-alm-11-p.de.bosch.com/ccm '
        script += "-m 1 --snapshot \"for_stream('${searchStream}') and in_teamarea('${teamarea}') "
        script += "and name matches '${nameContains}'\" --json"
        then:
        assert this.batMapCall[0].script == script
        assert releaseSnapshot == 'test_ReleaseSnapshot'
    }

}
