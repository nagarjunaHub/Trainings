/**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test

import groovy.util.slurpersupport.GPathResult
import org.codehaus.groovy.control.ConfigurationException

class JrsHelpersTest extends Specification {

    private final String proServer = 'https://rb-alm-11-p.de.bosch.com/rs'
    private final String altServer = 'https://rb-alm-12-p.de.bosch.com/rs'
    private final String datFormat = 'VSS91176datahttps://alm.com/qmVSS91177datahttps://alm.com/qm'
    private final String irmProServerTemplate = "irm -Uri '${this.proServer}'"
    private final String irmAltServerTemplate = "irm -Uri '${this.altServer}'"

    private List<Map> psMapCall = []
    private final Answer powershellOverride = new Answer<String>() {

        String answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.psMapCall += param
            final String psReturn = true
            if (param.containsKey('script') && param.containsKey('returnStdout')) {
                if (param.script.startsWith('irm -Uri \'https://rb-alm-') && param.script.contains('InnerXml')) {
                    return '''<?xml version="1.0" encoding="UTF-8"?>
                        <results>
                            <result>
                                <rqm_merged_QM_20Test_20Case1_projectArea>VSS</rqm_merged_QM_20Test_20Case1_projectArea>
                                <rqm_merged_QM_20Test_20Case1_shortId>91176</rqm_merged_QM_20Test_20Case1_shortId>
                                <rqm_merged_QM_20Test_20Case1_title>data</rqm_merged_QM_20Test_20Case1_title>
                                <rqm_merged_QM_20Test_20Case1>https://alm.com/qm</rqm_merged_QM_20Test_20Case1>
                            </result>
                            <result>
                                <rqm_merged_QM_20Test_20Case1_projectArea>VSS</rqm_merged_QM_20Test_20Case1_projectArea>
                                <rqm_merged_QM_20Test_20Case1_shortId>91177</rqm_merged_QM_20Test_20Case1_shortId>
                                <rqm_merged_QM_20Test_20Case1_title>data</rqm_merged_QM_20Test_20Case1_title>
                                <rqm_merged_QM_20Test_20Case1>https://alm.com/qm</rqm_merged_QM_20Test_20Case1>
                            </result>
                        </results>
                        '''
                }
            }
            return (this.returnStatusLiteral in param) ? '0' : psReturn
        }

    }

    @Test
    void 'test_reporHelpers_default'() {
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        mockPointer.env.jrsCredentials = 'test_cred_id'
        doAnswer(powershellOverride).when(mockPointer).powershell(any(Map))
        JrsHelpers jrsHelp = new JrsHelpers(mockPointer)
        AebeDevOps devOpsUtil = new AebeDevOps(mockPointer)
        when:
        String reportUrl = 'https://rb-alm-11-p.de.bosch.com/rs/query/29965'
        GPathResult data = jrsHelp.fetchReportData(reportUrl, 'mock_cred_id')
        Map transformData = jrsHelp.xmlMapWorkflow(reportUrl, 'mock_cred_id')
        devOpsUtil.writeMapToConfig(transformData)
        then:
        assert this.psMapCall[0].script.contains(irmProServerTemplate)
        assert this.psMapCall[0].script.contains('Og==')
        assert this.psMapCall[0].script.contains(reportUrl)
        assert this.psMapCall[0].returnStdout
        assert data == this.datFormat
    }

    @Test(expected = ConfigurationException)
    void 'test_JrsHelpers_exception'() {
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        JrsHelpers jrsHelp = new JrsHelpers(mockPointer)
        AebeDevOps devOpsUtil = new AebeDevOps(mockPointer)
        doAnswer(powershellOverride).when(mockPointer).powershell(any(Map))
        when:
        String reportUrl = 'https://rb-alm-11-p.de.bosch.com/rs/query/29967'
        Map transformData = jrsHelp.xmlMapWorkflow(reportUrl, 'mock_cred_id')
        devOpsUtil.writeMapToConfig(transformData, 'other_report', 'gson')
        then:
        assert this.psMapCall[0].script.contains(irmProServerTemplate)
        transformData.results.each { element ->
            assert element.containsKey('result') == true
        }
        thrown(ConfigurationException)
    }

    @Test
    void 'test_JrsHelpers_custom'() {
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        JrsHelpers jrsHelp = new JrsHelpers(mockPointer)
        AebeDevOps devOpsUtil = new AebeDevOps(mockPointer)
        doAnswer(powershellOverride).when(mockPointer).powershell(any(Map))
        when:
        String reportUrl = 'https://rb-alm-12-p.de.bosch.com/rs/query/29966'
        GPathResult data = jrsHelp.fetchReportData(reportUrl, 'mock_cred_id')
        Map transformData = jrsHelp.xmlMapWorkflow(reportUrl, 'mock_cred_id')
        devOpsUtil.writeMapToConfig(transformData, 'report_data', 'json')
        then:
        assert this.psMapCall[0].script.contains(irmAltServerTemplate)
        assert data == this.datFormat
        assert transformData.containsKey('results') == true
        transformData.results.each { element ->
            assert element.containsKey('result') == true
        }
    }

    @Test(expected = ConfigurationException)
    void 'test_JrsHelpers_wrongReportUrl'() {
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        JrsHelpers jrsHelp = new JrsHelpers(mockPointer)
        doAnswer(powershellOverride).when(mockPointer).powershell(any(Map))
        when:
        String reportUrl = 'fttp://rb-alm-12-p.de.bosch.com/rs/query/29967'
        jrsHelp.xmlMapWorkflow(reportUrl, 'mock_cred_id')
        then:
        thrown(ConfigurationException)
    }

}
