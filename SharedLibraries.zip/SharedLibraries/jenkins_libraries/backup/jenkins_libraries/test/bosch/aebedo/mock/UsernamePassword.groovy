/**
 * Copyright (C) 2018, 2018 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo.mock

class UsernamePassword {

    String credentialsId
    String usernameVariable
    String passwordVariable

    String getUsername() {
        switch (credentialsId) {
            case 'jenkinsCredentials':
                return 'jenkinsUser'
            case 'techUserCredentials':
                return 'techUser'
            default:
                return ''
        }
    }

    String getPassword() {
        switch (credentialsId) {
            case 'jenkinsCredentials':
                return 'encryptedHashedMegaPassword'
            case 'techUserCredentials':
                return 'encryptedTechUserPassword'
            default:
                return ''
        }
    }

}

class UsernameColonPassword {

    String credentialsId
    String variable

    String getUsername() {
        switch (credentialsId) {
            case 'jenkinsCredentials':
                return 'jenkinsUser'
            default:
                return ''
        }
    }

    String getPassword() {
        switch (credentialsId) {
            case 'jenkinsCredentials':
                return 'encryptedHashedMegaPassword'
            default:
                return ''
        }
    }

}
