/**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test

class BMIHelpersTest extends Specification {

    @Test
    void 'test_calcBMI'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        BMIHelpers bmiHelpers = new BMIHelpers(mockPointer)
        when:
        String collectMetricsPath = 'test'
        String bmifilePath = null
        Integer status = bmiHelpers.calcBMI(collectMetricsPath, bmifilePath)
        then:
        assert mockPointer.batMapCall['script'] == "python collect_metrics.py --bmifile ${bmifilePath}"
        assert status as int == 0
        when:
        String bmifilePath2 = 'test'
        bmiHelpers.calcBMI(collectMetricsPath, bmifilePath2)
        then:
        assert mockPointer.batMapCall['script'] == "python collect_metrics.py --bmifile ${bmifilePath2}"
    }

    @Test
    void 'test_setResult'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        BMIHelpers bmiHelpers = new BMIHelpers(mock)
        when:
        Integer bmiMetric = 0
        String result = bmiHelpers.setResult(bmiMetric)
        then:
        assert result == 'SUCCESS'
        when:
        BMIHelpers bmiHelpers2 = new BMIHelpers(mock)
        Integer bmiMetric2 = -1
        String result2 = bmiHelpers2.setResult(bmiMetric2)
        then:
        assert result2 == 'UNSTABLE'
        when:
        BMIHelpers bmiHelpers3 = new BMIHelpers(mock)
        Integer bmiMetric3 = 1
        String result3 = bmiHelpers3.setResult(bmiMetric3)
        then:
        assert result3 == 'FAILURE'
    }

}
