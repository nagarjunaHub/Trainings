/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import static org.mockito.Mockito.doReturn
import static org.mockito.Mockito.doThrow
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.ArtifactoryMock
import org.junit.Test
import spock.lang.Specification
import bosch.aebedo.mock.JenkinsFileMock

class Cdq0302DashboardTest extends Specification {

    private int echoCall = 0
    private final Answer echoOverride = new Answer<Void>() {

        Void answer(InvocationOnMock invocation) throws Throwable {
            String param = invocation.arguments[0] as String
            this.echoCall += 1
            return null
        }

    }

    @Test
    void 'test_cdq_checkoverrides'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.repo = 'aebe-test-default'
        mockPointer.env.artifactoryProject = 'CI_Artifactory_default'
        mockPointer.env.stream = 'Int_SW'
        mockPointer.env.metricType = 'Testmetric'
        String configPass = 'Credentials'
        Cdq0302Dashboard cdq = new Cdq0302Dashboard(mockPointer, configPass, null, Cdq0302Dashboard.ReqTools.DNG)
        when:
        cdq.setupMegenjaEnvironment()
        cdq.uploadMetrics()
        then:
        assert cdq.artifactory.envArtifactoryRepo == 'aebe-test-default'
        assert cdq.loadConfig().get(1) == "Metrics/MeGenJa/Config/${mockPointer.env.project}"
        assert cdq.loadConfig().get(2) == "Metrics/MeGenJa/dxl/${mockPointer.env.project}"
        assert cdq.downloadBuildData().get(0).stream == ('Int_SW')
        assert cdq.tool == Cdq0302Dashboard.ReqTools.DNG
    }

    @Test
    void 'test_cdq_checkdefault'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.repo = 'aebe-test-default'
        mockPointer.env.artifactoryProject = 'CI_Artifactory_default'
        mockPointer.env.toolVersion = 'version_14.1'
        mockPointer.env.configDir = 'Project/Config'
        mockPointer.env.dxlDir = 'Project/dxl'
        mockPointer.env.dataVersion = 'build_version_2'
        mockPointer.env.downloadProps = ['version':'XXX_YYY_ZZZ', 'type':'metrics', 'stream':'dev_SW']
        mockPointer.env.uploadPath = 'Upload_Path'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        String configPass = 'Credentials'
        Cdq0302Dashboard cdq = new Cdq0302Dashboard(mockPointer, configPass, artifobj)
        when:
        cdq.setupMegenjaEnvironment()
        cdq.uploadMetrics()
        then:
        assert cdq.artifactory == artifobj
        assert cdq.tool == Cdq0302Dashboard.ReqTools.DOORS
        assert cdq.artifactory.envArtifactoryRepo == 'aebe-test-new'
        assert cdq.loadTool().get(0).envArtifactoryRepo == 'aebe-devops-local'
        assert cdq.loadTool().get(1) == 'Tools/MeGenJa'
        assert cdq.loadTool().get(2) == 'version_14.1'
        assert cdq.loadConfig().get(0) == 'tmp/config'
        assert cdq.loadConfig().get(1) == 'Project/Config'
        assert cdq.loadConfig().get(2) == 'Project/dxl'
        assert cdq.downloadBuildData().get(1) == 'build_version_2'
        assert cdq.downloadBuildData().get(0).version == ('XXX_YYY_ZZZ')
        assert cdq.downloadBuildData().get(0).type == ('metrics')
        assert cdq.downloadBuildData().get(0).stream == ('dev_SW')
    }

    @Test
    void 'test_cdq_execute'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        when:
        mockPointer.env.dispName = 'Mock'
        mockPointer.env.mgjCred = 'jenkinsCredentials'
        mockPointer.env.domain = 'Mock_Proj'
        mockPointer.env.configPass = 'Passphrase'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        String configPass = 'Credentials'
        Cdq0302Dashboard cdq = new Cdq0302Dashboard(mockPointer, configPass, artifobj)
        cdq.executeMegenja()
        then:
        mockPointer.batCall.startsWith('java -jar MeGenJa.jar EXE')
        String argStringPass = mockPointer.batCall.split('java -jar MeGenJa.jar EXE')[1]
        final List<String> paramPass = ['-config Config/AE-BE_Mock_Proj', '-result Results',
                                         '-source Source', '-passphrase encryptedHashedMegaPassword']
        for (String param : paramPass) {
            assert argStringPass.contains(param)
        }
        assert argStringPass.contains('-LOGIN') == false
        assert cdq.reportFile == 'Mock_CDQ0302_Metrics.zip'
        when:
        mockPointer.batCall = []
        mockPointer.env.configPass = 'Credentials'
        mockPointer.env.rtcCredentials = 'jenkinsCredentials'
        mockPointer.env.doorsCred = 'techUserCredentials'
        cdq.executeMegenja()
        then:
        mockPointer.batCall.startsWith('java -jar MeGenJa.jar EXE')
        String argStringLogin = mockPointer.batCall.split('java -jar MeGenJa.jar EXE')[1]
        final List<String> paramLogin = ['-config Config/AE-BE_Mock_Proj', '-result Results', '-source Source',
                                          '-LOGIN \"auth|jenkinsUser|encryptedHashedMegaPassword\"',
                                          '-LOGIN \"authDoors|techUser|encryptedTechUserPassword\"']
        for (String param : paramLogin) {
            assert argStringLogin.contains(param)
        }
        assert argStringLogin.contains('-passphrase') == false
        assert cdq.reportFile == 'Mock_CDQ0302_Metrics.zip'
        when:
        mockPointer.batCall = []
        mockPointer.env.currentBuild = ['result':'SUCCESS']
        mockPointer.env.configPass = 'configType'
        cdq.executeMegenja()
        then:
        assert mockPointer.env.currentBuild.result == 'FAILURE'
    }

    @Test
    void 'test_cdq_scm'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.reportName = 'Test_Report'
        String configPass = 'Credentials'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        Cdq0302Dashboard cdq = new Cdq0302Dashboard(mockPointer, configPass, artifobj)
        when:
        mockPointer.env.configScm = 'GitSCM'
        mockPointer.env.configCred = 'test'
        mockPointer.env.configRepo = 'test'
        cdq.downloadConfigSCM()
        then:
        assert cdq.reportFile == 'Test_Report'

        when:
        mockPointer.env.configScm = 'GitSCM'
        mockPointer.env.configCred = 'test'
        mockPointer.env.configRepo = 'test'
        mockPointer.env.configBranch = 'feature/x'
        cdq.downloadConfigSCM()
        then:
        assert cdq.reportFile == 'Test_Report'

        when:
        mockPointer.env.configScm = 'RTCscm'
        mockPointer.env.configBranch = 'test'
        cdq.downloadConfigSCM()
        then:
        assert cdq.reportFile == 'Test_Report'
    }

    @Test
    void 'test_cdq0302_dashboard_download_build_data_fileExists'() {
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        mockPointer.metaClass.Artifactory = new ArtifactoryMock()
        doAnswer(echoOverride).when(mockPointer).echo(any(String))
        doReturn(false).when(mockPointer).fileExists(any(String))
        String configPass = 'Credentials'
        when:
        this.echoCall = 0
        Cdq0302Dashboard downloadData = new Cdq0302Dashboard(mockPointer, configPass, null)
        downloadData.downloadBuildData()
        then:
        assert mockPointer.fileExists('test') == false
        assert this.echoCall == 1
    }

    @Test(expected = IllegalArgumentException)
    void 'test_cdq0302_dashboard_download_build_data_exception'() {
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        mockPointer.env.project = 'dummy_proj'
        mockPointer.env.domain = 'dummy_domain'
        mockPointer.env.repo = 'dummy_repo'
        mockPointer.env.artifactoryProject = 'dummy_project'
        mockPointer.env.reportName = 'report_dummy'
        mockPointer.metaClass.Artifactory = new ArtifactoryMock()
        doAnswer(echoOverride).when(mockPointer).echo(any(String))
        String configPass = 'Credentials'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        artifobj = spy(artifobj)
        doThrow(new IllegalArgumentException()).when(artifobj)
        .download(any(String), any(String), any(Map), any(Boolean), any(Boolean), any(Boolean))
        when:
        this.echoCall = 0
        Cdq0302Dashboard downloadData = new Cdq0302Dashboard(mockPointer, configPass, artifobj)
        downloadData.downloadBuildData()
        then:
        assert this.echoCall == 2
        thrown(IllegalArgumentException)
    }

    @Test(expected = NullPointerException)
    void 'test_cdq0302_dashboard_download_build_data'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        String configPass = 'Credentials'
        Cdq0302Dashboard downloadData = new Cdq0302Dashboard(mockPointer, configPass)
        downloadData.jenkins.env = null
        when:
        downloadData.downloadBuildData()
        then:
        thrown(NullPointerException)
    }

    @Test(expected = NullPointerException)
    void 'test_cdq0302_dashboard_load_config'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        String confPass = 'Credentials'
        Cdq0302Dashboard loadConfig = new Cdq0302Dashboard(mockPointer, confPass)
        loadConfig.jenkins.env = null
        when:
        loadConfig.loadConfig()
        then:
        thrown(NullPointerException)
    }

    @Test(expected = NullPointerException)
    void 'test_cdq0302_dashboard_download_config_scm'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        String confPass = 'Credentials'
        Cdq0302Dashboard downloadconfigscm = new Cdq0302Dashboard(mockPointer, confPass)
        downloadconfigscm.jenkins.env = null
        when:
        downloadconfigscm.downloadConfigSCM()
        then:
        thrown(NullPointerException)
    }

    @Test(expected = NullPointerException)
    void 'test_cdq0302_dashboard_setup_megenja_environment'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        String confPass = 'Credentials'
        Cdq0302Dashboard setupMegenja = new Cdq0302Dashboard(mockPointer, confPass)
        setupMegenja.jenkins.env = null
        when:
        setupMegenja.setupMegenjaEnvironment()
        then:
        thrown(NullPointerException)
    }

    @Test(expected = NullPointerException)
    void 'test_cdq0302_dashboard_execute_megenja'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        String confPass = 'Credentials'
        Cdq0302Dashboard executeMegenja = new Cdq0302Dashboard(mockPointer, confPass)
        executeMegenja.jenkins.env = null
        when:
        executeMegenja.executeMegenja()
        then:
        thrown(NullPointerException)
    }

    @Test(expected = NullPointerException)
    void 'test_cdq0302_dashboard_upload_metrics'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        String confPass = 'Credentials'
        Cdq0302Dashboard uploadMetrics = new Cdq0302Dashboard(mockPointer, confPass)
        uploadMetrics.jenkins.env = null
        when:
        uploadMetrics.uploadMetrics()
        then:
        thrown(NullPointerException)
    }

    @Test(expected = IllegalArgumentException)
    void 'test_cdq0302_dashboard_authorization_empty_parameter'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.reportName = "${mockPointer.env.dispName}_CDQ0302_Metrics.zip"
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        when:
        String configPassEmpty = 'empty'
        new Cdq0302Dashboard(mockPointer, configPassEmpty, artifobj)
        then:
        thrown(IllegalArgumentException)
        when:
        String configPassNull = null
        new Cdq0302Dashboard(mockPointer, configPassNull, artifobj)
        then:
        thrown(IllegalArgumentException)
    }

    @Test
    void 'test_cdq0302_dashboard_authorization_filled_parameter'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.reportName = 'CDQ0302_Metrics.zip'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        when:
        String cred = 'Credentials'
        Cdq0302Dashboard cdqCred = new Cdq0302Dashboard(mockPointer, cred, artifobj)
        then:
        assert cdqCred.reportFile == 'CDQ0302_Metrics.zip'
        when:
        String pass = 'Passphrase'
        Cdq0302Dashboard cdqPass = new Cdq0302Dashboard(mockPointer, pass, artifobj)
        then:
        assert cdqPass.reportFile == 'CDQ0302_Metrics.zip'
    }

}
