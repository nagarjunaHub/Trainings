/**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test
import org.codehaus.groovy.control.ConfigurationException

class FossidHelpersTest extends Specification {

    private List<Map> psMapCall = []
    private final String listScans = '''{
                                        "operation": "get_all_scans",
                                        "status": "1",
                                        "data": {
                                            "1722": {
                                                "id": "AE-BE_Test_Master_1",
                                                "created": "2021-01-30 09:59:31",
                                                "updated": "2021-01-30 12:18:56",
                                                "user_id": "210",
                                                "project_id": "249",
                                                "code": "AE-BE_Test_Master_1",
                                                "name": "AE-BE_Test_Master_1",
                                                "description": "",
                                                "comment": "",
                                                "is_archived": null,
                                                "target_path": "",
                                                "is_blind_audit": null,
                                                "files_not_scanned": null,
                                                "pending_items": null,
                                                "is_from_report": null,
                                                "git_repo_url": "",
                                                "git_branch": "",
                                                "imported_metadata": null,
                                                "has_file_extension": "1",
                                                "jar_extraction": "if_no_fullmatch",
                                                "any_archives_expanded": "1",
                                                "uploaded_files": "1"
                                            },
                                            "1720": {
                                                "id": "AE-BE_Test_Master_2",
                                                "created": "2021-01-10 10:03:11",
                                                "updated": "2021-01-10 12:19:04",
                                                "user_id": "210",
                                                "project_id": "249",
                                                "code": "AE-BE_Test_Master_2",
                                                "name": "AE-BE_Test_Master_2",
                                                "description": "",
                                                "comment": "",
                                                "is_archived": 1,
                                                "target_path": "",
                                                "is_blind_audit": null,
                                                "files_not_scanned": null,
                                                "pending_items": null,
                                                "is_from_report": null,
                                                "git_repo_url": "",
                                                "git_branch": "",
                                                "imported_metadata": null,
                                                "has_file_extension": "1",
                                                "jar_extraction": "if_no_fullmatch",
                                                "any_archives_expanded": "1",
                                                "uploaded_files": "1"
                                            },
                                            "1725": {
                                                "id": "AE-BE_Test_Master_3",
                                                "created": "2021-01-22 10:03:11",
                                                "updated": "2021-01-22 12:19:04",
                                                "user_id": "210",
                                                "project_id": "249",
                                                "code": "AE-BE_Test_Master_3",
                                                "name": "AE-BE_Test_Master_3",
                                                "description": "",
                                                "comment": "",
                                                "is_archived": null,
                                                "target_path": "",
                                                "is_blind_audit": null,
                                                "files_not_scanned": null,
                                                "pending_items": null,
                                                "is_from_report": null,
                                                "git_repo_url": "",
                                                "git_branch": "",
                                                "imported_metadata": null,
                                                "has_file_extension": "1",
                                                "jar_extraction": "if_no_fullmatch",
                                                "any_archives_expanded": "1",
                                                "uploaded_files": "1"
                                            },
                                            "1730": {
                                                "id": "AE-BE_Test_Master_4",
                                                "created": "2021-02-04 10:03:11",
                                                "updated": "2021-02-04 12:19:04",
                                                "user_id": "210",
                                                "project_id": "249",
                                                "code": "AE-BE_Test_Master_4",
                                                "name": "AE-BE_Test_Master_4",
                                                "description": "",
                                                "comment": "",
                                                "is_archived": null,
                                                "target_path": "",
                                                "is_blind_audit": null,
                                                "files_not_scanned": null,
                                                "pending_items": null,
                                                "is_from_report": null,
                                                "git_repo_url": "",
                                                "git_branch": "",
                                                "imported_metadata": null,
                                                "has_file_extension": "1",
                                                "jar_extraction": "if_no_fullmatch",
                                                "any_archives_expanded": "1",
                                                "uploaded_files": "1"
                                            },
                                        },
                                    }'''
    private final List scans = ['AE-BE_Test_Master_3', 'AE-BE_Test_Master_1', 'AE-BE_Test_Master_4']
    private final Answer powershellOverride = new Answer<String>() {

        String answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.psMapCall += param
            String psReturn = true
            String jsonReturn = '{"status": "1", "message": "Archives found: No", "data":{"is_finished": "1"}}'
            if (param.containsKey('script') && param.containsKey('returnStdout')) {
                if (param.script.startsWith('irm -Uri https://rb-fossid.de.bosch.com/')\
                    && param.script.contains('get_all_scans')) {
                    return listScans
                } else if (param.script.startsWith('irm -Uri https://rb-fossid.de.bosch.com/')) {
                    return param.script.contains('ConvertTo-Json') ? jsonReturn : ''
                }
            }
            return (this.returnStatusLiteral in param) ? '0' : psReturn
        }

    }

    static Boolean equalsFossid(FossidHelpers h1, FossidHelpers h2) {
        return h1.jenkins == h2.jenkins &&
        h1.server == h2.server &&
        h1.credentials == h2.credentials &&
        h1.projectCode == h2.projectCode &&
        h1.scanCode == h2.scanCode &&
        h1.scanName == h2.scanName &&
        h1.reuseType == h2.reuseType &&
        h1.specificProjectCode == h2.specificProjectCode
    }

    @Test
    void 'test_Constructors'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        String fossidCredentials = 'fossidCredentials'
        String fossidProjectCode = 'fossidProjectCode'
        String fossidScanCode = 'fossidScanCode'
        when:
        FossidHelpers h1 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode)
        FossidHelpers h2 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, [:])
        then:
        assert equalsFossid(h1, h2)

        when:
        h1 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, 'foo')
        h2 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, [scanName:'foo'])
        then:
        assert equalsFossid(h1, h2)

        when:
        h1 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, 'foo', 'foo.bar')
        h2 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, [scanName:'foo',
                                                                                            server: 'foo.bar',])
        then:
        assert equalsFossid(h1, h2)

        when:
        h1 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, 'foo',
                                                                                           'foo.bar',
                                                                                           'no_reuse')
        h2 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, [scanName:'foo',
                                                                                            server: 'foo.bar',
                                                                                            reuseType: 'no_reuse',])
        then:
        assert equalsFossid(h1, h2)

        when:
        h1 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, 'foo',
                                                                                           'foo.bar',
                                                                                           'no_reuse',
                                                                                           's')
        h2 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, [scanName:'foo',
                                                                                            server: 'foo.bar',
                                                                                            reuseType: 'no_reuse',
                                                                                            specificProjectCode: 's',])
        then:
        assert equalsFossid(h1, h2)

        when:
        h1 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode,
                                fossidScanCode, '',
                                'https://rb-fossid.de.bosch.com/AE',
                                'specific_project',
                                's')
        h2 = new FossidHelpers(mock, fossidCredentials, fossidProjectCode, fossidScanCode, [specificProjectCode: 's',])
        then:
        assert equalsFossid(h1, h2)
    }

    @Test
    void 'test_defaultParams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, '', '', 'Auto_scan')
        then:
        assert fossidHelpers.scanName == 'Auto_scan'
        assert fossidHelpers.server == 'https://rb-fossid.de.bosch.com/AE'
        when:
        FossidHelpers fossidHelpersCustom = new FossidHelpers(mock, 'secret_creds', 'My_Project_Code', 'My_Scan_Code',
                                                              'My_Scan_Name', 'https://my.test.server.com')
        then:
        assert fossidHelpersCustom.server == 'https://my.test.server.com'
        assert fossidHelpersCustom.credentials == 'secret_creds'
        assert fossidHelpersCustom.projectCode == 'My_Project_Code'
        assert fossidHelpersCustom.scanCode == 'My_Scan_Code'
        assert fossidHelpersCustom.scanName == 'My_Scan_Name'
        assert fossidHelpersCustom.projectCode == 'My_Project_Code'
        assert fossidHelpersCustom.reuseIdentification == true
    }

    @Test
    void 'test_setupProjectScan'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.repo = 'my-artifactory-repo'
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, '', 'Auto_upload_project', 'Auto_scan')
        fossidHelpers.setupProjectScan()
        then:
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"projects","action":"create","data":{"username":"",' +
                                           '"key":"","project_code":"Auto_upload_project","project_name":' +
                                           '"Auto_upload_project"}}\' -ContentType \'application/json\' ' +
                                           '| ConvertTo-Json'
        assert this.psMapCall[1].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"scans","action":"create","data":{"username":"",' +
                                           '"key":"","project_code":"Auto_upload_project","scan_code":' +
                                           '"Auto_scan","scan_name":"Auto_scan"}}\' -ContentType \'application/json\'' +
                                           ' | ConvertTo-Json'
        when:
        FossidHelpers fossidHelpers2 = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan',
                                                         'custom')
        fossidHelpers2.setupProjectScan('new_project')
        then:
        assert this.psMapCall[2].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"projects","action":"create","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","project_code":' +
                                           '"Auto_upload_project","project_name":"new_project"}}\' -ContentType ' +
                                           '\'application/json\' | ConvertTo-Json'
        assert this.psMapCall[3].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"scans","action":"create","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","project_code":' +
                                           '"Auto_upload_project","scan_code":"Auto_scan","scan_name":"custom"}}\' ' +
                                           '-ContentType \'application/json\' | ConvertTo-Json'
    }

    @Test
    void 'test_uploadExtractSource'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        fossidHelpers.uploadExtractSource('src.zip')
        then:
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api_upload_endpoint.php ' +
                                           '-Method Post -Headers @{Authorization=(\'Basic {0}\' -f ' +
                                           '\'amVua2luc1VzZXI6ZW5jcnlwdGVkSGFzaGVkTWVnYVBhc3N3b3Jk\');' +
                                           '\'FOSSID-SCAN-CODE\'=\'QXV0b19zY2Fu\';\'FOSSID-FILE-NAME\'=\'' +
                                           'c3JjLnppcA==\'} -InFile src.zip'
    }

    @Test
    void 'test_runScan'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        fossidHelpers.runScan()
        then:
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"scans","action":"run","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","project_code":' +
                                           '"Auto_upload_project","scan_code":"Auto_scan","scan_name":"Auto_scan",' +
                                           '"auto_identification_detect_declaration":"1","auto_identification_detect_' +
                                           'copyright":"1","delta_only":"1","reuse_identification":"1",' +
                                           '"identification_reuse_type":"specific_project","specific_code":' +
                                           '"Auto_upload_project"}}\' -ContentType \'application/json\' ' +
                                           '| ConvertTo-Json'
        when:
        this.psMapCall = []
        fossidHelpers.runScan(false, false, false, 60)
        then:
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"scans","action":"run","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","project_code":' +
                                           '"Auto_upload_project","scan_code":"Auto_scan","scan_name":"Auto_scan",' +
                                           '"auto_identification_detect_declaration":"0","auto_identification_detect_' +
                                           'copyright":"0","delta_only":"0","reuse_identification":"1",' +
                                           '"identification_reuse_type":"specific_project","specific_code":' +
                                           '"Auto_upload_project"}}\' -ContentType \'application/json\' ' +
                                           '| ConvertTo-Json'
    }

    @Test
    void 'test_generateReport'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        when:
        this.psMapCall = []
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        fossidHelpers.generateReport('test_report.xlsx')
        then:
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"scans","action":"generate_report","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","scan_code":' +
                                           '"Auto_scan","report_type":"xlsx","selection_type":"include_all_licenses",' +
                                           '"selection_view":""}}\' -ContentType \'application/json\' ' +
                                           '-OutFile test_report.xlsx'
        when:
        fossidHelpers.generateReport('test_report2.html', 'dynamic', 'include_copyleft', 'pending_identification')
        then:
        assert this.psMapCall[1].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                           '-Body \'{"group":"scans","action":"generate_report","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","scan_code":' +
                                           '"Auto_scan","report_type":"dynamic","selection_type":"include_copyleft",' +
                                           '"selection_view":"pending_identification"}}\' -ContentType ' +
                                           '\'application/json\' -OutFile test_report2.html'
        when:
        fossidHelpers.generateReport('test_report.xlsx', 'docx')
        then:
        thrown(ConfigurationException)
        when:
        fossidHelpers.generateReport('test_report.xlsx', 'xlsx', 'include_black_duck')
        then:
        thrown(ConfigurationException)
        when:
        fossidHelpers.generateReport('test_report.xlsx', 'xlsx', 'include_copyleft', 'marked_as_unidentified')
        then:
        thrown(ConfigurationException)
    }

    @Test
    void 'test_listScans'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        List allScans = fossidHelpers.listScans('AE-BE_Test_Master')
        then:
        assert (this.psMapCall[0].script.contains('irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post ' +
                                                  '-Body \'{"group":"projects","action":"get_all_scans","data"'))
        assert this.psMapCall[0].returnStdout == true
        assert allScans == scans
    }

    @Test
    void 'test_selectedScans'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        List selectedScans = fossidHelpers.selectedScans(scans, 1)
        then:
        assert selectedScans == ['AE-BE_Test_Master_3', 'AE-BE_Test_Master_1']
        when:
        Integer keepScans = 50
        List selectedScans2 = fossidHelpers.selectedScans(scans, keepScans)
        then:
        assert selectedScans2 == []
    }

    @Test
    void 'test_archiveScans'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        String archivedScans = fossidHelpers.archiveScans(scans)
        then:
        assert archivedScans != ''
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post -Body ' +
                                           '\'{"group":"scans","action":"archive_scan","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","scan_code":' +
                                           '"AE-BE_Test_Master_3"}}\' -ContentType' +
                                           ' \'application/json\' | ConvertTo-Json'
        assert this.psMapCall[1].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post -Body ' +
                                           '\'{"group":"scans","action":"archive_scan","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","scan_code":' +
                                           '"AE-BE_Test_Master_1"}}\' -ContentType' +
                                           ' \'application/json\' | ConvertTo-Json'
    }

    @Test
    void 'test_deleteScans'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        when:
        FossidHelpers fossidHelpers = new FossidHelpers(mock, 'jenkinsCredentials', 'Auto_upload_project', 'Auto_scan')
        fossidHelpers.deleteScans(scans)
        then:
        assert this.psMapCall[0].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post -Body ' +
                                           '\'{"group":"scans","action":"delete","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","scan_code":' +
                                           '"AE-BE_Test_Master_3"}}\' -ContentType' +
                                           ' \'application/json\' | ConvertTo-Json'
        assert this.psMapCall[1].script == 'irm -Uri https://rb-fossid.de.bosch.com/AE/api.php -Method Post -Body ' +
                                           '\'{"group":"scans","action":"delete","data":{"username":' +
                                           '"jenkinsUser","key":"encryptedHashedMegaPassword","scan_code":' +
                                           '"AE-BE_Test_Master_1"}}\' -ContentType' +
                                           ' \'application/json\' | ConvertTo-Json'
        assert this.psMapCall[0].returnStdout == true
    }

}
