/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import bosch.aebedo.mock.JenkinsFileMock
import bosch.aebedo.mock.JenkinsFileUnixMock
import spock.lang.Specification
import org.junit.Test

class GitHelpersTest extends Specification {

    @Test
    void 'test_getGitTool'() {
        when:
        GitHelpers gitHelpers = new GitHelpers(new JenkinsFileMock())
        then:
        assert gitHelpers.gitTool == 'si-z667r_buildslaves'
        when:
        gitHelpers = new GitHelpers(new JenkinsFileUnixMock())
        then:
        assert gitHelpers.gitTool == 'Default'
    }

    @Test
    void 'test_getPathIncludingGit'() {
        when:
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.PATH = 'environmentDefault'
        GitHelpers gitHelpers = new GitHelpers(mock)
        then:
        assert gitHelpers.pathIncludingGit == 'extraGitPath;environmentDefault'
        when:
        mock = new JenkinsFileUnixMock()
        mock.env.PATH = 'environmentDefault'
        gitHelpers = new GitHelpers(mock)
        then:
        assert gitHelpers.pathIncludingGit == 'extraLinuxGitPath:environmentDefault'
    }

    @Test
    void 'test_checkoutDefaultParameters'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        GitHelpers gitHelpers = new GitHelpers(mock)
        mock.env.BRANCH_NAME = 'feature_branch'
        when:
        Map parameters = gitHelpers.getScmStepParameters('test_checkout_id', 'https://from_here')
        then:
        assert parameters.branches.size() == 1
        assert parameters.gitTool == 'si-z667r_buildslaves'
        assert parameters.branches.name.contains('feature_branch')
        assert parameters.userRemoteConfigs.size() == 1
        assert parameters.userRemoteConfigs.credentialsId.contains('test_checkout_id')
        assert parameters.userRemoteConfigs.url.contains('https://from_here')
        assert parameters.extensions.size() == 2
        assert parameters.extensions.$class.contains('UserIdentity')
        assert parameters.extensions.$class.contains('PreBuildMerge')
        parameters.extensions.each { ext ->
            switch (ext.$class) {
                case 'UserIdentity':
                    assert ext.email == 'ae-be-jenkins-noreply@bosch.com'
                    assert ext.name == 'jenkins automation'
                    break
                case 'PreBuildMerge':
                    assert ext.options.mergeRemote == 'origin'
                    assert ext.options.mergeTarget == 'feature_branch'
                    break
                default:
                    throw new AssertionError("Shouldn't get here")
            }
        }
    }

    @Test
    void 'test_checkoutParametersNoMerge'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        GitHelpers gitHelpers = new GitHelpers(mock)
        mock.env.BRANCH_NAME = 'feature_branch'
        when:
        Map parameters = gitHelpers.getScmStepParameters('test_checkout_id', 'https://from_here', false)
        then:
        assert parameters.branches.size() == 1
        assert parameters.gitTool == 'si-z667r_buildslaves'
        assert parameters.branches.name.contains('feature_branch')
        assert parameters.userRemoteConfigs.size() == 1
        assert parameters.userRemoteConfigs.credentialsId.contains('test_checkout_id')
        assert parameters.userRemoteConfigs.url.contains('https://from_here')
        assert parameters.extensions.size() == 1
        assert parameters.extensions.$class.contains('UserIdentity')
        parameters.extensions.each { ext ->
            if (ext.$class == 'UserIdentity') {
                assert ext.email == 'ae-be-jenkins-noreply@bosch.com'
                assert ext.name == 'jenkins automation'
            }
        }
    }

    @Test
    void 'test_checkoutParametersDifferentTargetBranchEnv'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        GitHelpers gitHelpers = new GitHelpers(mock)
        mock.env.BRANCH_NAME = 'feature_branch'
        mock.env.TARGET_BRANCH = 'master'
        when:
        Map parameters = gitHelpers.getScmStepParameters('test_checkout_id', 'https://from_here')
        then:
        assert parameters.branches.size() == 1
        assert parameters.gitTool == 'si-z667r_buildslaves'
        assert parameters.branches.name.contains('feature_branch')
        assert parameters.userRemoteConfigs.size() == 1
        assert parameters.userRemoteConfigs.credentialsId.contains('test_checkout_id')
        assert parameters.userRemoteConfigs.url.contains('https://from_here')
        assert parameters.extensions.size() == 2
        assert parameters.extensions.$class.contains('UserIdentity')
        assert parameters.extensions.$class.contains('PreBuildMerge')
        parameters.extensions.each { ext ->
            switch (ext.$class) {
                case 'UserIdentity':
                    assert ext.email == 'ae-be-jenkins-noreply@bosch.com'
                    assert ext.name == 'jenkins automation'
                    break
                case 'PreBuildMerge':
                    assert ext.options.mergeRemote == 'origin'
                    assert ext.options.mergeTarget == 'master'
                    break
                default:
                    throw new AssertionError("Shouldn't get here")
            }
        }
    }

    @Test
    void 'test_checkoutParametersBranchAPI'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        GitHelpers gitHelpers = new GitHelpers(mock)
        mock.env.BRANCH_NAME = 'feature_branch'
        mock.env.TARGET_BRANCH = 'master'
        when:
        Map parameters = gitHelpers.getScmStepParameters('test_checkout_id', 'https://from_here',
                                                         'feature_branch3', 'feature_branch2')
        then:
        assert parameters.branches.size() == 1
        assert parameters.gitTool == 'si-z667r_buildslaves'
        assert parameters.branches.name.contains('feature_branch3')
        assert parameters.userRemoteConfigs.size() == 1
        assert parameters.userRemoteConfigs.credentialsId.contains('test_checkout_id')
        assert parameters.userRemoteConfigs.url.contains('https://from_here')
        assert parameters.extensions.size() == 2
        assert parameters.extensions.$class.contains('UserIdentity')
        assert parameters.extensions.$class.contains('PreBuildMerge')
        parameters.extensions.each { ext ->
            switch (ext.$class) {
                case 'UserIdentity':
                    assert ext.email == 'ae-be-jenkins-noreply@bosch.com'
                    assert ext.name == 'jenkins automation'
                    break
                case 'PreBuildMerge':
                    assert ext.options.mergeRemote == 'origin'
                    assert ext.options.mergeTarget == 'feature_branch2'
                    break
                default:
                    throw new AssertionError("Shouldn't get here")
            }
        }
    }

    @Test
    void 'test_getFinalSourceBranch'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.CHANGE_BRANCH = 'feature_branch'
        mock.env.BRANCH_NAME = 'master'
        GitHelpers gitHelpers = new GitHelpers(mock)
        when:
        String testString = gitHelpers.getFinalSourceBranch('testBranch')
        testString = gitHelpers.getFinalSourceBranch('')
        then:
        assert testString == 'feature_branch'
    }

    @Test
    void 'test_getScmStepParametersOveload'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.CHANGE_BRANCH = 'feature_branch'
        mock.env.BRANCH_NAME = 'master'
        GitHelpers gitHelpers = new GitHelpers(mock)
        when:
        Map testData = gitHelpers.getScmStepParameters('test_cred', 'test_url',
                                                       'branch1', true)
        then:
        assert testData == [$class: 'GitSCM',
                            branches: [[name: 'branch1']],
                            extensions: [[$class: 'UserIdentity',
                                          email: 'ae-be-jenkins-noreply@bosch.com',
                                          name: 'jenkins automation'],
                                         [$class: 'PreBuildMerge',
                                         options: [mergeRemote: 'origin', mergeTarget: 'master']]],
                            gitTool: 'si-z667r_buildslaves',
                            userRemoteConfigs: [[credentialsId: 'test_cred',
                                                 url: 'test_url']]]
    }

    @Test
    void 'test_getCheckoutExtensions'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        GitHelpers gitHelpers = new GitHelpers(mock)
        when:
        List checkoutExtensions = gitHelpers.getCheckoutExtensions('target', false)
        then:
        assert checkoutExtensions == [[$class: 'UserIdentity',
                                       email: 'ae-be-jenkins-noreply@bosch.com',
                                       name: 'jenkins automation'],]
    }

    @Test
    void 'test_checkout_flags'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        GitHelpers gitHelpers = new GitHelpers(mock)
        when:
        gitHelpers.checkoutUsingGittool('test_cred', 'test_url',
                                        'branch1', 'branch2', false)
        then:
        assert mock.checkoutCall.changelog == true
        assert mock.checkoutCall.poll == true
        when:
        gitHelpers.checkoutUsingGittool('test_cred', 'test_url',
                                        'branch1', 'branch2', false, false, false)
        then:
        assert mock.checkoutCall.changelog == false
        assert mock.checkoutCall.poll == false
    }

}
