/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import bosch.aebedo.mock.JenkinsFileMock
import org.jfrog.hudson.pipeline.common.types.ConanClient
import org.junit.Test
import spock.lang.Specification

class ConanHelpersTest extends Specification {

    private final JenkinsFileMock jenkins = new JenkinsFileMock()

    @Test
    void 'test_getConanEnvListGenericEnv'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env = [CONAN_USER_HOME:'TEST', CONAN_USER_SHORT_HOME:'SHORT_TEST']
        ConanHelpers conanHelper = new ConanHelpers(mock)
        when:
        List<String> testList = conanHelper.conanEnvList
        then:
        assert testList.size() == 4
        assert testList.findAll { tst -> tst.startsWith('CONAN_USER_HOME=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_USER_SHORT_HOME=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_LOGGING_LEVEL=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_NON_INTERACTIVE=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_USER_HOME=') }.each { } [0].split('=')[1] == 'TEST'
        when:
        conanHelper.conanUserHome = 'HOMEDIR'
        testList = conanHelper.conanEnvList
        then:
        assert testList.findAll { tst -> tst.startsWith('CONAN_USER_HOME=') }.each { } [0].split('=')[1] == 'HOMEDIR'
    }

    @Test
    void 'test_getConanEnvListDefaultProperties'() {
        when:
        ConanHelpers conanHelper = new ConanHelpers(new JenkinsFileMock())
        List<String> testList = conanHelper.conanEnvList
        then:
        assert testList.size() == 4
        assert testList.findAll { tst -> tst.startsWith('CONAN_USER_HOME=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_USER_SHORT_HOME=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_LOGGING_LEVEL=') }.each { }.size() == 1
        assert testList.findAll { tst -> tst.startsWith('CONAN_NON_INTERACTIVE=') }.each { }.size() == 1
        String testString = testList.findAll { tst -> tst.startsWith('CONAN_USER_HOME=') }.each { } [0]
        assert testString.split('=')[1] == 'SLAVE_WORKSPACE\\conan_home'
    }

    @Test
    void 'test_getConanEnvListTemporaryEnv'() {
        this.jenkins.withEnv(['CONAN_USER_HOME=Overwrite']) {
            when:
            ConanHelpers conanHelper = new ConanHelpers(jenkins)
            List<String> testList = conanHelper.conanEnvList
            then:
            assert testList.size() == 4
            assert testList.findAll { tst -> tst.startsWith('CONAN_USER_HOME=') }.each { }.size() == 1
            assert testList.findAll { tst -> tst.startsWith('CONAN_USER_SHORT_HOME=') }.each { }.size() == 1
            assert testList.findAll { tst -> tst.startsWith('CONAN_LOGGING_LEVEL=') }.each { }.size() == 1
            assert testList.findAll { tst -> tst.startsWith('CONAN_NON_INTERACTIVE=') }.each { }.size() == 1
            /* groovylint-disable-next-line ImplicitClosureParameter */
            assert testList.findAll { it.startsWith('CONAN_USER_HOME=') }.each { } [0].split('=')[1] == 'Overwrite'
        }
    }

    @SuppressWarnings('JUnitTestMethodWithoutAssert')
    @Test
    void 'test_installConanConfigHTTPS'() {
        ConanHelpers conanHelper = new ConanHelpers(new JenkinsFileMock())
        when:
        conanHelper.installConanConfigHTTPS('testCredentials', 'https://github.com/myGitRepo.git')
        then:
        noExceptionThrown()
        when:
        conanHelper.installConanConfigHTTPS('', 'ssh://github.com/myGitRepo.git')
        then:
        thrown(IllegalArgumentException)
    }

    @Test
    void 'test_getConanClient'() {
        ConanHelpers conanHelper = new ConanHelpers(new JenkinsFileMock())
        ConanClient conanClient = null
        when:
        conanClient = conanHelper.conanClient
        then:
        assert conanClient.userHome == 'SLAVE_WORKSPACE\\conan_home'
        when:
        conanHelper.conanUserHome = 'Overwrite'
        conanClient = conanHelper.conanClient
        then:
        assert conanClient.userHome == 'SLAVE_WORKSPACE\\conan_home'
        when:
        conanHelper = new ConanHelpers(new JenkinsFileMock())
        conanHelper.conanUserHome = 'Overwrite'
        then:
        assert conanHelper.conanClient.userHome == 'Overwrite'
    }

}
