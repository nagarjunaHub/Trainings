/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import spock.lang.Specification
import bosch.aebedo.mock.JenkinsFileMock
import org.junit.Test

class TestCoverageTest extends Specification {

    @Test
    void 'test_testCoverage_executeBart_configTest'() {
    setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.project = ''
        mockPointer.env.dispName = 'Mock'
        mockPointer.env.bartJsonCfg =
        '''
        { "SRS_export" : "SRS_configFile",
          "SysRS_export" : "SysRS_configFile" }
        '''
        mockPointer.env.bartPythonPath = ''
        mockPointer.env.tstIter = ''
        mockPointer.env.DOMAIN = 'XX'
        mockPointer.env.PROJECT = 'XY'
        mockPointer.env.api = 'mockArtApiCred'
        TestCoverage testCoverage = new TestCoverage(mockPointer)
    when:
        testCoverage.setupTestCovEnv()
        testCoverage.executeTestCov()
        testCoverage.uploadTestCov()
    then:
        assert testCoverage.configMap['SysRS_export'] == 'SysRS_configFile'
        assert testCoverage.configMap['SRS_export'] == 'SRS_configFile'
        assert testCoverage.configMap['SysRS_export'] != 'Sys_configFile'
        assert testCoverage.reportFile == 'Mock_TestCov_Report.zip'
        assert testCoverage.resultFolder == 'RESULT'
    }

    @Test
    void 'test_testCoverage_withArtifactory'() {
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        mockPointer.env.project = ''
        mockPointer.env.dispName = 'Mock'
        mockPointer.env.bartJsonCfg =
        '''
        { "SRS_export" : "SRS_configFile",
          "SysRS_export" : "SysRS_configFile" }
        '''
        mockPointer.env.bartPythonPath = ''
        mockPointer.env.tstIter = 'Test_vTESTstudio_Import'
        mockPointer.env.DOMAIN = 'ZZ'
        mockPointer.env.PROJECT = 'YY'
        mockPointer.env.api = 'mockArtApiCred'
        mockPointer.env.ccmLoadDirectory = 'Custom'
        mockPointer.env.reportName = 'MockBartReport.zip'
        mockPointer.env.resultFolder = 'CustomResult'
        mockPointer.env.bartGitBranch = 'feature/ZZ'
        mockPointer.env.toolVersion = '4.1_20191018_142814'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', 'CI_Artifactory_new')
        TestCoverage testCoverage = new TestCoverage(mockPointer, artifobj)
    when:
        testCoverage.setupTestCovEnv()
        testCoverage.executeTestCov()
        testCoverage.uploadTestCov()
    then:
        assert testCoverage.configMap['SysRS_export'] == 'SysRS_configFile'
        assert testCoverage.configMap['SRS_export'] == 'SRS_configFile'
        assert testCoverage.configMap['SysRS_export'] != 'Sys_configFile'
        assert testCoverage.reportFile == 'MockBartReport.zip'
        assert testCoverage.resultFolder == 'CustomResult'
    }

}
