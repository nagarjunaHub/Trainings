/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.ArtifactoryMock
import org.junit.Test
import spock.lang.Specification
import bosch.aebedo.mock.JenkinsFileMock
import groovy.json.JsonSlurperClassic

class VectorCastTest extends Specification {

    private String archiveArtifactsParam = ''
    private final Answer archiveArtifactsOverride = new Answer<Void>() {

        Void answer(InvocationOnMock invocation) throws Throwable {
            String param = invocation.arguments[0] as String
            this.archiveArtifactsParam = param
            return null
        }

    }

    private Map jUnitParam = [:]
    private final Answer jUnitOverride = new Answer<Void>() {

        Void answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.jUnitParam = param
            return null
        }

    }

    @Test
    void 'test_vectorcast_executeVcast'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        when:
        VectorCast vectorcast = new VectorCast(mockPointer)
        vectorcast.executeVcast()
        String spec = vectorcast.artifactory.server.uploadCall.spec
        Map upSpec = new HashMap<>((new JsonSlurperClassic()).parseText(spec))
        then:
        assert mockPointer.batCall == 'call ./runVcast.bat null null null'
        assert upSpec.files.pattern == ['UnitTest_Metrics.zip']
        assert upSpec.files.target == ['null/null/null/VCast/']
        assert upSpec.files.props == ['build.number=null;retention.RetC=30']
        when:
        mockPointer.env.reportResults = 'My_Results.zip'
        mockPointer.env.repo = 'my-test-repo'
        mockPointer.env.artifactoryProject = 'My_Artifactory'
        mockPointer.env.dirVCAST = 'C:/VCAST'
        mockPointer.env.scmPath = 'rbd/tools/VectorCAST'
        mockPointer.env.vcastProj = 'Test_Project'
        mockPointer.env.project = 'test'
        mockPointer.env.dispName = 'build_5'
        VectorCast vectorcast2 = new VectorCast(mockPointer)
        vectorcast2.executeVcast()
        String spec2 = vectorcast2.artifactory.server.uploadCall.spec
        Map upSpec2 = new HashMap<>((new JsonSlurperClassic()).parseText(spec2))
        then:
        assert vectorcast2.artifactory.server.envAebeDevOpsArtifactory == 'My_Artifactory'
        assert mockPointer.batCall == 'call ./runVcast.bat C:/VCAST rbd/tools/VectorCAST Test_Project'
        assert upSpec2.files.pattern == ['My_Results.zip']
        assert upSpec2.files.target == ['my-test-repo/test/build_5/VCast/']
        assert upSpec2.files.props == ['build.number=build_5;retention.RetC=30']
    }

    @Test
    void 'test_vectorcast_artifactory'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        when:
        mockPointer.env.uploadDir = 'VCast_Reports'
        ArtifactoryHelpers artMock = new ArtifactoryHelpers(mockPointer, 'aebe-test-new', '', 'artCreds')
        VectorCast vectorcast = new VectorCast(mockPointer, artMock)
        vectorcast.executeVcast()
        String spec = vectorcast.artifactory.server.uploadCall.spec
        Map upSpec = new HashMap<>((new JsonSlurperClassic()).parseText(spec))
        then:
        assert vectorcast.artifactory.server.envAebeDevOpsArtifactory.credentialsId == 'artCreds'
        assert upSpec.files.target == ['aebe-test-new/VCast_Reports/']
    }

    @Test
    void 'test_vectorcast_nullUpload'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        when:
        VectorCast vectorcast = new VectorCast(mockPointer)
        vectorcast.metaClass.uploadVcast = { null }
        vectorcast.executeVcast()
        then:
        assert vectorcast.artifactory.server.uploadCall == [:]
    }

    @Test
    void 'test_vectorcast_setupVcast'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        when:
        VectorCast vectorcast = new VectorCast(mockPointer)
        vectorcast.setupVcast()
        then:
        assert mockPointer.stepCall.manageProjectName == '\"%workspace%/null/null.vcm\"'
        assert mockPointer.stepCall.nodeLabel == 'null'
        assert mockPointer.batCall == 'call \"%workspace%/null/null\"'

        when:
        mockPointer.env.scmPath = 'rbd/tools/VectorCAST'
        mockPointer.env.vcastProj = 'Test_Project'
        mockPointer.env.NODE_NAME = 'Build_Node_1'
        mockPointer.env.importScript = 'import.bat'
        VectorCast vectorcast2 = new VectorCast(mockPointer)
        vectorcast2.setupVcast()
        then:
        assert mockPointer.stepCall.manageProjectName == '\"%workspace%/rbd/tools/VectorCAST/Test_Project.vcm\"'
        assert mockPointer.stepCall.nodeLabel == 'Build_Node_1'
        assert mockPointer.batCall == 'call \"%workspace%/rbd/tools/VectorCAST/import.bat\"'
    }

    @Test
    void 'test_vectorcast_cleanVcast'() {
        setup:
        JenkinsFileMock mockPointer = spy(new JenkinsFileMock())
        VectorCast vectorcast = new VectorCast(mockPointer)
        assert mockPointer.visitedDir.size() == 0
        assert mockPointer.deleteDirCalled == 0
        when:
        vectorcast.cleanVcast()
        then:
        int lSize = ['execution', 'management', 'xml_data', 'vc_scripts', 'generatedJUnitFiles'].size()
        assert mockPointer.visitedDir.size() == lSize
        assert mockPointer.deleteDirCalled == lSize
    }

    @Test
    void 'test_vectorcast_abstractRegFlow'() {
        setup:
        JenkinsFileMock mockPointer = spy(JenkinsFileMock)
        mockPointer.env.reportResults = 'My_Results.zip'
        mockPointer.env.repo = 'my-test-repo'
        mockPointer.env.artifactoryProject = 'My_Artifactory'
        mockPointer.env.dirVCAST = 'C:/VCAST'
        mockPointer.env.scmPath = 'rbd/tools/VectorCAST'
        mockPointer.env.vcastProj = 'Test_Project'
        mockPointer.env.project = 'test'
        mockPointer.env.dispName = 'build_5'
        mockPointer.env.vcastWorkspaceOverride = 'C:/PROJ/data'
        mockPointer.metaClass.Artifactory = new ArtifactoryMock()
        doAnswer(archiveArtifactsOverride).when(mockPointer).archiveArtifacts(any(String))
        doAnswer(jUnitOverride).when(mockPointer).JUnit(any(LinkedHashMap))
        when:
        VectorCast vectorcast = new VectorCast(mockPointer, null)
        vectorcast.setupVcast()
        vectorcast.runVcast()
        then:
        assert mockPointer.writeFileCall.file == 'runVcast.bat'
        assert mockPointer.writeFileCall.text == true
        assert mockPointer.batCall == 'call ./runVcast.bat C:/VCAST rbd/tools/VectorCAST Test_Project C:/PROJ/data'
        assert this.archiveArtifactsParam == '*_rebuild*, *_report.html, execution/**, management/**, xml_data/**'
        assert this.jUnitParam.containsKey('deleteOutputFiles')
        assert this.jUnitParam.containsKey('failIfNotNew')
        assert this.jUnitParam.containsKey('pattern')
        assert this.jUnitParam.containsKey('skipNoTestFiles')
        assert this.jUnitParam.containsKey('stopProcessingIfError')
    }

}
