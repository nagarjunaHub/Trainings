/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test

class JobHelpersTest extends Specification {

    @Test
    void 'test_defaultParams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.repo = ''
        mock.env.artifactoryCredId = 'artCreds'
        mock.env.JobHelpersArtApi = 'artifactoryCredApiKey'
        JobHelpers jobCreation = new JobHelpers(mock)
        when:
        jobCreation.setupJobHelpersEnv()
        then:
        assert jobCreation.jenkinsUrl == 'https://rb-jmaas.de.bosch.com/AE-BE'
        assert jobCreation.yamlData == null
        assert jobCreation.toolDir == 'portable/Jenkins_Job_Builder'
        when:
        mock.env.jenkinsUrl = 'https://my.test.server.com'
        mock.env.jobCreatorVer = 'v1.0'
        mock.env.jobCreatorDir = 'customRelease/portable'
        mock.env.configScm = 'NotSupportedScm'
        JobHelpers jobCreationCustom = new JobHelpers(mock)
        jobCreationCustom.loadJobHelpersConfig()
        then:
        assert jobCreationCustom.jenkinsUrl == 'https://my.test.server.com'
        assert jobCreationCustom.toolDir == 'customRelease/portable'
    }

    @Test
    void 'test_commonWorkflow'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.repo = ''
        mock.env.artifactoryCredId = 'artifactoryCredAuthId'
        mock.env.jobCreatorArtApi = 'artifactoryCredApiKey'
        mock.env.configScm = 'GitScm'
        List<String> defDirList = ['Jenkins_Job_Builder', 'Jenkins_Job_Builder/Scripts', 'Jenkins_Job_Builder/Scripts']
        JobHelpers jobCreation = new JobHelpers(mock)
        when:
        jobCreation.setupJobHelpersEnv()
        jobCreation.loadJobHelpersConfig()
        jobCreation.executeJobCreator()
        then:
        assert jobCreation.yamlData != null
        assert jobCreation.jenkins.visitedDir == defDirList
    }

    @Test
    void 'nonNullYamlInit'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.repo = ''
        mock.env.artifactoryCredId = 'artifactoryCredAuthId'
        mock.env.jobCreatorArtApi = 'artifactoryCredApiKey'
        mock.env.configScm = 'RTCScm'
        mock.env.scriptLocation = 'JJB_v2/Dir'
        mock.env.jobCreatorVer = 'V2.0.0'
        ArtifactoryHelpers artifobj = new ArtifactoryHelpers(mock, 'aebe-test-new', 'CI_Artifactory_new')
        JobHelpers jobCreation = new JobHelpers(mock, artifobj, ['yamlData':'example'])
        when:
        jobCreation.setupJobHelpersEnv()
        jobCreation.loadJobHelpersConfig()
        jobCreation.executeJobCreator()
        then:
        assert jobCreation.yamlData != null
        assert jobCreation.jenkins.visitedDir == ['Jenkins_Job_Builder', 'JJB_v2/Dir', 'JJB_v2/Dir']
    }

}
