/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import bosch.aebedo.CustomStage
import bosch.aebedo.AebeDevOps
import bosch.aebedo.mock.JenkinsFileUnixMock
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test

class AebeDevOpsTest extends Specification {

    @Test
    void 'test_aebed_pathJoin'() {
        List<String> list = []
        list.add('foo')
        list.add('bar')
        AebeDevOps aebedoNonUnix = new AebeDevOps(new JenkinsFileMock())
        AebeDevOps aebedoUnix = new AebeDevOps(new JenkinsFileUnixMock())
        expect:
        assert aebedoUnix.pathJoin(list) == 'foo/bar'
        assert aebedoNonUnix.pathJoin(list) == 'foo\\bar'
    }
    @Test
    void 'test_aebed_mrgStage'() {
        setup:
        CustomStage mergedResult = new CustomStage()
        Closure setupMethod = { return false }
        Closure stageMethod = { return true }
        List<CustomStage> stages = []
        CustomStage oneStageDefined = new CustomStage(stageMethod : stageMethod)
        CustomStage threeStageDefined = new CustomStage(setup : stageMethod,
                                                        stageMethod : stageMethod,
                                                        teardown : stageMethod)
        when:
        AebeDevOps aebedoNonUnix = new AebeDevOps(new JenkinsFileMock())
        then:
        assert mergedResult.skip == aebedoNonUnix.mergeStageDescriptors(new CustomStage()).skip
        assert mergedResult.skip == aebedoNonUnix.mergeStageDescriptors([new CustomStage(), new CustomStage()]).skip
        assert oneStageDefined.stageMethod == aebedoNonUnix.mergeStageDescriptors(oneStageDefined).stageMethod
        when:
        CustomStage customNode = new CustomStage(node : 'master')
        then:
        assert customNode.node == aebedoNonUnix.mergeStageDescriptors(new CustomStage(node : 'master')).node
        when:
        stages = [(new CustomStage(stageMethod : stageMethod)), (new CustomStage(setup : stageMethod))]
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert new CustomStage(setup : stageMethod, stageMethod : stageMethod).setup == mergedResult.setup
        assert new CustomStage(setup : stageMethod, stageMethod : stageMethod).stageMethod == mergedResult.stageMethod
        when:
        CustomStage normalOrder = new CustomStage(stageMethod : stageMethod, setup : setupMethod)
        CustomStage reverseOrder = new CustomStage(stageMethod : setupMethod, setup : stageMethod)
        mergedResult.setup = aebedoNonUnix.mergeStageDescriptors(normalOrder).setup
        mergedResult.stageMethod = aebedoNonUnix.mergeStageDescriptors(reverseOrder).stageMethod
        then:
        assert normalOrder.setup == setupMethod
        assert reverseOrder.stageMethod == setupMethod
        when:
        stages = [ new CustomStage(stageMethod: stageMethod),
                   new CustomStage(setup: stageMethod),
                   new CustomStage(teardown: stageMethod) ]
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert threeStageDefined.setup == mergedResult.setup
        assert threeStageDefined.stageMethod == mergedResult.stageMethod
        assert threeStageDefined.teardown == mergedResult.teardown
    }
    @Test
    void 'test_aebed_mrgStage_override'() {
        setup:
        CustomStage mergedResult = new CustomStage()
        Closure stageMethod = { return true }
        Closure teardownMethod = { return false }
        CustomStage explicitSkipStage = new CustomStage(skip : true)
        CustomStage explicitNotSkipStage = new CustomStage(skip : false)
        CustomStage oneStageDefined = new CustomStage(stageMethod : stageMethod)
        CustomStage twoStageDefined = new CustomStage(setup : teardownMethod,
                                                      teardown : teardownMethod)
        CustomStage threeStageDefined = new CustomStage(setup : stageMethod,
                                                        stageMethod : stageMethod,
                                                        teardown : stageMethod)
        @SuppressWarnings('TrailingComma')
        Map overrideMock = [ skipOverrideTest : explicitSkipStage,
                             oneStgOverrideTest : oneStageDefined,
                             twoStgOverrideTest : twoStageDefined,
                             threeStgOverrideTest : threeStageDefined ]
        List<CustomStage> stages = []
        when:
        AebeDevOps aebedoNonUnix = new AebeDevOps(new JenkinsFileMock())
        stages = [new CustomStage(stageMethod : stageMethod)]
        stages += overrideMock.getOrDefault('skipOverrideTest', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == true
        assert mergedResult.setup == null
        assert mergedResult.stageMethod == stageMethod
        assert mergedResult.teardown == null
        when:
        stages = [new CustomStage(stageMethod : stageMethod)]
        stages += overrideMock.getOrDefault('oneStgOverrideTest', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == null
        assert mergedResult.stageMethod == stageMethod
        assert mergedResult.teardown == null
        when:
        stages = [new CustomStage(stageMethod : stageMethod)]
        stages += overrideMock.getOrDefault('twoStgOverrideTest', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == teardownMethod
        assert mergedResult.stageMethod == stageMethod
        assert mergedResult.teardown == teardownMethod
        when:
        stages = [new CustomStage(stageMethod : stageMethod)]
        stages += overrideMock.getOrDefault('threeStgOverrideTest', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == stageMethod
        assert mergedResult.stageMethod == stageMethod
        assert mergedResult.teardown == stageMethod
    }
    @Test
    void 'test_aebed_mrgStage_unkownKeyTest'() {
        setup:
        CustomStage mergedResult = new CustomStage()
        CustomStage explicitNotSkipStage = new CustomStage(skip : false)
        AebeDevOps aebedoNonUnix = new AebeDevOps(new JenkinsFileMock())
        List<CustomStage> stages = []
        Closure setupMethod = { return false }
        Closure stageMethod = { return true }
        Closure teardownMethod = { return false }
        when:
        Map overrideMock = [:]
        mergedResult = overrideMock.getOrDefault('unknownKey', new CustomStage(skip : false))
        then:
        assert explicitNotSkipStage.skip == mergedResult.skip
        assert explicitNotSkipStage.setup == mergedResult.setup
        assert explicitNotSkipStage.stageMethod == mergedResult.stageMethod
        assert explicitNotSkipStage.teardown == mergedResult.teardown
        when:
        stages = [ new CustomStage(setup : setupMethod, stageMethod : stageMethod, teardown : teardownMethod) ]
        stages += overrideMock.getOrDefault('unknownKey', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == setupMethod
        assert mergedResult.stageMethod == stageMethod
        assert mergedResult.teardown == teardownMethod
        when:
        stages = [new CustomStage(setup : setupMethod)]
        stages += overrideMock.getOrDefault('unknownKey', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == setupMethod
        assert mergedResult.stageMethod == null
        assert mergedResult.teardown == null
        when:
        stages = [new CustomStage(stageMethod : stageMethod)]
        stages += overrideMock.getOrDefault('unknownKey', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == null
        assert mergedResult.stageMethod == stageMethod
        assert mergedResult.teardown == null
        when:
        stages = [new CustomStage(teardown : teardownMethod)]
        stages += overrideMock.getOrDefault('unknownKey', explicitNotSkipStage)
        mergedResult = aebedoNonUnix.mergeStageDescriptors(stages)
        then:
        assert mergedResult.skip == false
        assert mergedResult.setup == null
        assert mergedResult.stageMethod == null
        assert mergedResult.teardown == teardownMethod
    }

    @Test
    void 'test_pathSeparator'() {
        AebeDevOps aebedoNonUnix = new AebeDevOps(new JenkinsFileMock())
        AebeDevOps aebedoUnix = new AebeDevOps(new JenkinsFileUnixMock())
        expect:
        assert aebedoNonUnix.envPathSeparator == ';'
        assert aebedoUnix.envPathSeparator == ':'
    }

}
