/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo.mock

import org.jfrog.hudson.pipeline.common.types.ArtifactoryServer

class ArtifactoryMock {

    ArtifactoryServerMock server(String clo) {
        return new ArtifactoryServerMock(clo)
    }

    ArtifactoryServerMock newServer(Map clo) {
        return new ArtifactoryServerMock(clo)
    }

    ArtifactoryBuildInfoMock newBuildInfo() {
        return new ArtifactoryBuildInfoMock()
    }

    ConanClientMock newConanClient(Map param) {
        return new ConanClientMock(param)
    }

}

@SuppressWarnings('UnusedMethodParameter') // Required for mocking methods
class ArtifactoryServerMock extends ArtifactoryServer {
    @SuppressWarnings('NoDef') // envAebeDevOpsArtifactory can either be String or Map
    /* groovylint-disable-next-line FieldTypeRequired, NoDef */
    @SuppressWarnings('FieldTypeRequired') // envAebeDevOpsArtifactory can either be String or Map
    def envAebeDevOpsArtifactory
    Boolean bypassProxy
    Map connection = ['timeout':0]
    Map uploadCall = [:]
    Map downloadCall = [:]
    Map setCall = [:]
    ArtifactoryServerMock(String input) {
        super(url: input)
        this.envAebeDevOpsArtifactory = input
    }
    ArtifactoryServerMock(Map input) {
        super(url: input)
        this.envAebeDevOpsArtifactory = input
    }
    boolean download(Map input) {
        this.downloadCall = input
        return true
    }
    boolean upload(Map input) {
        this.uploadCall = input
        return true
    }
    boolean setProps(Map input) {
        this.setCall = input
        return true
    }

    boolean publishBuildInfo(Object buildinfo) {
        return true
    }

}

@SuppressWarnings('UnusedMethodParameter') // Required for mocking methods
class ArtifactoryBuildInfoMock {
    String number = ''

    boolean append(boolean param) {
        return true
    }

}
