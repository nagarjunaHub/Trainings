/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.JenkinsFileMock
import bosch.aebedo.mock.ArtifactoryMock
import spock.lang.Specification
import org.junit.Test
import java.util.regex.Pattern
import java.util.regex.Matcher
import groovy.json.JsonSlurperClassic

class ArtifactoryHelpersTest extends Specification {

    private List<Map> psMapCall = []
    private final Answer powershellOverride = new Answer<String>() {

        String answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.psMapCall += param
            final String psReturn = true
            final String jsonReturn = '{"properties": {"version": "1.2.3.4", "type": "metrics"}}'
            if (param.containsKey('script') && param.containsKey('returnStdout')) {
                if (param.script.startsWith('Invoke-RestMethod')) {
                    return param.script.contains('ConvertTo-Json') ? jsonReturn : ''
                }
            }
            return (this.returnStatusLiteral in param) ? '0' : psReturn
        }

    }

    @Test
    void 'test_artifactoryHelpers_server_definition'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        when:
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, '', '', 'artCreds')
        then:
        assert artInstance.server.envAebeDevOpsArtifactory == [url: 'https://rb-artifactory.bosch.com/artifactory',
                                                               credentialsId: 'artCreds',]
        assert artInstance.server.bypassProxy == true
        assert artInstance.server.connection.timeout == 300
        when:
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, '', '', 'artCreds',
                                                                 'https://my-server.bosch.com/artifactory',
                                                                 false, 200)
        then:
        assert artInstance2.server.envAebeDevOpsArtifactory == [url: 'https://my-server.bosch.com/artifactory',
                                                                credentialsId: 'artCreds',]
        assert artInstance2.server.bypassProxy == false
        assert artInstance2.server.connection.timeout == 200
        when:
        mock.env.AEBE_DEVOPS_ARTIFACTORY = 'ArtID'
        ArtifactoryHelpers artInstance3 = new ArtifactoryHelpers(mock, '', '', 'artCreds')
        then:
        assert artInstance3.server.envAebeDevOpsArtifactory == 'ArtID'
    }
    @Test
    void 'test_artifactoryHelpers_getLatestVersion'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, 'my-repo-local')
        when:
        String versionMock = artInstance.getLatestVersion('AE', [type:'build'], '')
        then:
        assert versionMock == 'true'
        assert mock.psMapCall[0].script == '(Invoke-RestMethod -Uri "https://rb-artifactory.bosch.com/artifactory/' +
                                           'api/versions/my-repo-local/AE?type=build&listFiles=0" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"}).version'
        when:
        mock.psMapCall = []
        mock.env.ARTIFACTORY_URL = 'https://my-artifactory.local.com/artifactory'
        mock.env.ARTIFACTORY_REPO = 'my-custom-local'
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, 'my-repo-local')
        String versionMock2 = artInstance2.getLatestVersion('AE', [type:'build'], '')
        then:
        assert versionMock2 == 'true'
        assert mock.psMapCall[0].script == '(Invoke-RestMethod -Uri "https://my-artifactory.local.com/artifactory/' +
                                           'api/versions/my-custom-local/AE?type=build&listFiles=0" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"}).version'
    }
    @Test
    void 'test_artifactoryHelpers_propertiesMaker'() {
        when:
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(new JenkinsFileMock())
        Map mockProps = ['version':'XXX_YYY_ZZZ', 'type':'metrics', 'stream':'XYZ_XYZ_XYZ']
        String properties = artInstance.propertiesMaker(mockProps)
        Pattern propsPattern = Pattern.compile(/(.+?)(?:=|$)(.+?)(?:;|$)/)
        Matcher propsMatcher = propsPattern.matcher(properties)
        boolean matches = propsPattern.matcher(properties).matches()
        List<String> keyList = []
        then:
        // Test to see properties string result matches regex
        assert matches == true
        // Test pattern result contained inside the props
        while (propsMatcher.find()) {
            keyList.add(propsMatcher.group(1))
            assert mockProps.containsKey(propsMatcher.group(1)) == true
            assert mockProps.containsValue(propsMatcher.group(2)) == true
        }
        // Test that the keylist unique size is the same as the original
        assert keyList.clone().unique().size() == keyList.size()
        // Test if value sorted to the keys
        mockProps.eachWithIndex { entry, index ->
            assert entry.key == keyList[index]
        }
        when:
        Map emptyProps = [:]
        properties = artInstance.propertiesMaker(emptyProps)
        then:
        assert properties == ''
    }
    @Test
    void 'test_artifactoryHelpers_getProps'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, 'my-repo-local')
        when:
        String versionMock = artInstance.getProps('AE', '', 'my_props')
        then:
        assert versionMock == 'true'
        assert mock.psMapCall[0].script == '(Invoke-RestMethod -Uri "https://rb-artifactory.bosch.com/artifactory/' +
                                           'api/storage/my-repo-local/AE?properties=my_props" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"}).properties.my_props'
        when:
        mock.psMapCall = []
        mock.env.ARTIFACTORY_URL = 'https://my-artifactory.local.com/artifactory'
        mock.env.ARTIFACTORY_REPO = 'my-custom-local'
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, 'my-repo-local')
        String versionMock2 = artInstance2.getProps('AE', '', 'my_props')
        then:
        assert versionMock2 == 'true'
        assert mock.psMapCall[0].script == '(Invoke-RestMethod -Uri "https://my-artifactory.local.com/artifactory/' +
                                           'api/storage/my-custom-local/AE?properties=my_props" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"}).properties.my_props'
    }

    @Test
    void 'test_artifactoryHelpers_getPath'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, 'my-repo-local')
        when:
        String versionMock = artInstance.getPath('AE', [type:'build'], '')
        then:
        assert versionMock == 'true'
        assert mock.psMapCall[0].script == '(Invoke-RestMethod -Uri "https://rb-artifactory.bosch.com/artifactory/' +
                                           'api/versions/my-repo-local/AE?type=build&listFiles=1" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"}).artifacts.path'
        when:
        mock.psMapCall = []
        mock.env.ARTIFACTORY_URL = 'https://my-artifactory.local.com/artifactory'
        mock.env.ARTIFACTORY_REPO = 'my-custom-local'
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, 'my-repo-local')
        String versionMock2 = artInstance2.getPath('AE', [type:'build'], '')
        then:
        assert versionMock2 == 'true'
        assert mock.psMapCall[0].script == '(Invoke-RestMethod -Uri "https://my-artifactory.local.com/artifactory/' +
                                           'api/versions/my-custom-local/AE?type=build&listFiles=1" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"}).artifacts.path'
    }

    @Test
    void 'test_updateProps'() {
        when:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        Map oldProps = ['quality_gate':1]
        Map newProps = ['quality_gate':2]
        mockPointer.env.ARTIFACTORY_REPO = 'test_repo'
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mockPointer)
        artInstance.updateProps('test_bin.zip', oldProps, newProps)
        String spec = artInstance.server.setCall.spec
        Map setSpec = new HashMap<>((new JsonSlurperClassic()).parseText(spec))
        then:
        assert setSpec.files.pattern == ['test_repo/test_bin.zip']
        assert setSpec.files.props == ['quality_gate=1;']
        assert artInstance.server.setCall.props == 'quality_gate=2;'
        when:
        mockPointer.env.ARTIFACTORY_REPO = ''
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mockPointer, 'default_repo')
        artInstance2.updateProps('test_bin.zip', oldProps, newProps)
        String spec2 = artInstance2.server.setCall.spec
        Map setSpec2 = new HashMap<>((new JsonSlurperClassic()).parseText(spec2))
        then:
        assert setSpec2.files.pattern == ['default_repo/test_bin.zip']
    }

    @Test
    void 'test_upload'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, 'my-repo-local')
        when:
        artInstance.upload('*/my/pattern', 'AE')
        then:
        assert artInstance.server.uploadCall.spec.replaceAll('\\s', '') == '{"files":[{"pattern":"*/my/pattern",' +
        '"target":"my-repo-local/AE/","props":"retention.RetC=30","recursive":"true","flat":"true","regexp":"false",' +
        '"explode":"false","excludePatterns":[""]}]}'
        assert artInstance.server.uploadCall.failNoOp == true
        when:
        mock.env.ARTIFACTORY_REPO = 'my-custom-local'
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, 'my-repo-local')
        artInstance2.upload('*/my/pattern', 'AE', [type:'build'], false, false, false, true, true, '*/test', 20)
        then:
        assert artInstance2.server.uploadCall.spec.replaceAll('\\s', '') == '{"files":[{"pattern":"*/my/pattern",' +
        '"target":"my-custom-local/AE/","props":"type=build;retention.RetC=20","recursive":"false","flat":"false",' +
        '"regexp":"true","explode":"true","excludePatterns":["*/test"]}]}'
        assert artInstance2.server.uploadCall.failNoOp == false
    }

    @Test
    void 'test_download'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, 'my-repo-local')
        when:
        artInstance.download('*/my/pattern')
        then:
        assert artInstance.server.downloadCall.spec.replaceAll('\\s', '') == '{"files":[{"pattern":' +
        '"my-repo-local/*/my/pattern/","target":"/","props":"","recursive":"true","flat":"false","build":"",' +
        '"explode":"false","excludePatterns":[""]}]}'
        assert artInstance.server.downloadCall.failNoOp == true
        when:
        mock.env.ARTIFACTORY_REPO = 'my-custom-local'
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, 'my-repo-local')
        artInstance2.download('*/my/pattern', 'AE', [type:'build'], false, false, true, '1234', true, '*/test')
        then:
        assert artInstance2.server.downloadCall.spec.replaceAll('\\s', '') == '{"files":[{"pattern":' +
        '"my-custom-local/*/my/pattern/","target":"AE/","props":"type=build;","recursive":"false","flat":"true",' +
        '"build":"1234","explode":"true","excludePatterns":["*/test"]}]}'
        assert artInstance2.server.downloadCall.failNoOp == false
    }

    @Test
    void 'test_listProps'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        doAnswer(powershellOverride).when(mock).powershell(any(Map))
        this.psMapCall = []
        mock.metaClass.Artifactory = new ArtifactoryMock()
        ArtifactoryHelpers artInstance = new ArtifactoryHelpers(mock, 'my-repo-local')
        when:
        Map myProps = artInstance.listProps('path/to/artefact', '')
        then:
        assert myProps.version == '1.2.3.4'
        assert this.psMapCall[0].script == 'Invoke-RestMethod -Uri "https://rb-artifactory.bosch.com/artifactory/' +
                                           'api/storage/my-repo-local/path/to/artefact?properties" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"} | ConvertTo-Json'
        when:
        this.psMapCall = []
        mock.env.ARTIFACTORY_URL = 'https://my-artifactory.local.com/artifactory'
        mock.env.ARTIFACTORY_REPO = 'my-custom-local'
        ArtifactoryHelpers artInstance2 = new ArtifactoryHelpers(mock, 'my-repo-local')
        Map myProps2 = artInstance2.listProps('path/to/artefact', '')
        then:
        assert myProps2.version == '1.2.3.4'
        assert this.psMapCall[0].script == 'Invoke-RestMethod -Uri "https://my-artifactory.local.com/artifactory/' +
                                           'api/storage/my-custom-local/path/to/artefact?properties" -Method Get ' +
                                           '-Headers @{"X-JFrog-Art-Api"="null"} | ConvertTo-Json'
    }

}
