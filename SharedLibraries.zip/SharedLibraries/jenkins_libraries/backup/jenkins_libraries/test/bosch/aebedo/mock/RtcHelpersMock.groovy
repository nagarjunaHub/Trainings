/**
 * Copyright (C) 2020, 2020 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo.mock

import bosch.aebedo.RtcHelpers
import groovy.transform.InheritConstructors

@InheritConstructors
class RtcHelpersMock extends RtcHelpers {

    List<Map> lastSourceNodeMap = []
    List<Map> lastTargetNodeMap = []
    List<String> lastComponentRule = []
    Boolean lastBaselines = false
    Boolean lastChangesets = true
    Boolean lastSkipJenkinsBaselines = true
    Boolean lastReplacedComps = true
    Boolean lastAddedComps = true
    Boolean lastRemovedComps = true
    List<String> lastIncomingChangesets = []
    Integer numOfCalls = 0

    /* groovylint-disable-next-line ParameterCount */
    void deliverRtc(Map sourceNodeMap, Map targetNodeMap, String componentRule,
        Boolean baselines=true, Boolean changesets=true,
        Boolean skipJenkinsBaselines=true, Boolean replacedComps=true,
        Boolean addedComps=false, Boolean removedComps=false,
        String incomingChangesets='ABORT') {
        this.lastSourceNodeMap.add(sourceNodeMap)
        this.lastTargetNodeMap.add(targetNodeMap)
        this.lastComponentRule.add(componentRule)
        this.lastBaselines = baselines
        this.lastChangesets = changesets
        this.lastSkipJenkinsBaselines = skipJenkinsBaselines
        this.lastRemovedComps = removedComps
        this.lastAddedComps = addedComps
        this.lastReplacedComps = replacedComps
        this.lastIncomingChangesets.add(incomingChangesets)
        numOfCalls++
        }

}
