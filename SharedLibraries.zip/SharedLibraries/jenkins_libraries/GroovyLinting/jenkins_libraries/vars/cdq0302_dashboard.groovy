#!/usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import org.codehaus.groovy.control.ConfigurationException
import bosch.aebedo.CustomStage
import bosch.aebedo.AebeDevOps
import bosch.aebedo.Cdq0302Dashboard

void call(Object jenkins, Map overrides=[:]) {
    overrides.keySet().each { key ->
        if (!Cdq0302Dashboard.ALLOWED_KEY_WORDS.contains(key)) {
            String eMsg = "'${key}' not mentioned as valid overwrite parameter {${Cdq0302Dashboard.ALLOWED_KEY_WORDS}}"
            throw new ConfigurationException(eMsg)
        }
    }

    try {
        cdq_dashboard = new Cdq0302Dashboard(jenkins, overrides.getOrDefault('configPass', env.configPass),
                                            overrides.getOrDefault('artifactoryHelper', null))
        helpers = new AebeDevOps(jenkins)
        helpers.wrapStageWithNode('Create CDQ0302 Dashboard', helpers.mergeStageDescriptors(
                                                                [new CustomStage(
                                                                    setup: cdq_dashboard.&setupMegenjaEnvironment,
                                                                    stageMethod: cdq_dashboard.&executeMegenja,
                                                                    teardown: cdq_dashboard.&uploadMetrics)
                                                                ] +
                                                                overrides.getOrDefault('megenja',
                                                                                       new CustomStage(skip: false))))
    } catch (e) {
        emailext attachLog: true,
                 body: "${BUILD_TAG} pipeline failed. URL: ${BUILD_URL}",
                 to: "${jenkins.failMail}",
                 subject: "${BUILD_TAG} - Failed!"
        throw e
    }
}
