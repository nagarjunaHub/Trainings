/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.RtcHelpersMock
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test
import org.codehaus.groovy.control.ConfigurationException

class RtcHelpersTest extends Specification {

    private final String compareResult = '''
                                    {
                                        "direction": [
                                            {
                                                "components": [
                                                    { "added": false,
                                                        "changesets": [
                                                            {
                                                                "author": {
                                                                    "mail": "test.user@de.bosch.com",
                                                                    "userId": "TESTUSE",
                                                                    "userName": "Test User (AE-BE/ESW10-St)",
                                                                    "uuid": "_CBpiMOjMEem8G_L_b9wDAA"
                                                                },
                                                                "comment": "",
                                                                "creationDate": "2020/06/29",
                                                                "item-type": "changeset",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_dw5XHbnSEeqH_cyoxpizmw",
                                                                "versionables": [
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/src/Can_Appl.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_x3yyIDg9EeqUlqhoaLc6MQ"
                                                                    }
                                                                ]
                                                            },
                                                            {
                                                                "author": {
                                                                    "mail": "test.user@de.bosch.com",
                                                                    "userId": "TESTUSER",
                                                                    "userName": "Test User (AE-BE/ESW10-St)",
                                                                    "uuid": "_CBpiMOjMEem8G_L_b9wDAA"
                                                                },
                                                                "comment": "",
                                                                "creationDate": "2020/07/07",
                                                                "item-type": "changeset",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_eLPGULoCEeqH_cyoxpizmw",
                                                                "versionables": [
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/gen/Can_Lcfg.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_aAye4IAJEeqT8PjaVevvfw"
                                                                    },
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/src/Can_Appl.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_x3yyIDg9EeqUlqhoaLc6MQ"
                                                                    }
                                                                ]
                                                            }
                                                        ],
                                                        "item-type": "component",
                                                        "name": "rbd.testproject.version.proj.sw.05_MCAL.ComDrv.Can",
                                                        "removed": false,
                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                        "uuid": "_gTPUIDdqEeqWPremDs7l0g"
                                                    },
                                                    {
                                                        "added": false,
                                                        "baselines": [
                                                            {
                                                                "id": 72,
                                                                "item-type": "baseline",
                                                                "name": "test_snapshot",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_WaeCZLRoEeqH_cyoxpizmw"
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                    '''
    private final List componentChanges = ['rbd\\testproject\\version\\proj\\sw\\05_MCAL\\ComDrv\\Can\\src\\Can_Appl.c',
                                          'rbd\\testproject\\version\\proj\\sw\\05_MCAL\\ComDrv\\Can\\gen\\Can_Lcfg.c']

    private List<Map> batMapCall = []
    private final Answer batOverride = new Answer<String>() {

        String answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.batMapCall += param
            final String lscmTool = 'lscm.bat'
            final String jsonExt = '--json'
            if (param.containsKey('script') && param.containsKey('returnStdout')) {
                if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('compare')) {
                    return compareResult
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)) {
                    return jsonString
                }
            }
            return 'default'
        }

    }

    @Test
    void 'test_defaultParams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        when:
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        then:
        assert rtcHelpers.server == 'https://rb-alm-11-p.de.bosch.com/ccm'
        assert rtcHelpers.buildToolkit == 'RTC_BuildToolkit_6_0_4'
        assert rtcHelpers.credentials == ''
        assert rtcHelpers.rtcLoadPolicy == 'useLoadRules'
        when:
        mock.env.rtcServer = 'https://my.test.server.com'
        mock.env.rtcBuildToolkit = 'Toolkit_2.0'
        mock.env.rtcCredentials = 'secret_creds'
        mock.env.lscmPath = 'C:\\custom_lscm_path\\lscm.bat'
        RtcHelpers rtcHelpersCustom = new RtcHelpers(mock)
        then:
        assert rtcHelpersCustom.server == 'https://my.test.server.com'
        assert rtcHelpersCustom.buildToolkit == 'Toolkit_2.0'
        assert rtcHelpersCustom.credentials == 'secret_creds'
    }

    @Test
    void 'test_getBuildTypeDefinitionMap'() {
        RtcHelpers rtcHelpers = new RtcHelpers(new JenkinsFileMock())
        when:
        Map buildDef = rtcHelpers.getBuildTypeDefinitionMap('Test_BD')
        then:
        assert buildDef.buildDefinition == 'Test_BD'
        assert buildDef.customizedSnapshotName == ''
        assert buildDef.overrideDefaultSnapshotName == false
        assert buildDef.useDynamicLoadRules == false
        assert buildDef.value == 'buildDefinition'
        when:
        Map buildDefCustom = rtcHelpers.getBuildTypeDefinitionMap('Test_BD',
                                                                  'Test_Snapshot',
                                                                  true)
        then:
        assert buildDefCustom.buildDefinition == 'Test_BD'
        assert buildDefCustom.customizedSnapshotName == 'Test_Snapshot'
        assert buildDefCustom.overrideDefaultSnapshotName == true
        assert buildDefCustom.useDynamicLoadRules == true
    }

    /**
     * Tests the creation of a Map to specify an scm checkout based on an RTC workspace.
     * First, input parameter workspaceName (String). To test default values of the checkout.
     * Second, uses all non-default input parameter, including dynamic loadrule from constructor.
     */
    @Test
    void 'test_getBuildTypeWorkspaceMap'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.loadRulePath = 'path/to/loadrule.loadrule'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildDef = rtcHelpers.getBuildTypeWorkspaceMap('Test_WS')
        then:
        assert buildDef.acceptBeforeLoad == true
        assert buildDef.buildWorkspace == 'Test_WS'
        assert buildDef.clearLoadDirectory == false
        assert buildDef.customizedSnapshotName == ''
        assert buildDef.loadDirectory == 'JWS'
        assert buildDef.loadPolicy == 'useLoadRules'
        assert buildDef.overrideDefaultSnapshotName == false
        assert buildDef.pathToLoadRuleFile == 'path/to/loadrule.loadrule'
        assert buildDef.value == 'buildWorkspace'
        when:
        RtcHelpers rtcHelpers2 = new RtcHelpers(mock, [rtcLoadPolicy: 'useDynamicLoadRules'])
        Map buildDefCustom = rtcHelpers2.getBuildTypeWorkspaceMap('Test_WS',
                                                                 'different/path.loadrule',
                                                                 false, 'Test_Snapshot',
                                                                 true, 'LoadWS')
        then:
        assert buildDefCustom.acceptBeforeLoad == false
        assert buildDefCustom.buildWorkspace == 'Test_WS'
        assert buildDefCustom.clearLoadDirectory == true
        assert buildDefCustom.customizedSnapshotName == 'Test_Snapshot'
        assert buildDefCustom.loadDirectory == 'LoadWS'
        assert buildDefCustom.overrideDefaultSnapshotName == true
        assert buildDefCustom.pathToLoadRuleFile == 'different/path.loadrule'
        assert buildDefCustom.loadPolicy == 'useDynamicLoadRules'
    }

    /**
     * Tests the creation of a Map to specify an scm checkout based on an RTC snapshot.
     * First, input parameter snapshotName (String). To test default values of the checkout.
     * Second, input parameter snapshotName (String) and buildSnapshotContextMap. Validation of a specific loadrule
     * path.
     * Third, uses all non-default input parameter.
     * Fourth, tests the dynamic loadrule policy, set by constructor.
     */
    @Test
    void 'test_getBuildTypeSnapshotMap'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildDef = rtcHelpers.getBuildTypeSnapshotMap('Test_Snapshot')
        then:
        assert buildDef.buildSnapshot == 'Test_Snapshot'
        assert buildDef.buildSnapshotContext == [snapshotOwnerType: 'none']
        assert buildDef.clearLoadDirectory == false
        assert buildDef.currentSnapshotOwnerType == 'none'
        assert buildDef.loadDirectory == 'JWS'
        assert buildDef.loadPolicy == 'useLoadRules'
        assert buildDef.pathToLoadRuleFile == ''
        assert buildDef.value == 'buildSnapshot'
        when:
        mock.env.loadRulePath = 'path/to/loadrule.loadrule'
        RtcHelpers rtcHelpers2 = new RtcHelpers(mock)
        Map snapshotOfStream = rtcHelpers2.getSnapshotContextStreamMap('test_stream', 'test_PA')
        Map buildDefStream = rtcHelpers2.getBuildTypeSnapshotMap('Test_Snapshot', snapshotOfStream)
        then:
        assert buildDefStream.buildSnapshot == 'Test_Snapshot'
        assert buildDefStream.buildSnapshotContext == [owningStream: 'test_stream',
                                                       processAreaOfOwningStream: 'test_PA',
                                                       snapshotOwnerType: 'stream',]
        assert buildDefStream.currentSnapshotOwnerType == 'stream'
        assert buildDefStream.loadPolicy == 'useLoadRules'
        assert buildDefStream.pathToLoadRuleFile == 'path/to/loadrule.loadrule'
        when:
        Map snapshotOfWs = rtcHelpers.getSnapshotContextWorkspaceMap('test_workspace')
        Map buildDefCustom = rtcHelpers.getBuildTypeSnapshotMap('Test_Snapshot', snapshotOfWs,
                                                                'different/path.loadrule',
                                                                true, 'LoadWS')
        then:
        assert buildDefCustom.buildSnapshot == 'Test_Snapshot'
        assert buildDefCustom.buildSnapshotContext == [owningWorkspace: 'test_workspace',
                                                       snapshotOwnerType: 'workspace',]
        assert buildDefCustom.clearLoadDirectory == true
        assert buildDefCustom.currentSnapshotOwnerType == 'workspace'
        assert buildDefCustom.loadDirectory == 'LoadWS'
        assert buildDefCustom.pathToLoadRuleFile == 'different/path.loadrule'
        when:
        RtcHelpers rtcHelpers3 = new RtcHelpers(mock, [rtcLoadPolicy: 'useDynamicLoadRules'])
        Map buildLoadRule = rtcHelpers3.getBuildTypeSnapshotMap('Test_Snapshot', snapshotOfStream)
        then:
        assert buildLoadRule.loadPolicy == 'useDynamicLoadRules'
    }

    @Test
    void 'test_getBuildTypeStreamMap'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.loadRulePath = 'path/to/loadrule.loadrule'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildDef = rtcHelpers.getBuildTypeStreamMap('Test_Stream', 'Test_PA')
        then:
        assert buildDef.buildStream == 'Test_Stream'
        assert buildDef.clearLoadDirectory == false
        assert buildDef.customizedSnapshotName == ''
        assert buildDef.generateChangelogWithGoodBuild == false
        assert buildDef.loadDirectory == 'JWS'
        assert buildDef.loadPolicy == 'useLoadRules'
        assert buildDef.overrideDefaultSnapshotName == false
        assert buildDef.pathToLoadRuleFile == 'path/to/loadrule.loadrule'
        assert buildDef.processArea == 'Test_PA'
        assert buildDef.value == 'buildStream'
        when:
        Map buildDefCustom = rtcHelpers.getBuildTypeStreamMap('Test_Stream', 'Test_PA',
                                                              'different/path.loadrule',
                                                              'Test_Snapshot', true,
                                                              true, 'LoadWS')
        then:
        assert buildDefCustom.buildStream == 'Test_Stream'
        assert buildDefCustom.clearLoadDirectory == true
        assert buildDefCustom.customizedSnapshotName == 'Test_Snapshot'
        assert buildDefCustom.generateChangelogWithGoodBuild: true
        assert buildDefCustom.loadDirectory == 'LoadWS'
        assert buildDefCustom.overrideDefaultSnapshotName == true
        assert buildDefCustom.pathToLoadRuleFile == 'different/path.loadrule'
        assert buildDefCustom.processArea == 'Test_PA'
    }

    @Test
    void 'test_deliverRtcDefault'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap = rtcHelpers.getNodeByUUIDMap('12345678')
        Map targetNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.deliverRtc(sourceNodeMap, targetNodeMap, '*')
        then:
        assert mock.stepCall.$class == 'RTCDeliverPublisher'
        assert mock.stepCall.entries[0].components == '*'
        assert mock.stepCall.entries[0].includeBaselines == true
        assert mock.stepCall.entries[0].includeChangesets == true
        assert mock.stepCall.entries[0].includeComponents == false
        assert mock.stepCall.entries[0].includeRemovedComponents == false
        assert mock.stepCall.entries[0].includeReplacedComponents == true
        assert mock.stepCall.entries[0].incomingChangesetsHandling == 'ABORT'
        assert mock.stepCall.entries[0].skipAutoBaselines == true
        assert mock.stepCall.entries[0].source == [$class: 'NodeByUUIDIdentifier',
                                                   credentialsID: '',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',
                                                   uuid: '12345678',]
        assert mock.stepCall.entries[0].target == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: '',
                                                   flowNodeName: 'my_node',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',]
        assert mock.stepCall.entries[0].workitemCreationAlgo == [$class: 'CreateWiNeverAlgo']
    }

    @Test
    void 'test_deliverRtcOverride'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap2 = rtcHelpers.getNodeByUUIDMap('12345678', 'src_creds', 'source.com')
        Map targetNodeMap2 = rtcHelpers.getNodeByNameMap('my_node', 'tgt_creds', 'target.com')
        rtcHelpers.deliverRtc(sourceNodeMap2, targetNodeMap2, '*', false, false, false, false,
                              true, true, 'CHECK')
        then:
        assert mock.stepCall.entries[0].includeBaselines == false
        assert mock.stepCall.entries[0].includeChangesets == false
        assert mock.stepCall.entries[0].includeComponents == true
        assert mock.stepCall.entries[0].includeRemovedComponents == true
        assert mock.stepCall.entries[0].includeReplacedComponents == false
        assert mock.stepCall.entries[0].incomingChangesetsHandling == 'CHECK'
        assert mock.stepCall.entries[0].skipAutoBaselines == false
        assert mock.stepCall.entries[0].source == [$class: 'NodeByUUIDIdentifier',
                                                   credentialsID: 'src_creds',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',
                                                   uuid: '12345678',]
        assert mock.stepCall.entries[0].target == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'tgt_creds',
                                                   flowNodeName: 'my_node',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'target.com',]
        when:
        Map sourceNodeMap4 = rtcHelpers.getNodeByUUIDMap('12345678')
        Map targetNodeMap4 = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.deliverRtc(sourceNodeMap4, targetNodeMap4, '*', true, true, true, true,
                              false, false, 'STOP')
        then:
        thrown(ConfigurationException)
    }

    @Test
    void 'test_syncStreams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap = rtcHelpers.getNodeByUUIDMap('12345678')
        Map targetNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.syncStreams(sourceNodeMap, targetNodeMap)
        then:
        assert mock.stepCall.$class == 'RTCDeliverPublisher'
        assert mock.stepCall.entries[0].$class == 'RTCSynchronizeEntry'
        assert mock.stepCall.entries[0].source == [$class: 'NodeByUUIDIdentifier',
                                                   credentialsID: '',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',
                                                   uuid: '12345678',]
        assert mock.stepCall.entries[0].target == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: '',
                                                   flowNodeName: 'my_node',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'https://my.test.server.com',]
    }

    @Test
    void 'test_checkoutRtc'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map buildConfig = rtcHelpers.getBuildTypeDefinitionMap('Test_BD')
        rtcHelpers.checkoutRtc(buildConfig)
        then:
        assert mock.checkoutCall.changelog == true
        assert mock.checkoutCall.poll == true
        assert mock.checkoutCall.scm == [$class: 'RTCScm',
                                         avoidUsingToolkit: false,
                                         buildTool: 'RTC_BuildToolkit_6_0_4',
                                         buildType: [buildDefinition: 'Test_BD',
                                                     customizedSnapshotName: '',
                                                     overrideDefaultSnapshotName: false,
                                                     useDynamicLoadRules: false,
                                                     value: 'buildDefinition'],
                                         credentialsId: '',
                                         overrideGlobal: true,
                                         serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',
                                         timeout: 480,]
        when:
        Map buildConfig2 = rtcHelpers.getBuildTypeDefinitionMap('Test_BD')
        rtcHelpers.checkoutRtc(buildConfig2, false, false, 'my_creds', 'Toolkit_2.0', 'https://my.test.server.com')
        then:
        assert mock.checkoutCall.changelog == false
        assert mock.checkoutCall.poll == false
        assert mock.checkoutCall.scm == [$class: 'RTCScm',
                                         avoidUsingToolkit: false,
                                         buildTool: 'Toolkit_2.0',
                                         buildType: [buildDefinition: 'Test_BD',
                                                     customizedSnapshotName: '',
                                                     overrideDefaultSnapshotName: false,
                                                     useDynamicLoadRules: false,
                                                     value: 'buildDefinition'],
                                         credentialsId: 'my_creds',
                                         overrideGlobal: true,
                                         serverURI: 'https://my.test.server.com',
                                         timeout: 480,]
    }

    @Test
    void 'test_checkinRtc'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map targetNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        List files = [rtcHelpers.getFileEntryMap('a/b', 'my_file.c', 'c')]
        List components = [rtcHelpers.getComponentEntryMap('my_comp', files, 1234)]
        rtcHelpers.checkinRtc(targetNodeMap, components)
        then:
        assert mock.stepCall.$class == 'RTCCheckinPublisher'
        assert mock.stepCall.componentEntries == [[componentName: 'my_comp',
                                                   fileEntries: [[destPath: 'a/b',
                                                                  filename: 'my_file.c',
                                                                  folderLevel: 'c']],
                                                   workItemIdentifier: [$class: 'WorkItemByIdIdentifier',
                                                                        id: 1234]],]
        assert mock.stepCall.targetNode == [$class: 'NodeByNameIdentifier',
                                            credentialsID: '',
                                            flowNodeName: 'my_node',
                                            nodeType: 'workspaceOrStream',
                                            overrideGlobal: true,
                                            serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',]
    }

    @Test
    void 'test_applySnapshot'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        Map sourceNodeMap = rtcHelpers.getNodeByNameMap('my_node')
        rtcHelpers.applySnapshot('my_snapshot', sourceNodeMap)
        then:
        assert mock.stepCall.$class == 'SnapshotCreator'
        assert mock.stepCall.snapshotName == 'my_snapshot'
        assert mock.stepCall.source == [$class: 'NodeByNameIdentifier',
                                        credentialsID: '',
                                        flowNodeName: 'my_node',
                                        nodeType: 'workspaceOrStream',
                                        overrideGlobal: true,
                                        serverURI: 'https://rb-alm-11-p.de.bosch.com/ccm',]
    }

    @Test
    void 'test_parseRtcChanges'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        List fileList = rtcHelpers.parseRtcChanges(mock.currentBuild.changeSets)
        then:
        assert fileList == ['this\\is\\an\\rtc\\component\\your\\c\\file.c',
                            'this\\is\\an\\rtc\\component\\your\\h\\file.h']
        when:
        List fileListNull = rtcHelpers.parseRtcChanges(mock.currentBuild.changeSets,
                                                       ['.cpp'])
        then:
        assert fileListNull == []
        when:
        List fileListExclude = rtcHelpers.parseRtcChanges(mock.currentBuild.changeSets,
                                                          ['.c'],
                                                          ['this.is.an.rtc.component'])
        then:
        assert fileListExclude == []
    }

    @Test
    void 'test_getChangeSetData'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        String changes = rtcHelpers.getChangeSetData(mock.currentBuild.changeSets)
        then:
        assert changes == 'techUserDevOps on 1970-01-27T22:20:23.232+01:00[GMT+01:00]: x_delivered\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/c/file.c\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/h/file.h\r\n' +
                          'techUserDevOps on 1970-01-27T22:20:23.232+01:00[GMT+01:00]: x_delivered\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/c/file.c\r\n' +
                          '| Component : this.is.an.rtc.component | File : /your/h/file.h\r\n'
    }

    /**
    * A generic test for the comparison of two versions.
    * Input are 3 parameters: version (String), copmVersion (String) and excludeFiles (List of regex)
    * First, the test compares a snapshot with a workspace without limitations (excludeFiles)
    * Second, it compares them again with an exlude.
    */
    @Test
    void 'test_RTCcompare'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        List<String> allFindings = rtcHelpers.compare('snapshot', 'workspace')
        then:
        assert allFindings == componentChanges
        when:
        allFindings = rtcHelpers.compare('snapshot', 'workspace', ['gen\\\\'])
        then:
        assert allFindings == [componentChanges[0]]
    }

    @Test
    void 'test_prRebase'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        mock.env.rtcServer = 'https://my.test.server.com'
        RtcHelpersMock rtcHelpers = new RtcHelpersMock(mock)
        rtcHelpers.credentials = 'creds'
        rtcHelpers.server = 'source.com'
        when:
        rtcHelpers.prRebase('targetNodeMap', 'sourceNodeMap2', 'sourceNodeMap', 'test')
        then:
        assert rtcHelpers.numOfCalls == 2
        assert rtcHelpers.lastIncomingChangesets[0] == 'REPLACE'
        assert rtcHelpers.lastIncomingChangesets[1] == 'CHECK'
        assert rtcHelpers.lastComponentRule == ['*', 'test']
        assert rtcHelpers.lastSourceNodeMap[0] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'sourceNodeMap2',
                                                   overrideGlobal: true,
                                                   nodeType:'workspaceOrStream',
                                                   serverURI: 'source.com',]
        assert rtcHelpers.lastTargetNodeMap[0] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'targetNodeMap',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',]
        assert rtcHelpers.lastSourceNodeMap[1] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'sourceNodeMap',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',]
        assert rtcHelpers.lastTargetNodeMap[1] == [$class: 'NodeByNameIdentifier',
                                                   credentialsID: 'creds',
                                                   flowNodeName: 'targetNodeMap',
                                                   nodeType: 'workspaceOrStream',
                                                   overrideGlobal: true,
                                                   serverURI: 'source.com',]
    }

}
