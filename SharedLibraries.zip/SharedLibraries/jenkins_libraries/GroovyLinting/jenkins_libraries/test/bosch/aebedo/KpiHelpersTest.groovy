/**
 * Copyright (C) 2021, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 **/
package bosch.aebedo

import static org.mockito.Mockito.when
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test

class KpiHelpersTest extends Specification {

    private final String requestBody = '''{
                "event":
                {
                    "Project_Name" : "Test_Project",
                    "Build_Number" : "null",
                    "Build_Name" : "null",
                    "Pipeline_Status" : "SUCCESS"
                }
        }'''

    @Test
    void 'test_KPI_forwardData'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        KpiHelpers kpikHelpers = new KpiHelpers(mockPointer, 'splunk_token', 'aebedevops')
        when:
        String sourceType = 'JenkinsData'
        String dataKey = 'Pipeline_Status'
        String data = 'SUCCESS'
        String project = 'Test_Project'
        kpikHelpers.forwardData(sourceType, dataKey, data, project)
        then:
        assert mockPointer.httpRequestCall.url ==  'https://rb-itoa-splunk-alm-ae.de.bosch.com:8088/services' +
                                                    '/collector?index=aebedevops&sourcetype=JenkinsData'
        assert mockPointer.httpRequestCall.requestBody ==  requestBody
    }

    /**
    * This test function uses date from Java library, while jenkins
    * uses date from Joda library, therefore there is a difference
    * between both calculations, e.g. 132000 ms instead of 131949 ms .
    **/

    @Test
    void 'test_KPI_convertTimeDuration'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        KpiHelpers kpikHelpers = new KpiHelpers(mockPointer, 'splunk_token', 'aebedevops')
        when:
        Date time1 = Date.parseToStringDate('Tue May 04 15:03:47 CEST 2021')
        Date time2 = Date.parseToStringDate('Tue May 04 15:05:59 CEST 2021')
        String diff = kpikHelpers.convertTimeDuration(time1, time2)
        then:
        assert diff == '132000'
    }

}
