/**
 * Copyright (C) 2020, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
import bosch.aebedo.WarningHelpers
import bosch.aebedo.mock.JenkinsFileMock
import io.jenkins.plugins.analysis.warnings.groovy.ParserConfiguration
import spock.lang.Specification
import org.junit.Test
import java.util.regex.Matcher
import edu.hm.hafner.analysis.Severity
import edu.hm.hafner.util.TreeString

class AnnotatedReport {

    List report = []

}

class Report {

    TreeString fileName
    String path = ''

    void setFileName(String p, TreeString f) {
        path = p
        fileName = f
    }

}

class WarningHelpersTest extends Specification {

    private final String parserScriptBody = '''
        import java.util.regex.Matcher
        import edu.hm.hafner.analysis.Severity

        class Builder {
            String fileName
            Integer lineStart
            String category
            String message
            String type
            Severity severity
            String optional

            Builder buildOptional(String opt = '') {
                this.optional = opt
                return this
            }

            Builder setFileName(String fn) {
                this.fileName = fn
                return this
            }
            Builder setLineStart(Integer ls) {
                this.lineStart = ls
                return this
            }

            Builder setCategory(String cat) {
                this.category = cat
                return this
            }

            Builder setMessage(String msg) {
                this.message = msg
                return this
            }

            Builder setType(String t) {
                this.type = t
                return this
            }

            Builder setSeverity(Severity sev) {
                this.severity = sev
                return this
            }
        }
        Builder builder = new Builder()
        Matcher matcher = y =~ x
        matcher.find()

        '''

    @Test
    void 'scan'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        warningHelpers.scan(parserId, id, path, encoding)
        then:
        assert mockPointer.scanForIssuesCall.tool.parserId == 'parser1'
        assert mockPointer.scanForIssuesCall.tool.id == 'test'
        assert mockPointer.scanForIssuesCall.tool == [parserId:'parser1', id:'test',
                                                      pattern:'test_path', reportEncoding:'UTF-8',]
        when:
        parserId = 'armcl'
        warningHelpers.scan(parserId, id, path, encoding)
        then:
        assert mockPointer.scanForIssuesCall.tool.parserId == 'armcl'
        assert mockPointer.scanForIssuesCall.tool.id == 'test'
        assert mockPointer.scanForIssuesCall.tool == [parserId:'armcl', id:'test',
                                                      pattern:'test_path', reportEncoding:'UTF-8',]
    }
    @Test
    void 'fileInput'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        Object record = warningHelpers.scan(parserId, id, path, encoding)
        String filename = 'test_file'
        Integer count = warningHelpers.fileInput(record, filename)
        then:
        assert count == record.report.size()
        assert mockPointer.writeFileCall == [file: filename, text: record.report.collect { report ->
                                            "\n${report.text}" }.join(), ]
    }
    @Test
    void 'output'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        Object record = warningHelpers.scan(parserId, id, path, encoding)
        Integer threshold = 30
        warningHelpers.output(record, threshold, encoding)
        then:
        assert mockPointer.publishIssuesCall.qualityGates == [[threshold:30, type:'NEW_ERROR', unstable:false]]
    }
    @Test
    void 'parserOutput'() {
        setup:
        JenkinsFileMock mockPointer = new JenkinsFileMock()
        WarningHelpers warningHelpers = new WarningHelpers(mockPointer)
        when:
        String parserId = 'parser1'
        String id = 'test'
        String path = 'test_path'
        String encoding = 'UTF-8'
        String filename = 'test'
        Integer threshold = 30
        Object record = warningHelpers.scan(parserId, id, path, encoding)
        Integer count = warningHelpers.parserOutput(parserId, id, path, filename, threshold, encoding)
        then:
        assert count == record.report.size()
        assert mockPointer.groovyScriptCall != [:]
        assert mockPointer.scanForIssuesCall != [:]
    }

    @Test
    void 'prefixFilepathForRecords'() {
        when:
        AnnotatedReport rec = new AnnotatedReport()
        rec.report.add(new Report(fileName: new TreeString('bar')))
        rec.report.add(new Report(fileName: new TreeString('foo')))
        String prefix = 'JWS'
        WarningHelpers.prefixFilepathForRecords(rec, prefix)
        then:
        rec.report.each { rep ->
            assert rep.fileName.toString().startsWith(prefix)
        }
    }

    @Test
    void 'armParser'() {
        String parserName = 'armcl'
        when:
        WarningHelpers.registerParser(parserName)
        then:
        assert WarningHelpers.armClParser.id == parserName
        assert ParserConfiguration.instance.contains(parserName)
        when:
        WarningHelpers.deregisterParser(parserName)
        then:
        assert ParserConfiguration.instance.contains(parserName) == false
    }

    @Test
    void 'ghsParser2015_1_6'() {
        String parserId = 'ghsParser2015_1_6'
        String parserName = 'GHS Parser (2015_1_6)'
        when:
        WarningHelpers.registerParser(parserId)
        then:
        assert WarningHelpers.ghsParser2015_1_6.id == parserId
        assert WarningHelpers.ghsParser2015_1_6.desc == parserName
        assert ParserConfiguration.instance.contains(parserId)
        when:
        WarningHelpers.deregisterParser(parserName)
        then:
        assert ParserConfiguration.instance.contains(parserName) == false
    }

    @Test
    @SuppressWarnings('LineLength')
    void 'armParserParse' () {
        when:
        /* groovylint-disable-next-line LineLength */
        String goodLineString = '"../CDD/rbdBleArb/src/rbdBleArb_Gap.c", line 71: warning #225-D: function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly'
        Object b = Eval.xy(WarningHelpers.armClParser.pattern,
                goodLineString,
                parserScriptBody + WarningHelpers.armClParser.groovyString)
        then:
        assert b.fileName == '../CDD/rbdBleArb/src/rbdBleArb_Gap.c'
        assert b.lineStart == 71
        assert b.category == '#225-D'
        assert b.severity.name == Severity.WARNING_NORMAL.name
        assert b.message == 'function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly'
        when:
        Object b2 = Eval.xy(WarningHelpers.armClParser.pattern,
                WarningHelpers.armClParser.exampleLine,
                parserScriptBody + WarningHelpers.armClParser.groovyString)
        then:
        assert b.fileName == b2.fileName
        assert b.lineStart == b2.lineStart
        assert b.category == b2.category
        assert b.severity.name == b2.severity.name
        assert b.message == b2.message
        when:
        /* groovylint-disable-next-line LineLength */
        Eval.xy(WarningHelpers.armClParser.pattern,
            '"../CDD/rbdBleArb/src/rbdBleArb_Gap.c", line 71: information #225-D: function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly',
            parserScriptBody + WarningHelpers.armClParser.groovyString)
        then:
        thrown(IllegalStateException)
    }

    @Test
    @SuppressWarnings('LineLength')
    void 'ghsParser_2015_1_6_Parse' () {
        when:
        /* groovylint-disable-next-line LineLength */
        String goodLineString = '''InfoLine="MM/MasterCore/AIM/APP/MKE/src/MKE.c"::State="Completed"::ReturnValue="0"::Output=""MM/MasterCore/AIM/APP/MKE/src/MKE.c", line 145: warning #177-D: function "MKE_TestDefines" was declared but never referenced
  static void MKE_TestDefines(void);'''
        Object b = Eval.xy(WarningHelpers.ghsParser2015_1_6.pattern,
                goodLineString,
                parserScriptBody + WarningHelpers.ghsParser2015_1_6.groovyString)
        then:
        assert b.fileName == 'MM/MasterCore/AIM/APP/MKE/src/MKE.c'
        assert b.lineStart == 145
        assert b.category == '#177-D'
        assert b.severity.name == Severity.WARNING_NORMAL.name
        assert b.type == 'GHS Multi Compiler'
        assert b.message == '''function "MKE_TestDefines" was declared but never referenced'''
        when:
        Object b2 = Eval.xy(WarningHelpers.ghsParser2015_1_6.pattern,
                WarningHelpers.ghsParser2015_1_6.exampleLine,
                parserScriptBody + WarningHelpers.ghsParser2015_1_6.groovyString)
        then:
        assert b2.fileName == 'MM/MasterCore/AIM/APP/MKE/src/MKE.c'
        assert b2.lineStart == 145
        assert b2.category == '#177-D'
        assert b2.severity.name == Severity.WARNING_NORMAL.name
        assert b2.type == 'GHS Multi Compiler'
        assert b2.message == 'function "MKE_TestDefines" was declared but never referenced'

        when:
        // GHSParser_RN_SW400_VARIANT_B
        Object b3 = Eval.xy(WarningHelpers.ghsParser2015_1_6.pattern,
                '''"SW/MM/MasterCore/APPZ2_AIM/ARBSW_Config/Config/ECUC/Workaround/Rte_Compiler_Cfg.h", line 50: warning #1105-D:
          #warning directive: "HUE9SI : Added defines needed for generation of
          OS. This file is copied for initial generation of OS and has to be
          replaced or reviewed"''',
                parserScriptBody + WarningHelpers.ghsParser2015_1_6.groovyString)
        then:
        assert b3.fileName == 'SW/MM/MasterCore/APPZ2_AIM/ARBSW_Config/Config/ECUC/Workaround/Rte_Compiler_Cfg.h'
        assert b3.lineStart == 50
        assert b3.category == '#1105-D'
        assert b3.severity.name == Severity.WARNING_NORMAL.name
        assert b3.type == 'GHS Multi Compiler'
        assert b3.message == '''#warning directive: "HUE9SI : Added defines needed for generation of'''
        when:
        /* groovylint-disable-next-line LineLength */
        Eval.xy(WarningHelpers.ghsParser2015_1_6.pattern,
            '''InfoLine="MM/MasterCore/AIM/APP/MKE/src/MKE.c"::State="Completed"::ReturnValue="0"::Output=""MM/MasterCore/AIM/APP/MKE/src/MKE.c", line 145: info: function "MKE_TestDefines" was declared but never referenced
  static void MKE_TestDefines(void);''',
            parserScriptBody + WarningHelpers.ghsParser2015_1_6.groovyString)
        then:
        thrown(IllegalStateException)
    }

    @Test
    void 'ghsParser202015_1fp_x64'() {
        String parserId = 'ghsParser202015_1fp_x64'
        String parserName = 'GHS Parser (202015_1fp_x64)'
        when:
        WarningHelpers.registerParser(parserId)
        then:
        assert WarningHelpers.ghsParser202015_1fp_x64.id == parserId
        assert WarningHelpers.ghsParser202015_1fp_x64.desc == parserName
        assert ParserConfiguration.instance.contains(parserId)
        when:
        WarningHelpers.deregisterParser(parserName)
        then:
        assert ParserConfiguration.instance.contains(parserName) == false
    }

    @Test
    @SuppressWarnings('LineLength')
    void 'ghsParser202015_1fp_x64Parse' () {
        when:
        /* groovylint-disable-next-line LineLength */
        String goodLineString = '"..\\BIOS\\UJA113x\\cfg\\rb_Uja113x_Cfg.c", line 1173 (col. 38): warning #550-D: variable "sbcWdtStatus" was set but never used'
        Object b = Eval.xy(WarningHelpers.ghsParser202015_1fp_x64.pattern,
                goodLineString,
                parserScriptBody + WarningHelpers.ghsParser202015_1fp_x64.groovyString)
        then:
        assert b.fileName == '..\\BIOS\\UJA113x\\cfg\\rb_Uja113x_Cfg.c'
        assert b.lineStart == 1173
        assert b.category == '#550-D'
        assert b.severity.name == Severity.WARNING_NORMAL.name
        assert b.message == 'variable "sbcWdtStatus" was set but never used'
        when:
        Object b2 = Eval.xy(WarningHelpers.ghsParser202015_1fp_x64.pattern,
                WarningHelpers.ghsParser202015_1fp_x64.exampleLine,
                parserScriptBody + WarningHelpers.ghsParser202015_1fp_x64.groovyString)
        then:
        assert b.fileName == b2.fileName
        assert b.lineStart == b2.lineStart
        assert b.category == b2.category
        assert b.severity.name == b2.severity.name
        assert b.message == b2.message

        // GHSParser_CAL_Z223_V297
        /* groovylint-disable-next-line LineLength */
        Object b3 = Eval.xy(WarningHelpers.ghsParser202015_1fp_x64.pattern,
                '"MM/MasterCore/APP/AILCC/src/AILCC_A6_f.c", line 545 (col. 19): warning #550-D: variable "SAILCC2350_ApplicationError" was set but never used',
                parserScriptBody + WarningHelpers.ghsParser202015_1fp_x64.groovyString)
        then:
        assert b3.fileName == 'MM/MasterCore/APP/AILCC/src/AILCC_A6_f.c'
        assert b3.lineStart == 545
        assert b3.category == '#550-D'
        assert b3.severity.name == Severity.WARNING_NORMAL.name
        assert b3.message == 'variable "SAILCC2350_ApplicationError" was set but never used'

        when:
        /* groovylint-disable-next-line LineLength */
        Eval.xy(WarningHelpers.ghsParser202015_1fp_x64.pattern,
            '"../CDD/rbdBleArb/src/rbdBleArb_Gap.c", line 71: information #225-D: function "rbdBleWrap_ConnMgr_GetNumActiveConn" declared implicitly',
            parserScriptBody + WarningHelpers.ghsParser202015_1fp_x64.groovyString)
        then:
        thrown(IllegalStateException)
    }

}
