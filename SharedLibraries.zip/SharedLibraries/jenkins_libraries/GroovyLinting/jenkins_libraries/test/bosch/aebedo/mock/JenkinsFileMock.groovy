/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo.mock

@SuppressWarnings('MethodCount') //temporarily
@SuppressWarnings('UnusedMethodParameter') // Required for mocking methods
class JenkinsFileMock {

    int deleteDirCalled = 0
    /* groovylint-disable-next-line DuplicateNumberLiteral */
    int inputFuncCalled = 0

    String batCall = ''
    String psCall = ''
    final String returnStatusLiteral = 'returnStatus'
    final String scriptLiteral = 'script'
    final String returnStdOutLiteral = 'returnStdout'
    List<String> visitedDir = []

    Map<String, String> env = [WORKSPACE: 'SLAVE_WORKSPACE']
    Map<String, String> stepCall = [:]
    Map<String, String> checkoutCall = [:]

    Map batMapCall = [:]
    List<Map> psMapCall = []
    Map jsonWriteMap = [:]
    Map scanForIssuesCall = [:]
    Map groovyScriptCall = [:]
    Map publishIssuesCall = [:]
    Map writeFileCall = [:]
    Map httpRequestCall = [:]

    @SuppressWarnings('PropertyName') // 'Artifactory' required for correct mocking
    ArtifactoryMock Artifactory = new ArtifactoryMock()
    CurrentBuildMock currentBuild = new CurrentBuildMock()

    boolean isUnix() {
        return false
    }

    String dir(String param, Closure cl) {
        this.visitedDir.add(param)
        return cl.call()
    }

    boolean deleteDir() {
        this.deleteDirCalled += 1
        return true
    }

    void withEnv(List<String> env, Closure cl) {
        Map oldEnv = [:] << cl.thisObject.jenkins.env
        /* groovylint-disable-next-line DuplicateNumberLiteral */
        Integer splitIndex = 0
        String separator = '='
        env.each { var ->
            cl.thisObject.jenkins.env."${var.split(separator)[splitIndex]}" = var.split(separator)[1]
        }
        cl.call()
        env.each { var ->
            String key = var.split(separator)[splitIndex]
            if (oldEnv."${key}") {
                cl.thisObject.jenkins.env."${key}" = oldEnv."${key}"
            } else {
                cl.thisObject.jenkins.env.remove(key)
            }
        }
    }

    void withCredentials(List credentials, Closure cl) {
        credentials.each { cred ->
            switch (cred) {
                case UsernamePassword:
                    cl.thisObject.jenkins.env."${cred.usernameVariable}" = cred.username
                    cl.thisObject.jenkins.env."${cred.passwordVariable}" = cred.password
                    break
                case UsernameColonPassword:
                    cl.thisObject.jenkins.env."${cred.variable}" = "${cred.username}:${cred.password}"
                    break
            }
        }
        cl.call()
        credentials.each { cred ->
            switch (cred) {
                case UsernamePassword:
                    cl.thisObject.jenkins.env."${cred.usernameVariable}" = null
                    cl.thisObject.jenkins.env."${cred.passwordVariable}" = null
                    break
                case UsernameColonPassword:
                    cl.thisObject.jenkins.env."${cred.variable}" = null
                    break
            }
        }
    }

    boolean stash(Map param) {
        return true
    }

    boolean stash(String param) {
        return true
    }

    boolean unstash(String param) {
        return true
    }

    boolean checkout(Map param) {
        this.checkoutCall = param
        return true
    }

    boolean string(Map param) {
        return true
    }

    boolean powershell(String param) {
        this.psCall = param
        return true
    }

    String powershell(Map param) {
        this.psMapCall += param
        final String psReturn = true
        return (this.returnStatusLiteral in param) ? '0' : psReturn
    }

    String bat(Map param) {
        this.batMapCall = param
        return (this.returnStatusLiteral in param) ? '0' : 'default'
    }

    boolean error(String input) {
        return true
    }

    boolean bat(String param) {
        this.batCall = param
        return true
    }

    boolean fileExists(String param) {
        return true
    }

    UsernamePassword usernamePassword(Map param) {
        return new UsernamePassword(credentialsId: param.credentialsId,
                                    usernameVariable: param.usernameVariable,
                                    passwordVariable: param.passwordVariable)
    }

    UsernameColonPassword usernameColonPassword(Map param) {
        return new UsernameColonPassword(credentialsId: param.credentialsId,
                                         variable: param.variable)
    }

    boolean zip(Map param) {
        return true
    }

    String pwd() {
        return 'C:\\workspace\\workspace\\'
    }

    List findFiles(Map intput) {
        return ['C:\\file1.txt', 'C:\\file2.txt']
    }

    String readFile(String input) {
        return 'Lorem ipsum dolor sit amet\n'
    }

    boolean writeFile(Map input) {
        this.writeFileCall = input
        return true
    }

    boolean step(Map input) {
        this.stepCall = input
        return true
    }

    boolean archiveArtifacts(String param) {
        return true
    }

    boolean libraryResource(String param) {
        return true
    }
    Object groovyScript(Map data) {
        this.groovyScriptCall = data
        return data
    }
    Object scanForIssues(Map param) { //mock für record- report mock falsches level..
        this.scanForIssuesCall = param
        RecordMock recMock = new RecordMock()
        return recMock
    }

    Object publishIssues(Map param) {
        this.publishIssuesCall = param
        return param
    }
    String fileInput(Object record, String param) {
        return param
    }
    String output(Object record, Integer value, String param) {
        return param
    }

    @SuppressWarnings('MethodName') //MethodName Check should start with capital letter
    boolean JUnit(Map param) {
        return true
    }

    Object readYaml(Map param) {
        return ['mockyaml' : 'yamldata']
    }

    boolean writeYaml(Map param) {
        return true
    }

    @SuppressWarnings('Println') // "echo" is actually printing. The println rule does not apply here
    boolean echo(String param) {
        println(param)
        return true
    }

    boolean timeout(Map inputParam, Closure cl) {
        cl.call()
        return true
    }

    Map readJSON(Map param) {
        return param
    }

    void writeJSON(Map param) {
        this.jsonWriteMap = param
    }

    boolean input(String param) {
        inputFuncCalled += 1
        return true
    }

    @SuppressWarnings('EmptyMethod')
    void fileOperations(List param) {
    }

    @SuppressWarnings('EmptyMethod')
    void fileDeleteOperation(Map param) {
    }

    boolean httpRequest(Map input) {
        this.httpRequestCall = input
        return true
    }
}

class JenkinsFileUnixMock extends JenkinsFileMock {

    @Override
    boolean isUnix() {
        return true
    }
    @Override
    String pwd() {
        return '/var/jenkins_home/workspace/'
    }

}
