/**
 * Copyright (C) 2021, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import static org.mockito.Mockito.mock
import static org.mockito.Mockito.spy
import static org.mockito.Mockito.any
import static org.mockito.Mockito.when
import static org.mockito.Mockito.doAnswer
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer
import bosch.aebedo.mock.JenkinsFileMock
import spock.lang.Specification
import org.junit.Test

class LscmUtilityTest extends Specification {

    private final String snapshotList = '''
                                        {
                                            "snapshots": [
                                                {
                                                    "comment": "Comment_here",
                                                    "creationDate": "29.04.2020 18:17",
                                                    "name": "snapshot_20200429_224414",
                                                    "ownedby": {
                                                        "name": "streamName1",
                                                        "type": "STREAM",
                                                        "url": "https://rb-alm/ccm/",
                                                        "uuid": "XYZABCD1"
                                                    },
                                                    "url": "https://rb-alm/ccm/",
                                                    "uuid": "_iVT6MIoXEeqjdoU1qbl95w"
                                                },
                                                {
                                                    "comment": "Comment_here",
                                                    "creationDate": "29.04.2020 18:10",
                                                    "name": "snapshot_20200429_223710",
                                                    "ownedby": {
                                                        "name": "streamName1",
                                                        "type": "STREAM",
                                                        "url": "https://rb-alm/ccm/",
                                                        "uuid": "XYZABCD1"
                                                    },
                                                    "url": "https://rb-alm/ccm/",
                                                    "uuid": "_kEvF4IoWEeqjdoU1qbl95w"
                                                }
                                            ]
                                        }
                                        '''
    private final String compareResult = '''
                                    {
                                        "direction": [
                                            {
                                                "components": [
                                                    { "added": false,
                                                        "changesets": [
                                                            {
                                                                "author": {
                                                                    "mail": "test.user@de.bosch.com",
                                                                    "userId": "TESTUSE",
                                                                    "userName": "Test User (AE-BE/ESW10-St)",
                                                                    "uuid": "_CBpiMOjMEem8G_L_b9wDAA"
                                                                },
                                                                "comment": "",
                                                                "creationDate": "2020/06/29",
                                                                "item-type": "changeset",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_dw5XHbnSEeqH_cyoxpizmw",
                                                                "versionables": [
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/src/Can_Appl.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_x3yyIDg9EeqUlqhoaLc6MQ"
                                                                    }
                                                                ]
                                                            },
                                                            {
                                                                "author": {
                                                                    "mail": "test.user@de.bosch.com",
                                                                    "userId": "TESTUSER",
                                                                    "userName": "Test User (AE-BE/ESW10-St)",
                                                                    "uuid": "_CBpiMOjMEem8G_L_b9wDAA"
                                                                },
                                                                "comment": "",
                                                                "creationDate": "2020/07/07",
                                                                "item-type": "changeset",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_eLPGULoCEeqH_cyoxpizmw",
                                                                "versionables": [
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/gen/Can_Lcfg.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_aAye4IAJEeqT8PjaVevvfw"
                                                                    },
                                                                    {
                                                                        "item-type": "versionable",
                                                                        "path": "/src/Can_Appl.c",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "uuid": "_x3yyIDg9EeqUlqhoaLc6MQ"
                                                                    }
                                                                ]
                                                            }
                                                        ],
                                                        "item-type": "component",
                                                        "name": "rbd.testproject.version.proj.sw.05_MCAL.ComDrv.Can",
                                                        "removed": false,
                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                        "uuid": "_gTPUIDdqEeqWPremDs7l0g"
                                                    },
                                                    {
                                                        "added": false,
                                                        "baselines": [
                                                            {
                                                                "id": 72,
                                                                "item-type": "baseline",
                                                                "name": "test_snapshot",
                                                                "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                "uuid": "_WaeCZLRoEeqH_cyoxpizmw"
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                    '''
    private final String listResult = '''
                                    [
                                        {
                                            "name" : "streamName1",
                                            "owner" : "mock_project",
                                            "url" : "https://rb-alm/ccm/",
                                            "uuid" : "XYZABCD1"
                                        },
                                        {
                                            "name" : "streamName2",
                                            "owner" : "mock_project",
                                            "url" : "https://rb-alm/ccm/",
                                            "uuid" : "XYZABCD2"
                                        },
                                    ]
                                    '''
    private final String jsonString = '''
                                    {
                                        "name" : "streamName1",
                                        "owner" : "mock_project",
                                        "url" : "https://rb-alm/ccm/",
                                        "uuid" : "XYZABCD1"
                                    }
                                    '''
    private final String listComponent = '''
                                   {
                                     "workspaces": [
                                                       {
                                                         "components": [
                                                                          {
                                                                             "contains-subhierarchy-cycle": false,
                                                                             "is-accessible": true,
                                                                             "is-in-cycle": false,
                                                                             "is-in-workspace": true,
                                                                             "is-root": true,
                                                                             "name": "component1",
                                                                             "subcomponents": [
                                                                                                ],
                                                                             "uuid": "_zbtyMCN9EeuLZ5txoDRBZA"
                                                                           },
                                                                           {
                                                                             "contains-subhierarchy-cycle": false,
                                                                             "is-accessible": true,
                                                                             "is-in-cycle": false,
                                                                             "is-in-workspace": true,
                                                                             "is-root": true,
                                                                             "name": "component2",
                                                                             "subcomponents": [
                                                                                               ],
                                                                             "uuid": "_0jQ-QCUsEeuLZ5txoDRBZA"
                                                                            },
                                                                        ],
                                                                        "name": "streamName",
                                                                        "type": "STREAM",
                                                                        "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                                                        "userId": "TestArea",
                                                                        "uuid": "_m3Q9sCN-EeuLZ5txoDRBZA"
                                                        }
                                                   ]
                                    }
                                    '''

    private final String jsonSnapshot = '''
                                    [
                                        {
                                            "description": "",
                                            "name": "test_ReleaseSnapshot",
                                            "snapshot": "test_ReleaseSnapshot_02_12_2020",
                                            "url": "https://rb-alm-11-p.de.bosch.com/ccm/",
                                            "uuid": "_wmvfRTSLEeuyh5HGHAZnuA"
                                        }
                                    ]
                                    '''
    private final Map components = ['item-type':'component', 'removed':'false', 'added':'false',
                                    'name':'rbd.testproject.version.proj.sw.05_MCAL.ComDrv.Can',
                                    'changesets':[['item-type':'changeset', 'author':['mail':'test.user@de.bosch.com',
                                    'userName':'Test User (AE-BE/ESW10-St)', 'userId':'TESTUSER', 'uuid':
                                    '_CBpiMOjMEem8G_L_b9wDAA'], 'versionables':[['path':
                                    '/src/Can_Appl.c', 'item-type':'versionable', 'uuid':'_x3yyIDg9EeqUlqhoaLc6MQ',
                                    'url':'https://rb-alm-11-p.de.bosch.com/ccm/']], 'comment':'',
                                    'creationDate':'2020/06/29', 'uuid':'_dw5XHbnSEeqH_cyoxpizmw',
                                    'url':'https://rb-alm-11-p.de.bosch.com/ccm/'], ['item-type':'changeset',
                                    'author':['mail':'test.user@de.bosch.com', 'userName':'Test User (AE-BE/ESW10-St)',
                                    'userId':'TESTUSER', 'uuid':'_CBpiMOjMEem8G_L_b9wDAA'], 'versionables':
                                    [['path':'/gen/Can_Lcfg.c', 'item-type':'versionable', 'uuid':
                                    '_aAye4IAJEeqT8PjaVevvfw', 'url':'https://rb-alm-11-p.de.bosch.com/ccm/'],
                                    ['path':'/src/Can_Appl.c', 'item-type':'versionable', 'uuid':
                                    '_x3yyIDg9EeqUlqhoaLc6MQ', 'url':'https://rb-alm-11-p.de.bosch.com/ccm/']],
                                    'comment':'', 'creationDate':'2020/07/07', 'uuid':'_eLPGULoCEeqH_cyoxpizmw',
                                    'url':'https://rb-alm-11-p.de.bosch.com/ccm/']], 'uuid':
                                    '_gTPUIDdqEeqWPremDs7l0g', 'url':'https://rb-alm-11-p.de.bosch.com/ccm/',]

    private final List componentChanges = ['rbd\\testproject\\version\\proj\\sw\\05_MCAL\\ComDrv\\Can\\src\\Can_Appl.c',
                                          'rbd\\testproject\\version\\proj\\sw\\05_MCAL\\ComDrv\\Can\\gen\\Can_Lcfg.c']
    private List<Map> batMapCall = []
    private final Answer batOverride = new Answer<String>() {

        String answer(InvocationOnMock invocation) throws Throwable {
            Map param = invocation.arguments[0] as Map
            this.batMapCall += param
            final String lscmTool = 'lscm.bat'
            final String jsonExt = '--json'
            if (param.containsKey('script') && param.containsKey('returnStdout')) {
                if (param.script.contains(lscmTool) && param.script.contains(jsonExt)
                    && param.script.contains('list snapshots')) {
                    return snapshotList
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('compare')) {
                    return compareResult
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('list components')) {
                    return listComponent
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('list')) {
                    return listResult
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)\
                    && param.script.contains('query')) {
                    return jsonSnapshot
                } else if (param.script.contains(lscmTool) && param.script.contains(jsonExt)) {
                    return jsonString
                }
            }
            return 'default'
        }

    }
    @Test
    void 'test_defaultParams'() {
        JenkinsFileMock mock = new JenkinsFileMock()
        when:
        LscmUtility lscmHelpers = new LscmUtility(mock)
        then:
        assert lscmHelpers.server == 'https://rb-alm-11-p.de.bosch.com/ccm'
        assert lscmHelpers.lscmPath == 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        assert lscmHelpers.credentials == ''
        when:
        mock.env.rtcServer = 'https://my.test.server.com'
        mock.env.rtcCredentials = 'secret_creds'
        mock.env.lscmPath = 'C:\\custom_lscm_path\\lscm.bat'
        LscmUtility lscmHelpersCustom = new LscmUtility(mock)
        then:
        assert lscmHelpersCustom.server == 'https://my.test.server.com'
        assert lscmHelpersCustom.lscmPath == 'C:\\custom_lscm_path\\lscm.bat'
        assert lscmHelpersCustom.credentials == 'secret_creds'
    }

    @Test
    void 'lscmFunctionTests'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        lscmHelpers.login()
        lscmHelpers.logout()
        lscmHelpers.login(20)
        lscmHelpers.acceptFromSourceToTarget('target_stream', 'target_rws')
        lscmHelpers.acceptFromSourceToTarget('target_stream', 'target_rws', true)
        List<HashMap> streamList = lscmHelpers.listStreams('test_proj')
        List<HashMap> wsList = lscmHelpers.listWorkspaces()
        List<HashMap> createdStream = lscmHelpers.generateStream('test_proj',
                                                                         'snapshot_yy_mm_dd', 'mock_stream')
        lscmHelpers.deleteStream('mock_stream', '', '')
        List<HashMap> createdRws = lscmHelpers.generateRws('mock_stream', 'mock_rws')
        lscmHelpers.deleteRws('mock_rws')
        lscmHelpers.listSnapshots('test_proj', 'tempStream')
        lscmHelpers.deleteSnapshot('mock_rws', 'snapshot_yy_mm_dd')
        rtcHelpers.teamAreaSetup('mock_project', 'streamName1', 'snapshot_yy_mm_dd', ['rws1', 'rws2'])
        lscmHelpers.deleteSnapshot('mock_rws', 'snapshot_yy_mm_dd')
        rtcHelpers.teamAreaTearDown('test_proj', ['rws1', 'rws2'], 'intStrean', 'tempStream', '* !componenttofilter')
        then:
        Map data1 = ['owner': 'mock_project', 'name': 'streamName1', 'uuid': 'XYZABCD1', 'url': 'https://rb-alm/ccm/']
        Map data2 = ['owner': 'mock_project', 'name':'streamName2', 'uuid': 'XYZABCD2', 'url': 'https://rb-alm/ccm/']
        List<HashMap> reff = [data1]
        List<HashMap> reff2 = [data1, data2]
        assert lscmHelpers.lscmPath == 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        assert streamList == reff2
        assert wsList == reff2
        assert createdStream == reff
        assert createdRws == reff
        assert mock.inputFuncCalled == 1
    }

    @Test
    void 'test_lscmUtilCustom'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        RtcHelpers rtcHelpers = new RtcHelpers(mock)
        when:
        lscmHelpers.logout()
        lscmHelpers.login(20)
        lscmHelpers.acceptFromSourceToTarget('target_stream', 'target_rws', true)
        List<HashMap> streamList = lscmHelpers.listStreams('test_proj', 1)
        List<HashMap> wsList = lscmHelpers.listWorkspaces(1)
        List<HashMap> createdStream = lscmHelpers.generateStream('test_proj', 'snapshot_yy_mm_dd',
                                                                         'mock_stream', false)
        lscmHelpers.deleteStream('mock_stream', 'backup_stream')
        lscmHelpers.deleteStream('mock_stream', 'backup_stream', 'test_proj')
        List<HashMap> createdRws = lscmHelpers.generateRws('mock_stream', 'mock_rws', false)
        lscmHelpers.deleteRws('mock_rws', false)
        lscmHelpers.listSnapshots('test_proj', 'tempStream', 2)
        rtcHelpers.teamAreaTearDown('test_proj', ['rws1', 'rws2'], 'intStrean',
                                    'tempStream', '* !componenttofilter', true, true, 'intStream')
        then:
        Map data1 = ['owner': 'mock_project', 'name': 'streamName1', 'uuid': 'XYZABCD1', 'url': 'https://rb-alm/ccm/']
        Map data2 = ['owner': 'mock_project', 'name':'streamName2', 'uuid': 'XYZABCD2', 'url': 'https://rb-alm/ccm/']
        List<HashMap> reff = [data1]
        List<HashMap> reff2 = [data1, data2]
        assert lscmHelpers.lscmPath == 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        assert streamList == reff2
        assert wsList == reff2
        assert createdStream == reff
        assert createdRws == reff
        assert this.batMapCall[2].script.contains('--visibility private')
        assert this.batMapCall[2].script.contains('@C:\\rtc-scmtools\\eclipse\\lscm.bat list workspaces')
    }

    @Test
    void 'test_compare'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        when:
        this.batMapCall = []
        Map parsedJson = lscmHelpers.compare('snapshot', 'workspace')
        String script = '@C:\\rtc-scmtools\\eclipse\\lscm.bat compare -r '
        script += 'https://rb-alm-11-p.de.bosch.com/ccm snapshot snapshot ws workspace -I fc --json'
        then:
        assert this.batMapCall[0].script == script
        assert (parsedJson.containsKey('direction'))
        assert parsedJson.direction.components.changesets.versionables.path != []
    }

    /**
    * A generic test to get the affected files from compare.
    * Input are 2 parameters: parsedJson (Map) and excludeFiles (List of regex).
    * First, the test runs a compare to get the changesets (affected files).
    * Second, it compares them again and excludes one of the files.
    */
    @Test
    void 'test_findChangesets'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        when:
        Map changesets = lscmHelpers.compare('snapshot', 'workspace')
        List<HashMap> changesetFindings = lscmHelpers.findChangesets(changesets)
        then:
        assert changesetFindings == componentChanges
        when:
        changesets = lscmHelpers.compare('snapshot', 'workspace')
        changesetFindings = lscmHelpers.findChangesets(changesets, ['Can_Lcfg.c'])
        then:
        assert changesetFindings == [componentChanges[0]]
    }

    /**
    * A generic test to retrieve all file paths from a given component.
    * Input are 2 parameters: component (Map) and excludeFiles (List of regex).
    * It runs with an exclude of a file and gets a non-default pathSeparator from constructor.
    * Therefore the result contains forward slashes.
    */
    @Test
    void 'test_getFilesOfComponent'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock, [pathSeparator: '/'])
        when:
        List<String> files = lscmHelpers.getFilesOfComponent(components, ['src/Can_Appl.c'])
        then:
        assert files == ['rbd/testproject/version/proj/sw/05_MCAL/ComDrv/Can/gen/Can_Lcfg.c']
    }

    @Test
    void 'test_listComponents'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        when:
        this.batMapCall = []
        String mockStream = 'mock_str'
        String teamArea = 'mock_area'
        String maxArg = '--maximum all'
        Map componentList = lscmHelpers.listComponents(mockStream, teamArea)
        lscmHelpers.listComponents(mockStream, teamArea, 2)
        String script = '@C:\\rtc-scmtools\\eclipse\\lscm.bat list components -r https://rb-alm-11-p.de.bosch.com/ccm '
        script += "--teamarea \"${teamArea}\" \"${mockStream}\" $maxArg --json"
        then:
        assert this.batMapCall[0].script == script
        assert this.batMapCall[0].script.contains('--teamarea "mock_area"') == true
        assert this.batMapCall[0].script.contains('"mock_str" --maximum all --json') == true
        assert componentList.containsKey('workspaces') == true
        assert componentList['workspaces'].first().containsKey('components') == true
        assert componentList['workspaces'].first()['components'].size == 2
        assert componentList['workspaces'].first()['components'].first().containsKey('uuid') == true
        assert componentList['workspaces'].first()['name'] == 'streamName'
    }

    @Test
    void 'test_promoteSnapshotToStream'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        when:
        lscmHelpers.promoteSnapshotToStream('streamName1', 'snapshot1')
        then:
        assert this.batMapCall[0].script.contains('--ownedby "streamName1"')
        assert this.batMapCall[0].script.contains('-s "snapshot1"')
        when:
        this.batMapCall = []
        lscmHelpers.promoteSnapshotToStream('streamName1', 'snapshot1', 'mock_project')
        then:
        assert this.batMapCall[0].script.contains('--teamarea "mock_project"') == true
        assert this.batMapCall[0].script.contains('list streams') == true
        assert this.batMapCall[1].script.contains('--ownedby "XYZABCD1"')
        assert this.batMapCall[1].script.contains('-s "snapshot1"')
    }

    @Test
    void 'test_getLatestReleaseSnapshot'() {
        JenkinsFileMock mock = spy(JenkinsFileMock)
        mock.env.rtcCredentials = 'secret_creds'
        doAnswer(batOverride).when(mock).bat(any(Map))
        LscmUtility lscmHelpers = new LscmUtility(mock)
        when:
        this.batMapCall = []
        String searchStream = 'streamName1'
        String teamarea = 'mock_project'
        String nameContains = 'test_Name'
        String releaseSnapshot = lscmHelpers.getLatestReleaseSnapshot(
                                       searchStream, teamarea, nameContains)
        String script = '@C:\\rtc-scmtools\\eclipse\\lscm.bat query -r https://rb-alm-11-p.de.bosch.com/ccm '
        script += "-m 1 --snapshot \"for_stream('${searchStream}') and in_teamarea('${teamarea}') "
        script += "and name matches '${nameContains}'\" --json"
        then:
        assert this.batMapCall[0].script == script
        assert releaseSnapshot == 'test_ReleaseSnapshot'
    }

}
