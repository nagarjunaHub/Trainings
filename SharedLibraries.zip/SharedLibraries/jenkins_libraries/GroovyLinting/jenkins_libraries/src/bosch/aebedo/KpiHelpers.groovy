#!/usr/bin/env groovy
 /**
 * Copyright (C) 2021, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 **/
package bosch.aebedo

import groovy.time.TimeDuration
import groovy.time.TimeCategory
import com.cloudbees.groovy.cps.NonCPS

class KpiHelpers {

    Object jenkins = null
    /** Token ID used to authenticate connection to the splunk server.*/
    String token = ''
    /** Index Name on the splunk server to which the data will be forwarded.*/
    String index = ''

    KpiHelpers(Object jenkins, String splunkToken, String indexName) {
        this.jenkins = jenkins
        this.token = splunkToken
        this.index = indexName
    }
    /**
    * A generic function which helps to forward data from Jenkins to Splunk.
    * @sourceType - The source of data, JenkinsData should be used, required for search queries in Splunk.
    * @dataKey - The type of data to be sent from the pipeline, Checkout_Duration,
    * Checkout_Size and Pipeline_Status are possible options.
    * @data - The value of data to be sent from the pipeline.
    * @project - Name of the project that will be displayed on Splunk, this value should be unique for each pipeline.
    **/

    void forwardData(String sourceType, String dataKey, String data, String project) {
        String requestBody = """{
                "event":
                {
                    "Project_Name" : "${project}",
                    "Build_Number" : "${this.jenkins.env.BUILD_NUMBER}",
                    "Build_Name" : "${this.jenkins.env.BUILD_DISPLAY_NAME}",
                    "${dataKey}" : "${data}"
                }
        }"""

        this.jenkins.httpRequest(
            consoleLogResponseBody: true,
            customHeaders: [
                [
                    maskValue: false,
                    name: 'Authorization',
                    value: "Splunk ${this.token}"
                ],
                [
                    maskValue: false,
                    name: 'Content-Type',
                    value: 'application/json'
                ]
            ],
            httpMode: 'POST',
            ignoreSslErrors: true,
            quiet: false,
            requestBody: requestBody,
            responseHandle: 'NONE',
            url: 'https://rb-itoa-splunk-alm-ae.de.bosch.com:8088/services/collector?' +
                 "index=${this.index}&sourcetype=${sourceType}",
            validResponseCodes: '100:399'
        )
        requestBody = null
    }

    /**
    * This function returns the size of the working directory in MB.
    **/

    String checkoutSize() {
        String scriptString = 'foreach ($d in ls -Directory -Force) { $s=(ls $d -Recurse -Force |' +
                              ' measure length -sum).sum / 1MB; if ($s) {"$($s.toString("N0"))`t`t"} else {"0`t`t"}}'

        return this.jenkins.powershell(returnStdout: true, script: scriptString).trim()
    }

    /**
    * This function calculates the time duration between two timestamps in ms.
    **/

    @NonCPS
    String convertTimeDuration(Date time1, Date time2) {
        TimeDuration duration = TimeCategory.minus(time2, time1)
        return "${duration.toMilliseconds()}"
    }

}
