#! /usr/bin/env groovy
 /**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import org.jfrog.hudson.pipeline.common.types.ArtifactoryServer
import org.jfrog.hudson.pipeline.common.types.ConanClient

class ConanHelpers {

    private ConanClient privConanClient
    Object jenkins = null
    int conanLoggingLevel = 10
    private String privConanUserHome = ''
    private String privConanUserShortHome = ''

    /**
    * Create a Conan Helper object that provides some useful
    * methods when working with conan in Jenkins.
    * Some steps and the environment of the jenkins file in which the helper
    * are executed are needed and therefore the WorkflowScript (aka Jenkinsfile)
    * needs to be passed as parameter.
    */
    ConanHelpers(Object jenkins) {
        this.jenkins = jenkins
    }

    /**
    * Return the conan user home as String.
    * Either it's fetched from the environment['CONAN_USER_HOME'] or
    * it's generated based on the job workspace + conan_home.
    * The value of conan user home is set on the first call.
    * This can't be done in the constructor because of a call to AebeDevOps.pathJoin(...)
    * which is not allowed in a Jenkins job.
    */
    String getConanUserHome() {
        if (!this.privConanUserHome) {
            AebeDevOps helperFunctions = new AebeDevOps(this.jenkins)
            this.privConanUserHome = this.jenkins.env.CONAN_USER_HOME ?:
                                helperFunctions.pathJoin([this.jenkins.env.WORKSPACE, 'conan_home'])
        }
        return this.privConanUserHome
    }

    /**
    * Set the conan user home to a specific value
    */
    void setConanUserHome(String userHome) {
        this.privConanUserHome = userHome
    }

    /**
    * Return the conan user short home as String.
    * Either it's fetched from the environment['CONAN_USER_SHORT_HOME'] or
    * it's generated based on the job workspace + conan_short_home.
    * The value of conan user short home is set on the first call.
    * This can't be done in the constructor because of a call to AebeDevOps.pathJoin(...)
    * which is not allowed in a Jenkins job.
    */
    String getConanUserShortHome() {
        if (!this.privConanUserShortHome) {
            if (this.jenkins.env.CONAN_USER_SHORT_HOME) {
                this.privConanUserShortHome = this.jenkins.env.CONAN_USER_SHORT_HOME
            } else {
                AebeDevOps helperFunctions = new AebeDevOps(this.jenkins)
                this.privConanUserShortHome = helperFunctions.pathJoin([this.jenkins.env.WORKSPACE, 'conan_short_home'])
            }
        }
        return this.privConanUserShortHome
    }

    /**
    * Set the conan user short home to a specific value
    */
    void setConanUserShortHome(String userHome) {
        this.privConanUserShortHome = userHome
    }

    /**
    * Returns a conan client object associated with this helper object.
    */
    ConanClient getConanClient() {
        if (!this.privConanClient) {
            /* groovylint-disable-next-line UnnecessaryGetter */
            this.jenkins.withEnv(this.getConanEnvList()) {
                // Due to a bug in Artifactory plugin, conan user home has to be set in commands and as ENV
                /* groovylint-disable-next-line UnnecessaryGetter */
                this.privConanClient = this.jenkins.Artifactory.newConanClient userHome: this.getConanUserHome()
            }
        }
        return this.privConanClient
    }

    /**
    * Returns a List of strings used in the withEnv step of a Jenkinsfile.<br />
    * <code>
    * withEnv(myConanHelpersObject.getConanEnvList()) { ... }
    * </code>
    */
    List<String> getConanEnvList() {
        return ["CONAN_LOGGING_LEVEL=${this.conanLoggingLevel}",
                /* groovylint-disable-next-line UnnecessaryGetter */
                "CONAN_USER_HOME=${this.getConanUserHome()}",
                /* groovylint-disable-next-line UnnecessaryGetter */
                "CONAN_USER_SHORT_HOME=${this.getConanUserShortHome()}",
                'CONAN_NON_INTERACTIVE=1',]
    }

    /**
    * Calls the conan config install command with the given credentials.
    * The config is installed in the conanUserHome.
    */
    void installConanConfigHTTPS(final String credentialsId,
                        final String url='https://sourcecode.socialcoding.bosch.com/scm/aebedo/conan_settings.git') {
        if (!url.startsWith('https://')) {
            throw new IllegalArgumentException('Only https is currently supported as protocol in the URL')
        }
        this.jenkins.withEnv(["PATH=${(new GitHelpers(this.jenkins)).pathIncludingGit}",]) {
            this.jenkins.withCredentials([this.jenkins.usernamePassword(credentialsId: credentialsId,
                                                                        usernameVariable: 'JENKINS_USER',
                                                                        passwordVariable: 'JENKINS_PW'),]) {
                String protocol = url.split('://')[0]
                String address = url[protocol.length() + 3 .. -1]
                String userPw = "${this.jenkins.env.JENKINS_USER}:${this.jenkins.env.JENKINS_PW}"
                String cmd = "config install ${protocol}://${userPw}@${address}"
                /* groovylint-disable-next-line UnnecessaryGetter */
                this.getConanClient().run(command: cmd)
            }
        }
    }

    /**
    * Sets the credentials for this conan client for a given artifactory and conan remote.
    * Default is to use the Condition project (CI managed) artifactory.
    */
    void addUserCredential(final String credentialsId,
                           final String conanRemoteName,
                           final String url='https://rb-artifactory.bosch.com/artifactory') {
        ArtifactoryServer server = this.jenkins.Artifactory.newServer url: url, credentialsId: credentialsId
        /* groovylint-disable-next-line UnnecessaryGetter */
        this.jenkins.conanAddUser(server: server, serverName: conanRemoteName, conanHome: this.getConanUserHome())
    }

}
