#! /usr/bin/env groovy
/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import java.time.Instant
import java.time.ZoneId
import com.cloudbees.groovy.cps.NonCPS
import org.codehaus.groovy.control.ConfigurationException

/**
 * Library to aid common pipeline operations relating to the Rational Team Concert SCM.<br/>
 * The helpers in this class require the following plugins to be installed on Jenkins:
 * <ul><li><a href=https://wiki.jenkins-ci.org/display/JENKINS/Team+Concert+Plugin>Team Concert</a></li>
 * <li><a href=https://inside-docupedia.bosch.com/confluence/display/ubkalm/RTC+SCM+Checkin+Plugin>
 * RTC SCM Checkin Plugin</a></li>
 * <li><a href=https://inside-docupedia.bosch.com/confluence/display/ubkalm/RTC+SCM+Deliver+Plugin>
 * RTC SCM Deliver Plugin</a></li>
 * <li><a> href=https://jazz.net/help-dev/clm/index.jsp?topic=%2Fcom.ibm.team.scm.doc%2Ftopics%2Fr_scm_cli_scm.html>
 * LSCM Command Line Documentation</a></li></ul>
 */
class RtcHelpers {

    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null
    /** ALM server to connect to. Will be set to 'https://rb-alm-11-p.de.bosch.com/ccm' if the rtcServer
     * variable is not otherwise specified in the Jenkins environment.*/
    String server = ''
    /** Jenkins credentials ID to connect to the ALM server with. Must be set with the rtcCredentials
     * variable in the Jenkins environment.*/
    String credentials = ''
    /** Path to the loadrule file in the RTC repository workspace. Must be set with the loadRulePath
     * variable in the Jenkins environment.*/
    String loadRulePath = ''
    /** Build toolkit to use when interfacing with the ALM server. Will be set to 'RTC_BuildToolkit_6_0_4'
     * unless otherwise specified with the rtcBuildToolkit variable in the Jenkins environment.*/
    String buildToolkit = ''
    /** Public instance of the  suite of functions */
    LscmUtility lscmUtil = null
    /** String pathSeparator, default set to '\\'*/
    String pathSeparator = '\\'
    /** Possibility to use a loadrule file 'useLoadRules' or the dynamic generation 'useDynamicLoadRules'.
    * Default is set to 'useLoadRules'. If dynamic loadrule is used, no loadrulePath is needed.*/
    String rtcLoadPolicy = 'useLoadRules'

    private final Map snapshotContextNoneMap = [snapshotOwnerType: 'none']
    private final String defaultLoadDir = 'JWS'
    private final String wildcard = '*'
    private final String dotSeparator = '.'
    private final String deliverClass = 'RTCDeliverPublisher'
    private final List defaultIncludeExtensions = ['.c', '.h']
    private final String defaultBuildCondition = 'ALWAYS'
    private final String defaultRtcRespondsTo = 'getComponentName'

    private class ChangeSetHandles {

        final static String ABORT = 'ABORT'
        final static String DISCARD = 'DISCARD'
        final static String REPLACE = 'REPLACE'
        final static String CHECK = 'CHECK'
        final static List<String> ALLOWEDOPERATIONS = [ABORT, DISCARD, REPLACE, CHECK]

    }

    /**
     * Constructor for the RtcHelpers class.
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     * (aka WorkflowScript) in which context the code is executed.
     * @param props Fields of the object to overwrite the default values.
     * Fields have to exist in class definition.
     */
    RtcHelpers(Object jenkins, Map props = [:]) {
        this.jenkins = jenkins
        this.server = this.jenkins.env.rtcServer ?: 'https://rb-alm-11-p.de.bosch.com/ccm'
        this.credentials = this.jenkins.env.rtcCredentials ?: ''
        this.loadRulePath = this.jenkins.env.loadRulePath ?: ''
        this.buildToolkit = this.jenkins.env.rtcBuildToolkit ?: 'RTC_BuildToolkit_6_0_4'
        props.each { name, val ->
            this.setProperty(name, val)
        }
        this.lscmUtil = lscmUtil ?: new LscmUtility(this.jenkins, [credentials: this.credentials, server: this.server])
    }

    /**
     * Call the Jenkins checkout scm step with RTC-specific scm parameters.
     * @param buildConfig Map to detail the configuration for the build. Can be created with
     * <a href=#getScmConfigMap(java.util.Map,%20java.lang.String,%20java.lang.String,%20java.lang.String)>
     * getScmConfigMap()</a>
     * @param trackChanges Boolean parameter for if changes found in this scm checkout should be added to
     * the build's changelog. Set to true by default.
     * @param pollScm Boolean parameter for if the scm in this checkout should be polled by the job and
     * trigger a new job when changes are detected. Set to true by default.
     * @param creds String Jenkins credentials ID to use to access the scm. Will default to the class'
     * <a href=#credentials>credentials</a> property by default if not set.
     * @param buildToolkit String buildToolkit to connect to RTC with. Will default to the class'
     * <a href=#buildToolkit>buildToolkit</a> property by default if not set.
     * @param server String RTC server to connect to. Will default to the class' <a href=#server>server</a>
     * property by default if not set.
     * @see <a href="https://jenkins.io/doc/pipeline/steps/workflow-scm-step/#checkout-general-scm">
     * checkout SCM Step</a>
     */
    /* groovylint-disable-next-line ParameterCount */
    void checkoutRtc(Map buildConfig, Boolean trackChanges=true, Boolean pollScm=true,
                     String creds='', String buildToolkit='', String server='') {
        this.jenkins.checkout changelog: trackChanges,
                              poll: pollScm,
                              scm: this.getScmConfigMap(buildConfig, creds, buildToolkit, server)
    }

    /**
     * Check-in files to an RTC workspace or stream given a list of component map configurations.
     * @param targetNodeMap Map configuration to detail the name or UUID of the workspace or stream to check-in the
     * files to.
     * Can be created with <a href=#getNodeByNameMap(java.lang.String,%20java.lang.String,%20java.lang.String)>
     * getNodeByNameMap()</a> or <a href=#getNodeByUUIDMap(java.lang.String,%20java.lang.String,%20java.lang.String)>
     * getNodeByUUIDMap()</a>
     * @param components List of component map configurations that detail the files to be checked-in. Map elements of
     * the list can be created with <a href=#method_summary>getComponentEntryMap()</a>
     */
    void checkinRtc(Map targetNodeMap, List components) {
        this.jenkins.step([$class: 'RTCCheckinPublisher',
                           componentEntries: components,
                           targetNode: targetNodeMap,])
    }

    /**
     * Deliver changes from a workspace to a stream to another workspace or stream.
     * @param sourceNodeMap Map configuration to detail the name or UUID of the workspace or stream to provide the
     * changes from. Can be created with <a href=#method_summary>getNodeByNameMap()</a> or <a href=#method_summary>
     * getNodeByUUIDMap()</a>
     * @param targetNodeMap Map configuration to detail the name or UUID of the workspace or stream to deliver the
     * changes to. Can be created with <a href=#method_summary>getNodeByNameMap()</a> or <a href=#method_summary>
     * getNodeByUUIDMap()</a>
     * @param componentRule String to specify which components to include the changes from. Use '*' for all components.
     * @param baselines Boolean option to include outgoing baselines in the delivery. True by default.
     * @param changesets Boolean option to include outgoing changesets in the delivery. True by default.
     * @param skipJenkinsBaselines Boolean option to skip outgoing baselines in the delivery which were automatically
     * created by a Jenkins build. True by default.
     * @param replacedComps Boolean option to include components which have been replaced in the delivery.
     * True by default.
     * @param addedComps Boolean option to include components which have been added in the delivery. False by default.
     * @param removedComps Boolean option to include components which have been removed in the delivery.
     * False by default.
     * @param incomingChangesets String value to specify what to do if there are incoming changesets pending in the
     * target workspace/stream. I.e. there is a potential to create merge conflicts. Valid options are:<br/>
     * <ul><li>'ABORT' - abort the build with an error message (set by default)</li><li>'DISCARD' - discard all
     * incoming changeset and proceed with the delivery </li><li>'REPLACE' - replace the component which has incoming
     * changesets with the one from the source </li><li>'CHECK' - deliver without accepting incoming changesets, abort
     * if a conflict is detected</li></ul>
     */
    /* groovylint-disable-next-line ParameterCount */
    void deliverRtc(Map sourceNodeMap, Map targetNodeMap, String componentRule,
                    Boolean baselines=true, Boolean changesets=true,
                    Boolean skipJenkinsBaselines=true, Boolean replacedComps=true,
                    Boolean addedComps=false, Boolean removedComps=false,
                    String incomingChangesets='ABORT') {

        if (!(ChangeSetHandles.ALLOWEDOPERATIONS.contains(incomingChangesets))) {
            throw new ConfigurationException("""'${incomingChangesets}' is an invalid handle \n
                                             ${ChangeSetHandles.ALLOWEDOPERATIONS}""")
        }

        this.jenkins.step([$class: this.deliverClass,
                           entries: [[components: componentRule,
                                      condition: this.defaultBuildCondition,
                                      includeBaselines: baselines,
                                      includeChangesets: changesets,
                                      includeComponents: addedComps,
                                      includeRemovedComponents: removedComps,
                                      includeReplacedComponents: replacedComps,
                                      incomingChangesetsHandling: incomingChangesets,
                                      skipAutoBaselines: skipJenkinsBaselines,
                                      source: sourceNodeMap,
                                      target: targetNodeMap,
                                      workitemCreationAlgo: [$class: 'CreateWiNeverAlgo']]]
                         ])
    }

    /**
     * Simple delivery option to mirror the changes of one workspace or stream to another workspace or stream.
     * @param sourceNodeMap Map configuration to detail the name or UUID of the workspace or stream to provide the
     * changes from. Can be created with <a href=#method_summary>getNodeByNameMap()</a> or <a href=#method_summary>
     * getNodeByUUIDMap()</a>
     * @param targetNodeMap Map configuration to detail the name or UUID of the workspace or stream to deliver the
     * changes to. Can be created with <a href=#method_summary>getNodeByNameMap()</a> or <a href=#method_summary>
     * getNodeByUUIDMap()</a>
     */
    void syncStreams(Map sourceNodeMap, Map targetNodeMap) {
        this.jenkins.step([$class: this.deliverClass,
                           entries: [[$class: 'RTCSynchronizeEntry',
                                      condition: this.defaultBuildCondition,
                                      source: sourceNodeMap,
                                      target: targetNodeMap]]
                         ])
    }

    /**
     * Apply an RTC snapshot to a given workspace or stream.
     * @param name String snapshot name to apply
     * @param sourceNodeMap Map configuration to detail the name or UUID of the workspace or stream to take a snapshot
     * from. Can be created with <a href=#method_summary>getNodeByNameMap()</a> or <a href=#method_summary>
     * getNodeByUUIDMap()</a>
     */
    void applySnapshot(String name, Map sourceNodeMap) {
        this.jenkins.step([$class: 'SnapshotCreator',
                           snapshotName: name,
                           source: sourceNodeMap,])
    }

    /**
     * Creates a Map to specify an scm checkout based on an RTC build definition.
     * @param buildDefintionName String name of the build definition to use.
     * @param customSnapshotName String to specify the name given to the snapshot that is created after accepting
     * the changes. If left blank, a default snapshot name will be used. Blank by default.
     * @param dynamicLoadRules Boolean option to use dynamic load rules rather than the value specified in the build
     * definition. False by default.
     * @return Map in the correct form required for the buildConfig parameter of <a href=#method_summary>
     * getScmConfigMap()</a>
     */
    Map getBuildTypeDefinitionMap(String buildDefinitionName, String customSnapshotName='',
                                  Boolean dynamicLoadRules=false) {
        return Map [buildDefinition: buildDefinitionName,
                    customizedSnapshotName: customSnapshotName,
                    overrideDefaultSnapshotName: customSnapshotName ? true : false,
                    useDynamicLoadRules: dynamicLoadRules,
                    value: 'buildDefinition']
    }

    /**
     * Creates a Map to specify an scm checkout based on an RTC workspace.
     * @param workspaceName String name of the workspace to checkout.
     * @param loadRulePath String path to loadrule within the workspace. Will use the class' <a href=#loadRulePath>
     * loadRulePath</a> property by default.
     * @param acceptChanges Boolean value to specify if incoming changes to the workspace should be accepted before
     * loading. True by default.
     * @param customSnapshotName String to specify the name given to the snapshot that is created after accepting
     * the changes. If left blank, a default snapshot name will be used. Blank by default.
     * @param clearDir Boolean option to delete the load directory before the loading. False by default.
     * @param loadDir String option to specify the directory to load the workspace into. Set to 'JWS' by default.
     * @return Map in the correct form required for the buildConfig parameter of <a href=#method_summary>
     * getScmConfigMap()</a>
     */
    /* groovylint-disable-next-line ParameterCount */
    Map getBuildTypeWorkspaceMap(String workspaceName, String loadRulePath='',
                                 Boolean acceptChanges=true, String customSnapshotName='',
                                 Boolean clearDir=false, String loadDir='') {
        return Map [acceptBeforeLoad: acceptChanges,
                    buildWorkspace: workspaceName,
                    clearLoadDirectory: clearDir,
                    customizedSnapshotName: customSnapshotName,
                    loadDirectory: loadDir ?: this.defaultLoadDir,
                    loadPolicy: this.rtcLoadPolicy,
                    overrideDefaultSnapshotName: customSnapshotName ? true : false,
                    pathToLoadRuleFile: loadRulePath ?: this.loadRulePath,
                    value: 'buildWorkspace']
    }

    /**
     * Creates a Map to specify an scm checkout based on an RTC snapshot.
     * @param snapshotName String name of the snapshot to checkout.
     * @param snapshotContextMap Map configuration option to specify if the snapshot ownership is a stream or
     * workspace. Will not discriminate by default. Can be created with <a href=#method_summary>
     * getSnapshotContextStreamMap()</a> or <a href=#method_summary>getSnapshotContextWorkspaceMap()</a>
     * @param loadRulePath String path to loadrule within the workspace. Will use the class' <a href=#loadRulePath>
     * loadRulePath</a> property by default.
     * @param clearDir Boolean option to delete the load directory before the loading. False by default.
     * @param loadDir String option to specify the directory to load the workspace into. Set to 'JWS' by default.
     * @return Map in the correct form required for the buildConfig parameter of <a href=#method_summary>
     * getScmConfigMap()</a>
     */
    Map getBuildTypeSnapshotMap(String snapshotName, Map snapshotContextMap=[:],
                                String loadRulePath='', Boolean clearDir=false,
                                String loadDir='') {
        Map snapshotContext = snapshotContextMap ?: this.snapshotContextNoneMap
        return Map [buildSnapshot: snapshotName,
                    buildSnapshotContext: snapshotContext,
                    clearLoadDirectory: clearDir,
                    currentSnapshotOwnerType: snapshotContext.snapshotOwnerType,
                    loadDirectory: loadDir ?: this.defaultLoadDir,
                    loadPolicy: this.rtcLoadPolicy,
                    pathToLoadRuleFile: loadRulePath ?: this.loadRulePath,
                    value: 'buildSnapshot']
    }

    /**
     * Creates a Map to specify an scm checkout based on an RTC stream.
     * @param streamName String name of the stream to checkout.
     * @param streamProcessArea String name of the process area the stream is from.
     * @param loadRulePath String path to loadrule within the workspace. Will use the class' <a href=#loadRulePath>
     * loadRulePath</a> property by default.
     * @param customSnapshotName String to specify the name given to the snapshot that is created after accepting
     * the changes. If left blank, a default snapshot name will be used. Blank by default.
     * @param compareChangeLog Boolean option to generate a changelog by comparing the current build with the
     * last successful build. Otherwise, the current build is compared with the previous build. False by default.
     * @param clearDir Boolean option to delete the load directory before the loading. False by default.
     * @param loadDir String option to specify the directory to load the workspace into. Set to 'JWS' by default.
     * @return Map in the correct form required for the buildConfig parameter of <a href=#method_summary>
     * getScmConfigMap()</a>
     */
    /* groovylint-disable-next-line ParameterCount */
    Map getBuildTypeStreamMap(String streamName, String streamProcessArea, String loadRulePath='',
                              String customSnapshotName='', Boolean compareChangeLog=false,
                              Boolean clearDir=false, String loadDir='') {
        return Map [buildStream: streamName,
                    clearLoadDirectory: clearDir,
                    customizedSnapshotName: customSnapshotName,
                    generateChangelogWithGoodBuild: compareChangeLog,
                    loadDirectory: loadDir ?: this.defaultLoadDir,
                    loadPolicy: rtcLoadPolicy ?: this.rtcLoadPolicy,
                    overrideDefaultSnapshotName: customSnapshotName ? true : false,
                    pathToLoadRuleFile: loadRulePath ?: this.loadRulePath,
                    processArea: streamProcessArea,
                    value: 'buildStream']
    }

    /**
     * Creates a Map to specify the stream ownership of a snapshot.
     * @param streamName String name of the stream owning the snapshot.
     * @param processArea String name of the process area the stream is from.
     * @return Map in the correct form required for the snapshotContextMap parameter of <a href=#method_summary>
     * getBuildTypeSnapshotMap()</a>
     */
    Map getSnapshotContextStreamMap(String streamName, String processArea) {
        return Map [owningStream: streamName, processAreaOfOwningStream: processArea, snapshotOwnerType: 'stream']
    }

    /**
     * Creates a Map to specify the workspace ownership of a snapshot.
     * @param workspaceName String name of the workspace owning the snapshot.
     * @return Map in the correct form required for the snapshotContextMap parameter of <a href=#method_summary>
     * getBuildTypeSnapshotMap()</a>
     */
    Map getSnapshotContextWorkspaceMap(String workspaceName) {
        return Map [owningWorkspace: workspaceName, snapshotOwnerType: 'workspace']
    }

    /**
     * Creates a Map to specify a workspace or stream based on its UUID.
     * @param nodeUUID String UUID of the workspace or stream.
     * @param creds String Jenkins credential ID to access the workspace or stream with. Will use the class'
     * <a href=#credentials>credentials</a> property by default.
     * @param server String ALM server to access. Will use the class' <a href=#server>server</a> property by default.
     * @return Map in the correct form required for RTC helper methods that accept sourceNodeMap or targetNodeMap as a
     * parameter.
     */
    Map getNodeByUUIDMap(String nodeUUID, String creds='', String server='') {
        return Map [$class: 'NodeByUUIDIdentifier',
                    credentialsID: creds ?: this.credentials,
                    overrideGlobal: true,
                    serverURI: server ?: this.server,
                    uuid: nodeUUID]
    }

    /**
     * Creates a Map to specify a workspace or stream based on its name.
     * @param nodeName String name of the workspace or stream.
     * @param creds String Jenkins credential ID to access the workspace or stream with. Will use the class'
     * <a href=#credentials>credentials</a> property by default.
     * @param server String ALM server to access. Will use the class' <a href=#server>server</a> property by default.
     * @return Map in the correct form required for RTC helper methods that accept sourceNodeMap or targetNodeMap as a
     * parameter.
     */
    Map getNodeByNameMap(String nodeName, String creds='', String server='') {
        return Map  [$class: 'NodeByNameIdentifier',
                     credentialsID: creds ?: this.credentials,
                     flowNodeName: nodeName,
                     nodeType: 'workspaceOrStream',
                     overrideGlobal: true,
                     serverURI: server ?: this.server]
    }

    /**
     * Creates a Map to specify a file that shall be checked-in.
     * @param path String destination path of the file relative to the selected component.
     * @param file String file to check-in with its path relative to the Jenkins workspace.
     * @param folder String folder level to be copied when checking-in.
     * E.g:<ul><li>'0': Folder1/File1.txt -> ALM component %destinationPath%/Folder1/File1.txt</li>
     * <li>'1': Folder1/File1.txt -> ALM component %destinationPath%/File1.txt (first level will not be copied)</li>
     * </ul>
     * @return Map in the correct form required as an element for the files parameter of <a href=#method_summary>
     * getComponentEntryMap()</a>
     */
    Map getFileEntryMap(String path, String file, String folder) {
        return Map [destPath: path, filename: file, folderLevel: folder]
    }

    /**
     * Creates a Map to specify a component that shall be checked-in.
     * @param name String name of the component.
     * @param files List of Map elements to specify each file that shall be checked-in. Elements can created with
     * <a href=#method_summary>getFileEntryMap()</a>
     * @param workItem Integer of the workItem ID to associate with this check-in.
     * @return Map in the correct form required as an element for the components parameter of
     * <a href=#method_summary>checkinRtc()</a>
     */
    Map getComponentEntryMap(String name, List files, Integer workItem) {
        return Map [componentName: name, fileEntries: files,
                    workItemIdentifier: [$class: 'WorkItemByIdIdentifier', id: workItem]]
    }

    /**
     * Creates a Map to specify an RTC scm instance that shall be checked-out.
     * @param buildConfig Map configuration to detail the how the scm shall be checked-out. Can be created with either
     * <a href=#method_summary>getBuildTypeDefinitionMap()</a>, <a href=#method_summary>getBuildTypeSnapshotMap()</a>,
     * <a href=#method_summary>getBuildTypeStreamMap()</a>, or <a href=#method_summary>getBuildTypeWorkspaceMap()</a>,
     * @param creds String Jenkins credentials ID to use to access the scm. Will default to the class'
     * <a href=#credentials>credentials</a> property by default if not set.
     * @param buildToolkit String buildToolkit to connect to RTC with. Will default to the class'
     * <a href=#buildToolkit>buildToolkit</a> property by default if not set.
     * @param server String RTC server to connect to. Will default to the class' <a href=#server>server</a>
     * property by default if not set.
     * @return Map in the correct form required for the buildConfig parameter of <a href=#method_summary>
     * checkoutRtc()</a>
     */
    Map getScmConfigMap(Map buildConfig, String creds='', String buildToolkit='', String server='') {
        return Map [$class: 'RTCScm',
                    avoidUsingToolkit: false,
                    buildTool: buildToolkit ?: this.buildToolkit,
                    buildType: buildConfig,
                    credentialsId: creds ?: this.credentials,
                    overrideGlobal: true,
                    serverURI: server ?: this.server,
                    timeout: 480]
    }

    /**
     * Get path of selected files changed in a given RTC changeset.
     * <br/>
     * An example will be when needing to access changed files (e.g. for analysis) as the RTC changeset object
     * contains the filename and component name separately. The path of the file is derived from the component name.
     * Requires no env variable to be set before executing.
     * <br/>
     * @param changeLogSets Object passed from jenkins environment e.g this.jenkins.currentBuild.changeSets
     * @param includeExtensions List of file extensions to include in the returned file list.
     * @param excludeComponents List of components to ignore in the from the changeset.
     * @return List converted Windows file path of the file(s) included in the changeset.
     */
    @NonCPS
    List<String> parseRtcChanges(Object changeLogSets,
                                 List<String> includeExtensions=this.defaultIncludeExtensions,
                                 List<String> excludeComponents=[]) {
        List<String> fileList = []
        changeLogSets.each { entries ->
            entries.each { entry ->
                if (entry.metaClass.respondsTo(entry, this.defaultRtcRespondsTo)) {
                    List<String> filteredFiles = this.filterChangedFiles(entry, includeExtensions, excludeComponents)
                    filteredFiles.each { filePath ->
                        if (!fileList.contains(filePath)) {
                            fileList.push(filePath)
                        }
                    }
                }
            }
        }
        return fileList
    }

    /**
     * Return a list of filtered file paths given an RTC changeset entry.
     * <br/>
     * For each file in a changeset entry this method will validate its component and extension,
     * returning a list of files matching this criteria with their path build from the component
     * name.
     * @param entry Object from Jenkins build changeSets class.
     * @param includeExtensions List of file extensions to include in the returned file list.
     * @param excludeComponents List of components to ignore in the from the changeset.
     * @return List filtered Windows file paths of the file(s) in the changeSet entry.
     */
    @NonCPS
    List<String> filterChangedFiles(Object entry,
                                    List<String> includeExtensions=this.defaultIncludeExtensions,
                                    List<String> excludeComponents=[]) {
        List<String> filteredList = []
        String component = entry.componentName
        if (!excludeComponents.contains(component)) {
            List<String> changedFiles = (List<String>) entry.affectedPaths
            changedFiles.each { fileName ->
                if (includeExtensions.contains(fileName[fileName.lastIndexOf(dotSeparator)..-1])) {
                    filteredList.push(component.replace(dotSeparator, pathSeparator) +
                                      fileName.replace('/', pathSeparator))
                }
            }
        }
        return filteredList
    }

    /**
     * Return a human readable string detailing the changes in an RTC changeset. Example usage includes when
     * needing to write a reporting log of the changes for a given build.
     * @param changeLogSets Object passed from jenkins environment e.g this.jenkins.currentBuild.changeSets
     * @param timeZone String option to specify the timezone of the commit timestamps that will be logged.
     * @return String of the changes including author, date, commit message(s), component name(s) and file(s).
     */
    @NonCPS
    String getChangeSetData(Object changeLogSets, String timeZone='GMT+01:00') {
        String changes = ''
        changeLogSets.each { entries ->
            entries.each { entry ->
                if (entry.metaClass.respondsTo(entry, this.defaultRtcRespondsTo)) {
                    String componentName = entry.componentName
                    String timestamp = Instant.ofEpochMilli(entry.timestamp).atZone(ZoneId.of(timeZone))
                    changes += "${entry.author} on ${timestamp}: ${entry.msg}\r\n"
                    List<String> changedFiles = (List<String>) entry.affectedPaths
                    changedFiles.each { fileName ->
                        changes += "| Component : ${componentName} | File : ${fileName}\r\n"
                    }
                }
            }
        }
        return changes
    }

    /**
     * A generic function which helps the teamArea setup with a new stream
     * @param rtcHelpersInst explicit object refference being called when calling the function
     * @param teamArea the appropriate team area given a domain and a project
     * @param newStreamName the desired name of the new stream under the given team area
     * @param baseSnapshotName the snapshot that will be the baseline for the new stream
     * @param rwsToCreate a list of workspaces that needed to be created when setup a teamArea
     */
    Map teamAreaSetup(String teamArea, String newStreamName, String baseSnapshotName,
                      List<String> rwsToCreate, LscmUtility lscmInstance=this.lscmUtil) {
        lscmInstance.login()
        // create the desired stream given a teamArea
        lscmInstance.generateStream(teamArea, baseSnapshotName, newStreamName)
        // create the necessary stream given a list of stream to create e.g CICD and tester RWS for
        rwsToCreate.each { rws ->
            lscmInstance.generateRws(newStreamName, rws)
        }
        return ['createdStream' : newStreamName, 'createdRws' : rwsToCreate]
    }

    /**
     * A generic function which helps to delete temporary stream workspace given a teamArea
     * It only removes the RTC backend and stream. Please use JobHelper to delete jobs.
     * @param teamArea the appropriate team area given a domain and a project
     * @param rwsToCreate a list of workspaces that needed to be deleted when setup a teamArea
     * @param streamRef stream which will be in compared to in terms of changesets
     * @param streamToDelete the desired stream that needed to be deleted from the set of workspaces
     * @param changesetFilter the desired components to be filtered when merging to streamRef
     * @param override default false, check for changesets that have not been delivered to the stream defined in
                                      streamRef variable and shall fail the pipeline if changesets are found
     *                         true, will not check for changeset that is not in streamRef
     * @param delSnapshot default false, will move the snapshots owned by the deleted stream
                                         to the stream defined in streamRef
     *                            true, will delete the snapshots owned by the stream to be deleted
     * @param backupSnapshotOwner String to define a stream that shall own a backup snapshot of the deleted stream
                                  If left blank no backup snapshot will be taken
     * of the stream that shall be removed and assign that snapshot to that stream or workspace
     */
    /* groovylint-disable-next-line ParameterCount */
    Boolean teamAreaTearDown(String teamArea, List<String> rwsToDelete, String streamRef,
                             String streamToDelete, String changesetFilter, Boolean override=false,
                             Boolean delSnapshot=false, String backupSnapshotOwner='', Integer jobTimeOut=120,
                             LscmUtility lscmInstance=this.lscmUtil, RtcHelpers rtcInstance=this) {
        lscmInstance.login()
        if (!override) {
            rtcInstance.deliverRtc(rtcInstance.getNodeByNameMap(streamRef),
                                   rtcInstance.getNodeByNameMap(streamToDelete), changesetFilter,
                                   false, true, true, true, true, true, ChangeSetHandles.ABORT)
        }
        Boolean executeFlag = false
        try {
            String prompt = "Are you sure you want to delete ${streamToDelete} ?\n"
            prompt += 'Including the following workspace :\n'
            rwsToDelete.each { rws ->
                prompt += "\t WorkSpace : ${rws}\n"
            }
            this.jenkins.timeout(time: jobTimeOut, unit: 'SECONDS') {
                this.jenkins.input prompt
                rwsToDelete.each { rws ->
                    lscmInstance.deleteRws(rws)
                }
                List<String> snapshotList = []
                for (entry in lscmInstance.listSnapshots(teamArea, streamToDelete)) {
                    if (entry.key == 'snapshots') {
                        snapshotList = entry.value.name
                    }
                }
                snapshotList.each { snapshot ->
                    if (delSnapshot) {
                        lscmInstance.deleteSnapshot(streamRef, snapshot)
                    } else {
                        lscmInstance.promoteSnapshotToStream(streamRef, snapshot)
                    }
                }
                lscmInstance.deleteStream(streamToDelete, backupSnapshotOwner, teamArea)
            }
            executeFlag = true
        } catch (InterruptedException e) {
            this.jenkins.echo 'Timeout reached, teamAreaTearDown did not execute\n'
        }
        return executeFlag
    }

    /**
    * A generic function which allows the comparison of two versions.
    * A version can be a snapshot, a stream or a workspace in RTC.
    * @param version The version of the SCM that is the base for comparison
    * @param compVersion The version of the SCM which is compared to param version
    * @param excludeFiles List of regex strings which files shall not be included in the changes.
    *                     (See http://www.groovy-lang.org/Regular+Expressions for details)
    */
    List<String> compare(String version, String compVersion, List<String> excludeFiles=[]) {
        Map parsedJson = this.lscmUtil.compare(version, compVersion)
        return this.lscmUtil.findChangesets(parsedJson, excludeFiles)
    }

    /**
    * A generic function which can be used for Pull Request or Rebase.
    * Uses deliverRtc (mentioned above) to deliver changes from a workspace to a stream
    * to another workspace or stream.
    * @param componentRule: specifies which components to include the changes from. '*' includes all components.
    * @param stagingWorkspace: destination rws of the project e.g. 'rbd_starterkit_aurix2g_dev_ASW_jenkins_PR'
    * @param deststream: stream source of the project e.g. 'rbd_starterkit_aurix2g_sw_dev'
    * @param source: rws source of the project e.g. 'rbd_starterkit_aurix2g_dev_ASW_jenkins_prePR'
    */
    void prRebase(String stagingWorkspace, String destStream, String source, String componentRule = '*') {
        Map destination = getNodeByNameMap(stagingWorkspace)
        Map sourceStr = getNodeByNameMap(destStream)
        deliverRtc(sourceStr, destination, wildcard, false, true, true, true, true, true, ChangeSetHandles.REPLACE)
        Map src = getNodeByNameMap(source)
        deliverRtc(src, destination, componentRule, false, true, true, true, true, true, ChangeSetHandles.CHECK)
    }

}
