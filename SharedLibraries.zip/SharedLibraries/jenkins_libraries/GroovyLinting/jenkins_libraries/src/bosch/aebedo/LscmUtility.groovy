#! /usr/bin/env groovy
/**
 * Copyright (C) 2021, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package bosch.aebedo

import groovy.json.JsonSlurperClassic

/**
 * Library to aid common pipeline operations relating to the Rational Team Concert SCM.<br/>
 * <li><a> href=https://www.ibm.com/docs/en/elm/7.0.1?topic=reference-example-scm-commands>
 * LSCM Command Line Documentation</a></li></ul>
 */
class LscmUtility {

    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null
    /** ALM server to connect to. Will be set to 'https://rb-alm-11-p.de.bosch.com/ccm' if the rtcServer
     * variable is not otherwise specified in the Jenkins environment.*/
    String server = ''
    /** Jenkins credentials ID to connect to the ALM server with. Must be set with the rtcCredentials
     * variable in the Jenkins environment.*/
    String credentials = ''
    /** LSCM path to be specified when calling the  cli. Will be set to 'C:\\rtc-scmtools\\eclipse\\.bat'
    * unless otherwise specified with the lscmPath variable in the Jenkins environment.*/
    String lscmPath = ''
    /** String pathSeparator, default set to '\\'*/
    String pathSeparator = '\\'

    private final String nameKey = 'name'
    private final Integer listAllVal = 0

    /**
     * Constructor for the RtcHelpers class.
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     * (aka WorkflowScript) in which context the code is executed.
     * @param props Fields of the object to overwrite the default values. Fields
     * have to exist in class definition.
     */
    LscmUtility(Object jenkins, Map props= [:]) {
        this.jenkins = jenkins
        this.credentials = this.jenkins.env.rtcCredentials ?: ''
        this.server = this.jenkins.env.rtcServer ?: 'https://rb-alm-11-p.de.bosch.com/ccm'
        this.lscmPath = this.jenkins.env.lscmPath ?: 'C:\\rtc-scmtools\\eclipse\\lscm.bat'
        props.each { name, val ->
            this.setProperty(name, val)
        }
    }

    /**
    * A login function which is required at least to be called once in the beginning of before performing
    * any other  function call to ensure that the credentials is being cached
    * @param retry the amount of retry being given as sometimes the login call may fail on the first instance
    * @param cached flag which determine whether the command will run with the password being cached or not
    */
    void login(int retry=30, Boolean cached=false, String credentials=this.credentials,
                Boolean loginOverride=true) {
        Object almCred = this.jenkins.usernamePassword(credentialsId: credentials,
                                                        passwordVariable: 'PASSWORD',
                                                        usernameVariable: 'USERNAME')
        this.jenkins.withCredentials([almCred]) {
            String cachedExt = cached ? '' : '-c'
            /* groovylint-disable-next-line DuplicateNumberLiteral */
            for (int i = 0; i <= retry; i++) {
                try {
                    this.jenkins.bat """
                    ${this.lscmPath} login -r ${this.server} ^
                    -u ${this.jenkins.env.USERNAME} ^
                    -P ${this.jenkins.env.PASSWORD} ${cachedExt}
                    """
                    break
                } catch (e) {
                    if (i == 30) {
                        throw(e)
                    }
                    sleep(1)
                    if (loginOverride) {
                        lscmInstance.logout()
                    }
                }
            }
        }
    }

    /**
    * A logout function which is required during cleanup to ensure that previous login is cleared
    * For example this function should be called during the cleanup section of a pipeline
    */
    void logout() {
        this.jenkins.bat """
        ${this.lscmPath} logout -r ${this.server}
        """
    }

    /**
    * A generic function which return an object which contains stream names given a teamarea
    * @param teamArea the appropriate team area given a domain and a project
    * @param numberOfStreams default to list all otherwise valid only for input greater than 0
    * @return Object an object which has details of the list of streams e.g uuid, name
    */
    List<HashMap> listStreams(String teamArea, Integer numberOfStreams=this.listAllVal) {
        String maxArg = numberOfStreams == this.listAllVal ? '--maximum all' : "-m ${numberOfStreams}"
        String streamListJsonOutput = this.jenkins.bat (returnStdout: true,
                                                        script: """@${this.lscmPath} list streams ^
                                                                -r ${this.server} --teamarea \"${teamArea}\" ^
                                                                ${maxArg} --json
                                                                """)
        return (new JsonSlurperClassic()).parseText(streamListJsonOutput)
    }

    /**
    * A generic function which return an object which contains list of componennts in a stream given a teamarea
    * & workspace/stream
    * @param streamName the name of the stream/workspace to get the list of components
    * @param teamArea the appropriate team area given a domain and a project
    * @param numberOfComponents default to list all otherwise valid only for input greater than 0
    * @return Object an object which has details of the list of components
    */
    Map listComponents(String streamName, String teamArea, Integer numberOfComponents=this.listAllVal) {
        String maxArg = numberOfComponents == this.listAllVal ? '--maximum all' : "-m ${numberOfComponents}"
        String script = "@${this.lscmPath} list components -r ${this.server} --teamarea \"${teamArea}\" "
        script += "\"${streamName}\" ${maxArg} --json"
        String compListJsonOutput = this.jenkins.bat (returnStdout: true, script: script)
        return (new JsonSlurperClassic()).parseText(compListJsonOutput)
    }

    /**
    * A generic function which return an object which contains workspaces names given an optional visibility
    * @param teamArea the appropriate team area given a domain and a project
    * @param numberOfWorkspaces default to list all otherwise valid only for input greater than 0
    * @param visibility valid values are public, private, teamarea, projectarea, or accessgroup
    * @return Object an object which has details of the list of streams e.g uuid, name
    */
    List<HashMap> listWorkspaces(Integer numberOfWorkspaces=this.listAllVal, String visibility='private') {
        String maxArg = numberOfWorkspaces == this.listAllVal ? '--maximum all' : "-m ${numberOfWorkspaces}"
        String workspaceListJsonOutput = this.jenkins.bat (returnStdout: true,
                                                            script: """
                                                                    @${this.lscmPath} list workspaces ^
                                                                    --visibility ${visibility} ^
                                                                    -r ${this.server} ${maxArg} --json
                                                                    """)
        return (new JsonSlurperClassic()).parseText(workspaceListJsonOutput)
    }

    /*
    * @param teamArea the appropriate team area given a domain and a project
    * @param nodeToAnalyze The workspace, stream (name[@repo], alias or UUID[@repo]) or snapshot prefix.
    * @param numberOfWorkspaces default to list all otherwise valid only for input greater than 0
    */
    Map listSnapshots(String teamArea, String nodeToAnalyze, Integer numberOfSnaphosts=this.listAllVal) {
        String maxArg = numberOfSnaphosts == this.listAllVal ? '--maximum all' : "-m ${numberOfSnaphosts}"
        String snapshotListJsonOutput = this.jenkins.bat (returnStdout: true,
                                                            script: """
                                                                    @${this.lscmPath} list snapshots ^
                                                                    --teamarea \"${teamArea}\" ^
                                                                    -r ${this.server} ${maxArg} --json ^
                                                                    ${nodeToAnalyze}
                                                                    """)
        return (new JsonSlurperClassic()).parseText(snapshotListJsonOutput)
    }

    /**
    * A generic function which create stream given a teamarea
    * NOTE : it is possible to create stream with the same name but with different uuid
    * Please use the lscmListStreams function to perform an error check on the list of streams
    * @param teamArea the appropriate team area given a domain and a project
    * @param baseSnapshotName the snapshot that will be the baseline for the new stream
    * @param newStreamName the desired name of the new stream
    * @param checkForDuplicate default enabled which check whether stream with the same name already exist
    * @return Map a simple json map which details the stream that was created e.g uuid, name
    */
    List<HashMap> generateStream(String teamArea, String baseSnapshotName,
                                    String newStreamName, Boolean checkForDuplicate=true,
                                    LscmUtility lscmInstance=this) {
        if (checkForDuplicate) {
            List<HashMap> jsonStreamList = lscmInstance.listStreams(teamArea)
            jsonStreamList.each { stream ->
                if (stream[this.nameKey] == newStreamName) {
                    this.jenkins.error("Stream ${newStreamName} already exist")
                }
            }
        }
        String createStreamJsonOutput = this.jenkins.bat (returnStdout: true,
                                                            script: """
                                                                    @${this.lscmPath} ^
                                                                    create stream -r ${this.server} ^
                                                                    \"${newStreamName}\" --teamarea ^
                                                                    \"${teamArea}\" --snapshot ^
                                                                    ${baseSnapshotName} --json
                                                                    """)
        return [new HashMap<>((new JsonSlurperClassic()).parseText(createStreamJsonOutput))]
    }
    /**
    * A generic function which accept changes from source to target
    * @param source workspace or stream from which the changes will flow
    * @param target workspace into which the changes will flow
    * @param localRefresh if enabled Does not scan the file system for new changes.
    */
    void acceptFromSourceToTarget(String source, String target, Boolean localRefresh=false) {
        String refreshArgs = localRefresh ? '' : ' -N'
        this.jenkins.bat script: """
                                    ${this.lscmPath} accept -s ${source} ^
                                    -t ${target} -r ${this.server}${refreshArgs}
                                    """
    }

    /**
    * A generic function which delete the stream
    * @param streamToDelete the desired stream to be deleted
    * @param teamArea the desired team area associated with the stream that will be deleted
    * @param backupTarget the snapshot to for The workspace or stream to associate with the
    *  backup snapshot. To specify this workspace or stream, use its name[@repo], alias, or UUID[@repo].
    */
    void deleteStream(String streamToDelete, String backupTarget='', String teamArea='',
                        LscmUtility lscmInstance=this) {
        Boolean deleteFlag = false
        if (teamArea != '') {
            lscmInstance.listStreams(teamArea).each { streamObj ->
                if (streamObj[this.nameKey] == streamToDelete) {
                    deleteFlag = true
                }
            }
        }
        else {
            deleteFlag = true
        }
        if (deleteFlag) {
            String backupParam = backupTarget ? "-b ${backupTarget}" : ''
            this.jenkins.bat script: """
                                        ${this.lscmPath} delete stream -r ${this.server} ^
                                        ${streamToDelete} ${backupParam}
                                        """
        } else {
            this.jenkins.echo "Stream : ${streamToDelete} were not deleted"
        }
    }

    /**
    * A generic function which create repositoryworkspace given a stream to based its creation from
    * NOTE : that the workspace created from this function is automatically private on its visibility
    * @param baseStreamName the baseline from which stream the RWS created NOTE : Not a Snapshot full stream name
    * @param newRwsName the desired name of the repository workspace
    * @param checkForDuplicate default enabled which check whether privatge rws with the same name already exist
    * @return Map a simple json map which details the repository workspace that was created
    */
    List<HashMap> generateRws(String baseStreamName, String newRwsName,
                                Boolean checkForDuplicate=true, LscmUtility lscmInstance=this) {
        if (checkForDuplicate) {
            List<HashMap> jsonRwsStreamlist = lscmInstance.listWorkspaces()
            jsonRwsStreamlist.each { createdRws ->
                if (createdRws[this.nameKey] == newRwsName) {
                    this.jenkins.error("Workspace ${it} already exist")
                }
            }
        }
        String createWorkSpaceJsonOutput = this.jenkins.bat (returnStdout: true,
                                                                script: """
                                                                        @${this.lscmPath} ^
                                                                        create workspace -r ${this.server} ^
                                                                        \"${newRwsName}\" --stream ${baseStreamName} ^
                                                                        --json
                                                                        """)
        return [new HashMap<>((new JsonSlurperClassic()).parseText(createWorkSpaceJsonOutput))]
    }

    /**
    * A generic function which delete the workspace
    * @param workspaceToDelete the desired workspace to be deleted
    */
    void deleteRws(String rwsToDelete, Boolean checkForOwnerShip=true, LscmUtility lscmInstance=this) {
        Boolean deleteFlag = false
        if (checkForOwnerShip) {
            lscmInstance.listWorkspaces().each { workspaceObj ->
                if (workspaceObj[this.nameKey] == rwsToDelete) {
                    deleteFlag = true
                }
            }
        } else {
            deleteFlag = true
        }
        if (deleteFlag) {
            this.jenkins.bat script: "${this.lscmPath} delete workspace -r ${this.server} ${rwsToDelete}"
        } else {
            this.jenkins.echo "Workspace : ${rwsToDelete} were not deleted"
        }
    }

    /**
    * A generic function which promotes snapshot ownership to the stream
    * An example usage when promoting is to have this label to stream and artifacts for tracebility
    * @param rtcStream the target stream when promoting assigned stream ownership of the snapshot
    * @param createdSnapshotName CREATED_SNAPSHOT_NAME a variable availble once RtcHelpes.applySnapshot called
    */
    void promoteSnapshotToStream(String rtcStream, String createdSnapshotName, String teamArea='') {
        String streamUuid = teamArea == '' ? rtcStream : ''
        if (teamArea != '') {
            List<Map> streamList = this.listStreams(teamArea)
            streamList.each { streamObj ->
                if (streamObj.name == rtcStream) {
                    streamUuid = streamObj.uuid
                }
            }
        }
        this.jenkins.bat script: """
                                    ${this.lscmPath} set attributes -s \"${createdSnapshotName}\" ^
                                    --ownedby \"${streamUuid}\" -r ${this.server}
                                    """
    }

    /**
    * A generic function which deletes the snapshot after it is being created
    * An example of usage is when the build has failed then the snapshot is no longer a valid snapshot
    * where it is not appropriate for the snapshot to the be promoted to the stream
    * @param rtcWorkspace the RWS where the snapshot is being applied to when building the SW
    * @param createdSnapshotName CREATED_SNAPSHOT_NAME a variable availble once RtcHelpes.applySnapshot called
    */
    void deleteSnapshot(String rtcWorkspace, String createdSnapshotName) {
        this.jenkins.bat script: """
                                    ${this.lscmPath} delete snapshot -r ${this.server} ^
                                    ${rtcWorkspace} \"${createdSnapshotName}\"
                                    """
    }

    /**
    * A generic function which allowes the comparison of a snapshot and a workspace.
    * This will be used to find files which are affected within a changeset
    * @param snapshot the current taken snapshot which will be compared to the workspace
    * @param workspace is the workspace which contains the latest state
    * shortcuts: -r = repository workspace, ws = workspace, -I = include types,
    * f = file, c = component, --json = output in json format
    */
    Map compare(String snapshot, String workspace) {
        String script = "@${this.lscmPath} compare -r ${this.server} "
        script += "snapshot ${snapshot} ws ${workspace} -I fc --json"
        String jsonString = this.jenkins.bat (returnStdout: true, script: script)
        Map parsedJson = new JsonSlurperClassic().parseText(jsonString)
        return parsedJson
    }

    /**
    * A generic function which breakes down the affected files from compare.
    * This will find affected files from the changesets and add the path to them,
    * so SFA can continue working with them.
    * The changesetFingings output is a list.
    * @param excludeFiles List of regex strings which files shall not be included in the changes.
    *                     (See http://www.groovy-lang.org/Regular+Expressions for details)
    */
    List<String> findChangesets(Map parsedJson, List<String> excludeFiles=[]) {
        List changesetFindings = []
        parsedJson.direction.each { direction ->
            direction.components.each { component ->
                changesetFindings = changesetFindings + getFilesOfComponent(component, excludeFiles)
            }
        }
        changesetFindings.unique()
        return changesetFindings
    }

    /**
    * A function to search for the latest snapshot created in a specific team area on
    * a particular stream and returns it as String.
    * @param seachStream Name of the stream where the snapshot is located.
    * @param teamarea Name of the team area, where the stream is located.
    * @param nameContains Specific pattern to search for e.g. "Release".
    */
    String getLatestReleaseSnapshot(String searchStream, String teamarea, String nameContains) {
        String script = "@${this.lscmPath} query -r ${this.server} -m 1 --snapshot "
        script += "\"for_stream('${searchStream}') and in_teamarea('${teamarea}') "
        script += "and name matches '${nameContains}'\" --json"
        String latestSnapshotOutput = this.jenkins.bat (returnStdout: true, script: script)
        String output = (new JsonSlurperClassic()).parseText(latestSnapshotOutput).name
        return output.replaceAll('[\\[\\]]', '')
    }

    /**
    * Helper function to retrieve all file paths from a given component.
    * This function is not supposed to be used outside of LscmHelpers.
    * @param excludeFiles List of regex strings which files shall not be included in the changes.
    *                     (See http://www.groovy-lang.org/Regular+Expressions for details)
    */
    private List<String> getFilesOfComponent(Map component, List<String> excludeFiles=[]) {
        List<String> files = []
        if (component.containsKey ('changesets')) {
            component.changesets.each { changeset ->
                changeset.versionables.each { versionable ->
                    if (versionable.containsKey ('path')) {
                        String tempPath = component.'name'.replace ( '.', pathSeparator ) +
                                          versionable.path.replace ('/', pathSeparator)
                        Boolean exclude = false
                        excludeFiles.each { regex ->
                            exclude = exclude || tempPath =~ regex
                        }
                        if (!exclude) {
                            files.add(tempPath)
                        }
                    }
                }
            }
        }
        return files
    }

}
