echo "Please insert the Release Name:"
read release_name
declare -a complete=()
release_version=($(date +"%y.%U"))
release_branch_name="release/V${release_version}_${release_name}"
if ! git show-ref --verify --quiet "refs/heads/$release_branch_name"; then
    echo "Creating branch ${release_branch_name} based on origin/master"
    git fetch
    git branch "$release_branch_name" origin/master
fi
git checkout "$release_branch_name"

spin='-\|/'
i=0
echo "Gathering Commits"
while read -r commit; do
    i=$(((i + 1) % 4))
    printf "\r${spin:$i:1}"
    if [[ $commit =~ AEBEDO-[0-9]* ]]; then
        number=(${BASH_REMATCH})
        complete+=("$number")
    fi
done < <(git --no-pager log --format=medium --abbrev-commit --decorate=no origin/release/latest_stable_release..origin/master)

ids=($(printf "%s\n" "${complete[@]}" | sort -u))

if [[ -f "Release_Notes.md" ]]; then
    echo "moving old release notes"
    mv Release_Notes.md Release_Notes.md.old
fi
echo "<!-- @format -->" >Release_Notes.md
echo "" >>Release_Notes.md
echo "# AEBE Devops Jenkins Library" >>Release_Notes.md
echo "" >>Release_Notes.md
echo "## Version: $release_version ($release_name)" >>Release_Notes.md
echo "" >>Release_Notes.md
echo "Branch in git: [release/V${release_version}_${release_name}](https://sourcecode.socialcoding.bosch.com/projects/AEBEDO/repos/jenkins_libraries/browse?at=refs%2Fheads%2Frelease%2FV${release_version}_${release_name})" >>Release_Notes.md
echo "" >>Release_Notes.md
echo "Changes:" >>Release_Notes.md
echo "" >>Release_Notes.md
for number in "${ids[@]}"; do
    echo "- <Add information> [$number](https://rb-tracker.bosch.com/tracker01/browse/$number)" >>Release_Notes.md
done

if [[ -f "Release_Notes.md.old" ]]; then
    sed -n '/AEBE Devops Jenkins Library/,$p' <Release_Notes.md.old | sed '1d' >>Release_Notes.md
fi
echo "The Release_notes.md is updated with the new version"
echo "Please add some additional information for the changes of this Release"
