#!/usr/bin/env groovy
 /**
 * Copyright (C) 2021, 2021 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package edu.hm.hafner.analysis

class Severity {

    static final Severity ERROR = new Severity('ERROR')
    static final Severity WARNING_HIGH = new Severity('HIGH')
    static final Severity WARNING_NORMAL = new Severity('NORMAL')
    static final Severity WARNING_LOW = new Severity('LOW')

    static Severity guessFromString(String severity) {
        if (severity.toLowerCase() in ['error', 'severe', 'critical', 'fatal']) {
            return Severity.ERROR
        }
        if (severity.toLowerCase() in ['info', 'note']) {
            return Severity.WARNING_LOW
        }
        if (severity.toLowerCase() in ['warning']) {
            return Severity.WARNING_NORMAL
        }
        return Severity.WARNING_LOW
    }

    String name = ''

    Severity(final String name) {
        this.name = name
    }

    String getName() {
        return name
    }

    @Override
    String toString() {
        return name
    }

}
