Jenkins Job Builder
===================

.. include:: ../../README.rst

Contents
========
.. toctree::
   :maxdepth: 3

   quick-start
   installation
   execution
   definition
   extending

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
