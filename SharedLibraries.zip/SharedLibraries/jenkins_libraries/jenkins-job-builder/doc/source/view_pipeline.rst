.. _view_pipeline:

Pipeline View
=============

.. automodule:: view_pipeline
  :members:
