def jenkinsFileStart() {
	JenkinsLib = library('conTTinuous@JenkinsLib_v2.0.8')
	gitBitbucketLib = JenkinsLib.com.bosch.tt.GitBitbucket.new(this)
	confluenceLib = JenkinsLib.com.bosch.tt.Confluence.new(this)
	jiraLib = JenkinsLib.com.bosch.tt.JIRA.new(this)
	mavenLib = JenkinsLib.com.bosch.tt.Maven.new(this)
    sonarLib = JenkinsLib.com.bosch.tt.SonarQube.new(this)

	Global = library('conTTinuous_configs')
	globalVariables = Global.com.bosch.variables.GlobalVariables.new()
	
	try {

		stage('[Workspace] Initialize') {
			deleteDir()
		}

		stage('[Bitbucket] Checkout Source Code') {
				gitBitbucketLib.checkoutByBranch("${env.BRANCH_NAME}",globalVariables.UserJenkins,globalVariables.BitbucketLibRepo)
		}

		def pom = readMavenPom file: 'pom.xml'
		String pomVersion = pom.version

		if ("${env.BRANCH_NAME}" == 'master') {
			stage('[Bitbucket] Checkout Docs Source Code') {
				dir('jenkins_docs/') {
					gitBitbucketLib.checkoutByBranch('master',globalVariables.UserJenkins,globalVariables.BitbucketDocsRepo)
				}
			}
		}

		stage('[Maven] Build Project'){
			if ("${env.BRANCH_NAME}" == 'master') {
				mavenLib.buildPackage("${tool 'Jenkins Maven'}", globalVariables.MavenSettings, 'gplus:groovydoc')
				sh("mkdir -p ./jenkins_docs/docs/${pomVersion}/")
				sh("cp -R ./target/gapidocs/. ./jenkins_docs/docs/${pomVersion}")
				sh("cp -R ./img/docs/. ./jenkins_docs/img/docs")
			} else {
				mavenLib.buildPackage("${tool 'Jenkins Maven'}", globalVariables.MavenSettings, '')
			}
		}

		stage('[Maven] Run Unit Tests'){
				mavenLib.test("${tool 'Jenkins Maven'}", globalVariables.MavenSettings)
		}

		if ("${env.BRANCH_NAME}".contains('release') || "${env.BRANCH_NAME}" =='develop' || "${env.BRANCH_NAME}" =='master') {
			stage('[Jenkins] Run Integration Test (DEMO)'){
				String job = 'ttswq/development' 
				if ("${env.BRANCH_NAME}" == 'master') {
						job = 'ttswq/master'
				}
				build job: "${job}", propagate: true, wait: true
			}
		}

        stage('[SonarQube] Run Static Analysis') {
            def sonarQubeMap = ['master': "", 'release': "master", 'develop': "master", 'feature': "develop", 'hotfix': "master"]
            git_branch = "${env.BRANCH_NAME}"
        	mvn_options = sonarLib.initSonarQubeProject('SonarQube Test jenkins_lib', "com.bosch.conttinuous:jenkins_lib", "${git_branch}", '', '', '(develop|release|master).*')
            mavenLib.mavenRunSonarQubeAnalysis('SonarQube Test jenkins_lib', '2aad9cea-2795-42b7-a536-d8152c064436', "${mvn_options} -D sonar.sources=pom.xml,src/com/bosch,test/com/bosch -D sonar.exclusions=test/com/bosch/*.java,test/com/bosch/*.groovy,test/com/bosch/mock/*")
        }
      
        stage('[SonarQube] Quality Gate Validation') {
            sonarLib.sonarQualityGatesValidation()
        }		
		if ("${env.BRANCH_NAME}" == 'master') {
			stage('[Bitbucket] Push to jenkins_docs Repository') {
				dir('jenkins_docs/'){
					withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: globalVariables.UserJenkins, usernameVariable: 'username', passwordVariable: 'password']]) {
						sh('git config user.email "User.TTSWEQ@bcn.bosch.com"')
						sh('git config user.name "TSW1AV"')
						sh("git add docs/${pomVersion}/*")
						sh("git add img/*")
						sh('currentdate="` date `"; git commit --allow-empty -m "$currentdate"')
						sh("git tag -a ${pomVersion} -m " + '"tag auto generated"')
						script {
							env.encodedPass=URLEncoder.encode(password, "UTF-8")
						}
						sh("git push https://${username}:${encodedPass}@sourcecode.socialcoding.bosch.com/scm/conttinuous/jenkins_docs.git master ${pomVersion}")
					}
				}
			}

			stage('[Confluence] Generate Docupedia Page') {
				release_notes = jiraLib.getReleaseNotes(globalVariables.UserJenkins, 'CONTTINUOUS', "${pomVersion}", 'Html').split('</h2>')[1]
				issues_lost_retro_compatibility = jiraLib.getJiraListOfIssues('TT', "project = ConTTinuous and fixVersion in (${pomVersion}) and labels in (lost_retro)")
				issues_lost_retro_compatibility_final = "<ul>"
				if (issues_lost_retro_compatibility.size() > 0) {
					for (i = 0; i < issues_lost_retro_compatibility.size(); i++) {
						issueProperties = jiraLib.getJiraIssuesData('TT', "project = ConTTinuous and issuekey in (${issues_lost_retro_compatibility[i].toString()})")
						issues_lost_retro_compatibility_final += "<li>[<a href='\\''" + globalVariables.TrackRelease + issues_lost_retro_compatibility[i].toString() + "'\\'' class='\\''external-link'\\'' target='\\''_blank'\\''>" + issues_lost_retro_compatibility[i].toString() + "</a>] - " + issueProperties.toString().split('summary=')[1].split('customfield_')[0][0..-3] + "</li>" 
					}
				} else {
					issues_lost_retro_compatibility_final += "<p>No issues found</p>"
				}
				issues_lost_retro_compatibility_final += "</ul>"
				release_notes_content = '<h1>Release Notes for Jenkins Library</h1>' + release_notes + '<h1>Functions that lost retro-compatibility:</h1>' + issues_lost_retro_compatibility_final

				practical_documentation_content = "<h1>Practical Documentation for Jenkins Library</h1><a href='\\''https://sourcecode.socialcoding.bosch.com/projects/CONTTINUOUS/repos/jenkins_lib/browse/EXAMPLES.md?at=refs%2Ftags%2F" + pomVersion + "'\\'' class='\\''external-link'\\'' target='\\''_blank'\\''>Practical Documentation for Jenkins Library</a>"  

				technical_documentation_content = "<h1>Technical Documentation for Jenkins Library</h1><h2>Introduction</h2><a href='\\''https://sourcecode.socialcoding.bosch.com/projects/CONTTINUOUS/repos/jenkins_lib/browse/INTRO.md?at=refs%2Ftags%2F" + pomVersion + "'\\'' class='\\''external-link'\\'' target='\\''_blank'\\''>Introduction - Technical Documentation for Jenkins Library</a><h2>Modules</h2><a href='\\''http://sw-quality.bosch.com/conttinuous-docs/docs/" + pomVersion + "'\\'' class='\\''external-link'\\'' target='\\''_blank'\\''>Modules - Technical Documentation for Jenkins Library</a>" 

				content = release_notes_content + technical_documentation_content + practical_documentation_content

				confluenceLib.editDocupedia(globalVariables.ConfluenceURL, globalVariables.UserJenkins, globalVariables.ConfluenceAPIKey, "ConTTinuous Jenkins Library Documentation", 'BBTESY', "${pomVersion}", "$content")
			}

			stage('[Bitbucket] Add Git Tag') {
				withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: globalVariables.UserJenkins, usernameVariable: 'username', passwordVariable: 'password']]) {
					sh('git config user.email "User.TTSWEQ@bcn.bosch.com"')
					sh('git config user.name "TSW1AV"')
					sh("git tag -a ${pomVersion} -m " + '"tag auto generated"')
					script {
						env.encodedPass=URLEncoder.encode(password, "UTF-8")
					}
					sh("git push https://${username}:${encodedPass}@sourcecode.socialcoding.bosch.com/scm/conttinuous/jenkins_lib.git ${pomVersion}")
				}
			}
		}

	} catch (error) {

		throw error

	}
}

return this