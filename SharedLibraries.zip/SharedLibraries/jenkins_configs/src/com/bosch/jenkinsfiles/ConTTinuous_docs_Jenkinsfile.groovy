def jenkinsFileStart() {
	JenkinsLib = library('conTTinuous@JenkinsLib_v2.0.2')
    gitBitbucketLib = JenkinsLib.com.bosch.tt.GitBitbucket.new(this)
    dockerLib = JenkinsLib.com.bosch.tt.Docker.new(this)
	
	Global = library('conTTinuous_configs')
	globalVariables = Global.com.bosch.variables.GlobalVariables.new()
	
	try {

		stage('[Workspace] Initialize') {
			deleteDir()
		}
		
		stage('[Bitbucket] Checkout Latest Source Code') {
			gitBitbucketLib.checkoutByBranch("${env.BRANCH_NAME}",globalVariables.UserJenkins,
			globalVariables.BitbucketDocsRepo)
			def config = readJSON file: 'config.json'
			env.TAG = config['version']
            env.BRANCH_TO_DEPLOY = config['branchToDeploy']
			
			withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: globalVariables.UserJenkins, usernameVariable: 'username', passwordVariable: 'password']]) {
					sh "git tag -f ${env.TAG}"
					script {
						env.encodedPass=URLEncoder.encode(password, "UTF-8")
					}
					sh "git push -f https://${username}:${encodedPass}@sourcecode.socialcoding.bosch.com/scm/conttinuous/jenkins_docs.git ${env.BRANCH_NAME} ${env.TAG}"
				}
		}

		stage('[Artifactory] Build and Push') {
            def snapOrRelease = 'snapshot'
			if ("${env.BRANCH_NAME}" == "${env.BRANCH_TO_DEPLOY}") {
				snapOrRelease = 'release'
			}
			def imageName = 'conttinuous-docs'
			def repo = "tt-swq-docker-${snapOrRelease}-local.rb-artifactory.bosch.com/"

			dockerLib.dockerBuildPush("${repo}",globalVariables.UserJenkins, "${imageName}", "${env.TAG}", ' ', true)

			repo = 'localhost:5000'
			sh "docker build . -t ${repo}/${imageName}"
			sh "docker push ${repo}/${imageName}"
			sh "docker image prune -f"
			def imageId = sh(returnStdout: true, script: "docker images ${repo}/${imageName} -q").trim()
			sh "docker rmi -f ${imageId}"
		}

		stage('[k8s] Pull and Deploy') {
			if ("${env.BRANCH_NAME}" == "${env.BRANCH_TO_DEPLOY}") {
                withKubeConfig([credentialsId: globalVariables.UserK8s, serverUrl: 'https://10.58.112.221:6443']) {
                  sh 'kubectl apply -f full-deploy.yaml'
                  sh 'kubectl rollout restart deploy docs-deploy'
				}
            }
		}

	} catch (error) {

        throw error

    }
}

return this
