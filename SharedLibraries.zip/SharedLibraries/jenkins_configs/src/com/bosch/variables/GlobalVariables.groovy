package com.bosch.variables
import groovy.transform.Field;
@Field UserJenkins = 'd5884684-c624-40c9-9e11-76f76518043d'
@Field MavenSettings = '2aad9cea-2795-42b7-a536-d8152c064436'
@Field ConfluenceAPIKey = '02bea493-600c-433a-b1da-b013ea80dfcc'
@Field BitbucketLibRepo = 'https://sourcecode.socialcoding.bosch.com/scm/conttinuous/jenkins_lib.git'
@Field BitbucketDocsRepo = 'https://sourcecode.socialcoding.bosch.com/scm/conttinuous/jenkins_docs.git'
@Field TrackRelease = 'https://rb-tracker.bosch.com/tracker13/'
@Field ConfluenceURL = 'https://ews-esz-emea.api.bosch.com/knowledge/docupedia/v1.1'
@Field UserK8s = '72f66e62-356b-421f-b687-011c8f96d8db'
