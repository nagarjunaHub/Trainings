@Library('AE-BE_DevOps_SharedLibraries@release/latest_stable_release') _
AE_ContX_Library = library('AE_ContX_JenkinsLib')
import bosch.aebedo.ArtifactoryHelpers
import bosch.aebedo.RtcHelpers
import bosch.aebedo.JobHelpers
cicdStreamName = "rbd_${env.PROJECT.toLowerCase()}_${env.DOMAIN}_sw_" + "${env.MODULE}_${SHORT_DESC}_${WORKITEM_NUM}_${OWNER_NAME}"
node ('nbd5kor_slave-machine') {
    timestamps {
        try {
            stage ('Setup Environment') {
                cleanWs()
                envVariablesKeys = ["BASE_SNAPSHOT_NAME", "PROJECT",
                                    "DOMAIN", "MODULE",
                                    "SHORT_DESC", "WORKITEM_NUM", "OWNER_NAME", "rtcCredentials"]
                
                // Common error check for the environment variables
                envVariablesKeys.each { key ->
                    // Error check on the actual variables
                    if (!env[key]) {
                        error("Missing env variable ${key}")
                    }
                    else if (env[key].contains(' ')) {
                        error("${key} contains whitespace")
                    }
                }

                // Error check on the WORKITEM_NUM
                if (!env['WORKITEM_NUM'].isBigInteger()) {
                    error("WORKITEM_NUM should be an integer value")
                }

                // Error check on the SHORT_DESC
                shortDescLimit = 50
                if (env['SHORT_DESC'].length() > shortDescLimit) {
                    error("SHORT_DESC parameter is longer than ${shortDescLimit}")
                }
                env.stream = "${WORKITEM_NUM}_${SHORT_DESC}_${OWNER_NAME}"
                env.destination="${env.folderpath}${env.MODULE}"
                //currentBuild.displayName = "stream_creator_${BASE_SNAPSHOT_NAME}" + "_${WORKITEM_NUM}_${SHORT_DESC}_${OWNER_NAME}"
            }
            stage ('Create Stream') {
                // Create a repository workspace under the technical user being assigned
                println("creating ${cicdStreamName} from ${BASE_SNAPSHOT_NAME} in TA ${env.Team_Area}")
                List<String> rwsToCreate = ["${cicdStreamName}_cicd_BW", "${cicdStreamName}_cicd_tester_BW", "${cicdStreamName}_cicd_rebase_BW"]
                rtc = new RtcHelpers(this)
                //rtc.teamAreaSetup("${env.Team_Area}", cicdStreamName, BASE_SNAPSHOT_NAME, rwsToCreate)
                //rtc.teamAreaSetup('NE5 SW Build Tools', cicdStreamName, 'rbd_tools_Jenkins_Build_Scripts_001', rwsToCreate)
            }
            stage('Create Pipelines') {
				job_builder_yaml = readYaml file: "${env.jobCreatorYamlCfgLoc}"
                job_builder_yaml['defaults'].each { defaults ->
                    if (defaults != null) {
                        defaults.stream = "${WORKITEM_NUM}_${SHORT_DESC}_${OWNER_NAME}"
                        defaults.module = "${MODULE}"
                        defaults.destination = "${folderpath}/${Module}"
                        defaults.rtcCredentials = "${rtcCredentials}"
                        defaults.rtcStream = "${cicdStreamName}"
                        defaults.rtcWorkspace = "${rtcStream}"
                        defaults.projectArtCreds = "${artifactoryCredId}"
                        defaults.rtcDevStream = "rbd_${env.PROJECT.toLowerCase()}_${env.DOMAIN}_sw_dev"
                        defaults.rtcModuleDevBws = "${cicdStreamName}_cicd_BW"
                        defaults.rtcModulePR = "${cicdStreamName}_PR_BW"
                        defaults.rtcModulePrePR = "${cicdStreamName}_prePR_BW"
                        defaults.rtcModuleRebase = "${cicdStreamName}_rebase_BW"
                    }
                }
                
                // input will be job template, stream, rtcStream, MMChannel, destination, nightlyDisabled, weeklyDisabled
                job_builder_yaml['project'].each { project ->
                    if (project != null && project['name'] == "${PROJECT}_Configuration") {
                        echo "Test: ${project.name}"
                        project['jobs'] = ['{project}_full_tempStream_template':
                                            [ stream: "${WORKITEM_NUM}_${SHORT_DESC}_${OWNER_NAME}",
                                              rtcStream: "${cicdStreamName}",
                                              destination: "${folderpath}/${Module}",
                                              nightlyDisabled: true]]
                    }
                }
            }
            stage('Configure Jobs') {
                jobHelper = new JobHelpers(this, null, job_builder_yaml)
                jobHelper.setupJobHelpersEnv()
                jobHelper.executeJobCreator()
            }
            String jobSummary = 'Job Summary :\n'
            jobSummary += "Stream Created : ${cicdStreamName}\n"
            rwsToCreate.each { rws -> 
                jobSummary += "\tRWS Created : ${rws}\n"
            }
            jobSummary += "Stream Key : ${WORKITEM_NUM}_${SHORT_DESC}_${OWNER_NAME}\n"
            echo jobSummary
        } catch(e){
            throw e
            println "error caught"
            currentBuild.result = 'FAILURE'
        } 
    } 
    
}