// Input params for the pipeline
// --------- EDITABLE PARAMETERS :
// STREAM_NAME : REQUIRED PARAMETER | Temporary stream that has finished its delivery and wished to be cleanedup

@Library('AEBEDevops')
import bosch.aebedo.RtcHelpers
import bosch.aebedo.JobHelpers

import hudson.model.Hudson
import org.jenkinsci.plugins.workflow.job.WorkflowJob
import com.cloudbees.hudson.plugins.folder.Folder
import java.util.regex.Matcher

node('si-z667r_buildslaves') {
    timestamps {
        try {
            stage ('Setup Environment') {
                cleanWs()
                envVariablesKeys = ['STREAM_NAME', 'DOMAIN', 'targetStream',
                                    'PROJECT', 'rtcCredentials', 'componentFilter', 'MODULE']
                // Common error check for the environment variables
                envVariablesKeys.each { key ->
                    // Error check on the actual variables
                    if (!env[key]) {
                        error("Missing env variable ${key}")
                    } else if (env[key].contains(' ') && key != 'componentFilter') {
                        error("${key} contains whitespace")
                    }
                }
                currentBuild.displayName = "stream_teardown_${STREAM_NAME}"
                rtcWorkspace = "${env.rtcWorkspace}"
                rtc = new RtcHelpers(this)
                rtc.checkoutRtc(rtc.getBuildTypeWorkspaceMap("${env.rtcWorkspace}"))
                String job_builder_config = "${pwd()}\\JWS\\Tools\\CICD\\config\\" +
                                            "${env.DOMAIN.toLowerCase()}_${env.PROJECT.toLowerCase()}_job_builder.yml"
                pipelineConfig = readYaml file: "${job_builder_config}"
                pipelineConfig.defaults.first().permanentStream.each { streamName ->
                    if (streamName == env.STREAM_NAME) {
                        error("This stream is permanent cannot delete stream ${env.STREAM_NAME}")
                    }
                }
            }

            stage('Delete Jobs') {
                jobHelper = new JobHelpers(this)
                jobHelper.setupJobHelpersEnv()

                streamFolder = getstreamFolder(env.STREAM_NAME)
                String commonFolder = "${env.folderpath}/${env.MODULE}/${streamFolder}"
                // Retrive alias within the configuration which determine which job to be deleted given a job template
                pipelineConfig['job-group'].each { jobGroup ->
                    if (jobGroup != null && jobGroup.name == '{project}_full_tempStream_template') {
                        jobGroup.jobs.each { jobTemplate ->
                            jobTemplate.each { template, override ->
                                if (override != null && override.alias != null) {
                                   jobHelper.jobListToDelete.push("${commonFolder}/${env.PROJECT}_${env.MODULE}" +
                                                                  "_${streamFolder}_${override.alias}")
                                }
                            }
                        }
                    }
                }
                jobHelper.jobListToDelete.push(commonFolder)

                jobHelper.jobListToDelete.each { jobLocation ->
                    def singleItem = Jenkins.instance.getItemByFullName(jobLocation)
                    if (singleItem instanceof Folder) {
                        singleItem = null
                        jobHelper.execJJB('delete', jobLocation)
                    } else if (singleItem instanceof WorkflowJob) {
                        singleItem.disabled = true
                        if (singleItem.isBuilding()) {
                            error("${jobLocation} is still building make sure to wait till job is finished")
                        } else {
                            singleItem = null
                            jobHelper.execJJB('delete', jobLocation)                            
                        }
                    } else {
                        echo "${jobLocation} is already deleted"
                    }
                    singleItem = null
                }
            }

            stage ('Teardown Stream and Rws') {
                rwsToDelete = ["${env.STREAM_NAME}_cicd_BW",
                               "${env.STREAM_NAME}_cicd_tester_BW",
                               "${env.STREAM_NAME}_cicd_prePR_BW",
                               "${env.STREAM_NAME}_cicd_PR_BW",
                               "${env.STREAM_NAME}_cicd_rebase_BW"]
                targetStream = "${env.targetStream}_${env.MODULE}_dev"
                rtc.teamAreaTearDown("${env.Team_Area}", rwsToDelete, targetStream,
                                     env.STREAM_NAME, env.componentFilter, false, false, targetStream)
            }

            String jobSummary = 'Job Summary :\n'
            jobSummary += "Stream Deleted : ${env.STREAM_NAME}\n"
            rwsToDelete.each { rws -> 
                jobSummary += "\tRWS Deleted : ${rws}\n"
            }
            echo jobSummary

            env.EMAIL_SUBJECT = "Stream Deleted : ${env.STREAM_NAME}"

        } catch (e) {
            throw e
            currentBuild.result = 'FAILURE'
            echo e.toString()
            env.EMAIL_SUBJECT = 'Build failed, please check the console log'
        } finally {
            emailext attachLog: true, body: '${SCRIPT, template="pipeline.groovy"}',
                     recipientProviders: [[$class: 'RequesterRecipientProvider']],
                     subject: env.EMAIL_SUBJECT
        }
    }
}

@NonCPS
def getstreamFolder(fullStreamName) {
    // Validate version matches specification
    Matcher matcher = fullStreamName =~ /rbd_${env.DOMAIN.toLowerCase()}/ + 
                                      /_${env.PROJECT}/ +
                                      /_sw_${env.MODULE}/ +
                                      /_(?<shortStreamName>\w+)/
    if (!matcher) {
        error("${fullStreamName} is an invalid stream to be deleted")
    }
    // Extract parameters from version prop
    matcher.matches()
    return matcher.group('shortStreamName')
}