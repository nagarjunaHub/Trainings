def call(def myparams=[:]) {
	def build = myparams.get('jobName', env.JOB_NAME)
	usage = null
	build.getTransientActions().each { action ->
		if (action instanceof BuildDiskUsageAction) {
		  // println action.buildUsageString
		  // println action.allDiskUsage
		  usage = action
		}
	}
	return usage
}