def call(def myparams=[:]) {
	/*This script shows how to get basic information about a job and its builds*/
	def jenkins = Jenkins.getInstance()
	def jobName = myparams.get('jobName', env.JOB_NAME)
	def job = jenkins.getItem(jobName)
	return job
}
