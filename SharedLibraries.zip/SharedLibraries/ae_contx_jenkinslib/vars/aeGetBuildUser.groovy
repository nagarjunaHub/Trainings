def call() {
	/*This script gets the current build trigger userid*/

	return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}
