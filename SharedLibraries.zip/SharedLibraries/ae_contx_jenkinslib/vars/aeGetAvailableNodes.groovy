def call() {
  def nodes = []
  jenkins.model.Jenkins.instance.computers.each { c ->
      nodes.add(c.node.selfLabel.name)
  }
  return nodes
}