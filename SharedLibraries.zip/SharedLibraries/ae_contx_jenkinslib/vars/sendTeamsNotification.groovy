def call(def myparams=[:]) {
	defaultWebhook = 'https://bosch.webhook.office.com/webhookb2/175c1596-b778-4c9e-8498-fc0b4e4fdc7e@0ae51e19-07c8-4e4b-bb6d-648ee58410f4/JenkinsCI/13982c12b3c4479ba6fb4ca3e7e1aaca/c409fce6-f49c-442c-beb3-527fda7f0489'
	def myWebhookUrl = myparams.get('webhookUrl', defaultWebhook)
	def myMessage = myparams.get('message', "Build result for ${env.JOB_NAME} ${env.BUILD_NUMBER} (<${env.BUILD_URL}|Open>)")
	def myStatus = myparams.get('status','')
	def myColor = myparams.get('color', '0000ff')
	office365ConnectorSend color: myColor, message: myMessage, status: myStatus, webhookUrl: myWebhookUrl
}