#! /usr/bin/env groovy
/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch

import java.time.Instant
import java.time.ZoneId
import com.cloudbees.groovy.cps.NonCPS
import org.codehaus.groovy.control.ConfigurationException
import groovy.json.JsonSlurperClassic
import java.io.File
/**
 * Library to aid common pipeline operations relating to Cubas Software Build (CDGB).<br/>
 */
class AE_CdgbHelpers {
    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null

    /**
     * Constructor for the AE_CdgbHelpers class.
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     * (aka WorkflowScript) in which context the code is executed.
     */
    AE_CdgbHelpers(Object jenkins) {
        this.jenkins = jenkins
	}

    /**
     * setup the Build environment by installing the required CDGB and AEEE-Pro versions if missing from the jenkins instance.
     * @param cdgbVersion String representing the CDGB or AEEE-Pro version to be used for the build process
     */
	 
	void setupCdgbHelpersEnv(String cdgbVersion='2018.2.1') {
        this.jenkins.bat "tini -useEnv:cdg.de cdgb ${cdgbVersion}"
    }
	
	/**
     * Rebuild the project by cleaning previously generated build artifacts
     * The files present in _log, _gen, _out folders will be deleted and regenrated during the build
     */
	void cleanBuild(String aeee_path, String buildVaraint, String prj_root) {
		this.jenkins.bat "cd ${prj_root}"
        this.jenkins.bat "texec ${aeee_path} -cdgb rebuild -m ${buildVaraint} -p ${prj_root}"
    }
	
	/**
     * build the project by executing the build actions only for the modified source files.
     * This function is only recommended for onComming and nightly pipelines. It must not be used for release pipelines
     */
	void incrementalBuild(String aeee_path, String buildVaraint, String prj_root) {
		this.jenkins.bat "cd ${prj_root}"
        this.jenkins.bat "texec ${aeee_path} -cdgb build -m ${buildVaraint} -p ${prj_root}"
    }
	
	/** Create a zip file with all the artifiacts specified through parameters
	 * prjPath: Path to project root directory
	 * regex: Regular expression for collecting the required files from prjPath
	 * outFile: output file (zip) name
	*/
	void buildArtifactsZip(String prjPath, String regex, String outFile) {
		this.jenkins.zip (zipFile: "${outFile}${this.jenkins.env.BUILD_NUMBER}.zip", archive: true, dir: prjPath, glob: regex)
	}
}	
