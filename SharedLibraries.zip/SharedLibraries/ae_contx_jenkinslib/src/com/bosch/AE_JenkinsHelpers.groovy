#! /usr/bin/env groovy
/**
 * Copyright (C) 2019, 2019 Robert Bosch GmbH and its subsidiaries.
 * This program and the accompanying materials are made available under
 * the terms of the Bosch Internal Open Source License v4
 * which accompanies this distribution, and is available at
 * http://bios.intranet.bosch.com/bioslv4.txt
 */
package com.bosch

import java.time.Instant
import java.time.ZoneId
import com.cloudbees.groovy.cps.NonCPS
import org.codehaus.groovy.control.ConfigurationException
import groovy.json.JsonSlurperClassic
import java.io.File
import jenkins.model.*
import groovy.time.TimeCategory;
/**
 * Library to aid common pipeline operations relating to Jenkins.<br/>
 */
class AE_JenkinsHelpers {
    /** Jenkinsfile instance. Passed to the constructor.*/
    Object jenkins = null
    /**
     * Constructor for the AE_CdgbHelpers class.
     * @param jenkins The class needs an instance of the actual Jenkinsfile
     * (aka WorkflowScript) in which context the code is executed.
     */
	 def steps
    AE_JenkinsHelpers(steps) {
        this.steps = steps
	}

    /**
     * setup the Build environment by installing the required CDGB and AEEE-Pro versions if missing from the jenkins instance.
     * @param cdgbVersion String representing the CDGB or AEEE-Pro version to be used for the build process
     */
	 
	void getBuildInfo(String buildNumber) {
        this.jenkins.bat "tini -useEnv:cdg.de cdgb ${cdgbVersion}"
    }
	
	/**
     * Rebuild the project by cleaning previously generated build artifacts
     * The files present in _log, _gen, _out folders will be deleted and regenrated during the build
     */
	void cleanWorkspace() {
		this.jenkins.clenWs()
    }
	
	/**
     * build the project by executing the build actions only for the modified source files.
     * This function is only recommended for onComming and nightly pipelines. It must not be used for release pipelines
     */
	void copyArtifacts(String sourceJob, String destJob) {
		this.jenkins.bat "cd ${prj_root}"
        this.jenkins.bat "texec ${aeee_path} -cdgb build -m ${buildVaraint} -p ${prj_root}"
    }

	void buildJob(String jobName) {
		//this.jenkins.zip (zipFile: "${outFile}${this.jenkins.env.BUILD_NUMBER}.zip", archive: true, dir: prjPath, glob: regex)
	}
	
	List<String> allocateNode(String nodeName) {
		List<String> nodes = []
		def jenkins = Jenkins.instance
		def computers = jenkins.computers
		println "listing nodes"
		computers.each{ 
		  println "${it.displayName} ${it.hostName}"
		  nodes.add("${it.displayName}")
		}
		return nodes
	}	
	
	List<String> getAllJobs() {
		println "inside getAllJobs"
		List<String> jobNames = []
		def jenkins = Jenkins.instance 
		jenkins.getAllItems().each {it ->
			println it.fullName
			jobNames.add(it.fullName)
		}
		return jobNames
		/** def buildingJobs = Jenkins.instance.getAllItems(Job.class).findAll { 
		*it.isBuilding() }
		*return buildingJobs
		**/
	}
	void allocateWorkspace(String workspace) {
		this.jenkins.zip (zipFile: "${outFile}${this.jenkins.env.BUILD_NUMBER}.zip", archive: true, dir: prjPath, glob: regex)
	}
	
	/** LastBuildStatus retruns the jenkins job's last build status.
	* @param jobName: the job name for which its last build status to be checked 
	* This functions returns the following string values 
	* 'null' -> if the last build was aborted or no previous builds exists 
	* 'BUILDING' -> if the job is currently executing
	* 'QUEUE' -> if the job is currently in queue
	* 'SUCCESS' -> if the last build was Successful
	* 'FAILURE' -> if the last build was Failed */
	String LastBuildStatus(String jobName) {
		def job = Jenkins.instance.getItemByFullName(jobName)
		if(job !=null) {
			def numbuilds = job.builds.size()
			if (numbuilds == 0) {
				println '  -> no build'
				return
			}
			if(job.isBuilding()) {
				return 'BUILDING'
			}
			else if(job.isInQueue()) {
				return 'QUEUE'
			}
			else {
				def lastbuild = job.getLastBuild()
				return lastbuild.result 
			}
		}
	}
	
	/** MonitorJobs retruns the list of Jenkins jobs with a specified no.of previous continuous builds were failed.
	* @param buildsToCheck: Number of builds to check for continuous failure
	* This function returns a list of jenkins jobs with all previous buildsToCheck builds are failed 
	* Note: this function returns a list with jobs objects not just the job name.
	*/
	List<String> MonitorJobs(int buildsToCheck=5) {
		List<String> JobsToReport = [] 
		def jobs = Jenkins.instance.getAllItems()
		jobs.each { job -> 
			def status = 0
			if (job instanceof com.cloudbees.hudson.plugins.folder.Folder) { return }
			def numbuilds = job.builds.size()
			if(numbuilds > buildsToCheck){
				def lastbuildNumber = job.getLastBuild().getNumber()
				for(int i = 0; i<buildsToCheck; i++) {
					def lastbuild = job.getBuildByNumber(lastbuildNumber - i)
					if(lastbuild != null) {
						/** Using println statements within shared library */
						/** steps.println "checking ${job} with buildnumber ${lastbuildNumber-i}:${lastbuild}: ${lastbuild.getTime()}" */
						if(lastbuild.result.toString() != 'FAILURE') {
							status = 1
						} 
					}
				}
				if(status == 0) {
					JobsToReport.add(job)
				
				}
			}
		}
		return JobsToReport
	}

	/** getInactiveJobs retruns all the Jenkins jobs/pipelines which are not being used from a give time duration.
	* @param duration: to search for all the jobs that are not executed from given number of days 
	* default value for duration will be 180 days 
	* This functions returns a list of strings with all the jobnames which are not executed from the specified duration */
	List<String> getInactiveJobs(int duration = 180) {
		List<String> inactiveJobs = [] 
		def CurrentDate = new Date()
		def jobs = Jenkins.instance.getAllItems()
		jobs.each { job -> 
			if (job instanceof com.cloudbees.hudson.plugins.folder.Folder) { return }
			def numbuilds = job.builds.size()
			if(numbuilds == 0){
				return
			}
			/** def lastbuild = job.builds[numbuilds - 1] */
			def lastbuild = job.getLastBuild()
			def TimeDiff = CurrentDate - lastbuild.timestamp.getTime()
			if(TimeDiff > duration) {
				inactiveJobs.add(job.fullName)
			}
		}
		return inactiveJobs
	}
}	
