#include<stdio.h>
void minimumBribes(int q_count, int* q) {
    int bribes = 0;
    for(int i=q_count-1;i>=0;i--) {
        if(q[i] != i+1){
            if(q[i-1] == i+1) {
                bribes+=1;
            }
            else if (q[i-2] == i+1) {
                bribes+=2;
            }
            else {
                printf("Too chaotic");
                return;
            }

        }

    }
    printf("%d\n",bribes);
}
int main() {
	int q[8] = {1,2,5,3,7,8,6,4};
	int n = sizeof(q)/sizeof(q[0]);
	printf("ary size is: %d\n",n);
	minimumBribes(n,q);
}