#include<stdio.h>
void swap(int* ary, int x, int y) {
    int tmp = 0;
    tmp = ary[x];
    ary[x] = ary[y];
    ary[y] = tmp;
}
// Complete the minimumSwaps function below.
int minimumSwaps(int arr_count, int* arr) {
    int swaps = 0,iter = 0;
	printf("before swap\n");
	for(int x=0;x<arr_count;x++) {
		printf("%d\t",arr[x]);
	}
	printf("\n");
    while(iter < arr_count-1){
		printf("iter:%d\n",iter);
        for(int i = 0;i<arr_count-iter-1;i++) {
			printf("i:%d\n",i);
            if(arr[i] == arr_count-iter) {
				printf("swapping index %d:%d and index%d:%d indeces\n",i,arr[i],arr_count-iter-1,arr[arr_count-iter-1]);
                swap(arr, i,arr_count-iter-1);
				for(int x=0;x<arr_count;x++) {
					printf("%d\t",arr[x]);
				}
				printf("\n");
                swaps+=1;
            }
        }
        iter++;
    }
    return swaps;

}
int main() {
	int size = 5;
	int ary[5] = {2,3,4,1,5};
	int minSwaps = minimumSwaps(size,ary);
	printf("min possible swaps %d",minSwaps);
}