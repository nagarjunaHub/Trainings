#include<stdio.h>
const int r = 6;
const int c = 6;
int hourglassSum(int row, int col, int array[r][c]) {
	int res_ary[(r-2)*(c-2)];
	int index = 0;
	for(int i = 0;i<row-2;i++) {
		for(int j = 0;j<col-2;j++) {
			//printf("%d\n",array[i][j]+array[i][j+1]+array[i][j+2]+array[i+1][j+1]+array[i+2][j]+array[i+2][j+1]+array[i+2][j+2]);
			res_ary[index] = array[i][j]+array[i][j+1]+array[i][j+2]+array[i+1][j+1]+array[i+2][j]+array[i+2][j+1]+array[i+2][j+2];
			index = index + 1;
		}
	}
	int result = res_ary[0];
	for (int i=1;i<(r-2)*(c-2);i++) {
		if(res_ary[i]>result) {
			result = res_ary[i];
		}
	}
	return result;
}

int main() {
	int n=6,m=6;
	// int arr[6][6] = {{1,1,1,0,0,0},{0,1,0,0,0,0},{1,1,1,0,0,0},{0,0,2,4,4,0},{0,0,0,2,0,0},{0,0,1,2,4,0}};
	int arr[6][6] = {{-9,-9,-9,1,1,1},{0,-9,0,4,3,2},{-9,-9,-9,1,2,3},{0,0,8,6,6,0},{0,0,0,-2,0,0},{0,0,1,2,4,0}};
	int result = hourglassSum(n,m,arr);
	printf("%d\n",result);
}