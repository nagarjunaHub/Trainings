#include<stdio.h>
#include<stdbool.h>
bool isPrime(int num) {
	if(num==1) {
		printf("%d is nither prime nor composite",num);
		return false;
	}
	else {
		for(int i=2;i<=num/2;i++) {
			if(num%i==0) {
				return false;
			}
		}
		return true;
	}
}

bool isEven(int num) {
	if(num%2 == 0) {
		return true;
	}
	return false;
}
void printFibonacci(int num) {
	int i=0,j=1,nextNum;
	if(num<2){
		printf("enter conrrect number\n");
	}
	else{
		printf("fibonacci series is: ");
		for(int temp=1;temp<=num;temp++) {
			printf("%d",i);
			nextNum = i+j;
			i=j;
			j=nextNum;
		}
		printf("\n");
	}
}

void printFactorial(int num) {
	int i,fact=1;
	for (i=num;i>=1;i--) {
		fact=fact*i;
	}
	printf("Factorial value is %d:\n",fact);
}

int main(){
	int n;
	printf("enter a number:");
	scanf("%d",&n);
	printf("Prime: %d\tEven: %d\n",isPrime(n),isEven(n));
	printFibonacci(n);
	printFactorial(n);
}

