def fibonacci(n):
	i,j=0,1
	num = 0
	while(num <n):
		yield i
		i, j = j, i + j
		num += 1

fs = fibonacci(8)
for i in fs:
	print(i)
