from random import random
print(random())