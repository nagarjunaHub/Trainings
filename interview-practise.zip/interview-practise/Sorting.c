#include <stdio.h>
#include <time.h>
void swap(int *p,int *q) {
	int tmp = *p;
	*p=*q;
	*q=tmp;
}

void printAry(char *s,int ary[],int size) {
	printf("%s:",s);
	for (int i=0;i<size;i++) {
		printf("%d ",ary[i]);
	}
	printf("\n");
}

void selectionSort(int ary[], int n) {
	for(int i=0;i<n-1;i++) {
		int tmp_index = i;
		for(int j=i+1;j<n;j++) {
			if(ary[j]<ary[tmp_index]) {
				tmp_index = j;
			}
		}
		swap(&ary[i],&ary[tmp_index]);
	}
}
void bubbleSort(int ary[], int n) {
	for(int i=0;i<n-1;i++) {
		for(int j=0;j<n-i-1;j++) {
			if(ary[j]>ary[j+1]) {
				swap(&ary[j],&ary[j+1]);
			}
		}
	}
}

void merge(int ary[],int l,int m,int r) {
	int laSize = m-l+1;
	int raSize = r-m;
	int LA[laSize],RA[raSize];
	for (int i = 0;i<laSize;i++) {
		LA[i] = ary[l+i];
	}
	for (int i = 0;i<raSize;i++) {
		RA[i] = ary[m+1+i];
	}
	int i=0,j=0,k=l;
	while(i<laSize && j<raSize) {
		if(LA[i]<=RA[j]){
			ary[k] = LA[i];
			i++;
		}
		else {
			ary[k] = RA[j];
			j++;
		}
		k++;
	}
	while(i<laSize) {
		ary[k] = LA[i];
		i++;
		k++;
	}
	while(j<raSize) {
		ary[k] = RA[j];
		j++;
		k++;
	}
}
void mergeSort(int ary[],int l,int r){
	if(l<r) {
		int m = (l+r)/2;
		mergeSort(ary, l, m);
		mergeSort(ary, m+1, r);
		merge(ary, l, m, r);
	}
}

int partition(int ary2[], int l, int r){
	int pivot = ary2[r];
	int i = (l-1);
	for(int j = l;j<=r-1;j++) {
		if(ary2[j]<pivot) {
			i++;
			swap(&ary2[i],&ary2[j]);
		}
	}
	swap(&ary2[i+1],&ary2[r]);
	// printAry("quickSort",ary,r-l);
	return i+1;
}
void quickSort(int ary1[],int l,int r) { 
	if(l<r) {
		int pi = partition(ary1,l,r);
		// printf("%d\n",pi);
		quickSort(ary1,l,pi-1);
		quickSort(ary1,pi+1,r);
	}
	
}


int main() {
	// clock_t t,t1,t2;
	int array[] = {10,15,12,8,17,22,6,18,9};
	int size = sizeof(array)/sizeof(array[0]);
	// printf("array size: %d",size);
	// t1 = clock();
	selectionSort(array, size);
	// t2 = clock()-t1;
	// double time_taken = ((double)t2)/CLOCKS_PER_SEC;
	// printf("selectionSort() took %f seconds to execute \n", time_taken);
	printAry("selectionSort",array,size);

	bubbleSort(array, size);
	printAry("bubbleSort",array,size);
	mergeSort(array,0,size-1);
	printAry("mergeSort",array,size);
	quickSort(array,0,size-1);
	printAry("quickSort",array,size);
}