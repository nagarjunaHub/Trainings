#include<stdio.h>
#include<stdlib.h>

int* LShift(int a_count, int* a, int d, int* result_count){
	for (int lshift = 0; lshift<d;lshift++) {
		for(int i = 0;i<a_count-1;i++) {
			printf("%d\t",a[i]);
			printf("\n");
			printf("shifting %d and %d for index %d\n",a[i],a[i+1],i);
			int tmp = a[i];
			a[i]=a[i+1];
			a[i+1] = tmp;
		}
		
	}
	*result_count = a_count;
	return a;
}

int main() {
	int a_count = 5;
	int *a = malloc(a_count*sizeof(int));
	int d = 3;
	for (int i = 0;i<a_count;i++) {
		a[i] = i+1;
	}
	int result_count;
	int* result = LShift(a_count, a, 3, &result_count);
	printf("result_count: %d\n",result_count);
	for(int i = 0;i<result_count;i++) {
		printf("%d\t",result[i]);
	}
}