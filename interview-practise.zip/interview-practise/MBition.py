import os
baseFilename = "basefilename.txt"
c_list = "c_"+baseFilename
cpp_list = "cpp_"+baseFilename
cs_list = "cs_"+baseFilename
c_handler = open(c_list,"w")
cpp_handler = open(cpp_list,"w")
cs_handler = open(cs_list,"w")
base_handler = open(baseFilename)
# files_list=base_handler.read().replace('\n','')
files_list = base_handler.readlines()
for line in files_list:
    # print("before split:%s:"%line)
    tmpline = line.rstrip('\n')
    # print("after split:%s:"%line)    
    name, extension = tmpline.split('.')
    if(extension == 'cpp'):
        print("%s is cpp file"%tmpline)
        cpp_handler.write(line)
    elif(extension == 'cs'):
        print("%s is cs file"%tmpline)
        cs_handler.write(line)        
    elif(extension == 'c'):
        print("%s is c file"%tmpline)        
        c_handler.write(line)        
c_handler.close()
cpp_handler.close()
cs_handler.close()
base_handler.close()


