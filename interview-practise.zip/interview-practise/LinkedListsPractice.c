#include<stdio.h>
#include<stdlib.h>
void DisplayOptions();
void AddStart(int nodeValue);
void AddMiddle(int pos, int nodeValue);
void AddEnd(int nodeValue);
void DelStart();
void DelMiddle(int pos);
void DelEnd();
void DisplayList();
int getLength();

struct Node {
	int data;
	struct Node *next;
}*head = NULL;

int main() {
	int choice;
	while(1) {
		int nodeValue = 0, pos = 0;
		DisplayOptions();
		printf("What do you want to do?\n");
		scanf("%d",&choice);
		switch(choice) {
			case 1:
				printf("Enter node value\n");
				scanf("%d",&nodeValue);
				AddStart(nodeValue);
				break;
			case 2:
				printf("Enter node Position\n");
				scanf("%d",&pos);			
				printf("Enter node value\n");
				scanf("%d",&nodeValue);				
				AddMiddle(pos,nodeValue);
				break;
			case 3:
				printf("Enter node value\n");
				scanf("%d",&nodeValue);
				AddEnd(nodeValue);
				break;
			case 4:
				DelStart();
				break;
			case 5:
				printf("Enter Node Position\n");
				scanf("%d",&pos);			
				DelMiddle(pos);
				break;
			case 6:
				DelEnd();
				break;
			case 7:
				DisplayList();
				break;
			case 8:
				return 0;
			default:
				printf("please choose correct option\n");
				break;
		}
	}
}

void DisplayOptions() {
	printf("1. Add Element at beginning\n");
	printf("2. Add Element at Middle\n");
	printf("3. Add Element at End\n");
	printf("4. Delete Element at beginning\n");
	printf("5. Delete Element at Middle\n");
	printf("6. Delete Element at End\n");
	printf("7. Display List\n");
	printf("8. Exit\n");
}

void AddStart(int nodeValue) {
	struct Node *tmpNode = malloc(sizeof(struct Node));
	tmpNode->data = nodeValue;
	if(head == NULL) {
		tmpNode->next = NULL;
	}
	else {
		tmpNode->next = head;
	}
	head = tmpNode;
	DisplayList();
}

void AddMiddle(int pos, int nodeValue){
	if(head == NULL) {
		printf("List is empty. adding element at start position\n");
		AddStart(nodeValue);	
		return;
	}
	int Listlength = getLength();
	if(Listlength<=pos) {
		printf("List contains only %d elements. adding element at the end\n",Listlength);
		AddEnd(nodeValue);
		return;
	}
	else{
		struct Node *p = head;
		struct Node *tmpNode = malloc(sizeof(struct Node));
		int i = 0;
		tmpNode->data = nodeValue;
		while(i<pos) {
			p = p->next;
			i++;
		}
		tmpNode->next = p->next;
		p->next = tmpNode;
		DisplayList();
	}
	
}
void AddEnd(int nodeValue){
	if(head == NULL) {
		printf("List is empty. adding element at the beginning\n");
		AddStart(nodeValue);
	}
	else {
		struct Node *p = head;
		struct Node *tmpNode = malloc(sizeof(struct Node));
		tmpNode->data = nodeValue;
		tmpNode->next = NULL;
		while(p->next != NULL) {
			p = p->next;
		}
		p->next = tmpNode;
		DisplayList();
	}
	
}
void DelStart(){
	struct Node *p = head;
	if(head == NULL) {
		printf("nothing to delete. Please add elements to list\n");
	}
	else {
		head = p->next;
		free(p);
	}
	DisplayList();
	
}
void DelMiddle(int pos){
	if(head == NULL) {
		printf("nothing to delete. Please add elements to list\n");
	}
	else {
		int Listlength = getLength();
		if(Listlength <= pos) {
			printf("List only contains %d elements. deleting the last element\n");
			DelEnd();
		}
		else {
			struct Node *p=head,*q;
			int index = 0;
			while (index < pos) {
				p = p->next;
				index++;
			}
			q = p->next;
			p->next = q->next;
			free(q);
		}
		DisplayList();
	}
}
void DelEnd(){
	if(head == NULL) {
		printf("nothing to delete. Please add elements to list\n");
	}
	else {
		struct Node *p=head,*q;
		while(p->next->next != NULL) {
			p = p->next;
		}
		q = p->next;
		p->next = NULL;
		free(q);
	}
	DisplayList();
}
void DisplayList() {
	system("cls");
	if(head == NULL) {
		printf("List is Empty. Please add some elements\n");
		return;
	}
	printf("List contains %d elements\n",getLength());
	struct Node *tmpNode = head;
	while(tmpNode != NULL) {
		printf("%d\t",tmpNode->data);
		tmpNode = tmpNode->next;
	}
	printf("\n\n");
}

int getLength() {
	struct Node *p = head;
	int length = 0;
	while(p != NULL) {
		p = p->next;
		length+=1;
	}
	return length;
}