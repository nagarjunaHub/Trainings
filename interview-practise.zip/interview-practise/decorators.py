def do_twice(func):
    ''' The special syntax *args in function definitions is used to pass a variable number of arguments to a function. It is used to pass a non-key worded, varaible-length argument list.
    The special syntax **kwargs in function definitions is used to pass a keyworded, variable-length arguments list. '''
    def wrapper(*args, **kwargs):
        print("before calling")
        func(*args, **kwargs)
        func(*args, **kwargs)
        print("after calling")
    return wrapper
