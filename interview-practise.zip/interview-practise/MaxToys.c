int partition(int ary2[], int l, int r){
	int pivot = ary2[r];
	int i = (l-1);
	for(int j = l;j<=r-1;j++) {
		if(ary2[j]<pivot) {
			i++;
			swap(&ary2[i],&ary2[j]);
		}
	}
	swap(&ary2[i+1],&ary2[r]);
	// printAry("quickSort",ary,r-l);
	return i+1;
}
void quickSort(int ary1[],int l,int r) { 
	if(l<r) {
		int pi = partition(ary1,l,r);
		// printf("%d\n",pi);
		quickSort(ary1,l,pi-1);
		quickSort(ary1,pi+1,r);
	}
	
}

int main() {

}