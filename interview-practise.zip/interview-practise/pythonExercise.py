##################################### Passing function as param ##########################
# def say_hello(name):
    # return f"Hello {name}"
# def say_goodbye(name):
    # return f"Goodbye {name}"
# def greet_naga(function):
    # return function("naga")
    
# print(greet_naga(say_hello))
# print(greet_naga(say_goodbye))
##########################################################################################

####################################### Inner functions ###############################
# def parent():
    # print("in parent")
    # def child1():
        # print("in child1")
    # def child2():
        # print("in child2")
    # child2()
    # child1()

# parent()
##########################################################################################

##################################### Return function from function ######################
# def parent(num):
    # def first_child():
        # print("Hello, I am child1")
    # def second_child():
        # print("Hello, I am child2")
    # if(num == 1):
        # return first_child
    # else:
        # return second_child
# first = parent(1)
# second = parent(2)
# print(first)
# print(second)
# print(first())
# print(second())
##########################################################################################

##################################### Decorators1 #########################################
# def my_decorator(func):
    # def wrapper():
        # print("something is happening before calling the func")
        # func()
        # print("something is happening after calling the func")
    # return wrapper
    
# @my_decorator
# def say_hello():
    # print("Hello, Naga")

# say_hello()
##########################################################################################

##################################### Reusing Decorators #################################
# from decorators import do_twice # A module created in same folder as pythonExercise.py
# @do_twice
# def say_hello():
    # print("Hello, Naga")

# say_hello()
##########################################################################################

##################################### Decorators arguments ###############################
# from decorators import do_twice # A module created is same folder as pythonExercise.py
# @do_twice
# def say_hello(name):
    # print(f"Hello, {name}")

# say_hello("Naga")
##########################################################################################

##################################### Return from Decorators #############################
# import functools
# def decorator(func):
    # @functools.wraps(func)
    # def wrapper(*args, **kwargs):
        # value = func(*args, **kwargs)
        # return value
    # return wrapper

# def say_hello(name):
    # print(f"hello {name}")
# hi_naga = say_hello("Naga")
# print(hi_naga)
##########################################################################################

##################################### lambda #############################################
# sum = lambda a, b : a + b
# print(sum(2,3))

# (lambda x, y, z: x + y + z)(1, 2, 3)
# (lambda x, y, z=3: x + y + z)(1, 2)
# (lambda x, y, z=3: x + y + z)(1, y=2)
# (lambda *args: sum(args))(1,2,3)
# (lambda **kwargs: sum(kwargs.values()))(one=1, two=2, three=3)
# (lambda x, *, y=0, z=0: x + y + z)(1, y=2, z=3)
##########################################################################################

##################################### single linked list #############################################
class Node:
    def __init__(self, data=None):
        self.data = data
        self.next = None
class SingleLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.count = 0
    def append_item(self, data):
        node = Node(data)
        if self.tail:
            self.tail.next =  node
            self.tail = node
        else:
            self.head = node
            self.tail = node
        self.count += 1
    def search_item(self, val):
        for node in self.display_items():
            if val == node:
                return True
        return False
    def display_items(self):
        current_item = self.head
        while current_item:
            val = current_item.data
            current_item = current_item.next
            yield val
    def modify_index(self, index, value):
        if index > self.count - 1:
            raise Exception("Index out of range")
        current = self.head
        for i in range(index):
            current = current.next
        current.data = value
    def modify_value(self, value, newValue):
        current = self.head
        if current.data == value:
            current.data = newValue
            return True
        current = current.next
            

linked_list = SingleLinkedList()
linked_list.append_item('Chinna')          
linked_list.append_item('Ramana')          
linked_list.append_item('Krishna')          
linked_list.append_item('Sudha')          
linked_list.append_item('Naga')          
linked_list.append_item('Aruna')          

for val in linked_list.display_items():
    print(val)

print("head.data",linked_list.head.data)    
print("tail.data",linked_list.tail.data)    

# print("searching Naga:",linked_list.search_item('Nagar'))

linked_list.modify_index(4, "Nagarjuna")
linked_list.modify_index(5, "Anu Radha")
for val in linked_list.display_items():
    print(val)
    
linked_list.modify_value("Krishna", "Venkata Krishna")
for val in linked_list.display_items():
    print(val)
##########################################################################################

##################################### single linked list #############################################