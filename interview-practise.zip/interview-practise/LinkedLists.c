#include<stdio.h>
#include <stdlib.h>
void addBeginning();
void addMiddle();
void addEnd();
void deleteBeginning();
void deleteMiddle();
void deleteEnd();
void DisplayList();
void displayOptions();
int getListLength();
struct node {
	int data;
	struct node *next;
}*head=NULL;
int main() {
	int choice;
	while(1) {
		displayOptions();
		scanf("%d",&choice);
		switch(choice){
			case 1: 
				addBeginning();
				break;
			case 2: 
				addMiddle();
				break;
			case 3: 
				addEnd();
				break;
			case 4: 
				deleteBeginning();
				break;
			case 5:
				deleteMiddle();
				break;
			case 6:
				deleteEnd();
				break;
			case 7:
				DisplayList();
				break;
			case 8:
				return 0;
			defalut:
				printf("please select correct option\n");
				break;
		}
	}
	return 0;
}

void displayOptions() {
	printf("Select an option:\n");
	printf("1. Add at beginning\n");
	printf("2. Add at middle\n");
	printf("3. Add at End\n");
	printf("4. Remove at beginning\n");
	printf("5. Delete Middle\n");
	printf("6. Delete End\n");
	printf("7. Display list\n");
	printf("8. Exit\n");
}
void addBeginning() {
	struct node *tmpNode = malloc(sizeof(struct node));
	printf("Enter node value\n");
	scanf("%d",&tmpNode->data);
	if(head == NULL) {
		tmpNode->next = NULL;
		head = tmpNode;
	}
	else {
		tmpNode->next=head;
		head=tmpNode;
	}
	DisplayList();
}
void addMiddle() {
	struct node *tmpNode = malloc(sizeof(struct node));
	struct node *p;
	int pos;
	printf("add node value to add at the middle:\n");
	scanf("%d",&tmpNode->data);
	printf("enter position to add the node\n");
	scanf("%d",&pos);
	// int length = getListLength();
	int i=1;
	p=head;
	while(i<pos){
		p=p->next;
		i++;
	}
	tmpNode->next = p->next;
	p->next = tmpNode;
	DisplayList();
}
void addEnd() {
	struct node *tmpNode = malloc(sizeof(struct node));
	struct node *p;
	p = head;
	printf("enter value to append at end\n");
	scanf("%d",&tmpNode->data);
	while(p->next != NULL) {
		p=p->next;
	}
	tmpNode->next = NULL;
	p->next=tmpNode;
	DisplayList();
}
void deleteBeginning() {
	if(head == NULL){
		printf("Empty list. Nothing to delete\n");
		return;
	}
	else{
		struct node *p = head;
		head = head->next;
		printf("deleted node:%d\n",p->data);
		free(p);
	}
	DisplayList();
}
void deleteMiddle() {
	if(head == NULL){
		printf("Empty list. Nothing to delete\n");
		return;
	}
	else{
		struct node *p = head;
		int pos,i=1;
		printf("enter node number to delete\n");
		scanf("%d",&pos);
		while(i<=pos-1) {
			p=p->next;
			i++;
		}
		struct node *q = p->next;
		p->next = q->next;
		printf("deleted node:%d\n",q->data);
		free(q);
	}
	DisplayList();
}
void deleteEnd() {
	if(head == NULL){
		printf("Empty list. Nothing to delete\n");
		return;
	}
	else{
		struct node *p = head;
		while(p->next->next != NULL){
			p=p->next;
		}
		struct node *q=p->next;
		p->next = NULL;
		printf("deleted node:%d\n",q->data);
		free(q);
		DisplayList();
	}
}
void DisplayList() {
	printf("displaying list\n");
	struct node *tmpNode = malloc(sizeof(struct node));
	if(head == NULL) {
		printf("list is empty. Please add elements to list\n");
	}
	else{
		tmpNode = head;
		printf("nodes in the list:");
		while(tmpNode != NULL) {
			printf("%d ",tmpNode->data);
			tmpNode = tmpNode->next;
		}
		printf("\n");
	}
}

int getListLength() {
	struct node *tmpNode = malloc(sizeof(struct node));
	int length = 0;
	if(head == NULL) {
		return 0;
	}
	else{
		tmpNode = head;
		while(tmpNode != NULL) {
			length++;
			tmpNode=tmpNode->next;
		}
	}
}