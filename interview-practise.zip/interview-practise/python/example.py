import os
def selSort(ary):
    size = len(ary)
    for i in range(size):
        min_index = i
        for j in range(i+1, size):
            if(ary[min_index]>ary[j]):
                min_index = j
        (ary[i], ary[min_index]) = (ary[min_index], ary[i])

def insSort(ary):
    size = len(ary)
    for i in range(1, size):
        insValue = ary[i]
        j = i
        while j>0 and insValue<ary[j-1]:
            ary[j] = ary[j-1]
            j = j-1
        ary[j] = insValue

def bubSort(ary):
    size = len(ary)
    for i in range(size):
        for j in range(0, size-i-1):
            if(ary[j]>ary[j+1]):
                (ary[j+1], ary[j]) = (ary[j], ary[j+1])

def mergeSort(ary):
    size = len(ary)
    if(size>1):
        mid = size//2
        left_half = ary[:mid]
        right_half = ary[mid:]
        print(f"left_half: {left_half}")
        print(f"right_half: {right_half}")
        mergeSort(left_half)
        mergeSort(right_half)
        i = j = k = 0
        while i<len(left_half) and j<len(right_half):
            if(left_half[i]<right_half[j]):
                ary[k] = left_half[i]
                i = i+1
            else:
                ary[k] = right_half[j]
                j = j+1
            k = k+1
        while(i<len(left_half)):
            print(f"sorting remaining elemets: {left_half[i]}")        
            ary[k] = left_half[i]
            i = i+1
            k = k+1
        while(j<len(right_half)):
            print(f"sorting remaining elemets: {right_half[j]}")        
            ary[k] = right_half[j]
            j = j+1
            k = k+1
            
nlist = [14,46,43,27,57,1,3,41,45,21,70,12, 11, 120, 111]
# selSort(nlist)
# print(f"selection sort:\n{nlist}")

# insSort(nlist)
# print(f"insertion sort:\n{nlist}")

# bubSort(nlist)
# print(f"bubble sort:\n{nlist}")
# mergeSort(nlist)
# print(f"Merge sort:\n{nlist}")

txtFile = os.path.dirname(__file__)+ "/example.txt"
print(txtFile)
with open(txtFile, 'r') as file:
    content = file.readlines()
    # print(type(content))
    # print(content)
    for line in content:
        print(line.strip())
 
