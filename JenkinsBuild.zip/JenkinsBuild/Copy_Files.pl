use strict;
use warnings;
use File::Find;
use File::Spec;
use File::Copy;
use File::Path;

my $workspace_path=$ARGV[0];
my $tools_cfg_path=$ARGV[1];

my $LibPrg_Fc_path=$tools_cfg_path.'\LibPrg_fc.mak';
my $LibPrg_Tl_path=$tools_cfg_path.'\LibPrg_tl.mak';


my $dest_path= $workspace_path.'\polyspace';

my @dir=();
@dir=File::Spec->splitdir($tools_cfg_path);
my $AlmRwsPath="$dir[0]\\$dir[1]\\$dir[2]\\$dir[3]\\$dir[4]\\$dir[5]\\$dir[6]\\$dir[7]\\$dir[8]";

my $tools_cfg=$tools_cfg_path;
$tools_cfg =~ s/swBuild//ig;
my $Additional_files=$tools_cfg.'polyspace\AdditionalFiles.txt';

#Removing the already existing contents of polyspace folder
rmdir $dest_path;
unlink glob "$dest_path/*.*";

#Creating polyspace folder
my $error;
mkdir $dest_path or $error = $!;
unless (-d $dest_path) {
    die "Cannot create directory '$dest_path': $error";
}

my @damos_files=($workspace_path.'\Damos\rom_tl.h',$workspace_path.'\Damos\rom_tl.c',$workspace_path.'\Damos\rom_ih.h',$workspace_path.'\Damos\rom_ih.c',$workspace_path.'\Damos\ram_tl.h',$workspace_path.'\Damos\ram_tl.c',$workspace_path.'\Damos\ram_ih.h',$workspace_path.'\Damos\ram_ih.c');
my $include_file_loc=$workspace_path.'\include';

open FILE1, "<", $LibPrg_Fc_path or die $!;
 my @c_file_fc_list = <FILE1>;
 close FILE1;


open FILE2, "<", $LibPrg_Tl_path or die $!;
	my @cfile_tl_list = <FILE2>;
	close FILE2;
	
my @final_c_list;

	foreach my $c_file (@c_file_fc_list,@cfile_tl_list) {
		chomp($c_file);
		$c_file =~ /^#/ and next;
		$c_file =~ s/\QPRG_CFILES_FC += $(imp_set)\E/$AlmRwsPath/g;
		$c_file =~ s/\QPRG_CFILES_TL += $(imp_set)\E/$AlmRwsPath/g;
		if (-f $c_file) {
			if(-e $c_file) {
				push (@final_c_list, $c_file);
			}
		}
		
	}
	
opendir(my $DIR, $include_file_loc) || die "can't opendir $include_file_loc: $!";  
my @h_files = readdir($DIR);

#header file copy
foreach my $t (@h_files)
{
   if(-f "$include_file_loc/$t" ) {
#     Check with -f only for files (no directories)
copy "$include_file_loc/$t", "$dest_path/$t";
   }
}
closedir($DIR);

#varid_cc.c file copy
copy "$workspace_path.\\varid_cc.c", $dest_path;

#C and damos file copy
foreach my $file (@final_c_list,@damos_files) {
copy("$file",$dest_path) or die "Copy  failed: $!";
}

#Additionalfile.txt copy process
my @Additional_file_copy=();
my @c_files_copy=();
if(-f $Additional_files)
{
open FILE3, "<", $Additional_files or die $!;
	my @additional_files = <FILE3>;
	close FILE3;
foreach my $files (@additional_files) {

		chomp($files);
		my $find='\rbd';
		my $replace=$AlmRwsPath.'\rbd';
		 $files =~ s/\Q$find\E/${replace}/;
		if (-d $files) {
			
				push (@Additional_file_copy, $files);
			
		}
		elsif(-f $files)
		{
			push(@c_files_copy,$files);
		}
		
	}

#copying files from directories in AdditionalFiles.txt
foreach my $file1 (@Additional_file_copy) {
  
    opendir(my $DIR1, $file1) || die "can't opendir $file1: $!";  
my @c_files_copy1 = readdir($DIR1);

foreach my $t1 (@c_files_copy1)
{
   if(-f "$file1/$t1" ) {
#     Check with -f only for files (no directories)
copy "$file1/$t1", "$dest_path/$t1";
   }
}
closedir($DIR1);
}

#copying files listed in .txt file
foreach my $t2 (@c_files_copy)
{
 if(-f $t2)
 {
 copy "$t2","$dest_path";
 }
}

}





