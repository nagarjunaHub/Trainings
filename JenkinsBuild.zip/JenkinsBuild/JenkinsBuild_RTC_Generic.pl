#!/usr/local/bin/perl
use Tk;
use Tk::NoteBook;
use Win32::FileOp;
use Win32;
use StickyButton;
use File::Spec;
use File::Basename;
use Cwd;

## Working well as long as if we don't use START /MIN wperl SWDE_Stepper.pl. Otherwise we may get an error.
$ENV{HOME} = "C:\\"; #define to request warnings in Tk.pm
$Alm_flag = $ARGV[0] ;
print "Alm_flag: $Alm_flag\n";
## Identify the number of cores available in the target machine
$number_of_cores=$ENV{"NUMBER_OF_PROCESSORS"};
$parallel_process=$number_of_cores-1;


my $PROJ_Path = "";
if($Alm_flag==1){
$PROJ_Path = getdcwd();
} else {
$PROJ_Path = getcwd();
}
#Global Constants:
my $PROJ_Path = "";
my $SWTOOLS_ROOT = "";
my $SWTOOLS_TOOLSET = "ToolSet\\SWTOOLS";
my $PROJ_VOB = "";

# $PROJ_Path = getdcwd();
# my $vob = fileparse($PROJ_Path);
# my $RWS_path = dirname($PROJ_Path);
# my $RWS_name = fileparse(dirname($PROJ_Path));


print "vob:$vob\n";
print "RWS_path:$RWS_path\n";
print "RWS_name:$RWS_name\n";
if($Alm_flag == 1) {
	$PROJ_Path = getdcwd();
	print "cwd $PROJ_Path\n";
	my $vob = fileparse(dirname($PROJ_Path));
	$vob_path = $PROJ_Path;
	# ($drive,$workspace,$jobs,$job_name,$view,$vob) = File::Spec->splitdir($PROJ_Path);
	# $vob_path = "$drive\\$workspace\\$jobs\\$job_name\\$view\\$vob";
	($AlmBUnit, $AlmProject, $AlmPrjVariant, $AlmSw) = split('_', $vob);
	# ($AlmBUnit, $AlmProject, $AlmPrjVariant, $AlmSw) = split('_', $view);
	$AlmProjectPath = "$vob_path\\$AlmBUnit\\$AlmProject";
	$AlmDepPath = "$vob_path\\$AlmBUnit\\dep";
	$AlmRWSPath = "$vob_path\\$AlmBUnit";	
	if($AlmSw eq "sw") {
		$AlmPrjVarPath = "$vob_path\\$AlmBUnit\\$AlmProject\\$AlmPrjVariant\\$AlmSw";
		$AlmPfPath = "$vob_path\\$AlmBUnit\\$AlmProject\\pf\\$AlmSw";
		$AlmWorkspacePath = $vob_path;
	}
	else {
		$AlmPrjVarPath = "$vob_path\\$AlmBUnit\\$AlmProject\\$AlmPrjVariant";
		$AlmPfPath = "$vob_path\\$AlmBUnit\\$AlmProject\\pf";
		$AlmWorkspacePath = $vob_path;
	}

	$AlmSwBuildCfgPath = "$AlmPrjVarPath\\tools_cfg\\swBuild";
	# $AlmProjectPath = "$vob_path\\$AlmBUnit\\$AlmProject";
	# $AlmDepPath = "$vob_path\\$AlmBUnit\\dep";
	# $AlmRWSPath = "$vob_path\\$AlmBUnit";
	# $AlmPrjVarPath = "$vob_path\\$AlmBUnit\\$AlmProject\\$AlmPrjVariant\\$AlmSw";
	# $AlmPfPath = "$vob_path\\$AlmBUnit\\$AlmProject\\pf\\$AlmSw";
	# $AlmSwBuildCfgPath = "$AlmPrjVarPath\\tools_cfg\\swBuild";
	print "AlmSwBuildCfgPath : $AlmSwBuildCfgPath\n";
	$PROJ_VOB = $vob_path;
	$SWTOOLS_ROOT = "$PROJ_VOB\\$AlmBUnit\\invrTools\\swBuild\\SWTOOLS";
}
else {
	$PROJ_Path = getcwd();
	($drive,$view,$vob) = File::Spec->splitdir($PROJ_Path);
	$vob_path = File::Spec->catdir($drive,$view,$vob);
	$PROJ_VOB = $vob_path;
	$SWTOOLS_ROOT = File::Spec->catfile( $PROJ_VOB, $SWTOOLS_TOOLSET);
}

if($vob eq "PT_PVI") {
	$vob_path = $vob_path."\\SW_Software";
	$PROJ_VOB = $vob_path;
	$SWTOOLS_ROOT = File::Spec->catfile( $PROJ_VOB, $SWTOOLS_TOOLSET);
}


# my $PROJ_VOB = $vob_path;
# my $SWTOOLS_TOOLSET = "ToolSet\\SWTOOLS";
# my $SWTOOLS_ROOT = File::Spec->catfile( $PROJ_VOB, $SWTOOLS_TOOLSET);
# print "SWTOOLS_ROOT:$SWTOOLS_ROOT\n";
my $template_dir = "$SWTOOLS_ROOT\\Esprit\\system_1\\__templates";
my $make_temp_file = "make3.tmp" ;
my $mw_select_prj;

my $card_nr;



#Global Variables


@Tool_Entwicklung_0 = ( 
                 ["(OBJ) Update make3.bat and user_variables.mak","update_uservariables"], 
                 ["(OBJ) Delete all Objectfiles","clean"],    
                 ["(VAR) Create DAMOS Sourcefile (*.kgt u. *.xmo => ram*/rom*.c/h)","damos_new estop"],     
                 ["(VAR) Create Compiler Switch Files (def*.mak => *.ccf/*.lcf) ", "gen_comp_link_flags estop"],
                 ["(VAR) Create Software-ID File: Boot + Drive (varid_anc_mk.mak => varid_cc.c)", "varid estop"],
                 ["(BAS) Create Program Library (LibProg_fc/tl.mak => *.obj => *p_fc/tl.a, rmake_pl_fc/tl.log  )", "prog_lib estop"],
                 ["(VAR) Create Data Library (LibData_fc/tl.mak => *.obj => *d_fc/tl.a, rmake_dl_fc/tl.log  )", "data_lib estop"],
                 ["(BAS) Create Test Library (LibPrg_st/LibData_st.mak => *.obj => *p_st/*d_st.a, rmake_*_st.log )", "test_lib estop"],
                 ["(VAR) Linking all Libraries (libraries_bov_mk.mak => *.hex, *.mot, *rmakel*.log)", "hex estop"],
                 ["(BAS) Create ASAP2 Files: Program + Test (*.map => *rb(_st).a2l)", "damos_asap_files_st estop"],
                 ["(VAR) Merge with Customer ASAP2 Files and actualize addresses (*rb.a2l => *rb_merged.a2l)", "merge_a2l estop"],
                 ["(VAR) Create Delivery-Software (*.mot => DRVCRC*.hex)","driveprog_crc estop"],
                 ["(VAR) Containererstellung DELIVERIES\<SW_IDENT>.cnt","ecumgen estop"]);


@Tool_Sonderfkt_1 = (
                 ["(OBJ) Create single Object File, (Userinput *.c => *.o, *_co.log, error.log)", "FileCompile_O"],
                 ["(OBJ) Create single Preprocessor File (Userinput *.c =>*.i, *_co.log, error.log)", "FileCompile_I"], 
                 ["(VAR)\\qac\\output Check MISRA\/coding-guidelines & SW metrics for single sourcefile","swqs_misra estop"],
                 ["(OBJ) Create all Preprocessor Files (makeplib.mak => *.i)","prepro"],
                 ["(VAR)\\qac\\output Check MISRA\/coding-guidelines & SW metrics for all sourcefiles","swqs_misra_all estop"]);


@Tool_Integ_Delivery_2 = (
                 ["(CC) Store Build Environment Results in CM (From VAR,BAS OBJ-Dir.)", "CM_BuildRes estop"],
                 ["N.A. (CC) Prepare Delivery for Customer (store in CM)", "CM_Delivery estop"]);



@Card_Names = ('Entw','Sonderf','IntegDeliv');	
@Card_Names_Label = ('Development','Single File / QAC Functions','Integration/Delivery');
my %Card_Names_index;
@Card_Names_index{@Card_Names} = (0..$#Card_Names);






my @Tool_TextAction_all = (\@Tool_Entwicklung_0, \@Tool_Sonderfkt_1, \@Tool_Integ_Delivery_2);
#my @Tool_TextAction_all = (\@Tool_Entwicklung_0, \@Tool_Sonderfkt_1);




my $PRJ_PATH="";
my $PRJ_MAKE;
my $PRJ_CHECK;
# ?? my $Path_var = "$ARGV[0]\\";
# $Path_var = "C:\\JenkinsBuildResults\\";
my $job_name = $ENV{"JOB_NAME"};
my $numberofcores = $ENV{"NUMBER_OF_PROCESSORS"};
my $CORES_TO_USE = $numberofcores*2-1;
if($job_name eq "") {
$jenkins_flag = 0;
} else {
$jenkins_flag = 1;
}
# my $Path_var = "";
print "jenkins_flag:$jenkins_flag\n";
# local $Path_var = "C:\\";
if($jenkins_flag==0){
$Path_var = "C:\\";
} else {
$Path_var = $ENV{"WORKSPACE"}."\\";
	if (-e "$Path_var\\QAC_Plot_Results.csv") {
	system("del $Path_var\\QAC_Plot_Results.csv");
	print "$Path_var\\QAC_Plot_Results.csv was deleted ..."
	}
}
print "Path_var:$Path_var\n";



my $Prj_txt = "000";
my $Var_txt = "000";
my $Mst_txt = "X";
my $Prg_txt = "00";
my $Dat_txt = "00";
my $Pos =-3; 

foreach $para (@ARGV)
{
	if ($para =~ /-p/)
	{
	        # Parameter -p<WS-PATH>, eg -pu:\WS\>
		# Base-Dir Workspace is not set to default
                $Path_var = $para;
		$Path_var =~ s/-p//;
       	}

	if ($para =~ /-u/)
	{
	       # Parameter -u
		# Base-Dir of Workspace is set to Env.-Variable USERPROFILE
		$Path_var = $ENV{"USERPROFILE"}."\\";
	}
	if ($para =~ /-v/)
	{       # Parameter -v<VAR-PATH>, eg -vC:\200\200\b0101>
		# VAR-Path (helpfull, if SWDE-Stepper is started from a Workspace-Dir
                # instead of a View with Label or Label-comment)
                # in this case, the Path with the Parameter -v is analysed and used.
                $PRJ_PATH = $para;
		$PRJ_PATH =~ s/-v//;
	}
}

my $frm_job;
my $result;
my $Target;

# Main Window

search_releaselabel_in_view();
if($jenkins_flag) {
Check_Prj();
} else {
Start_Entwicklung();
&create_workspace;
$frame_mw ->update();
}

#$Target = "clean";
#system("$PRJ_MAKE $Target");

##system("$PRJ_MAKE $ARGV[0] estop");




# Ende Main-Programm
################################################

## Funktion search_releaselabel_in_view (prüft mit Cleartool, ob übergebener Pfad ein View
# ist und dort ein Releaselabel eingetragen ist.
# wenn ja, Workspace-ID wird aus Release übernommen
# wenn nein, prüfen ob übergebenener Pfad einem Variantenpfad entspricht und ggf. daraus Workspace-ID übernehmen
#

sub search_releaselabel_in_view {

print "\n\n";
print " Search 1. Release-Label in View:\n"; # Pos = 0
print " if not found, then search 1. Release-Comment in View:\n"; # Pos =-1

#open (PS, "net user pfa2si /domain  |"); 
if ($Alm_flag = 0) {
	open (PS, "cleartool catcs  |"); 
}	
else {
    print "findstr SW_RELEASE_LABEL_PRJ $AlmSwBuildCfgPath\\project_variables.mak\n";
    open (PS, "findstr SW_RELEASE_LABEL_PRJ $AlmSwBuildCfgPath\\project_variables.mak  |");
}
$cnt = 0;
$Pos =-3; 
  while (($line = <PS>) && ($Pos < 0)) {
    $cnt = $cnt +1; 
    $commentsign = substr($line,0,1); 

    if ($commentsign eq "#") {
        
        $line = substr($line,1,);
	$line =~ s/^\s+//;
    }

    ($view_column_1, $view_vob, $view_version ) = split(/\s+/, $line); 

#print "$line" if $cmd =~ /httpd/; 
print "$view_column_1:$view_vob:$view_version\n"; 


    if (  (($view_column_1 eq "element") || ($view_column_1 eq "SW_RELEASE_LABEL_PRJ")) && ($view_version =~ /^\S\S\S_\S\S\S_\w_\S\S_\S\S*/ )) {
    print "$view_column_1:$view_vob:$view_version\n";

## Optional: deaktivate next line to get same default path e.g 000 ... for Jennkins-Server
	($Prj_txt, $Var_txt, $Mst_txt, $Prg_txt, $Dat_txt ) = split(/_/, $view_version );


	print "$Prj_txt\n";
	print "$Var_txt\n";
	print "$Mst_txt\n";
	print "$Prg_txt\n";
	print "$Dat_txt\n";
   

        if ($commentsign eq "#") {
      print "Comment-Label found in actual View, Workspace\/ID set to: $Path_var, $Prj_txt, $Var_txt, $mst_dst_prg\n";
# Eintrag gefunden -> Beenden:
#  	  $Pos = -1; 
# set to same Priority as Release-Label
  	  $Pos = 0; 
        }
		elsif ($commentsign eq "S") {
		print "Release-Label project_variables.mak, Workspace\/ID set to: $Path_var, $Prj_txt, $Var_txt, $mst_dst_prg\n";
		$Pos = 0;
		}
        else {
      print "Release-Label found in actual View, Workspace\/ID set to: $Path_var, $Prj_txt, $Var_txt, $mst_dst_prg\n";
# Eintrag gefunden -> Beenden:
  	  $Pos = 0; 
        } 
    }
  }

  if ($Pos < -1) {

    if ($PRJ_PATH =~ /$Path_var\\d\d\d\\\d\d\d\\\w\d\d\d\d/ )  {
# Keine Releaseinfo in View gefunden, untersuche Pfad-Info und setze Workspace (wenn plausibel) auf aktuelles Verzeichnis 
        print "PRJ_PATH:$PRJ_PATH\n";
                

#		($Path_var, $Prj_txt, $Var_txt, $mst_dst_prg ) = split(/\\\\/, $PRJ_PATH);
		($Path_var, $Prj_txt, $Var_txt, $mst_dst_prg ) = split(/\\/, $PRJ_PATH);
		    print "No Release-Label or Comment found in actual View, Workspace\/ID set to VAR-Path given by Program-Argument: $Path_var, $Prj_txt, $Var_txt, $mst_dst_prg\n";
		 $Path_var = "$Path_var\\"; 
		 $Mst_txt = uc(substr($mst_dst_prg,0,1));
		 $Prg_txt = substr($mst_dst_prg,1,2);
		 $Dat_txt = substr($mst_dst_prg,3,2);
                 $Pos = -2; 
    }
    else {
#       print "Path $PRJ_PATH not found in $Path_var:T\n";
    }
  }
}

#******************************************************************************
# Check whether workspace is available. If not, it will (ask for) create a new workspace.
# Workspace und Files angelegt werden sollen)
sub Check_Prj {

  $PRJ_PATH = "$Path_var$Prj_txt\\$Var_txt\\$Mst_txt$Prg_txt$Dat_txt";
  $PRJ_MAKE="$PRJ_PATH\\make3.bat";
  $PRJ_CHECK="$PRJ_PATH\\user_variables.mak";

  print " Checking $PRJ_MAKE and $PRJ_CHECK\n";

  if (-e "$template_dir\\$make_temp_file") {
     print " found $template_dir\\$make_temp_file\n";

  } else {
          print " error didn't found $template_dir\\$make_temp_file\n";
          Win32::MsgBox("$template_dir\\$make_temp_file missing, not a valid SWDE-View on $SWTOOLS_ROOT mounted",48,'Error!');
          exit;
  }

  #$result = Win32::MsgBox('File '.$PRJ_CHECK.' or '.$PRJ_MAKE.' missing! Create Workspace files?', 16+4, 'Error');
  #if ($result == 6) {
     create_workspace();
	 return 1;
  #}
  #else {
	# return 0;
  #}

}

#******************************************************************************
## Funktion/Fenster "Start_Entwicklung" (Starten der Tool-Checkliste aus entsprechendem Reiter)
#******************************************************************************

sub Start_Entwicklung {
     my $mw = new MainWindow;
      $mw-> attributes(-topmost => 0);


#$mw -> minsize(400, 200); # $mw->minsize(breite,hoehe);



     my $frame_mw = $mw->Frame();
     $frame_mw ->pack (-side=>"top");


#        $card_all[$card_nr] -> Label(-text=>"ProjektId [XXX]:");
        $frame_mw -> Label(-text => "Selected RWS : $vob", -width => 50, -font => '{Arial} 10 {bold}')->pack();
        $frame_mw -> Label(-text => "Working drive / Project-Id:", -width => 42, -font => '{Arial} 8 {bold}')->pack();

        $Prjid_ent_mw = $frame_mw -> Entry()->pack();
        $Prjid_ent_mw -> insert(0,"$Path_var   $Prj_txt $Var_txt $Mst_txt $Prg_txt $Dat_txt");
        $Prjid_ent_mw->configure(-state => 'readonly');

        @StartButtonChangeWD_mw = $frame_mw->StickyButton(-text => 'Change workspace',
                                     -command => sub {
#                                         $card_nr = 0;
                                         &select_workspace;
                                         $frame_mw ->update();
        
                                     }
                             )->pack(-side,'left' );

#        @StartButtonChangeWD_mw = $frame_mw->StickyButton(-text => 'Update make3.bat+user_varibles.mak',
#                                     -command => sub {
#                                         $card_nr = 0;
#                                         &create_workspace;
#                                         $frame_mw ->update();
        
#                                    }
#                             )->pack(-side,'right');



     my $nb =  $mw->NoteBook() -> pack();




#   $mw->geometry('470x710+0+0');
#   $mw -> minsize(399, 199);

#Geometry Management


my $card_0 = $nb->add($Card_Names[0],  -label => $Card_Names_Label[0]);
my $card_1 = $nb->add($Card_Names[1],  -label => $Card_Names_Label[1]);
my $card_2 = $nb->add($Card_Names[2],  -label => $Card_Names_Label[2]);


     my $frame_0 = $card_0->Frame();
     $frame_0 ->pack (-side=>"top");

     my $frame_1 = $card_1->Frame();
     $frame_1 ->pack (-side=>"top");

     my $frame_2 = $card_2->Frame();
     $frame_2 ->pack (-side=>"top");


my @card_all = ($card_0, $card_1, $card_2);
my @frame_all = ($frame_0, $frame_1, $frame_2);
#my @card_all = ($card_0, $card_1);
#my @frame_all = ($frame_0, $frame_1);


my @Tool_chk_Temp = @Tool_chk;
my @Tool_TextAction_Temp = @{$Tool_TextAction_all[0]};

my @StartButtonTS;
my @SelectAllButtonTS;
my @DeselectAllButtonTS;
my $i;

        if ($Pos < -2) { # Keine gueltige Workspace-Info gefunden
           select_workspace();
           $mw_select_prj->raise;
           $mw_select_prj-> attributes(-topmost => 1);
   
#           $mw_select_prj->update();

        } else {
             Check_Prj();
        }

# $cardEntw -> Label(-text => 'In Seite 1')->pack();





        $card_nr = -1;
        for  $row ( @{Tool_TextAction_all}) {
		$card_nr = $card_nr + 1;

        draw_checkboxes();
        $StartButtonTS[$card_nr] = $card_all[$card_nr]->StickyButton(-text => 'Start',
                                     -width => 15,
                                     -command => sub {
#                                         $card_nr = 0;
                                         &push_button_entw_start;
#                                         print "cardnr=$card_nr";
                                     }
                             )->pack(-pady => 5,-side => 'bottom');



        $SelectAllButtonTS[$card_nr] = $card_all[$card_nr]->StickyButton(-text => 'Mark all',
                                     -width => 8,
                                     -command => sub {
					  # reread $CardNr of actual notebook
					  $card_nr = $Card_Names_index{$nb->raised()};
                                          $i = 0;
	 				  for $col (@{@{$Tool_TextAction_all[$card_nr]}}) {
				            $i = $i + 1;
					    if ($Tool_TextAction_all[$card_nr][$i-1][0] =~ /^N.A./)	{
					    } else { 	
				                  $Tool_chk_Temp[$card_nr][$i] -> select();
					    }
					  }
					}
				  	
                             )->pack(-pady => 5,-side => 'left');


        $DeselectAllButtonTS[$card_nr] = $card_all[$card_nr]->StickyButton(-text => 'Unmark all',
                                     -width => 8,
                                     -command => sub {
					  # reread $CardNr of actual notebook
					  $card_nr = $Card_Names_index{$nb->raised()};
                                          $i = 0;
	 				  for $col (@{@{$Tool_TextAction_all[$card_nr]}}) {
				            $i = $i + 1;
					    if ($Tool_TextAction_all[$card_nr][$i-1][0] =~ /^N.A./)	{
					    } else { 	
				                  $Tool_chk_Temp[$card_nr][$i] -> deselect();
					    }
					  }
					}

                             )->pack(-pady => 5,-side => 'left');
        }	



#        $card_nr = 1;
#        draw_checkboxes();
#        $StartButtonTS[$card_nr] = $card_all[$card_nr]->StickyButton(-text => 'Start',
#                                     -width => 15,
#                                     -command => sub {
#                                         $card_nr = 1;
#                                         &push_button_entw_start;
#                                     }
#                             )->pack(-pady => 5,-side => 'bottom');



#        $card_nr = 2;
#        draw_checkboxes();
#        $StartButtonTS[$card_nr] = $card_all[$card_nr]->StickyButton(-text => 'Start',
#                                     -width => 15,
#                                     -command => sub {
#                                         $card_nr = 2;
#                                         &push_button_entw_start;
#                                     }
#                             )->pack(-pady => 5,-side => 'bottom');





#******************************************************************************
#  Sub Funktion wich draws the List of Tool-Checkboxes, 
#  called from Function Start_Entwicklung
#******************************************************************************
#

sub draw_checkboxes {

        $i = 0;



        for $row ( @{@{$Tool_TextAction_all[$card_nr]}} ) {
          $i= $i+1;

          $Tool_chk_Temp[$card_nr][$i] = $card_all[$card_nr] -> Checkbutton(-text=>$Tool_TextAction_all[$card_nr][$i-1][0],
                -variable=>\$Tool_Value[$card_nr][$i-1])->pack(-side=>"top",-anchor=>'nw');
          $Tool_chk_Temp[$card_nr][$i] -> deselect();
        }

}

#******************************************************************************
#  Sub Funktion wich starts the selected Jobs from the List of Tool-Checkboxes,
#  called from Function Start_Entwicklung
#******************************************************************************

        sub push_button_entw_start {

 #$StartButtonTS->configure(-state => 'disabled');
 #              &ChangeMainWindowCursor('watch');


                $i = 0;
                $error_Alm_flag = 0;
   	        # reread $CardNr of actual notebook
		$card_nr = $Card_Names_index{$nb->raised()};


        	for $row (@{@{$Tool_TextAction_all[$card_nr]}}){
        	  $i = $i + 1;
        	  my $job = "";

          	  #See whether he is employed
          	  if (( $Tool_Value[$card_nr][$i-1] == 1 )  and ($error_Alm_flag == 0)){
                        $Tool_chk_Temp[$card_nr][$i] -> configure(-foreground=>'blue');
                        $card_all[$card_nr] ->update();

#      $result = Win32::MsgBox($Tool_TextAction_all[$card_nr][$i-1][0].' starting ...', 16+4, 'Error');

        	  	print "$Tool_TextAction_all[$card_nr][$i-1][0] starting ...\n";
#                $Tool_chk_Temp[1] -> configure(-foreground=>'blue');

        #             system("s:\\Scripte\\Esprit_mak\\start_make $PRJ_PATH $Tool_TextAction_all[$card_nr][$i-1][1]");

          	     if ( "$Tool_TextAction_all[$card_nr][$i-1][1]" eq "update_uservariables" ){
        #               $card_nr = 0;
                       &create_workspace;
                       $frame_mw ->update();

                     }
                     else {
#						if ( "$Tool_TextAction_all[$card_nr][$i-1][1]" eq "prog_lib estop" ){
#							system("$PRJ_MAKE inline_prog_inf estop");
#						}
#						elsif( "$Tool_TextAction_all[$card_nr][$i-1][1]" eq "test_lib estop" ){
#							system("$PRJ_MAKE inline_test_inf estop");
#							system("$PRJ_MAKE $Tool_TextAction_all[$card_nr][$i-1][1]");
#						}
#						else {
                        system("$PRJ_MAKE $Tool_TextAction_all[$card_nr][$i-1][1]");
#						}
                     }


                     if ($? != 0) {
                       $error_Alm_flag = $?;
         	       $result = Win32::MsgBox('Error '.$error_Alm_flag.' occured! View Error.log ?', 16+4, 'Error');
                  (($result == 6) ? system("$SWTOOLS_ROOT\\Esprit\\system_1\\__utility\\notepad.exe $PRJ_PATH\\error.log") : print "bye !\n");
        #(($result == 6) ? Win32::MsgBox('A',48,'Alert ! Alert') : Win32::MsgBox('B',48,'Alert ! Alert'));


        #          (($result == 6) ? Win32::MsgBox('A '.$error_flag.' occured! View Error.log ?', 16+4, 'Error') : Win32::MsgBox('B '.$error_flag.' occured! View Error.log ?', 16+4, 'Error'));
        #                print "Error:$?\n";
        #               $wait_input = <STDIN>;
                     }
                     $Tool_chk_Temp[$card_nr][$i] -> configure(-foreground=>'black');
          	  }
         	  else {
        	  }
                }
        }





#******************************************************************************
## Funktion/Fenster "select_workspace"
#******************************************************************************

sub select_workspace{

        print "Commandline Parameter -v$PRJ_PATH is not a valid Workspace for Main Directory $Path_var, please Select Workspace ...\n";
  
#        my $mw_select_prj = $mw ->Toplevel;
        $mw_select_prj = $mw ->Toplevel;
        $mw_select_prj->title("Workspace / ID");
        $mw_select_prj-> attributes(-topmost => 0);
# geht hier noch nicht in Vordergrund    $mw_select_prj-> attributes(-topmost => 1);

        $mw_select_prj -> minsize(199, 169);

        #GUI Building Area
        my $frm_name = $mw_select_prj -> Frame();


        my $Prj = $frm_name -> Label(-text=>"Project Number [XXX]:");
        my $Prj_ent = $frm_name -> Entry(-width => 3);

        my $Var = $frm_name -> Label(-text=>"Variant Number [XXX]:");
        my $Var_ent = $frm_name -> Entry(-width => 3);
        my $Mst = $frm_name -> Label(-text=>"Sample Version [A,B,C,D]:");
        my $Mst_ent = $frm_name -> Entry(-width => 1);
        my $Prg = $frm_name -> Label(-text=>"Program Version [XX]:");
        my $Prg_ent = $frm_name -> Entry(-width => 2);
        my $Dat = $frm_name -> Label(-text=>"Data Version [XX]:");
        my $Dat_ent = $frm_name -> Entry(-width => 2);

        my $Path = $frm_name -> Label(-text=>"Drive:");
        my $Path_ent = $frm_name -> Entry(-width => 3);
        #$Path_var =  "C:\\";
        my $drive_but = $mw_select_prj -> Button(-text=>"Select Working Drive",
                                                -command => sub {
                        # (Drive_Button) Achtung: Variablen/Textboxen müssen bereits definiert sein,
                        # um hier verändert zu werden

                        #    $var = BrowseForFolder("Choose Directory", CSIDL_PERSONAL);
                            $Path_var = substr(BrowseForFolder("Choose Drive", CSIDL_DRIVES),0,3);
                        #    $var = BrowseForFolder("Choose Directory", CSIDL_DESKTOP);
                        #    $Path_var =~ s|\\|/|g;  # for prettiness :)
                            $Path_ent -> delete(0,'end');
                            $Path_ent -> insert(0,"$Path_var");
                            print "New Path: $Path_var\n";

                            $mw_select_prj-> attributes(-topmost => 1);
                            $mw_select_prj ->update();


                 }
        );

#        Writes the old Variable-Values in the Inputfields
        $Prj_ent -> insert(0,"$Prj_txt");
        $Var_ent -> insert(0,"$Var_txt");
        $Mst_ent -> insert(0,"$Mst_txt");
        $Prg_ent -> insert(0,"$Prg_txt");
        $Dat_ent -> insert(0,"$Dat_txt");
        $Path_ent -> insert(0,"$Path_var");

        #my $frm_titel = $mw_select_prj -> Frame();
        #my $Titel = $frm_titel -> Label(-text=>"Projekt-Datei $PRJ_CHECK existiert nicht, anlegen?");

        my $but = $mw_select_prj -> Button(-text=>" OK ", -command => sub {
#         Writes the new one from the Inputfields to the Variables
                $Prj_txt = $Prj_ent -> get();
                $Var_txt = $Var_ent -> get();
                $Mst_txt = $Mst_ent -> get();
                $Prg_txt = $Prg_ent -> get();
                $Dat_txt = $Dat_ent -> get();
                print "Prj: $Prj_txt\n";
                print "Var: $Var_txt\n";
                print "Mst: $Mst_txt\n";
                print "Prg: $Prg_txt\n";
                print "Dat: $Dat_txt\n";
                print "Path: $Path_var\n";
                Check_Prj();
                $Pos = -2;


#         Write the new Variables to Workpace-Textfield
                 $Prjid_ent_mw ->configure(-state => 'normal');
                 $Prjid_ent_mw -> delete(0,'end');
                 $Prjid_ent_mw -> insert(0,"$Path_var   $Prj_txt $Var_txt $Mst_txt $Prg_txt $Dat_txt");
                 $Prjid_ent_mw ->configure(-state => 'readonly');
                $mw_select_prj->destroy();
            }
        );



        #Geometry Management of select_workspace

        $frm_name -> grid(-row=>1,-column=>1,-columnspan=>2);
        $Prj -> grid(-row=>2,-column=>1);
        $Prj_ent -> grid(-row=>2,-column=>2);
        $Var -> grid(-row=>3,-column=>1);
        $Var_ent -> grid(-row=>3,-column=>2);
        $Mst -> grid(-row=>4,-column=>1);
        $Mst_ent -> grid(-row=>4,-column=>2);
        $Prg -> grid(-row=>5,-column=>1);
        $Prg_ent -> grid(-row=>5,-column=>2);
        $Dat -> grid(-row=>6,-column=>1);
        $Dat_ent -> grid(-row=>6,-column=>2);
        $Path -> grid(-row=>7,-column=>1);
        $Path_ent -> grid(-row=>7,-column=>2);

        #$frm_titel -> grid(-row=>10,-column=>1,-columnspan=>2);
        #$Titel -> grid(-row=>2,-column=>1);
        $drive_but -> grid(-row=>9,-column=>1,-columnspan=>2);
        $but -> grid(-row=>11,-column=>1,-columnspan=>2);




}

#******************************************************************************
#  Ende Sub select_workspace
#******************************************************************************


#******************************************************************************
# Sub Function  "create_workspace" (legt Verzeichnisse und lokale Files an)
#******************************************************************************

sub create_workspace{
      my $VAR_PATH = $Path_var.$Prj_txt."\\\\".$Var_txt."\\\\".$Mst_txt.$Prg_txt.$Dat_txt;
      my $BAS_PATH = $Path_var.$Prj_txt."\\\\".bas."\\\\".$Mst_txt.$Prg_txt."00";

  if (-e "$template_dir\\$make_temp_file") {	  
# Projekt-Verzeichnisse anlegen
      if (-e "$VAR_PATH") {
         print "Workspace allready existing ...\n";
	  } else {
         print "cmd /c MD $VAR_PATH\n";
         system("cmd /c MD $VAR_PATH");
      }
      if (-e "$VAR_PATH\\OBJ") {
     
      } else {
         system("cmd /c MD $VAR_PATH\\OBJ");
      }
      if (-e "$BAS_PATH") {
     
      } else {
         system("cmd /c MD $BAS_PATH");
      }
      if (-e "$VAR_PATH\\include") {

      } else {
         system("cmd /c MD $VAR_PATH\\include");
      }

# User_variables.mak anlegen
# 1. Projekt-Variablen
      print "$VAR_PATH\\user_variables.tmp\n";
      open (OUTFILE, ">$VAR_PATH\\user_variables.tmp") or die "Error: unable to create $VAR_PATH\\user_variables.tmp File";
      print OUTFILE "PRO_NR = $Prj_txt\n";
      print OUTFILE "VAR_NR = $Var_txt\n";
      print OUTFILE "MST = $Mst_txt\n";
      print OUTFILE "PST = $Prg_txt\n";
      print OUTFILE "DST = $Dat_txt\n";
#      print OUTFILE "BAS_NR = $Prj_txt\n";
      print OUTFILE "PC_USER = ".lc ($ENV{"USERNAME"})."\n";
      print OUTFILE "BEARBEITER = ".lc ($ENV{"USERNAME"})."\n";
      print OUTFILE "PC_NAME = ".lc ($ENV{"COMPUTERNAME"})."\n";
      ($sec, $min, $hour, $day, $month, $year, ) = (localtime)[0,1,2,3,4,5];

      $DateStr = sprintf ("%4d\/%02d\/%02d\n", $year + 1900, $month + 1, $day);
      # $DateStr = sprintf ("%02d.%02d.%4d\n", $day, $month + 1,$year + 1900);
      $TimeStr = sprintf ("%02d:%02d:%02d\n", $hour, $min, $sec);
      print OUTFILE "DATE = $DateStr";
      print OUTFILE "TIME = $TimeStr";
# noch zu ersetzen *+++++++++++
      print OUTFILE "SRC_BASE = $vob_path\n";
      print OUTFILE "AlmPfPath = $AlmPfPath\n";
      print OUTFILE "AlmPrjVarPath = $AlmPrjVarPath\n";
       print OUTFILE "VAR_NAME = $Prj_txt$Var_txt$Mst_txt$Prg_txt$Dat_txt\n";
      print OUTFILE "SWTOOL_ROOT = $SWTOOLS_ROOT\\\\\n";
      print OUTFILE "SYS_PATH = $SWTOOLS_ROOT\\Esprit\\system_1\\\\\n";
      print OUTFILE "UTIL_PATH = $SWTOOLS_ROOT\\Esprit\\system_1\\__utility\\\\\n";
      print OUTFILE "DELETEIF = \$(UTIL_PATH)delif.bat\n";
      close (OUTFILE);

# 2. Template anhängen
      print "copy $VAR_PATH\\user_variables.tmp + $template_dir\\user_variables.tmp $VAR_PATH\\user_variables.mak\n";
      system("cmd /c copy $VAR_PATH\\user_variables.tmp + $template_dir\\user_variables.tmp $VAR_PATH\\user_variables.mak");
      system("del $VAR_PATH\\user_variables.tmp");
# clearmake_user_variables.mak anlegen
# 1. Projekt-Variablen
      print "$VAR_PATH\\clearmake_user_variables.mak\n";
      open (OUTFILE, ">$VAR_PATH\\clearmake_user_variables.mak") or die "Error: unable to create $VAR_PATH\\clearmake_user_variables.mak File";
      print OUTFILE "PRO_NR = $Prj_txt\n";
      print OUTFILE "VAR_NR = $Var_txt\n";
      print OUTFILE "MST = $Mst_txt\n";
      print OUTFILE "PST = $Prg_txt\n";
      print OUTFILE "DST = $Dat_txt\n";
 #    print OUTFILE "BAS_NR = $Prj_txt\n";
      print OUTFILE "PC_USER = ".lc ($ENV{"USERNAME"})."\n";
      print OUTFILE "BEARBEITER = ".lc ($ENV{"USERNAME"})."\n";
      print OUTFILE "PC_NAME = ".lc ($ENV{"COMPUTERNAME"})."\n";
      ($sec, $min, $hour, $day, $month, $year, ) = (localtime)[0,1,2,3,4,5];

      $DateStr = sprintf ("%02d.%02d.%4d\n", $day, $month + 1,$year + 1900);
      $TimeStr = sprintf ("%02d:%02d:%02d\n", $hour, $min, $sec);
      print OUTFILE "DATE = $DateStr";
      print OUTFILE "TIME = $TimeStr";
 # noch zu ersetzen *+++++++++++
      print OUTFILE "SRC_BASE = $vob_path\n";
      print OUTFILE "VAR_NAME = $Prj_txt$Var_txt$Mst_txt$Prg_txt$Dat_txt\n";
      print OUTFILE "SWTOOL_ROOT = $SWTOOLS_ROOT\\\\\n";
      print OUTFILE "SYS_PATH = $SWTOOLS_ROOT\\Esprit\\system_1\\";
      print OUTFILE "UTIL_PATH = $SWTOOLS_ROOT\\Esprit\\system_1\\__utility\\\\\n";
      print OUTFILE "DELETEIF = \$(UTIL_PATH)delif.bat\n";
      print OUTFILE "include $SWTOOLS_ROOT\\Make\\global_makefiles\\License_settings_cmak.mak\n";	  	  
      close (OUTFILE);

# 2. Wrapper-Batchfile to solve Error-Handling for parallel build together with logfile generate by tee.exe
      print "$VAR_PATH\\clearmake_user_variables.mak\n";
      open (OUTFILE, ">$VAR_PATH\\make3_wrapper.bat") or die "Error: unable to create $VAR_PATH\\make3_wrapper.bat File";
	  print OUTFILE "$SWTOOLS_ROOT\\make\\gMake\\bin\\make --output-sync=recurse -j 5 -f %loc_obj_set%\\gnu_makefile.mak  %para1% %para2% %3 %4 %5 %6 %7 %8 %9\n";
      print OUTFILE "\n";
      print OUTFILE "set omake_errorlevel=%ERRORLEVEL%\n";
      print OUTFILE "\n";
      print OUTFILE "echo omake exit code %omake_errorlevel% stored in %OMAKE_RET%\n";
      print OUTFILE "echo set omake_errorlevel=%omake_errorlevel% >> %OMAKE_RET%\n";
      close (OUTFILE);

      if($jenkins_flag) {
          open (OUTFILE, ">>$Path_var\\viewEnvironment.bat") or die "Error: unable to create $ARGV[0]\\viewEnvironment.bat File";
          print OUTFILE "set env_set=$SWTOOLS_ROOT\\Esprit\\system_1\\__utility\\make_util\n";
          print OUTFILE "set SWTOOL=$SWTOOLS_ROOT\n";
          print OUTFILE "set AlmSwBuildCfgPath=$AlmSwBuildCfgPath\n";
          print OUTFILE "set imp_set=$vob_path\n";
		  print OUTFILE "set AlmWorkspacePath=$AlmWorkspacePath\n";
          print OUTFILE "set dep_set=$VAR_PATH\\\n";
          print OUTFILE "set test_set=$PROJ_VOB\\TestSet\n";
          my $VAR_PATH_sk = $VAR_PATH;
          $VAR_PATH_sk =~ s/\\\\/\\/g;
          print OUTFILE "set loc_set=$VAR_PATH_sk\n";
          print OUTFILE "set loc_bas_set=$BAS_PATH\\\n";
          print OUTFILE "set loc_obj_set=$VAR_PATH\\OBJ\n";
          print OUTFILE "set DAMOS_C_PATH=$VAR_PATH\\Damos\\\n";
          print OUTFILE "set CCASE_MAKE_COMPAT=gnu\n";
          print OUTFILE "set GHS_LMHOST=@@0rb-lic0.de.bosch.com\n";
          print OUTFILE "set GHS_LMWHICH=ghs\n";
          close (OUTFILE);
          print "**************************************************************\n";
          print "* Files viewEnvironment.exe in Dir. C:\JenkinsBuild\   *\n";
          print "* successfully created!                                      *\n";
          print "**************************************************************\n";
      }
# make.mak anlegen
# 1.  Variablen in make-File
      open (OUTFILE, ">$VAR_PATH\\make3.tmp") or die "Error: unable to create $VAR_PATH\\make3.tmp File";
      print OUTFILE "set env_set=$SWTOOLS_ROOT\\Esprit\\system_1\\__utility\\make_util\n";
      print OUTFILE "set SWTOOL=$SWTOOLS_ROOT\n";
      print OUTFILE "set AlmSwBuildCfgPath=$AlmSwBuildCfgPath\n";
      print OUTFILE "set AlmProjectPath=$AlmProjectPath\n";
      print OUTFILE "set AlmDepPath=$AlmDepPath\n";
      print OUTFILE "set AlmRWSPath=$AlmRWSPath\n";
      print OUTFILE "set imp_set=$vob_path\n";
      print OUTFILE "set AlmWorkspacePath=$AlmWorkspacePath\n";
      print OUTFILE "set dep_set=$VAR_PATH\\\n";
      print OUTFILE "set test_set=$PROJ_VOB\\TestSet\n";
      print OUTFILE "set loc_set=$VAR_PATH\n";
      print OUTFILE "set loc_bas_set=$BAS_PATH\\\n";
      print OUTFILE "set loc_obj_set=$VAR_PATH\\OBJ\n";
      print OUTFILE "set DAMOS_C_PATH=$VAR_PATH\\Damos\n";
      print OUTFILE "set CCASE_MAKE_COMPAT=gnu\n";
      # print OUTFILE "set GHS_LMHOST=@@0rb-lic0.de.bosch.com\n";
      # print OUTFILE "set GHS_LMWHICH=ghs\n";
      $Laufwerk = substr($VAR_PATH,0,2); 
      print OUTFILE "$Laufwerk\n";
      close (OUTFILE);
      
# 2. Make-Template anhaengen
      print "copy $VAR_PATH\\make3.tmp + $template_dir\\$make_temp_file $VAR_PATH\\make3.bat\n";
      system("cmd /c copy $VAR_PATH\\make3.tmp + $template_dir\\$make_temp_file $VAR_PATH\\make3.bat");
      system("del $VAR_PATH\\make3.tmp");
      $PRJ_PATH = $VAR_PATH;
      print "\n";
      print "**************************************************************\n";
      print "* Files make3.bat and user_variables.mak in Dir. $VAR_PATH   *\n";
      print "* successfully created!                                      *\n";
      print "**************************************************************\n";	  
	  
#      Check_Prj();

    }
    else {
        Win32::MsgBox("$template_dir\\$make_temp_file missing, not a valid SWDE-View on $SWTOOLS_ROOT mounted",48,'Error!');
        exit;
    }

}





MainLoop;





#******************************************************************************
# sub ChangeMainWindowCursor
#
# Cursor generell aendern, z.B. Sanduhr (watch) wenn beschaeftigt
#******************************************************************************

# wird aktuell nicht verwendet
	sub ChangeMainWindowCursor
	{
	    my $cursor = shift;
	    $mw->configure(-cursor => $cursor);
	    $mw->update();
	} # ChangeMainWindowCursor


}





