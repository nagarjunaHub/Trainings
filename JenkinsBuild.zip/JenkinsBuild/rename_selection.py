import sys
import fileinput


old_variant=sys.argv[1]
new_variant=sys.argv[2]
selection_path=sys.argv[3]
# replace all occurrences of 'sit' with 'SIT' and insert a line after the 5th
for i, line in enumerate(fileinput.input(selection_path, inplace=1)):
    sys.stdout.write(line.replace(old_variant, new_variant))  # replace and write
    
