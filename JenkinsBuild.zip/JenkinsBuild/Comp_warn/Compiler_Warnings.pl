#!/usr/bin/perl
use warnings;
#use Spreadsheet::ParseExcel;
use File::Basename;
use File::Path;
use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
use Win32::OLE::Variant;
use Win32::OLE::NLS qw(:LOCALE :DATE);
use Fcntl;                # for 'sysopen'
use Cwd 'getcwd';         # for 'getcwd'
$Win32::OLE::Warn = 3; # Die on Errors. 
# die on errors...;

$datestring = localtime();
print "start time $datestring\n";
$COMPILER_LOG = $ARGV[0];
$BIN_PATH = $ARGV[1];
open (DATAI,'<',"$COMPILER_LOG\\compiler.log") || die "Can't open $COMPILER_LOG\\compiler.log";
my $COMPILER_WARNINGS_CSV = "$BIN_PATH\\Compiler_Warnings.xlsx";
# unless (-e $COMPILER_WARNINGS_CSV) {
# open (DATA, '>', $COMPILER_WARNINGS_CSV);
# print DATA "File Name,Line number,Warning Message\n";
# }
# else{
	# open (DATA, '>', $COMPILER_WARNINGS_CSV);
# }
my @Source_ary = ();
my $Excel = Win32::OLE->GetActiveObject('Excel.Application')
        || Win32::OLE->new('Excel.Application', 'Quit');
$Excel->{DisplayAlerts}=0;  
my $Book = $Excel->Workbooks->Add();

$Book->SaveAs($COMPILER_WARNINGS_CSV);

#$Book->SaveAs($out_excelfile); #Good habit when working with OLE, save 
$Book = $Excel->Workbooks->Open($COMPILER_WARNINGS_CSV);    

my $row = 2;
my $Sheet = $Book->Worksheets(1);
$Sheet->{Name} = "WarningsList";
$Sheet->Cells(1,1)->{Value} = "File Name";
$Sheet->Cells(1,2)->{Value} = "Line No";
$Sheet->Cells(1,3)->{Value} = "Warning";

my @uniq_warnings_list = ();
 my @compiler_file = <DATAI>;
foreach $line (@compiler_file){
              if($line =~m/^"[\/\w\-]+\/([\w\-]+\.\w)",\s+line\s+(\d*)\s+\(col. \d+\)\:\s+warning\s+(.*)/){
				$line =~/^"[\/\w\-]+\/([\w\-]+\.\w)",\s+line\s+(\d*)\s+\(col. \d+\)\:\s+warning\s+(.*)/;
				# if ( !grep( /^$line$/, @uniq_warnings_list ) ) {
					# print "$line\n";
					push(@uniq_warnings_list,$line);
					$Sheet->Cells($row, 1)->{Value} = $1;
					$Sheet->Cells($row, 2)->{Value} = $2;
					$Sheet->Cells($row, 3)->{Value} = $3;
					push(@Source_ary,$1);
					$row = $row + 1;
				# }
            }
			elsif($line=~m/.*::Output=""[\/\w\-]+\/([\w\-]+\.\w)",\s+line\s+(\d*)\s+\(col. \d+\)\:\s+warning\s+(.*)/){
				$line=~/.*::Output=""[\/\w\-]+\/([\w\-]+\.\w)",\s+line\s+(\d*)\s+\(col. \d+\)\:\s+warning\s+(.*)/;
				# if ( !grep( /^$line$/, @uniq_warnings_list ) ) {
					# push(@uniq_warnings_list,$line);				
					$Sheet->Cells($row, 1)->{Value} = $1;
					$Sheet->Cells($row, 2)->{Value} = $2;
					$Sheet->Cells($row, 3)->{Value} = $3;
					push(@Source_ary,$1);
					$row = $row + 1;
				# }
			}

}
my $War_Cnt_Sheet = $Book->Worksheets->Add({After=>$Book->Worksheets($Book->Worksheets->{Count})}) or die Win32::OLE->LastError();  
$War_Cnt_Sheet->{Name} = "WarningsCount";
$War_Cnt_Sheet->Activate(); 
$War_Cnt_Sheet->Cells(1, 1)->{Value} = "File Name";
$War_Cnt_Sheet->Cells(1, 2)->{Value} = "Warnings Count";
my @sorted_ary = sort(@Source_ary);
my $prev="";
$row = 2;
my $count=0;
foreach my $element (@sorted_ary) {
	if($prev ne $element){
		if($count !=0) {
			$War_Cnt_Sheet->Cells($row, 1)->{Value} = $prev;
			$War_Cnt_Sheet->Cells($row, 2)->{Value} = $count;
			# print "$prev\t$count\n";
			$row = $row + 1;
		}
		$prev = $element;
		$count = 0;
	}
	$count = $count + 1;
}
	if($count !=0) {
		$War_Cnt_Sheet->Cells($row, 1)->{Value} = $prev;
		$War_Cnt_Sheet->Cells($row, 2)->{Value} = $count;
		# print "$prev\t$count\n";
		$row = $row + 1;
	}

$Book->Save();
$Book = $Excel->Workbooks->Close(); 

$datestring = localtime();
print "end time $datestring\n";

