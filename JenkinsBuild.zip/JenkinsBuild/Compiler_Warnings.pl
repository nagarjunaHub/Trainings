#!/usr/bin/perl
use warnings;
#use Spreadsheet::ParseExcel;
use POSIX qw(strftime);
use File::Basename;
use File::Path;
use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
use Win32::OLE::Variant;
use Win32::OLE::NLS qw(:LOCALE :DATE);
use Fcntl;                # for 'sysopen'
use Cwd 'getcwd';         # for 'getcwd'
$Win32::OLE::Warn = 3; # Die on Errors. 
# die on errors...;
$COMPILER_LOG = $ARGV[0];
$BIN_PATH = $ARGV[1];
my $BUILD_NUMBER = $ARGV[2];
my $date = strftime "%m_%d_%Y_", localtime;
my $BUILD_DATE = $date."".$BUILD_NUMBER;
print $BUILD_DATE;
open (DATAI,'<',"$COMPILER_LOG") || die "Can't open $COMPILER_LOG";
my $COMPILER_WARNINGS_CSV = "$BIN_PATH\\Compiler_Warnings_$BUILD_DATE.xlsx";
# unless (-e $COMPILER_WARNINGS_CSV) {
# open (DATA, '>', $COMPILER_WARNINGS_CSV);
# print DATA "File Name,Line number,Warning Message\n";
# }
# else{
	# open (DATA, '>', $COMPILER_WARNINGS_CSV);
# }
my @Source_ary = ();
my $Excel = Win32::OLE->GetActiveObject('Excel.Application')
        || Win32::OLE->new('Excel.Application', 'Quit');
$Excel->{DisplayAlerts}=0;  
my $Book = $Excel->Workbooks->Add();

$Book->SaveAs($COMPILER_WARNINGS_CSV);

#$Book->SaveAs($out_excelfile); #Good habit when working with OLE, save 
$Book = $Excel->Workbooks->Open($COMPILER_WARNINGS_CSV);    

my $row = 2;
my $Sheet = $Book->Worksheets(1);
$Sheet->{Name} = "WarningsList";
$Sheet->Cells(1,1)->{Value} = "File Name";
$Sheet->Cells(1,2)->{Value} = "Line No";
$Sheet->Cells(1,3)->{Value} = "Warning";
$Sheet->Cells(1,4)->{Value} = "Message";

 my @compiler_file = <DATAI>;
foreach $line (0 .. $#compiler_file){
              if($compiler_file[$line] =~m/^"\w\:\/[\/\w\-]+\/\.\w+\/[\/\w\-]+\/([\w\-]+\.\w)",\s+line\s+(\d*)\:\s+warning\s+(#(\d+).*):/){
				$compiler_file[$line] =~m/^"\w\:\/[\/\w\-]+\/\.\w+\/[\/\w\-]+\/([\w\-]+\.\w)",\s+line\s+(\d*)\:\s+warning\s+(#(\d+).*):/;				
				$Sheet->Cells($row, 1)->{Value} = $1;
				$Sheet->Cells($row, 2)->{Value} = $2;
				$Sheet->Cells($row, 3)->{Value} = $3;
				$Sheet->Cells($row, 4)->{Value} = $compiler_file[$line+1];
				push(@Source_ary,$1);
				$row = $row + 1;
            }
			
}
my $War_Cnt_Sheet = $Book->Worksheets->Add({After=>$Book->Worksheets($Book->Worksheets->{Count})}) or die Win32::OLE->LastError();  
$War_Cnt_Sheet->{Name} = "WarningsCount";
$War_Cnt_Sheet->Activate(); 
$War_Cnt_Sheet->Cells(1, 1)->{Value} = "File Name";
$War_Cnt_Sheet->Cells(1, 2)->{Value} = "Warnings Count";
my @sorted_ary = sort(@Source_ary);
my $prev="";
$row = 2;
my $count=0;
foreach my $element (@sorted_ary) {
	if($prev ne $element){
		if($count !=0) {
			$War_Cnt_Sheet->Cells($row, 1)->{Value} = $prev;
			$War_Cnt_Sheet->Cells($row, 2)->{Value} = $count;
			# print "$prev\t$count\n";
			$row = $row + 1;
		}
		$prev = $element;
		$count = 0;
	}
	$count = $count + 1;
}
	if($count !=0) {
		$War_Cnt_Sheet->Cells($row, 1)->{Value} = $prev;
		$War_Cnt_Sheet->Cells($row, 2)->{Value} = $count;
		# print "$prev\t$count\n";
		$row = $row + 1;
	}

$Book->Save();
$Book = $Excel->Workbooks->Close(); 


