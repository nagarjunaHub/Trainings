#
#  This script checks the existence of the source files and the test files.
#
#  The correct command looks like:
#  <path of the perl.exe>\perl.exe mdTstAbdeckung.pl <path of the source files> <path of the test files>
#
#  For example:
#  G:\Documents\Books\Perl\v5_8_8_817\bin\perl.exe mdTstAbdeckung.pl O:\ED_EPS_PP\ImplementationSet\Drive\DeviceLayer\ECUControl\ O:\ED_EPS_PP\TestSet\Module\Drive\DeviceLayer\ECUControl\
#
#
#  Does not work? Then you should check the next points.
#  1. Did you chose the right path for your perl.exe?
#  2. Is it really available?
#  3. Are the paths for the files to check correct?
#  4. Are your vobs mounted?
#  5. Are the case of the letters in the paths correct?
#  6. Do you have access to the necessary folders?
#
#  AUTOR:   Markus Jung BPTE
#  DATE:    2014.06.05
#  FILE:    filechecker.pl
#  VERSION: 1.5
#
use English;
use File::Basename;
use File::Find;
use FileHandle;
use strict;
use Data::Dumper;
# use Time::Piece;
use POSIX;
use Getopt::Std;
use List::Util qw/ max min /;


#for Date Update according to history of a file delivered in RTC
 # use Date::Parse;
 # use DateTime;


 # get and save current working directory
use Cwd;
my $curdir = getcwd;

# --------------------------------------------------------------------------------------------------
# Preparations for Getopt
# initialize options as empty
my %opts = ();
# get commandline options
getopts ('s:t:o:h', \%opts);
usage() if (!keys (%opts));
usage() if ($opts{'h'});
sub usage {
  $0 =~ s,.*/,,g;
  print <<EOT;
#  usage: $0 [options]
#  options:
#    Arguments to options must be quoted '' or "" under UNIX if wildcards are used,
#    because the SHELL would otherwise interpolate the ARGS
#    -h         help, this message!
#    -s [DIR]   Source-Tree containing Source-Files
#    -t [DIR]   Test-Set containing Q-Documents
#    -o [PATH]  Path to result file
EOT
  exit 1;
}
# --------------------------------------------------------------------------------------------------



################# Variables ##########
my $md_pfad;   # Module path - source files will be searched there
my $tl_pfad;   # Testlist path - test files will be searched there
my $project_id;   # This script is able to check the files of the EFS, EPS and SSM2 projects.
                  # No additional parameters are necessary to set the project, because the
                  # script "detects", which project is being checked.
                  # project_id = 0 -> EFS, EPS, project_id = 1 -> SSM2, project_id = 10 -> error
                  # This whole thing is important at the creation of the output.

my $g_postfix;
my $g_extension;
my $fd_dir;
# source files
my @md_array;
my @cc_array;
my @mc_array;
my @c_array;

my @md_date_array;
my @cc_date_array;
my @mc_date_array;
my @c_date_array;

my @cc_size_array;
my @mc_size_array;
my @c_size_array;

# modul test (vcar) files
my @tl_array;
my @ft_array;
my @po_array;
my @ti_array;
my @tr_array;
my @cmo_array;
my @cmt_array;

my @tl_date_array;
my @ft_date_array;
my @po_date_array;
my @ti_date_array;
my @tr_date_array;
my @cmo_date_array;
my @cmt_date_array;

# compulsory test files
my @mr_array;
my @me_array;
my @ps_array;
my @ptu_array;
my @co_array;
my @th_array;
my @thz_array;

my @mr_date_array;
my @me_date_array;
my @ps_date_array;
my @ptu_date_array;
my @co_date_array;
my @th_date_array;
my @thz_date_array;

my @co_warnings_array;
my $co_warnings_index = 0;

# review file
my @rs_array;
my @rsxls_array;
my @rd_array;
my @rdxls_array;
my @rc_array;
my @rcxls_array;
my @ri_array;
my @rixls_array;
my @ru_array;
my @rg_array;
my @ruxls_array;
my @rgxls_array;
my @rt_array;
my @rtxls_array;

my @rs_date_array;
my @rsxls_date_array;
my @rd_date_array;
my @rdxls_date_array;
my @rc_date_array;
my @rcxls_date_array;
my @ri_date_array;
my @rixls_date_array;
my @ru_date_array;
my @rg_date_array;
my @ruxls_date_array;
my @rgxls_date_array;
my @rt_date_array;
my @rtxls_date_array;

my @l_array;
my @l_date_array;
my @l_size_array;
my @result_array;
my @result_todo_array;
my $ofh;
my $l_maxnotdone;

my $workspace = $ENV{"WORKSPACE"};

# 
my $cc_count;
my $mc_count;
my $arxml_count;
my $sbsx_count;
my $co_count;
my $mr_count;
my $me_count;
my $ptu_count;
my $ps_count;
my $th_count;
my $tl_count;
my $ft_count;
my $ti_count;
my $cmt_count;
my $tr_count;
my $cmo_count;
my $po_count;
my $rs_count;
my $rd_count;
my $rc_count;
my $ri_count;
my $ru_count;
my $rg_count;
my $rt_count;

my $cc_countupdate;
my $arxml_countupdate;
my $sbsx_countupdate;
my $mc_countupdate;
my $co_countupdate;
my $mr_countupdate;
my $me_countupdate;
my $ptu_countupdate;
my $ps_countupdate;
my $th_countupdate;
my $tl_countupdate;
my $ft_countupdate;
my $ti_countupdate;
my $cmt_countupdate;
my $tr_countupdate;
my $cmo_countupdate;
my $po_countupdate;
my $rs_countupdate;
my $rd_countupdate;
my $rc_countupdate;
my $ri_countupdate;
my $ru_countupdate;
my $rg_countupdate;
my $rt_countupdate;

my $ps_counttoupdate;
my $mr_counttoupdate;
my $me_counttoupdate;
my $arxml_counttoupdate;
my $sbsx_counttoupdate;
my $co_counttoupdate;
my $rs_counttoupdate;
my $rd_counttoupdate;
my $rc_counttoupdate;
my $ri_counttoupdate;
my $ru_counttoupdate;
my $rg_counttoupdate;
my $rt_counttoupdate;
my $ptu_counttoupdate;

my @cc_remaining;
my @mc_remaining;
my @co_remaining;
my @mr_remaining;
my @me_remaining;
my @ptu_remaining;
my @ps_remaining;
my @th_remaining;
my @tl_remaining;
my @ft_remaining;
my @ti_remaining;
my @cmt_remaining;
my @tr_remaining;
my @cmo_remaining;
my @po_remaining;
my @rs_remaining;
my @rd_remaining;
my @rc_remaining;
my @ri_remaining;
my @ru_remaining;
my @rg_remaining;
my @rt_remaining;
my @arxml_remaining;
my @sbsx_remaining;

my @fd_array;
my $l_actualfd;
my $fd_dir;
my $l_position = 50;

my $variant_name;

$md_pfad = $opts{'s'};
$tl_pfad = $opts{'t'};
$variant_name = @ARGV[0];

$fd_dir = $md_pfad;
printf "\n This script checks the completness of the necessary files.\n";
printf "\n Module path :    			<%s>", $md_pfad;
printf "\n Test path :      			<%s>", $tl_pfad;
printf "\n Feature Data path :          <%s>", $fd_dir;

printf "\n\n variant_name : $variant_name \n\n";
printf "\n -------\n";

my ($sec, $min, $hour, $mday, $mon, $year) = localtime(time);
$mon += 1;      # To correct the 0-based result
$year += 1900;  # To correct the 1900-based counting
$mon = sprintf("%02d", $mon);     # make month & day of month 0-padded
$mday = sprintf("%02d", $mday);	
my $Credentials_File = "$curdir\\"."$variant_name"."_Rtc_Credentials.txt";
my $Stream_Database = "$curdir\\"."$variant_name"."_Database_${year}-${mon}-${mday}".".txt";	
my $Password_encrpt_file = "$curdir\\GetStreamHistory\\password.encrypted";

### Generate Stream Database file
if(-e $Stream_Database) {
	unlink $Stream_Database or die "$Stream_Database: $!";
}
print "java -jar $curdir\\GetStreamHistory\\FileChecker.jar $Credentials_File $Stream_Database $md_pfad $Password_encrpt_file\n";
system("java -jar $curdir\\GetStreamHistory\\FileChecker.jar $Credentials_File $Stream_Database $md_pfad $Password_encrpt_file");
sub FilesFind($);
sub CheckExistenceOfFiles($$$\@\@\@);
sub CheckVcarFiles;

opendir my $dir, $fd_dir or die "Cannot open directory: $!";
@fd_array = readdir $dir;

##### Search for files - the postfix and the extension must be given in the global variables ####
# Search for source files
# C source files - _cc.c
$g_postfix = '_cc';
$g_extension = 'c';
my ($cc_array_ref, $cc_date_array_ref, $cc_size_array_ref) = FilesFind($md_pfad);
@cc_array = @$cc_array_ref;
@cc_date_array = @$cc_date_array_ref;
@cc_size_array = @$cc_size_array_ref;

# C Matlab source files - _mc.c
$g_postfix = '_mc';
$g_extension = 'c';
my ($mc_array_ref, $mc_date_array_ref, $mc_size_array_ref) = FilesFind($md_pfad);
@mc_array = @$mc_array_ref;
@mc_date_array = @$mc_date_array_ref;
@mc_size_array = @$mc_size_array_ref;

# C source files without _mc and _cc as postfix - *.c
$g_postfix = '';
$g_extension = 'c';
my ($c_array_ref, $c_date_array_ref, $c_size_array_ref) = FilesFind($md_pfad);
@c_array = @$c_array_ref;
@c_date_array = @$c_date_array_ref;
@c_size_array = @$c_size_array_ref;
my @arxml_array;
my @arxml_date_array;
my @arxml_size_array;
my $l;
$g_postfix = 'ArItf';
$g_extension = 'arxml';
my ($arxml_array_ref, $arxml_date_array_ref) = FilesFind($tl_pfad);
@arxml_array = @$arxml_array_ref;
@arxml_date_array = @$arxml_date_array_ref;

my @sbsx_array;
my @sbsx_date_array;
$g_postfix = '';
$g_extension = 'sbsx';
my ($sbsx_array_ref, $sbsx_date_array_ref) = FilesFind($tl_pfad);
@sbsx_array = @$sbsx_array_ref;
@sbsx_date_array = @$sbsx_date_array_ref;


#### Search for compulsory files
# Compiler output - _co.log
$g_postfix = '_co';
$g_extension = 'txt';
my ($co_array_ref, $co_date_array_ref) = FilesFind($tl_pfad);
@co_array = @$co_array_ref;
@co_date_array = @$co_date_array_ref;
# Misra result - _mr.html
$g_postfix = '_mr';
$g_extension = 'html';
my ($mr_array_ref, $mr_date_array_ref) = FilesFind($tl_pfad);
@mr_array = @$mr_array_ref;
@mr_date_array = @$mr_date_array_ref;
# Software metric results - _me.html
$g_postfix = '_me';
$g_extension = 'html';
my ($me_array_ref, $me_date_array_ref) = FilesFind($tl_pfad);
@me_array = @$me_array_ref;
@me_date_array = @$me_date_array_ref;
# Naming rules result - _ptu.html
$g_postfix = '_cc';
$g_extension = 'ptu';
my ($ptu_array_ref, $ptu_date_array_ref) = FilesFind($tl_pfad);
@ptu_array = @$ptu_array_ref;
@ptu_date_array = @$ptu_date_array_ref;
# Polyspace result - _ps.zip
$g_postfix = '_ps';
$g_extension = 'zip';
my ($ps_array_ref, $ps_date_array_ref) = FilesFind($tl_pfad);
@ps_array = @$ps_array_ref;
@ps_date_array = @$ps_date_array_ref;
# TH test header - _th.h
$g_postfix = '_th';
$g_extension = 'h';
my ($th_array_ref, $th_date_array_ref) = FilesFind($tl_pfad);
@th_array = @$th_array_ref;
@th_date_array = @$th_date_array_ref;
$g_postfix = '_th';
$g_extension = 'zip';
my ($thz_array_ref, $thz_date_array_ref) = FilesFind($tl_pfad);
@thz_array = @$thz_array_ref;
@thz_date_array = @$thz_date_array_ref;
# Test list - _tl.txt
$g_postfix = '_tl';
$g_extension = 'txt';
my ($tl_array_ref, $tl_date_array_ref) = FilesFind($tl_pfad);
@tl_array = @$tl_array_ref;
@tl_date_array = @$tl_date_array_ref;

#### Search for modul test files
# Parser output - _po.txt
$g_postfix = '_po';
$g_extension = 'txt';
my ($po_array_ref, $po_date_array_ref) = FilesFind($tl_pfad);
@po_array = @$po_array_ref;
@po_date_array = @$po_date_array_ref;
# Vcar test input - _ti.txt
$g_postfix = '_ti';
$g_extension = 'txt';
my ($ti_array_ref, $ti_date_array_ref) = FilesFind($tl_pfad);
@ti_array = @$ti_array_ref;
@ti_date_array = @$ti_date_array_ref;
# Vcar test reference - _tr.odat
$g_postfix = '_tr';
$g_extension = 'odat';
my ($tr_array_ref, $tr_date_array_ref) = FilesFind($tl_pfad);
@tr_array = @$tr_array_ref;
@tr_date_array = @$tr_date_array_ref;
# Vcar test input colouring - _ti.cmt
$g_postfix = '_ti';
$g_extension = 'cmt';
my ($cmt_array_ref, $cmt_date_array_ref) = FilesFind($tl_pfad);
@cmt_array = @$cmt_array_ref;
@cmt_date_array = @$cmt_date_array_ref;
# Vcar test reference colouring - _tr.cmo
$g_postfix = '_tr';
$g_extension = 'cmo';
my ($cmo_array_ref, $cmo_date_array_ref) = FilesFind($tl_pfad);
@cmo_array = @$cmo_array_ref;
@cmo_date_array = @$cmo_date_array_ref;
# Modul test documentation - _ft.doc
$g_postfix = '_ft';
$g_extension = 'doc';
my ($ft_array_ref, $ft_date_array_ref) = FilesFind($tl_pfad);
@ft_array = @$ft_array_ref;
@ft_date_array = @$ft_date_array_ref;

$g_postfix = '_ft';
$g_extension = 'docx';
my ($ft_docx_array_ref, $ft_docx_date_array_ref) = FilesFind($tl_pfad);
my @ft_docx_array = @$ft_docx_array_ref;
my @ft_docx_date_array = @$ft_docx_date_array_ref;

@ft_array = (@ft_array , @ft_docx_array);
@ft_date_array = (@ft_date_array , @ft_docx_date_array) ;

#### Search for modul review files
# Review documentation - _rs.xls
$g_postfix = '_rs';
$g_extension = 'xlsm';
my ($rs_array_ref, $rs_date_array_ref) = FilesFind($fd_dir);
@rs_array = @$rs_array_ref;
@rs_date_array = @$rs_date_array_ref;

$g_postfix = '_rs';
$g_extension = 'xls';
my ($rsxls_array_ref, $rsxls_date_array_ref) = FilesFind($fd_dir);
@rsxls_array = @$rsxls_array_ref;
@rsxls_date_array = @$rsxls_date_array_ref;

@rs_array = (@rs_array , @rsxls_array);
@rs_date_array = (@rs_date_array , @rsxls_date_array) ;

# Review documentation - _rd.xlsm
$g_postfix = '_rd';
$g_extension = 'xlsm';
my ($rd_array_ref, $rd_date_array_ref) = FilesFind($tl_pfad);
@rd_array = @$rd_array_ref;
@rd_date_array = @$rd_date_array_ref;

$g_postfix = '_rd';
$g_extension = 'xls';
my ($rdxls_array_ref, $rdxls_date_array_ref) = FilesFind($tl_pfad);
@rdxls_array = @$rdxls_array_ref;
@rdxls_date_array = @$rdxls_date_array_ref;

@rd_array = (@rd_array , @rdxls_array);
@rd_date_array = (@rd_date_array , @rdxls_date_array) ;

# Review documentation - _rc.xlsm
$g_postfix = '_rc';
$g_extension = 'xlsm';
my ($rc_array_ref, $rc_date_array_ref) = FilesFind($tl_pfad);
@rc_array = @$rc_array_ref;
@rc_date_array = @$rc_date_array_ref;

$g_postfix = '_rc';
$g_extension = 'xls';
my ($rcxls_array_ref, $rcxls_date_array_ref) = FilesFind($tl_pfad);
@rcxls_array = @$rcxls_array_ref;
@rcxls_date_array = @$rcxls_date_array_ref;

@rc_array = (@rc_array , @rcxls_array);
@rc_date_array = (@rc_date_array , @rcxls_date_array) ;

# Review documentation - _ri.xlsm
$g_postfix = '_ri';
$g_extension = 'xlsm';
my ($ri_array_ref, $ri_date_array_ref) = FilesFind($tl_pfad);
@ri_array = @$ri_array_ref;
@ri_date_array = @$ri_date_array_ref;

$g_postfix = '_ri';
$g_extension = 'xls';
my ($rixls_array_ref, $rixls_date_array_ref) = FilesFind($tl_pfad);
@rixls_array = @$rixls_array_ref;
@rixls_date_array = @$rixls_date_array_ref;

@ri_array = (@ri_array , @rixls_array);
@ri_date_array = (@ri_date_array , @rixls_date_array) ;

# Review documentation - _rm.xlsm
$g_postfix = '_ru';
$g_extension = 'xlsm';
my ($ru_array_ref, $ru_date_array_ref) = FilesFind($tl_pfad);
@ru_array = @$ru_array_ref;
@ru_date_array = @$ru_date_array_ref;

$g_postfix = '_ru';
$g_extension = 'xls';
my ($ruxls_array_ref, $ruxls_date_array_ref) = FilesFind($tl_pfad);
@ruxls_array = @$ruxls_array_ref;

@ruxls_date_array = @$ruxls_date_array_ref;
@ru_array = (@ru_array , @ruxls_array);
@ru_date_array = (@ru_date_array , @ruxls_date_array) ;

# Review documentation - _rg.xlsm
$g_postfix = '_rg';
$g_extension = 'xlsm';
my ($rg_array_ref, $rg_date_array_ref) = FilesFind($tl_pfad);
@rg_array = @$rg_array_ref;
@rg_date_array = @$rg_date_array_ref;

$g_postfix = '_rg';
$g_extension = 'xls';
my ($rgxls_array_ref, $rgxls_date_array_ref) = FilesFind($tl_pfad);
@rgxls_array = @$rgxls_array_ref;
@rgxls_date_array = @$rgxls_date_array_ref;

@rg_array = (@rg_array , @rgxls_array);
@rg_date_array = (@rg_date_array , @rgxls_date_array) ;
# Review documentation - _rt.xlsm
$g_postfix = '_rt';
$g_extension = 'xlsm';
my ($rt_array_ref, $rt_date_array_ref) = FilesFind($fd_dir);
@rt_array = @$rt_array_ref;
@rt_date_array = @$rt_date_array_ref;

$g_postfix = '_rt';
$g_extension = 'xls';
my ($rtxls_array_ref, $rtxls_date_array_ref) = FilesFind($fd_dir);
@rtxls_array = @$rtxls_array_ref;
@rtxls_date_array = @$rtxls_date_array_ref;

@rt_array = (@rt_array , @rtxls_array);
@rt_date_array = (@rt_date_array , @rtxls_date_array) ;

# There are some moduls, which do not contain _cc.c files. These modules has to be listed
# and checked also. So we have to combine the _cc.c and the _mc.c lists.
&CombineLists;

&CheckVcarFiles;

# We have now the list of the files, we have to compare it to the modul list
# Checking the source files
@cc_array = &CheckExistenceOfFiles(0,'_cc','c',\@cc_array,\@cc_date_array,\@cc_size_array);
@mc_array = &CheckExistenceOfFiles(0,'_mc','c',\@mc_array,\@mc_date_array,\@mc_size_array);
@c_array = &CheckExistenceOfFiles(0,'','c',\@c_array,\@c_date_array,\@c_size_array);

# Checking the compulsory files
my @dummy;
@arxml_array = &CheckExistenceOfFiles(0,'_ArItf','arxml',\@arxml_array,\@arxml_date_array,\@dummy);


@sbsx_array = &CheckExistenceOfFiles(0,'','sbsx',\@sbsx_array,\@sbsx_date_array,\@dummy);

@co_array = &CheckExistenceOfFiles(0,'_co','txt',\@co_array,\@co_date_array,\@co_warnings_array);
@mr_array = &CheckExistenceOfFiles(0,'_mr','html',\@mr_array,\@mr_date_array,\@dummy);
@me_array = &CheckExistenceOfFiles(0,'_me','html',\@me_array,\@me_date_array,\@dummy);
@ptu_array = &CheckExistenceOfFiles(0,'_cc','ptu',\@ptu_array,\@ptu_date_array,\@dummy);
@ps_array = &CheckExistenceOfFiles(0,'_ps','zip',\@ps_array,\@ps_date_array,\@dummy);
@th_array = &CheckExistenceOfFiles(0,'_th','h',\@th_array,\@th_date_array,\@dummy);
@thz_array = &CheckExistenceOfFiles(0,'_th','zip',\@thz_array,\@thz_date_array,\@dummy);
@tl_array = &CheckExistenceOfFiles(0,'_tl','txt',\@tl_array,\@tl_date_array,\@dummy);

# Checking the modultest files
@ft_array = &CheckExistenceOfFiles(0,'_ft','docx',\@ft_array,\@ft_date_array,\@dummy);

@ti_array = &CheckExistenceOfFiles(1,'_ti','txt',\@ti_array,\@ti_date_array,\@dummy);
@cmt_array = &CheckExistenceOfFiles(1,'_ti','cmt',\@cmt_array,\@cmt_date_array,\@dummy);
@tr_array = &CheckExistenceOfFiles(1,'_tr','odat',\@tr_array,\@tr_date_array,\@dummy);
@cmo_array = &CheckExistenceOfFiles(1,'_tr','cmo',\@cmo_array,\@cmo_date_array,\@dummy);
@po_array = &CheckExistenceOfFiles(0,'_po','txt',\@po_array,\@po_date_array,\@dummy);

# Checking the review document file

@rs_array = &CheckExistanceOfFeatureData(0,'_rs',\@rs_array,\@rs_date_array,\@dummy);
@rd_array = &CheckExistenceOfFiles(0,'_rd','xlsm',\@rd_array,\@rd_date_array,\@dummy);
@rc_array = &CheckExistenceOfFiles(0,'_rc','xlsm',\@rc_array,\@rc_date_array,\@dummy);
@ri_array = &CheckExistenceOfFiles(0,'_ri','xlsm',\@ri_array,\@ri_date_array,\@dummy);
@ru_array = &CheckExistenceOfFiles(0,'_ru','xlsm',\@ru_array,\@ru_date_array,\@dummy);
@rg_array = &CheckExistenceOfFiles(0,'_rg','xlsm',\@rg_array,\@rg_date_array,\@dummy);
@rt_array = &CheckExistanceOfFeatureData(0,'_rt',\@rt_array,\@rt_date_array,\@dummy);


# The arraies with the 'X's and with '-'s are ready. But we are curious to know the exact numbers.

@cc_array = &CountXs(0,0,@cc_array);
@arxml_array = &CountXs(13,4,@arxml_array);
@sbsx_array = &CountXs(14,4,@sbsx_array);

@mc_array = &CountXs(0,0,@mc_array);
@ps_array = &CountXs(1,1,@ps_array);
@mr_array = &CountXs(2,1,@mr_array);
@me_array = &CountXs(3,1,@me_array);
@co_array = &CountXs(4,1,@co_array);
@ptu_array = &CountXs(11,3,@ptu_array);

@rs_array = &CountXs(5,4,@rs_array);
@rd_array = &CountXs(6,4,@rd_array);
@rc_array = &CountXs(7,4,@rc_array);
@ri_array = &CountXs(8,4,@ri_array);
@ru_array = &CountXs(9,4,@ru_array);
@rg_array = &CountXs(12,4,@rg_array);
@rt_array = &CountXs(10,4,@rt_array);
@rt_array = &CountXs(10,4,@rt_array);


&ResultList;
&ResultListToDoList;
&PrintResult;

#-------------------------------------------------------
#         Definitions of the functions
#-------------------------------------------------------

## CountXs
#
#  This function counts the number of 'X's in the parameter array
#  and puts the result after the last element of the array.
#
sub CountXs($\$\@){
   my ($eventid,$enabledatecheck,@l_tocheckarray) = @_;
      
   my $l_counter;
   my $l_xcounter = 0;
   my $l_notdonecounter = 0;
   my $l_notupdatedcounter = 0;
   my $l_tocompare;
   my $l_found = 0;
   my @l_remaining;
   my @l_tocheckarraylocal;

   for ($l_counter = 0; $l_counter <=$#l_tocheckarray; $l_counter++) {
	  $l_found = 0;
	  
			if ($eventid == 11)
			{
				if ($ptu_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $ptu_array[$l_counter];
				}
				elsif ($ft_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $ft_array[$l_counter];
				}
				elsif ($tl_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $tl_array[$l_counter];
				}
				elsif ($th_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $th_array[$l_counter];
				}
				elsif ($ti_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $ti_array[$l_counter];
				}
				elsif ($po_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $po_array[$l_counter];
				}
				elsif ($thz_array[$l_counter] ne '   -    ')
				{
					$l_tocheckarraylocal[$l_counter] = $thz_array[$l_counter];
				}
				else
				{
					$l_tocheckarraylocal[$l_counter] = '   -    ';
				}
				
			}
			else
			{
				$l_tocheckarraylocal[$l_counter] = $l_tocheckarray[$l_counter];
			}
	  
	  
      if ( ($l_tocheckarraylocal[$l_counter] ne '   -    ') && ($l_tocheckarraylocal[$l_counter] ne '    -        -  ') && ($l_tocheckarraylocal[$l_counter] ne '    -         -') ){
         # An 'X' was found, let's increment the value of the counter for 'X's.

		  if ($enabledatecheck != 0)
		  {
			
			  if ( (($eventid == 1) || ($eventid == 2) || ($eventid == 3) || ($eventid == 4))  && ($cc_array[$l_counter] eq '    -        -  ') )
			  {
			  }
elsif ( (($eventid == 5) || ($eventid == 6) || ($eventid == 7) || ($eventid == 8) || ($eventid == 9) || ($eventid == 10) || ($eventid == 11)|| ($eventid == 12)|| ($eventid == 13)|| ($eventid == 14))     && ( ($cc_array[$l_counter] eq '    -        -  ') && ($mc_array[$l_counter] eq '    -        -  ') ) )
			  {
			  }
			  else
			  {
				if ($enabledatecheck == 1){
					$l_tocompare = $cc_array[$l_counter];
				}
				elsif ($enabledatecheck == 2){
					$l_tocompare = $mc_array[$l_counter];
				}
				elsif (($enabledatecheck == 3) || ($enabledatecheck == 4)){
					if ($cc_array[$l_counter] eq '    -        -  '){
						$l_tocompare = $mc_array[$l_counter];
					}
					else{
						$l_tocompare = $cc_array[$l_counter];
					}
				}
				
				my $date1 = $l_tocompare;
				my $date2;
				if ($eventid == 11)
				{
					if ($ptu_array[$l_counter] ne '   -    ')
					{
						$date2 = $ptu_array[$l_counter];
					}
					elsif ($ft_array[$l_counter] ne '   -    ')
					{
						$date2 = $ft_array[$l_counter];
					}
					elsif ($tl_array[$l_counter] ne '   -    ')
					{
						$date2 = $tl_array[$l_counter];
					}
					elsif ($th_array[$l_counter] ne '   -    ')
					{
						$date2 = $th_array[$l_counter];
					}
					elsif ($ti_array[$l_counter] ne '   -    ')
					{
						$date2 = $ti_array[$l_counter];
					}
					elsif ($po_array[$l_counter] ne '   -    ')
					{
						$date2 = $po_array[$l_counter];
					}
					elsif ($thz_array[$l_counter] ne '   -    ')
					{
						$date2 = $thz_array[$l_counter];
					}
					else
					{
						$date2 = '00.00.00';
					}
				}
				else
				{
					$date2 = $l_tocheckarray[$l_counter];
				}
				
				if ($enabledatecheck == 4)
				{
					$date2 = '99.99.99';
				}
				
				
				
				$date1 = substr($date1,0,8);
				my @date1Split = split(/\./, $date1);

				$date2 = substr($date2,0,8);
				my @date2Split = split(/\./, $date2);
				
				if ($date1Split[2] < $date2Split[2]) 
				{
					$l_found = 1;
				}
				elsif ($date1Split[2] == $date2Split[2])
				{
					if ($date1Split[1] < $date2Split[1])
					{
						$l_found = 1;
					}
					elsif ($date1Split[1] == $date2Split[1])
					{
						if ($date1Split[0] < $date2Split[0])
						{
							$l_found = 1;
						}
						elsif ($date1Split[0] == $date2Split[0])
						{
							$l_found = 1;
						}
					}
				}
				
				
			   }
		  }
		  else
		  {
			 $l_found = 1;
		  }
		  

		  
		  if ($l_found == 1)
		  {
			  $l_xcounter++;
		  }
		  else
		  {
					
			  if ((($eventid == 1) || ($eventid == 2) || ($eventid == 3) || ($eventid == 4))){
			  if ($cc_array[$l_counter] ne '    -        -  '){
			  $l_remaining[$l_notdonecounter] = $md_array[$l_counter];
			  $l_notdonecounter++;
			  $l_notupdatedcounter++;
			  }
		      }
			  #Feature data
		      if (($eventid == 5) || ($eventid == 10)){
					next if($fd_array[$l_counter] =~ /\Q.\E/);
					$l_remaining[$l_notdonecounter] = $fd_array[$l_counter];
					$l_notdonecounter++;
					$l_notupdatedcounter++;
			  }
		     
		       if ((($eventid == 6) || ($eventid == 7) || ($eventid == 8) || ($eventid == 9) || ($eventid == 11)|| ($eventid == 12)|| ($eventid == 13)|| ($eventid == 14))){
			  if ( ($cc_array[$l_counter] ne '    -        -  ') || ($mc_array[$l_counter] ne '    -        -  ') ){ 

	  
			  $l_remaining[$l_notdonecounter] = $md_array[$l_counter];
			  $l_notdonecounter++;
			  $l_notupdatedcounter++;
			  }
		   }
		  } 
      }
	  else
	  {
		   if ((($eventid == 1) || ($eventid == 2) || ($eventid == 3) || ($eventid == 4))){
			  if ($cc_array[$l_counter] ne '    -        -  '){
			  $l_remaining[$l_notdonecounter] = $md_array[$l_counter];
			  $l_notdonecounter++;
			  }
		   }
		 if (($eventid == 5) || ($eventid == 10)){
					next if($fd_array[$l_counter] =~ /\Q.\E/);
					$l_remaining[$l_notdonecounter] = $fd_array[$l_counter];
					$l_notdonecounter++;
					# $l_notupdatedcounter++;
			}
		   if (( ($eventid == 6) || ($eventid == 7) || ($eventid == 8) || ($eventid == 9) || ($eventid == 11) || ($eventid == 12)|| ($eventid == 13)|| ($eventid == 14))){
			  if ( ($cc_array[$l_counter] ne '    -        -  ') || ($mc_array[$l_counter] ne '    -        -  ') ){  
			  $l_remaining[$l_notdonecounter] = $md_array[$l_counter];
			  $l_notdonecounter++;
			  #$l_notupdatedcounter++;
			  }
		   }
      }
   }
   if ($eventid == 1){
		$ps_countupdate = $l_notdonecounter;
		$ps_counttoupdate = $l_notupdatedcounter;
		@ps_remaining = @l_remaining;
   }
   elsif ($eventid == 2){
		$mr_countupdate = $l_notdonecounter;
		$mr_counttoupdate = $l_notupdatedcounter;
		@mr_remaining = @l_remaining;
		
   }
   elsif ($eventid == 3){
		$me_countupdate = $l_notdonecounter;
		$me_counttoupdate = $l_notupdatedcounter;
		@me_remaining = @l_remaining;
   }
   elsif ($eventid == 4){
		$co_countupdate = $l_notdonecounter;
		$co_counttoupdate = $l_notupdatedcounter;
		@co_remaining = @l_remaining;
   }
   elsif ($eventid == 5){
		$rs_countupdate = $l_notdonecounter;
		$rs_counttoupdate = $l_notupdatedcounter;
		@rs_remaining = @l_remaining;
   }
   elsif ($eventid == 6){
		$rd_countupdate = $l_notdonecounter;
		$rd_counttoupdate = $l_notupdatedcounter;
		@rd_remaining = @l_remaining;
   }
   elsif ($eventid == 7){
		$rc_countupdate = $l_notdonecounter;
		$rc_counttoupdate = $l_notupdatedcounter;
		@rc_remaining = @l_remaining;
   }
   elsif ($eventid == 8){
		$ri_countupdate = $l_notdonecounter;
		$ri_counttoupdate = $l_notupdatedcounter;
		@ri_remaining = @l_remaining;
   }
 elsif ($eventid == 9){
		$ru_countupdate = $l_notdonecounter;
		$ru_counttoupdate = $l_notupdatedcounter;
		@ru_remaining = @l_remaining;
   }
   elsif ($eventid == 12){
		$rg_countupdate = $l_notdonecounter;
		$rg_counttoupdate = $l_notupdatedcounter;
		@rg_remaining = @l_remaining;
   }
   elsif ($eventid == 13){
		$arxml_countupdate = $l_notdonecounter;
		$arxml_counttoupdate = $l_notupdatedcounter;
		@arxml_remaining = @l_remaining;
   }
   elsif ($eventid == 14){
		$sbsx_countupdate = $l_notdonecounter;
		$sbsx_counttoupdate = $l_notupdatedcounter;
		@sbsx_remaining = @l_remaining;
   }
   
   elsif ($eventid == 10){
		$rt_countupdate = $l_notdonecounter;
		$rt_counttoupdate = $l_notupdatedcounter;
		@rt_remaining = @l_remaining;
   }
   elsif ($eventid == 11){
		$ptu_countupdate = $l_notdonecounter;
		$ptu_counttoupdate = $l_notupdatedcounter;
		@ptu_remaining = @l_remaining;
		$ft_countupdate = $l_notdonecounter;
		@ft_remaining = @l_remaining;
		$tl_countupdate = $l_notdonecounter;
		@tl_remaining = @l_remaining;
		$th_countupdate = $l_notdonecounter;
		@th_remaining = @l_remaining;
		$ti_countupdate = $l_notdonecounter;
		@ti_remaining = @l_remaining;
		$po_countupdate = $l_notdonecounter;
		@po_remaining = @l_remaining;
   }
	
   # We have now the number of 'X's. We can put it after the last element of the array.
   push (@l_tocheckarray, $l_xcounter);
   
   
   return (@l_tocheckarray);
}

## FillUpString
#
#  This function fills up the given string till the given
#  length with the given character.
#
sub FillUpString{
   my $l_str = $_[0];   # This string will be filled up
   my $l_len = $_[1];   # Till will be the string filled up
   my $l_chr = $_[2];   # With this character will be the string filled up
   my $l_is_len;
   my $l_ret;
   my $l_lauf;

   $l_is_len = length($l_str);

   if ($l_is_len >= $l_len) {
      $l_ret = substr($l_str,0,$l_len);
   } else {
      $l_ret = $l_str;
      for ($l_lauf = 0; $l_lauf < $l_len - $l_is_len; $l_lauf++) {
         $l_ret = $l_ret . $l_chr;
      }
   }
   return ($l_ret);
} # end sub FillUpString

## CombineLists
#
#  This function takes the lists of _cc.c and _mc.c files and create a
#  combined list from them. Combined means the union of the two lists.
#
sub CombineLists{
   my $l_mdcounter;
   my $l_cccounter;
   my $l_ccounter;
   my $l_IFoundThisInMdarray;
   my $l_IFoundThisAtPosition;
   my $l_acutalccname;

   # After the prozess, there must be more (or equal) _mc.c files, so this array is the base.
   for ($l_mdcounter = 0; $l_mdcounter <= $#mc_array; $l_mdcounter++)
   {
      # Copying the names into the module array - removing the _mc.c form the name.
      $md_array[$l_mdcounter] = substr($mc_array[$l_mdcounter],0,-5);
   }

   # Ok, now we have the base. We have to check if there are some missing _cc.c files.
   for ($l_cccounter = 0; $l_cccounter <= $#cc_array; $l_cccounter++)
   {
      # Before the comparsion the ending must be removed
      $l_acutalccname = substr($cc_array[$l_cccounter],0,-5);
      $l_IFoundThisInMdarray = 0;
      for ($l_mdcounter = 0; $l_mdcounter <= $#md_array; $l_mdcounter++)
      {
         if ($md_array[$l_mdcounter] eq $l_acutalccname) {
            $l_IFoundThisInMdarray = 1;
            #last;
         }
      }
      if ($l_IFoundThisInMdarray eq 0) {
         push (@md_array, $l_acutalccname);
      }
   }

   # Ok, now we have the base. We have to check if there are some missing *.c files.
   for ($l_ccounter = 0; $l_ccounter <= $#c_array; $l_ccounter++)
   {
      # Before the comparsion the ending must be removed
      $l_acutalccname = substr($c_array[$l_ccounter],0,-5);
      $l_IFoundThisInMdarray = 0;
      for ($l_mdcounter = 0; $l_mdcounter <= $#md_array; $l_mdcounter++)
      {
         if ($md_array[$l_mdcounter] eq $l_acutalccname) {
            $l_IFoundThisInMdarray = 1;
            #last;
         }
      }
      if ($l_IFoundThisInMdarray eq 0) {
         push (@md_array, substr($c_array[$l_ccounter],0,-2));
      }
   }
   
   # Arranging the md array
   #K2: @md_array = sort { $a cmp $b } @md_array;
}

sub PrintResult{

  local *RFH;
  my $l_lauf;

  # Test for generating Date / Time in Filename. But how to get info about HMI / PP ?
  my ($sec, $min, $hour, $mday, $mon, $year) = localtime(time);
  $mon += 1;      # To correct the 0-based result
  $year += 1900;  # To correct the 1900-based counting
  $mon = sprintf("%02d", $mon);     # make month & day of month 0-padded
  $mday = sprintf("%02d", $mday);
  my $fName = "";
  if($workspace eq "") {
	$fName = $variant_name."_Check_${year}-${mon}-${mday}_$opts{o}.txt";
  } else {
	$fName = "${workspace}\\".$variant_name."_Check_${year}-${mon}-${mday}_$opts{o}.txt";	
  }
  print "fName: ${fName}";
  print "$fName\n";
  
  
  open(RFH,">$fName") or die "Error at opening the output file: $!";

  print RFH "\n       " . localtime;
  printf RFH "\n  --------------------------";
  printf RFH "\n  Source files path : <%s>" , $md_pfad ;
  printf RFH "\n  Test files path   : <%s>" , $tl_pfad ;
  
  printf RFH "\n  -------------------------- \n";

  for ($l_lauf = 0; $l_lauf <= $#result_array; $l_lauf++){
      printf RFH "\n%s", $result_array[$l_lauf];
  } #endfor
  
  #-----------------------------------------------------------------------
  
  my $fName = "";
  if($workspace eq "") {
	$fName = $variant_name."_Check_${year}-${mon}-${mday}_$opts{o}_ToDo_List.txt.txt";
  } else {
	$fName = "${workspace}\\".$variant_name."_Check_${year}-${mon}-${mday}_$opts{o}_ToDo_List.txt";	
  }
  print "fName: ${fName}";
  print "$fName\n";
  
  
  open(RFH,">$fName") or die "Error at opening the output file: $!";

  print RFH "\n       " . localtime;
  printf RFH "\n  --------------------------";
  printf RFH "\n  Source files path : <%s>" , $md_pfad ;
  printf RFH "\n  Test files path   : <%s>" , $tl_pfad ;
  printf RFH "\n  -------------------------- \n";
  
  for ($l_lauf = 0; $l_lauf <= ($l_maxnotdone+5); $l_lauf++){
      printf RFH "\n%s", $result_todo_array[$l_lauf];
  } #endfor

}# end

## FilesFind ($)
#
#  This function finds files at the given path. The postfix and
#  the extension must be set properly before calling this function.
#
sub FilesFind ($){
  my $f_path = shift;
  my $l_counter = 0;
  my $l_temp;
  my $l_temp2;
  my $l_len;
  my @l_resultarray;
  my @l_date_resultarray;
  my @l_size_resultarray;
  my $l_resultarraycnt = 0;

  print "\n Searching for files ending with $g_postfix.$g_extension  ";

  # Filling the array with 0
  for ($l_counter = 0; $l_counter <= $#l_array; $l_counter++)
  {
     $l_array[$l_counter] = '0';
     $l_date_array[$l_counter] = '0';
  }

	find({ wanted => \&WantedFiles, no_chdir=>1}, $f_path);

	 sub WantedFiles{
		 package main;
		 my $f_name;
		 my $l_name;
		 my $l_date_name;
		 my $l_size_name;
		 #my $l_warning;
		 my $l_path;
		 my $l_suffix;
		 
		#Variables used for displaying Date according to history of a file
		 my $output;
		 my @str1;
		 my @dmy;
		 my @fdate;
		 my %mon2num;
		 
		 # Comparing every files in the given path with the given postfix and with the given extension
		 if((($g_extension eq "sbsx") and (index($File::Find::name, "featureData") != -1)) or (($g_extension eq "sbsx") and (index(lc $File::Find::name, "aritf") != -1))){
			# print $File::Find::name."\n";
		 }
		 else {
			 if ($File::Find::name =~ /.*$g_postfix\.$g_extension$/i){
				# Changing every letter to lower case
				$f_name = lc $File::Find::name;
				($l_name,$l_path,$l_suffix) = fileparse($f_name,"\.$g_extension");
				$l_name = $l_name . $l_suffix;
				$f_name =~ s/\//\\/g;
				my ($l_date_val, $l_time_val)=Get_CheckinDate($f_name);
				my @yyyymmdd=split("-",$l_date_val);
				my $l_date_name="$yyyymmdd[2].$yyyymmdd[1].".substr($yyyymmdd[0],2);
		##		
				
				$l_size_name = -s $File::Find::name;
				$l_size_name = ceil($l_size_name / 1024);
				$l_size_name = sprintf "%3s", $l_size_name;
				$l_size_name = $l_size_name.'  ';
				if($g_postfix eq "ArItf" && $g_extension eq "arxml") {
					if ( (split(/\_/, $l_array[-1], 2))[0] eq (split(/\_/, $l_name, 2))[0]) {
						if(to_comparable($l_date_array[-1]) lt to_comparable($l_date_name)) {
							pop @l_array;
							pop @l_date_array;
							pop @l_size_array;
							push (@l_array, $l_name);
							push (@l_date_array, $l_date_name);
							push (@l_size_array, $l_size_name);
						}
					}
					else {
						push (@l_array, $l_name);
						push (@l_date_array, $l_date_name);
						push (@l_size_array, $l_size_name);
					}
				}
				else {
					push (@l_date_array, $l_date_name);
					push (@l_array, $l_name);
					push (@l_size_array, $l_size_name);
				}
				if ($g_postfix eq "_co" && $g_extension eq "txt"){
								open my $fh , '<' , $File::Find::name or die 'Cannot open file'; 
					my $l_warning=0;
					while (<$fh>){
						chomp;
						$l_warning+=s/warning//g;
					}
				
					close $fh;
					$l_warning = sprintf "%2s", $l_warning;
					push (@co_warnings_array, $l_warning);
				}
				
			 } #endif
		}

   } #end sub WantedFiles

	
	
   # Maybe there are some rubbish in the l_array - because it is a global array -, this rubbish has to be removed
   # How long is a the actual extension?
   $l_len = length($g_extension);

   $l_len = $l_len * (-1);

   for ($l_counter = 0; $l_counter <= $#l_array;$l_counter++){
      # Comparing the actual extension with the extension in the array
      $l_temp2 = substr($l_array[$l_counter],$l_len);
      if ($l_temp2 eq $g_extension) {
         # If they are the same, the actual element can be copied into the result array
         $l_resultarray[$l_resultarraycnt] = $l_array[$l_counter];
         $l_date_resultarray[$l_resultarraycnt] = $l_date_array[$l_counter];
                 $l_size_resultarray[$l_resultarraycnt] = $l_size_array[$l_counter];
         $l_resultarraycnt++;
      }
   }

   # Arranging the result array
   #K2: @l_resultarray = sort { $a cmp $b } @l_resultarray;

   print "ok \n";

   # Returning the result array
   return (\@l_resultarray, \@l_date_resultarray, \@l_size_resultarray);

} #end subfunctions

sub to_comparable {
   my ($date) = @_;
   my @cols  = split(/\./, $date);
   return "$cols[2]$cols[1]$cols[0]";
}

sub Get_CheckinDate($)
{	
	open (FILE1,"<", "$Stream_Database") or die "Couldn't open file $Stream_Database, $!";
	my @Database_content = <FILE1>;

	my @File_Details;
	my $File_To_Check = shift;
	chomp $File_To_Check;
	foreach my $File_History (@Database_content) {
		@File_Details = split(" ", $File_History);
		if(lc($File_Details[0]) eq $File_To_Check) {
			return ($File_Details[1], $File_Details[2]);
		}
	}
}
##  ResultList
#
#   This function prepares the arraies which will be written into the result file.
#
sub ResultList {
   my $l_counter;


   # source files
   $result_array[0]=FillUpString('Filename  ',$l_position,' ') . '  _CC.C   CC_SIZE';
   $l_position = $l_position + 17;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '  _MC.C    MC_SIZE';
   $l_position = $l_position + 19;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '  *.C     C_SIZE';
   
   $l_position = $l_position + 20;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . 'ARITF.ARXML';
   $l_position = $l_position + 14;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . 'SBSX';
   # compulsory files
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . ' PS';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . ' MR';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . ' ME';
   $l_position = $l_position + 8;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_CO.TXT    WARNING  ';
   $l_position = $l_position + 21;
   #$result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RS.XLSM';
   #$l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RD.XLSM';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RC.XLSM';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RI.XLSM';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RU.XLSM';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RG.XLSM';
   $l_position = $l_position + 10;   
   # $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_RT.XLSM';
   # $l_position = $l_position + 12;

   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . 'PTU';
   $l_position = $l_position + 8;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_FT.DOC';
   $l_position = $l_position + 10;
   $result_array[0]=FillUpString($result_array[0],$l_position,' ') . '_TH.ZIP';

   $result_array[1]=FillUpString('-',260,'-');

   for ($l_counter = 0; $l_counter <= $#md_array; $l_counter++) {
      $result_array[$l_counter + 2] = FillUpString($md_array[$l_counter],50, ' ');
      #$result_array[$l_counter + 2] = $result_array[$l_counter + 2].'  '.$cc_array[$l_counter].'  '.$mc_array[$l_counter].'  '.$c_array[$l_counter];
	  $result_array[$l_counter + 2] = $result_array[$l_counter + 2].$cc_array[$l_counter].'  '.$mc_array[$l_counter].'  '.$c_array[$l_counter].'       '.$arxml_array[$l_counter].'  '.$sbsx_array[$l_counter];
	  #$result_array[$l_counter + 2] = $result_array[$l_counter + 2].$cc_array[$l_counter].'  '.$mc_array[$l_counter];
      $result_array[$l_counter + 2] = $result_array[$l_counter + 2].'  '.$ps_array[$l_counter].'  '.$mr_array[$l_counter].'  '.$me_array[$l_counter].'  '.$co_array[$l_counter];
	  # bk up for below stmt: $result_array[$l_counter + 2] = $result_array[$l_counter + 2].'      '.$rs_array[$l_counter].'  '.$rd_array[$l_counter].'  '.$rc_array[$l_counter].'  '.$ri_array[$l_counter].'  '.$ru_array[$l_counter].'  '.$rg_array[$l_counter].'  '.$rt_array[$l_counter];
	  $result_array[$l_counter + 2] = $result_array[$l_counter + 2].'  '.$rd_array[$l_counter].'  '.$rc_array[$l_counter].'  '.$ri_array[$l_counter].'  '.$ru_array[$l_counter].'  '.$rg_array[$l_counter];
      $result_array[$l_counter + 2] = $result_array[$l_counter + 2].'  '.$ptu_array[$l_counter].'  '.$ft_array[$l_counter].'  '.$thz_array[$l_counter];
   }

   # Now the list is ready, but we want to add the numbers of the found files.
   # We have to read the last elements from the arraies.
   $result_array[$#md_array + 3] = FillUpString('-',275,'-');
   $result_array[$#md_array + 4] = "The number of modules is:  ".($#md_array + 1)."                     ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$cc_array[$#md_array + 1]."        -     ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$mc_array[$#md_array + 1]."        -     ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.(($#md_array + 1)-$cc_array[$#md_array + 1]-$mc_array[$#md_array + 1])."       -     ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'           '.$arxml_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$sbsx_array[$#md_array + 1]."       ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$ps_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$mr_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$me_array[$#md_array + 1]."       ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$co_array[$#md_array + 1]."         -      ";
   # $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$rs_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$rd_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$rc_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$ri_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$ru_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$rg_array[$#md_array + 1]."      ";
   # $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$rt_array[$#md_array + 1]."      ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$ptu_array[$#md_array + 1]."         ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$ft_array[$#md_array + 1]."        ";
   $result_array[$#md_array + 4] = $result_array[$#md_array + 4].'  '.$thz_array[$#md_array + 1];
   $result_array[$#md_array + 5] = FillUpString('-',275,'-');


   
      #Feature data 
   $l_position=50;
   $result_array[$#md_array + 9] ="Review Documents from \"FeatureData Folder\" : \n";
   $result_array[$#md_array + 10]=FillUpString('-',80,'-');
   $result_array[$#md_array + 11]=FillUpString('Folder  ',$l_position,' ') . '_RS.XLSM      _RT.XLSM';
   # $result_array[$#md_array + 8]=FillUpString($result_array[$#md_array + 8],$l_position,' ') . '_RS.XLSM';
   # $l_position = $l_position + 10;
   # $result_array[$#md_array + 8]=FillUpString($result_array[$#md_array + 8],$l_position,' ') . '_RT.XLSM';
   $result_array[$#md_array + 12]=FillUpString('-',80,'-');
   for ($l_counter = 0; $l_counter <= $#fd_array; $l_counter++) {
	   next if($fd_array[$l_counter] =~ /\Q.\E/);
      $result_array[$l_counter + $#md_array + 11] = FillUpString($fd_array[$l_counter],50, ' ');
      #$result_array[$l_counter + 2] = $result_array[$l_counter + 2].'  '.$cc_array[$l_counter].'  '.$mc_array[$l_counter].'  '.$c_array[$l_counter];
	  $result_array[$l_counter + $#md_array + 11] = $result_array[$l_counter + $#md_array + 11].$rs_array[$l_counter].'      '.$rt_array[$l_counter];
   }
	$l_position=$#md_array + $#fd_array + 12;
   $result_array[$l_position]=FillUpString('-',80,'-');
	my $rs_cnt;
	my $rt_cnt;
	 #my $char = '-';
	
 # # Now the list is ready, but we want to add the numbers of the found files.
   # # We have to read the last elements from the arraies.

	   my @rs;
	   my @rt;
	   @rs = grep(!/-/, @rs_array);
	   @rt = grep(!/-/, @rt_array);
	   @rt = grep(!/-/, @rt_array);

	$result_array[$l_position + 2] = "The number of modules are:  ".($#fd_array - 1)."                        ".$rs[@rs - 1]."             ".$rt[@rt - 1];
	$result_array[$l_position + 4] = FillUpString('-',80,'-');


} #end sub ResultList


sub ResultListToDoList {
   my $l_counter;
   my $l_position = 58;
   

   # source files
   $result_todo_array[0]=FillUpString(' Events List                  PS  ',$l_position,' ') . '            MR  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '            ME  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          ARITF.ARXML  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          SBSX  ';   
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _CO.TXT  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RS.XLSM  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RD.XLSM  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RC.XLSM  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RI.XLSM  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RU.XLSM  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RG.XLSM  ';
   $l_position = $l_position + 40; 
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          _RT.XLSM  ';
   $l_position = $l_position + 40;
   $result_todo_array[0]=FillUpString($result_todo_array[0],$l_position,' ') . '          TEST  ';
   
   $result_todo_array[1]=FillUpString('-',490,'-');
   
 $l_maxnotdone = max($ps_countupdate, $mr_countupdate, $me_countupdate,$arxml_countupdate,$sbsx_countupdate, $co_countupdate, $rs_countupdate, $rd_countupdate, $rc_countupdate, $ri_countupdate, $ru_countupdate,$rg_countupdate, $rt_countupdate); 
  
   for ($l_counter = 0; $l_counter < $l_maxnotdone; $l_counter++) {
   $l_position = 58;
   $result_todo_array[$l_counter + 2]=FillUpString('                  '.$ps_remaining[$l_counter],$l_position,' ') .$mr_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$me_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$arxml_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$sbsx_remaining[$l_counter];
   
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$co_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$rs_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$rd_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$rc_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$ri_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$ru_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$rg_remaining[$l_counter];
   $l_position = $l_position + 40;   
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$rt_remaining[$l_counter];
   $l_position = $l_position + 40;
   $result_todo_array[$l_counter + 2]=FillUpString($result_todo_array[$l_counter + 2],$l_position,' ') .$ptu_remaining[$l_counter];
   
   }

   
   $result_todo_array[$l_maxnotdone + 2]=FillUpString('-',490,'-');
   $l_position = 58;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString(' Not Done -->                '.$ps_countupdate,$l_position,' ').'            '.$mr_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$me_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$arxml_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$sbsx_countupdate;
   
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$co_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$rs_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$rd_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$rc_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$ri_countupdate;
   $l_position = $l_position + 40;
  $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$ru_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$rg_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$rt_countupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 3]=FillUpString($result_todo_array[$l_maxnotdone + 3],$l_position,' ') .'            '.$ptu_countupdate;
   
   $l_position = 58;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString(' Not Updated -->             '.$ps_counttoupdate,$l_position,' ').'            '.$mr_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$me_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$arxml_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$sbsx_counttoupdate;
   
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$co_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$rs_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$rd_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$rc_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$ri_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$ru_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$rg_counttoupdate;
   $l_position = $l_position + 40; 

   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$rt_counttoupdate;
   $l_position = $l_position + 40;
   $result_todo_array[$l_maxnotdone + 4]=FillUpString($result_todo_array[$l_maxnotdone + 4],$l_position,' ') .'            '.$ptu_counttoupdate;

   #For Jenkings Bar Chart Plot
    if($workspace eq "") {
	} else {
	   my @elements = ($ps_countupdate,$ps_counttoupdate);  
	   open (FH, "> ${workspace}\\filechecker.csv") or die "$!";

	   print FH qq |NotDone,NotUpdated\n|;
	   print FH qq |$elements[0],$elements[1]|;

	   close(FH);	
	}
   

   

} #end sub ResultListToDoList

sub CheckVcarFiles{
   my $l_referencelength;
   my $l_tochecklength;
   my @l_referencearray;
   my @l_tocheckarray;
   my @l_doifindarray;
   my $l_referencecounter;
   my $l_actualreferencename;
   my $l_tocheckcounter;
   my $l_tocheckname;
   my $l_modulecounter;
   my $l_actualmodulname;
   my $l_aganumber;

   my @l_colreferencearray;
   my @l_coltocheckarray;
   my @l_coldoifindarray;
   my $l_colreferencecounter;
   my $l_colactualreferencename;
   my $l_coltocheckcounter;
   my $l_coltocheckname;

   my $l_tempmodulname;

   # This part of the function compares the test input files with the reference files
   # first of all we have to compare the test input and the test reference arraies
   if ($#ti_array >= $#tr_array) {
      @l_referencearray = @ti_array;
      @l_tocheckarray = @tr_array;
      $l_referencelength = (-1) * length("_ti.txt");
      $l_tochecklength = (-1) * length("_tr.odat");
   }else{
      @l_referencearray = @tr_array;
      @l_tocheckarray = @ti_array;
      $l_referencelength = (-1) * length("_tr.odat");
      $l_tochecklength = (-1) * length("_ti.txt");
   }

   # Now we have to compare the names in the reference array one by one with the names in the another array
   for($l_referencecounter = 0; $l_referencecounter<=$#l_referencearray; $l_referencecounter++){
      # Reading the actual name
      $l_actualreferencename = $l_referencearray[$l_referencecounter];
      # Removing the "reference" ending
      $l_actualreferencename = substr($l_actualreferencename,0,$l_referencelength);
      for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#l_tocheckarray; $l_tocheckcounter++){
         # Reading the name to check
         $l_tocheckname = $l_tocheckarray[$l_tocheckcounter];
         # Removing the "to check" ending
         $l_tocheckname = substr($l_tocheckname,0,$l_tochecklength);
         # now we can compare the names
         if ($l_actualreferencename eq $l_tocheckname) {
            # in another array, which is as long as the l_referencearray, we put an 'X', because we found its pair
            $l_doifindarray[$l_referencecounter] = 'X';
         }
      }
   }

   # if we did not find some files pairs, we put an '-' there
   for($l_referencecounter = 0; $l_referencecounter<=$#l_referencearray; $l_referencecounter++){
      if ($l_doifindarray[$l_referencecounter] ne 'X') {
         $l_doifindarray[$l_referencecounter] = '-';
      }
   }

   # This part of the function compares the test input colouring files with the reference files
   # first of all we have to compare the test input and the test reference arraies
   if ($#cmt_array >= $#cmo_array) {
      @l_colreferencearray = @cmt_array;
      @l_coltocheckarray = @cmo_array;
      $l_referencelength = (-1) * length("_ti.cmt");
      $l_tochecklength = (-1) * length("_tr.cmo");
   }else{
      @l_colreferencearray = @cmo_array;
      @l_coltocheckarray = @cmt_array;
      $l_referencelength = (-1) * length("_tr.cmo");
      $l_tochecklength = (-1) * length("_ti.cmt");
   }

   # Now we have to compare the names in the reference array one by one with the names in the another array
   for($l_referencecounter = 0; $l_referencecounter<=$#l_colreferencearray; $l_referencecounter++){
      # Reading the actual name
      $l_actualreferencename = $l_colreferencearray[$l_referencecounter];
      # Removing the "reference" ending
      $l_actualreferencename = substr($l_actualreferencename,0,$l_referencelength);
      for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#l_coltocheckarray; $l_tocheckcounter++){
         # Reading the name to check
         $l_tocheckname = $l_coltocheckarray[$l_tocheckcounter];
         # Removing the "to check" ending
         $l_tocheckname = substr($l_tocheckname,0,$l_tochecklength);
         # Now we can compare the names
         if ($l_actualreferencename eq $l_tocheckname) {
            # In another array, which is as long as the l_referencearray, we put an 'X', because we found its pair
            $l_coldoifindarray[$l_referencecounter] = 'X';
         }
      }
   }

   # If we did not find some files pairs, we put an '-' there
   for($l_referencecounter = 0; $l_referencecounter<=$#l_colreferencearray; $l_referencecounter++){
      if ($l_coldoifindarray[$l_referencecounter] ne 'X') {
         $l_coldoifindarray[$l_referencecounter] = '-';
      }
   }

   # At this point, we have four arraies with the different files (_ti.txt, _tr.odat, _ti.cmt, _tr.cmo) and two
   # arraies with X's and with -'s - which means the existence or the absence of some files. Now we have to check,
   # if exist for every modules (for every c files) at least one entire group of test files.

   # Now we have to compare the names in the reference array one by one with the names in the another array
   for($l_modulecounter = 0; $l_modulecounter<=$#md_array; $l_modulecounter++){
      # Reading the actual name
      $l_actualmodulname = $md_array[$l_modulecounter];
      # Removing the bp_cc.c ending
      #  $l_actualmodulname = substr($l_actualmodulname,0,-7);
         $l_actualmodulname = substr($l_actualmodulname,0,-2);
      $l_tempmodulname = $l_actualmodulname;
      $l_aganumber = substr($l_actualmodulname,0,-7);
      for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#l_coltocheckarray; $l_tocheckcounter++){
         # Reading the name to check
         $l_tocheckname = $l_coltocheckarray[$l_tocheckcounter];
         # Removing the "to check" ending
         $l_tocheckname = substr($l_tocheckname,0,$l_tochecklength);
         # Now we can compare the names
         if ($l_actualreferencename eq $l_tocheckname) {
            # In another array, which is as long as the l_referencearray, we put an 'X', because we found its pair
            $l_coldoifindarray[$l_referencecounter] = 'X';
         }
      }
   }
}

## CheckExistenceOfFiles($$$\@)
#
#     This function compares the given type of files with the
#     array of c files. If the given file exists, in the result
#     array will be an 'X' if not a '-'. The input parameters
#     are: sign of special files (1 - for Vcar files because
#     of the name ..._02_bmgti.txt, 2 - for IH files) postfix,
#     of the files to check, extension and the address of the
#     array to check.
#
sub CheckExistanceOfFeatureData($$\@\@\@) {
	
   my ($l_ItIsVcarTestFile, $g_postfix, $l_tocheckarray_ref, $l_date_tocheckarray_ref, , $l_size_tocheckarray_ref) = @_;
   my $l_PostAndExtLen;
   my $l_fdcounter;
   my $l_tocheckcounter;
   my $l_tempstring;
   my $l_tempstring2;
   my @l_resultarray;

   my @l_tocheckarray = @$l_tocheckarray_ref;
   my @l_date_tocheckarray = @$l_date_tocheckarray_ref;
   my @l_size_tocheckarray = @$l_size_tocheckarray_ref;
	for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#fd_array; $l_tocheckcounter++) {
		$l_resultarray[$l_tocheckcounter] = '   -    ';
	}
   for ($l_fdcounter = 0; $l_fdcounter <= $#fd_array; $l_fdcounter++){
		$l_actualfd = $fd_array[$l_fdcounter];
		next if($l_actualfd =~ /\Q.\E/);
		for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#l_tocheckarray; $l_tocheckcounter++){
			my @values = split('_', $l_tocheckarray[$l_tocheckcounter]);
			$l_tempstring = $values[0];
			if ($l_actualfd eq $l_tempstring){	
				$l_resultarray[$l_fdcounter] = $l_date_tocheckarray[$l_tocheckcounter];
				last;
			}
		}
   }
   return (@l_resultarray);
}
sub CheckExistenceOfFiles($$$\@\@\@) {
   my ($l_ItIsVcarTestFile, $g_postfix, $g_extension, $l_tocheckarray_ref, $l_date_tocheckarray_ref, , $l_size_tocheckarray_ref) = @_;
   my $l_PostAndExtLen;
   my $l_mdcounter;
   my $l_tocheckcounter;
   my $l_actualmd;
   my $l_tempstring;
   my $l_tempstring2;
   my @l_resultarray;

   my @l_tocheckarray = @$l_tocheckarray_ref;
   my @l_date_tocheckarray = @$l_date_tocheckarray_ref;
   my @l_size_tocheckarray = @$l_size_tocheckarray_ref;

   if ($g_postfix eq "_co" && $g_extension eq "txt"){
		for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#md_array; $l_tocheckcounter++) {
		$l_resultarray[$l_tocheckcounter] = '    -         -';
		}
   }
   elsif ($g_extension eq "c"){
		for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#md_array; $l_tocheckcounter++) {
		$l_resultarray[$l_tocheckcounter] = '    -        -  ';
		}
   }
   else{
		for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#md_array; $l_tocheckcounter++) {
		$l_resultarray[$l_tocheckcounter] = '   -    ';
		}
   }
   
   for ($l_mdcounter = 0; $l_mdcounter <= $#md_array; $l_mdcounter++){
      # Reading the name of the actual modul
      $l_actualmd = $md_array[$l_mdcounter];
      # We would like to compare the modul name with the name in the array
      # First of all we have to remove the postfix and the extension
      if ($l_ItIsVcarTestFile == 0) {
         # We are searching now for "normal" files - the aga name should not be removed
         #  $l_actualmd = substr($l_actualmd,0,-5);
      }else{
         # We are searching for "special" files (ih, Vcar) - the aga name should be removed
         #  $l_actualmd = substr($l_actualmd,0,-11);
         $l_actualmd = substr($l_actualmd,0,-6);
      }

          if (($g_extension eq "xlsm") || ($g_extension eq "docx") || ($g_extension eq "arxml") || ($g_extension eq "sbsx") || ( ($g_postfix eq "_th") && ($g_extension eq "zip")) )
          {
				my @values = split('_', $l_actualmd);
                $l_actualmd = $values[0];
		  }


      for ($l_tocheckcounter = 0; $l_tocheckcounter <=$#l_tocheckarray; $l_tocheckcounter++){
         $l_tempstring2 = $l_tocheckarray[$l_tocheckcounter];
         # We would like to compare the modul name with the name in the array
         # First of all we have to remove the postfix and the extension
         # How long is it?
         $l_PostAndExtLen = (-1) * (length($g_postfix.$g_extension) + 1);
         if ($l_ItIsVcarTestFile == 1) {
            # We are searching for vcar files - the aga name should be removed
            $l_PostAndExtLen = $l_PostAndExtLen - 9;
         }
         if ($l_ItIsVcarTestFile == 2){
            # We are searching for ih files - removing characters till the end of the name of the module
            $l_PostAndExtLen = $l_PostAndExtLen - 4;
         }
         # Removing the postfix and the extension

        
		if (index($l_tempstring2, "xls") != -1) {
			
			if(index($l_tempstring2, "xlsm") == -1) {
				$l_tempstring2 = substr($l_tempstring2,0,$l_PostAndExtLen+1);
			}
			else {
				$l_tempstring2 = substr($l_tempstring2,0,$l_PostAndExtLen);
			}
			
		}
		
		elsif (index($l_tempstring2, "doc") != -1) {
			if(index($l_tempstring2, "docx") == -1) {
				$l_tempstring2 = substr($l_tempstring2,0,$l_PostAndExtLen+1);
			}
			else {
				$l_tempstring2 = substr($l_tempstring2,0,$l_PostAndExtLen);
			}
		}
		
		elsif (($g_extension eq "arxml") or ($g_extension eq "sbsx")){
			$l_tempstring2 = substr($l_tempstring2,0,$l_PostAndExtLen);
			my @ModName = split('_', $l_tempstring2);
			$l_tempstring2 = $ModName[0];
		}
		else {
			$l_tempstring2 = substr($l_tempstring2,0,$l_PostAndExtLen);
		}
         # Now we have to check if the file exists or not
         #printf "\n Ez a modulnev: $l_actualmd \n";
         #printf "\n Most ezt talaltuk: $l_tempstring2 \n";

         if ($l_actualmd eq $l_tempstring2){
            # If exist put an X instead of the name
            #$l_resultarray[$l_mdcounter] = 'X       ';
                        #my $mtime = (stat $l_tocheckarray[$l_tocheckcounter])[9];
                        #my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($mtime);
                        #$l_resultarray[$l_mdcounter] = substr('0'.$mday,-2).substr('0'.".",-1).substr('0'.($mon+1),-2).substr('0'.".",-1).substr($year+1900,-2);
                                                if ($g_extension eq "c")
                                                {
                                                        $l_resultarray[$l_mdcounter] = $l_date_tocheckarray[$l_tocheckcounter];
														$l_resultarray[$l_mdcounter] = $l_resultarray[$l_mdcounter].'   '.$l_size_tocheckarray[$l_tocheckcounter];
												}
                                                else
                                                {
														if ($g_postfix eq "_co" && $g_extension eq "txt")
														{
															$l_resultarray[$l_mdcounter] = $l_date_tocheckarray[$l_tocheckcounter].'     '.$co_warnings_array[$l_tocheckcounter];
														}
														else
														{
															$l_resultarray[$l_mdcounter] = $l_date_tocheckarray[$l_tocheckcounter];
														}
                                                }
                        #print "$l_date_tocheckarray[$l_tocheckcounter]\n";
                        #<STDIN>;
                        #printf "\n most jo \n";
            last;
         }
      }
   }

   # Returning the result array
   return (@l_resultarray);

}

format callingerror =

  You have made some mistakes at the calling.
  The proper call looks like:
  <path of the perl.exe>\perl.exe mdTstAbdeckung.pl <path of the source files> <path of the test files>
  example: G:\Documents\Books\Perl\v5_8_8_817\bin\perl.exe mdTstAbdeckung.pl O:\ED_EPS_PP\ImplementationSet\Drive\DeviceLayer\ECUControl\ O:\ED_EPS_PP\TestSet\Module\Drive\DeviceLayer\ECUControl\
.
