/* ---------------------------------------------------------------------
   Kurzbeschreibung: 	Wandelt MOTOROLS-S -Files  in Bin�rfile um
   ---------------------------------------------------------------------
   Projekt:		Flash
   Sourcefile:		s192bin.C
   Autor:		RtW/FVS72-Wiese (04.01.1996)
   Zielsystem:		HP9000/S715 (HP-UX 9.04)
   Sprache:		ANSI-C
   ---------------------------------------------------------------------
   Prototyp:
   
   int intelkonv
   (FILE *		// <I> Eingabefile
   ,FILE *)		// <O> Ausgabefile
   
   ---------------------------------------------------------------------
   Aufruf:
   
   error = s192bin
   (file1		// <I> Eingabefilepointer
   ,file2)		// <O> Ausgabefilepointer
   
   if (error != 0) 	// Fehlerbeschreibung ...
   {
   // Fehlerhandling ...
   }
   
   ---------------------------------------------------------------------
   Funktionsbeschreibung:
   
   Diese Routine liest Zeilenweise das Eingabefile ein,
   checkt auf
    S[0123789] am Zeilenanfang
    Checksumme der Zeile,
   ermittelt die aktuelle Adresse des Bytes und schreibt die Daten in ein
   Feld, das vorinitialisiert ist.
   
   ---------------------------------------------------------------------*/

/*-- defines -----------------------------------------------------------*/
/*-- includes ----------------------------------------------------------*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "pgh_crc.h"
/*-- external functions / variables ------------------------------------*/

/*-- global variables (nur im  "main" erlaubt) -------------------------*/

/* -Begin---------------------------------------------------------------
   Wandelt Intelhexfiles in Bin�rfile um
   ---------------------------------------------------------------------*/

int s192bin(FILE *fptr1, unsigned char *feld, 
            unsigned long int from_adr, unsigned long int len)
{
    char                string[522];
    char                strData[512];
    char                strCount[4];
    char                str1Byte[4];
    char                str_tmp[10];
    unsigned long int   intCount;
    unsigned long int   l;
    unsigned long int 	adresse=0;
    unsigned long int   adress_offset=0;
    unsigned char       Schecksumme;
    unsigned long int   filechecksum=0;
    unsigned long int   filewritechecksum=0;
    unsigned long int	intWord;
    unsigned long int	i;
    unsigned int        string_len;
    unsigned long int   tmp;
    unsigned int        zeilenzaehler=0;
    char *              ptr;

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /*                 Konvertierung: MototolaS -> Bin�r                 */
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    printf("STARTING S192bin with fieldlen %li Byte\n",len);

    while( fgets( string, 522, fptr1 ) != NULL )
    {
        zeilenzaehler++;
        string_len=strlen(string);
        string_len=kill_token(string, ' ',0x09, ';', 0x0A, 0x0D, string_len);
        if (string_len==0) continue; 		// Leerzeilen ignorieren
        if (*string!='S')
        {
            printf( "s192bin> kein Mototrola-S in Zeile %i !\n", zeilenzaehler );
            return (-1);
        }
        /* strCount = Anzahl der Nutzbytes im String */
        strncpy( strCount, (string+2), 2 );

        *(strCount+2)=0;	/* Eingef�hrt da kein /0 am Ende des Strings
               sscanf greift auf diesen Speicherplatz zu */
        intCount = strtoul( strCount,&ptr, 16);
        if (ptr!=strCount+2)
        {
            printf( "s192bin> L�nge [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                    strCount, zeilenzaehler );
            return (-2);
        }
        /* Checksumme errechnen */

        Schecksumme=0;
        for (i=0;i<intCount;i++)
        {
            strncpy( str_tmp, (string+(i*2)+2), 2 );
            *(str_tmp+2)=0;
            tmp = strtoul( str_tmp,&ptr, 16);
            if (ptr!=str_tmp+2)
            {
                printf( "s192bin> Datum [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                        strCount, zeilenzaehler );
                return (-3);
            }
            Schecksumme = ( Schecksumme + tmp) & 0x0FF;
        }

        /* Checksumme auslesen und auswerten*/

        strncpy( str_tmp, (string+((intCount+1)*2)), 2 );
        *(str_tmp+2)=0;
        tmp = strtoul( str_tmp,&ptr, 16);
        if (ptr!=str_tmp+2)
        {
            printf( "s192bin> Checksumme [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                    strCount, zeilenzaehler );
            return (-4);
        }

        Schecksumme = ~Schecksumme;

        if (Schecksumme!=tmp)
        {
            printf( "s192bin> Schecksumme %04X != gelesen %04lX in Zeile %i !\n", Schecksumme, tmp ,zeilenzaehler);
            return (-5);
        }

        /* *(string+1) = Typ der Zeile:
     S0 = Header Record Adressfield zeros, code-Data contains information
     S1 = Data Record with 2 byte Adress
     S2 = Data Record with 3 byte Adress
     S3 = Data Record with 4 byte Adress
     S7 = Termination Record 4 byte Adress for signal entry point
     S8 = Termination Record 3 byte Adress for signal entry point
     S9 = Termination Record 2 byte Adress for signal entry point
     */

        adress_offset=0;
        /* * * * * intTyp = 0: es sind zu konvertierende daten * * * * */
        switch (*(string+1))
        {
        case '1': 	/* Data Record with 2 byte Adress */
            adress_offset=2;
        case '2': 	/* Data Record with 3 byte Adress */
            if (adress_offset==0) adress_offset=3;
        case '3': 	/* Data Record with 4 byte Adress */
            /*** Adresse ermitteln ***/
            if (adress_offset==0) adress_offset=4;
            strncpy( str_tmp, (string+4), adress_offset*2 );
            *(str_tmp+adress_offset*2)=0;
            tmp = strtoul( str_tmp,&ptr, 16);
            if (ptr!=str_tmp+adress_offset*2)
            {
                printf( "s192bin> Adresse [%s] nicht HEX-INT wandelbar in Zeile %i !\n",
                        strCount, zeilenzaehler );
                return (-6);
            }
            adresse = tmp;
            if ((adresse >= from_adr+len) || (adresse < from_adr))
            {
                printf("Skipping Adresse %02lX\n",adresse);
                break;
            }
            else
            {
                //printf("Writing Adresse %02X: ",adresse);
            }
            /*** Daten ermitteln ***/
            strncpy( strData, (string+4+adress_offset*2), ((intCount-1-adress_offset)*2) );
            for (i=0;i<((intCount-1-adress_offset));i++)
            {
                strncpy( str1Byte, strData+(2*i), 2 );
                str1Byte[2] = '\0';
                intWord = strtoul( str1Byte,&ptr, 16);
                if (ptr!=str1Byte+2)
                {
                    printf( "s192bin> Datum [%s] nicht HEX-INT wandelbar in Zeile %i !\n",
                            strCount, zeilenzaehler );
                    return (-7);
                }
                if (adresse + i >= from_adr+len)
                    continue;
                if (adresse + i < from_adr)
                    continue;
                if (feld[i+adresse-from_adr]!=0x0FF)
                {
                    printf("adresse=%08lX, from_adr=%08lx, len=%08lX, i=%li\n",adresse, from_adr, len, i);
                    printf( "s192bin> Datum an Adresse 0x%08lX bereits mit %02X beschrieben in Zeile %i !\n",
                            i+adresse, feld[i+adresse-from_adr], zeilenzaehler );
                    return (-8);
                }

                feld[i+adresse-from_adr] = (unsigned char) intWord;
                filewritechecksum = (filewritechecksum + (unsigned char) intWord) & 0x0FFFF ;
            }
            //printf("\n");
            break;
        case '7': /* Ende des HEX Files */
        case '8': /* Ende des HEX Files */
        case '9': /* Ende des HEX Files */
            /***  File beschreiben mit Daten aus 'feld' bis maxadresse ***/
            for (l=0;l<len;l++)
            {
                filechecksum = (filechecksum + feld[l]) & 0x0FFFF;
            }
            printf("s192bin> to_adr ............................. : %06lX\n",from_adr);
            printf("s192bin> len ................................ : %06lX\n",len);
            printf("s192bin> Checksumme Daten mit 0xFF gef�llt out: %04lX\n",filechecksum);
            printf("s192bin> Checksumme gelesene Daten          in: %04lX\n",filewritechecksum);
            return( 0 );
        case '0': /* Header Record Adressfield zeros, code-Data contains information */
            break;
        default:
        {
            printf( "s192bin> Unbekannter Format - Typ %i aufgetaucht in Zeile %i \n",
                    *(string+1), zeilenzaehler );
            return( -9 );
        }
        }

    }
    printf( "s192bin> File endete ohne ENDE - RECORD in Zeile %i \n", zeilenzaehler);
    return( -7 );
}
