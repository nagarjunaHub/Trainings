/* ---------------------------------------------------------------------
   Kurzbeschreibung:    Wandelt eine String in einen Rohstring
   ---------------------------------------------------------------------
   Projekt:		Flashprogrammierung
   Sourcefile:		kill_tok.C
   Autor:		RtW/FVS72-Wiese (06.12.95)
   Zielsystem:		HP9000/S800 (HP-UX 9.04)
   Sprache:		ANSI-C
   ---------------------------------------------------------------------
   Prototyp:
   
   unsigned long int kill_token (char 			*pointer,
                     char 			sign1,
                     char 			sign2,
                     char 			stoptoken1,
                     char 			stoptoken2,
                     char 			stoptoken3,
                     unsigned long int	maxlen)

   ---------------------------------------------------------------------
   Aufruf:
   
   len =  kill_token string ignoresign stoptoken1 stoptoken2 maxlen
   char*	string      	// <I/O> String, der bearbeitet wird
   char		ignoresign1	// <I> Zeichen, das entfernt werden soll : typisch (' ')
   char		ignoresign2	// <I> Zeichen, das entfernt werden soll : typisch (' ')
   char		stoptoken1	// <I> Zeichen, das das Ende kennzeichnet : typisch (';')
   char		stoptoken2	// <I> Zeichen, das das Ende kennzeichnet : typisch 0x0A
   char		stoptoken3	// <I> Zeichen, das das Ende kennzeichnet : typisch 0x0D
   int		maxlen		// <I> Maximall�nge, die verarbeitet wird

   ---------------------------------------------------------------------
   Funktionsbeschreibung:
   
   Bearbeitet eine String in der folgenden Weise:
   Alle Zeichen (ignoresign) werden entfernt
   Alle Zeichen (stoptoken 1,2) beenden den String zu entfrenung von Kommentaren
   ---------------------------------------------------------------------*/

/*-- defines -----------------------------------------------------------*/
/*-- includes ----------------------------------------------------------*/
#include <ctype.h>
/*-- external functions / variables ------------------------------------*/

/*-- global variables (nur im  "main" erlaubt) -------------------------*/

/* -Begin---------------------------------------------------------------
   Entfernt Zeichen und beendet die Zeile bei bestimmten Zeichen
   ---------------------------------------------------------------------*/

unsigned long int kill_token (char 		*pointer,
                              char 		sign1,
                              char 		sign2,
                              char 		stoptoken1,
                              char 		stoptoken2,
                              char 		stoptoken3,
                              unsigned long int	maxlen)
{
    unsigned long int eingabe=0, ausgabe=0;
    while (*(pointer+eingabe)!=0
           && eingabe <= maxlen
           && *(pointer+eingabe)!=stoptoken1
           && *(pointer+eingabe)!=stoptoken2
           && *(pointer+eingabe)!=stoptoken3
           )
    {
        if ((*(pointer+eingabe) != sign1)&&(*(pointer+eingabe) != sign2))
        {
            *(pointer+ausgabe++)=(char)toupper(*(pointer+eingabe++));
        }
        else eingabe++;
    }
    *(pointer+ausgabe)=0;
    return ausgabe;
}
