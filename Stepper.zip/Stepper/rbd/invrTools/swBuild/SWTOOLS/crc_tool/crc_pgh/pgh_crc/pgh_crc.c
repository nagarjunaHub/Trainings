/* ---------------------------------------------------------------------
   Kurzbeschreibung:    Checksummen von HEX-Files ermitteln
   ---------------------------------------------------------------------
   Projekt:		Flashprogrammierung
   Sourcefile:		pgh_crc.C
   Autor:		RtW/FVS72-Wiese (06.12.95)
   Zielsystem:		HP9000/S800 (HP-UX 9.04)
   Sprache:		ANSI-C
   ---------------------------------------------------------------------
   Prototyp:
   
   int bin2ds2
   
   ---------------------------------------------------------------------
   Aufruf:
   
   error = pgh_crc file anfangsadresse len
   file      	// <I> Eingabefile
   anfangsadresse// <I> Adresse, ab der die Checksumme berechnet werden soll
   len		// <I> Laenge der Daten
   
   if (error != 1) 	// Fehlerbeschreibung ...
   {
   // Fehlerhandling ...
   }
   
   ---------------------------------------------------------------------
   Funktionsbeschreibung:
   
   pgh_crc berechnet die Checksumme der Intelhex oder Motorola-S - Files
   ---------------------------------------------------------------------*/

/*-- defines -----------------------------------------------------------*/
/*-- includes ----------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pgh_crc.h"
/*-- external functions / variables ------------------------------------*/
/*-- global variables (nur im  "main" erlaubt) -------------------------*/

/* -Begin---------------------------------------------------------------
   Berechnet die Checksumme eines IntelHex oder Mot-S - files
   ---------------------------------------------------------------------*/

int main(int argc, char *argv[])
{
    FILE *ein, *out;  				/* zu kopierende Datei und Zieldatei */
    unsigned long int startadr=0;
    unsigned long int endadr=0;
    unsigned long int len=0;
    int 		      ret;
    unsigned long int crc;
    unsigned char *   pointer;

    switch (argc)
    {
    case 5:
        startadr=strtoul(argv[3],NULL,0);
        endadr=strtoul(argv[4],NULL,0);
        if (endadr>startadr)
        {
            len=endadr-startadr+1;
        }
        else
        {
            printf("%s>Startadr %08lX bigger than endadress %08lX\n",
                   argv[0],startadr,endadr);
            exit(-4);
        }

        printf("%s>file %s, startadr=%08lX, endadr=%08lX, len=%08lX\n",argv[0],argv[1], startadr, endadr,len);
        break;
    default:
        printf("%s>Aufruf mit %s infile outfile startadr endadr\n"
               , argv[0],argv[0]);
        exit( - 3);
    }
    if ((ein = fopen(argv[1], "rb")) == NULL)
    {
        printf ("%s>Datei %s konnte zum lesen nicht geoeffnet werden\n", argv[0],argv[1]);
        exit( - 1);
    }
    if ((out = fopen(argv[2], "wb")) == NULL)
    {
        printf ("%s>Datei %s konnte zum lesen nicht geoeffnet werden\n", argv[0],argv[2]);
        exit( - 1);
    }
    pointer=(unsigned char *) malloc(len);
    if (pointer==NULL)
    {
        printf("can't allocate %li Bytes Memory\n",len);
        fclose(ein);
        return -1;
    }
    memset(pointer, 0x0FF, len);
    ret=s192bin(ein, pointer, startadr, len);
    if (ret==-1)	/* Unbekanntes Format */
    {
        rewind(ein);
        ret=intelkonv(ein, pointer, startadr, len);
    }
    if (ret!=0)
    {
        printf("Can't convert %s\n",argv[1]);
        fclose(ein);
        free(pointer);
        return -1;
    }

    crc=crc_calc(pointer,len);
    printf("crc=0x%08lX\n",crc);
    free(pointer);
    fclose(ein);
    fprintf(out,"%06lX %06lX %08lX\n",startadr,endadr,crc);
    return (0);
}
