extern unsigned long crc_calc
(
/*-------------------------------------------------------------------------*\
| Purpose:                                                                  |
|   calculate crc over given address range                                  |
+---------------------------------------------------------------------------+
| Input Parameters:                                                         |
\*-------------------------------------------------------------------------*/
   unsigned char *buf_addr,             /* start of buffer to compute CRC  */
   size_t        buf_size               /* size of buffer (number of bytes)*/
);
extern unsigned long int kill_token (char 		*pointer,
				     char 		sign1, 
				     char 		sign2, 
				     char 		stoptoken1, 
				     char 		stoptoken2, 
				     char 		stoptoken3,
				     unsigned long int	maxlen);
extern int intelkonv(FILE *fptr1, 
		     unsigned char *feld, 
             unsigned long int from_adr,
             unsigned long int len);
extern int s192bin(FILE *fptr1, unsigned char *feld, 
          unsigned long int from_adr, unsigned long int len);

