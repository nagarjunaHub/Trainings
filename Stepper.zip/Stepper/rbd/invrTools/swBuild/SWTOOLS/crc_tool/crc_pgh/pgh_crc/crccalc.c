/*===============================================================*\
| Project: PGH Programmiergeraet High-Speed                       |
+-----------------------------------------------------------------+
| File: crccalc.c                                                 |
+-----------------------------------------------------------------+
|                    1999 IMD                                     |
|      Ingenieurbuero fuer Microcomputertechnik Th. Doerfler      |
|                       all rights reserved                       |
+-----------------------------------------------------------------+
| this file is a sample how to use the crc macro in "crctab.h"    |
| This file is intended to be used in conjunction with the        |
| GNU C Compiler                                                  |
|                                                                 |
+-----------------------------------------------------------------+
|   date                      history                        ID   |
| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |
| 19.10.99  creation                                         doe  |
|*****************************************************************|
\*===============================================================*/
#include <stdio.h>
#include "crctab.h"

/*=========================================================================*\
| Function:                                                                 |
\*-------------------------------------------------------------------------*/
unsigned long crc_calc
(
        /*-------------------------------------------------------------------------*\
        | Purpose:                                                                  |
        |   calculate crc over given address range                                  |
        +---------------------------------------------------------------------------+
        | Input Parameters:                                                         |
        \*-------------------------------------------------------------------------*/
        unsigned char *buf_addr,             /* start of buffer to compute CRC  */
        size_t        buf_size               /* size of buffer (number of bytes)*/
        )
/*-------------------------------------------------------------------------*\
| Return Value:                                                             |
|    crc result                                                             |
\*=========================================================================*/
{
    unsigned long crc_val = 0;

    /*
   * call macro for every byte in buffer
   */
    while (buf_size > 0) {
        crc_val = UPDC32((unsigned char)(*buf_addr),
                         crc_val);
        buf_addr++;
        buf_size--;
    }
    return crc_val;
}
