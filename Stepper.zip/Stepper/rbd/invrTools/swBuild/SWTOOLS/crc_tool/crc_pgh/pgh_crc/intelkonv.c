/* ---------------------------------------------------------------------
   Kurzbeschreibung: 	Wandelt Intelhexfiles in Bin�rfile um
   ---------------------------------------------------------------------
   Projekt:		Flash
   Sourcefile:		intelkonv.C
   Autor:		RtW/FVS72-Wiese (04.01.1996)
   Zielsystem:		HP9000/S715 (HP-UX 9.04)
   Sprache:		ANSI-C
   ---------------------------------------------------------------------
   Prototyp:

   int intelkonv
   (FILE *		// <I> Eingabefile
   ,FILE *)		// <O> Ausgabefile

   ---------------------------------------------------------------------
   Aufruf:

   error = intelkonv
   (file1		// <I> Eingabefilepointer
   ,file2)		// <O> Ausgabefilepointer

   if (error != 0) 	// Fehlerbeschreibung ...
   {
   // Fehlerhandling ...
   }

   ---------------------------------------------------------------------
   Funktionsbeschreibung:

   Diese Routine liest Zeilenweise das Eingabefile ein,
   checkt auf
   Doppelpunkt am Zeilenanfang
   Checksumme der Zeile,
   ermittelt die aktuelle Adresse des Bytes und schreibt die Daten in ein
   Feld, das mit FF vorinitialisiert ist.
   Am Schluss wird das Feld mit der Feldl�nge in das Ausgabefeld �bergeben

   ---------------------------------------------------------------------*/

/*-- defines -----------------------------------------------------------*/
/*-- includes ----------------------------------------------------------*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "pgh_crc.h"
/*-- external functions / variables ------------------------------------*/
/*-- global variables (nur im  "main" erlaubt) -------------------------*/

/* -Begin---------------------------------------------------------------
   Wandelt Intelhexfiles in Bin�rfile um
   ---------------------------------------------------------------------*/

int intelkonv(FILE *fptr1,
              unsigned char *feld,
              unsigned long from_adr,
              unsigned long len)
{
    char                string[522];
    char                strData[512];
    char                strCount[4];
    char                strTyp[4];
    char                str1Byte[4];
    char                str_tmp[5];
    unsigned long int   intCount;
    unsigned long int   intTyp;
    unsigned long       l;
    unsigned long int   adresse=0;
    unsigned long int   offset_2=0;
    unsigned long int   offset_4=0;
    unsigned char       Schecksumme;
    unsigned int        filechecksum=0;
    unsigned int        filewritechecksum=0;
    unsigned char       byteValue;
    unsigned int        i;
    unsigned int        string_len;
    unsigned long int   tmp;
    unsigned int        zeilenzaehler=0;
    char *              ptr;

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    /*                 Konvertierung: Intel Hex -> Bin�r                 */
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

    while( fgets( string, 522, fptr1 ) != NULL )
    {
        zeilenzaehler++;
        string_len=strlen(string);
        string_len=kill_token(string, ' ',0x09, ';', 0x0A, 0x0D, string_len);
        if (string_len==0) continue; 		// Leerzeilen ignorieren
        if (*string!=':')
        {
            printf( "intelhex2bin> kein Intel Hex File in Zeile %i !\n", zeilenzaehler );
            return (-1);
        }
        /* strCount = Anzahl der Nutzbytes im String */
        strncpy( strCount, (string+1), 2 );

        *(strCount+2)=0;	/* Eingef�hrt da kein /0 am Ende des Strings
               sscanf greift auf diesen Speicherplatz zu */
        intCount = strtoul( strCount,&ptr, 16);
        if (ptr!=strCount+2)
        {
            printf( "intelhex2bin> L�nge [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                    strCount, zeilenzaehler );
            return (-2);
        }

        /* Checksumme errechnen */

        Schecksumme=0;
        for (i=0;i<intCount+4;i++)
        {
            strncpy( str_tmp, (string+(i*2)+1), 2 );
            *(str_tmp+2)=0;
            tmp = strtoul( str_tmp,&ptr, 16);
            if (ptr!=str_tmp+2)
            {
                printf( "intelhex2bin> Daten [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                        strCount, zeilenzaehler );
                return (-3);
            }
            Schecksumme = ( Schecksumme + tmp) & 0x0FF;
        }

        /* Checksumme auslesen und auswerten*/

        strncpy( str_tmp, (string+((intCount+4)*2)+1), 2 );
        *(str_tmp+2)=0;
        tmp = strtoul( str_tmp,&ptr, 16);
        if (ptr!=str_tmp+2)
        {
            printf( "intelhex2bin> Checksumme [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                    strCount, zeilenzaehler );
            return (-4);
        }
        Schecksumme = 0x0000 - Schecksumme;

        if (Schecksumme!=tmp)
        {
            printf( "intelhex2bin> Schecksumme %04X != gelesen %04lX in Zeile %i !\n", Schecksumme, tmp ,zeilenzaehler);
            return (-5);
        }

        /* strTyp = Typ der Zeile:
     00 = DATA RECORD: Aktuelle Daten
     01 = END RECORD: Ende des File Type Record
     02 = EXTENDED SEGMENT ADDRESS RECORD
     Offset  Bit 4 - 19 um die absolute Adresse zu erreichen
     03 = START SEGMENT ADDRESS RECORD (nicht implementiert)
     Offset Bit 4 - 19 um die execution Start Adresse zu erreichen
     04 = EXTENDED LINEAR ADDRESS RECORD
     Offset  Bit 16 - 31 um die absolute Adresse zu erreichen
     05 = START LINEAR ADDRESS RECORD (nicht implementiert)
     Offset Bit 16 - 31 um die execution Start Adresse zu erreichen */


        strncpy( strTyp, (string+7), 2 );
        *(strTyp+2)=0;		/* Eingef�hrt da kein /0 am Ende des Strings
                   sscanf greift auf diesen Speicherplatz zu */
        intTyp = strtoul( strTyp,&ptr, 16);
        if (ptr!=strTyp+2)
        {
            printf( "intelhex2bin> Typ [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                    strCount, zeilenzaehler );
            return (-6);
        }

        /* * * * * intTyp = 0: es sind zu konvertierende daten * * * * */
        switch (intTyp)
        {
        case 0: 	/* Normale Datenzeile */
        case 0x010: 	/* Ende des Blockes (Special BMW) */
            /*** Adresse ermitteln ***/
            strncpy( str_tmp, (string+2+1), 4 );
            *(str_tmp+4)=0;
            tmp = strtoul( str_tmp,&ptr, 16);
            if (ptr!=str_tmp+4)
            {
                printf( "intelhex2bin> Adresse [%s] nicht HEX-INT wandelbar in Zeile %i !\n",
                        strCount, zeilenzaehler );
                return (-7);
            }
            adresse = tmp + offset_2 + offset_4;
            if ((adresse >= from_adr+len) || (adresse < from_adr))
            {
                printf("Skipping Adresse %02lX\n",adresse);
                continue;
            }
            else
            {
                //printf("Writing Adresse %02X: ",adresse);
            }
            /*** Daten ermitteln ***/
            strncpy( strData, (string+9), (intCount*2) );
            for (i=0;i<intCount;i++)
            {
                strncpy( str1Byte, strData+(2*i), 2 );
                str1Byte[2] = '\0';
                byteValue = (unsigned char) strtoul( str1Byte,&ptr, 16);
                if (ptr!=str1Byte+2)
                {
                    printf( "intelhex2bin> Datum [%s] nicht HEX-INT wandelbar in Zeile %i !\n",
                            strCount, zeilenzaehler );
                    return (-8);
                }
                if (adresse+i >= from_adr+len)
                    continue;
                //printf("%02X ",intWord);
                if (feld[i+adresse-from_adr]!=0x0FF)
                {
                    printf( "s192bin> Datum an Adresse %li bereits mit %02X beschrieben in Zeile %i !\n",
                            i+adresse, feld[i+adresse-from_adr], zeilenzaehler );
                    return (-8);
                }
                feld[i+adresse-from_adr] = byteValue;
                filewritechecksum = (filewritechecksum + byteValue) & 0x0FFFF ;
            }
            //printf("\n");
            break;
        case 1: /* Ende des HEX Files */
            /***  File beschreiben mit Daten aus 'feld' bis maxadresse ***/
            for (l=0;l<len;l++)
            {
                filechecksum = (filechecksum + feld[l]) & 0x0FFFF ;
            }
            printf("intelhex2bin> Anzahl_Bytes: %06lX\n",len);
            printf("intelhex2bin> Checksumme out: %04X\n",filechecksum);
            return( 0 );
        case 2: /* EXTENDED SEGMENT ADDRESS RECORD */
            strncpy( str_tmp, (string+(4*2)+1), 4 );
            *(str_tmp+4)=0;
            tmp = strtoul( str_tmp,&ptr, 16);
            if (ptr!=str_tmp+4)
            {
                printf( "intelhex2bin> EXTENDED SEGMENT ADDRESS RECORD: Offset [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                        strCount, zeilenzaehler );
                return (-9);
            }
            offset_2=tmp*0x10;
            //printf( "intelhex2bin> offset_2 = %08X\n", offset_2);
            break;
        case 4: /* EXTENDED LINEAR ADDRESS RECORD */
            strncpy( str_tmp, (string+(4*2)+1), 4 );
            *(str_tmp+4)=0;
            tmp = strtoul( str_tmp,&ptr, 16);
            if (ptr!=str_tmp+4)
            {
                printf( "intelhex2bin> EXTENDED LINEAR ADDRESS RECORD: Offset [%s] HEX-INT nicht wandelbar in Zeile %i !\n",
                        strCount, zeilenzaehler );
                return (-10);
            }
            offset_4=tmp*0x10000;
            //printf( "intelhex2bin> offset_4 = %08X\n", offset_4);
            break;
        case 5: /* ignore Start Linear Address Record 	Lineare Startadresse (EIP-Register) */
            break;
        default:
            printf( "intelhex2bin> Unbekannter Format - Typ %li aufgetaucht in Zeile %i \n", intTyp, zeilenzaehler );
            return( -11 );
        }

    }
    printf( "intelhex2bin> File endete ohne ENDE - RECORD in Zeile %i \n", zeilenzaehler);
    return( -12 );
}



