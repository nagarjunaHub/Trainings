/*===============================================================*\
| Project: PGH Programmiergeraet High-Speed                       |
+-----------------------------------------------------------------+
| File: crctab.c
+-----------------------------------------------------------------+
|                    Used 1999 IMD                                |
|      Ingenieurbuero fuer Microcomputertechnik Th. Doerfler      |
+-----------------------------------------------------------------+
| this file contains functions to calculate a CCITT-CRC32         |
| The table below is derived from the "ZMODEM" source package     |
| Please note the copyright notice below                          |
| Some cosmetic changes by IMD                                    |
| This file is intended to be used in conjunction with the        |
| GNU C Compiler                                                  |
|                                                                 |
+-----------------------------------------------------------------+
|   date                      history                        ID   |
| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |
| 19.07.99  creation                                         doe  |
|*****************************************************************|
|*RCS information:                                                |
|*(the following information is created automatically,            |
|*do not edit here)                                               |
|*****************************************************************|
|* $Log: crctab.h,v $
|* Revision 1.1  2004/05/03 13:49:46  wiese
|* Initial revision
|*
|* Revision 1.1  1999/08/17 19:04:35  thomas
|* added crctab.h (this is a bit late)
|*
|*
 *
|*****************************************************************|
\*===============================================================*/
#ifndef _CRCTAB_H
#define _CRCTAB_H
/*
 * Copyright (C) 1986 Gary S. Brown.  You may use this program, or
 * code or tables extracted from it, as desired without restriction.
 */


extern unsigned long cr3tab[]; /* CRC polynomial 0xedb88320 */
/*
 * WARNING: please note that parameter 'c' is referenced twice,
 * so don't use pointer autoincrement when using this macro!!!
 */
#define UPDC32(b, c) (cr3tab[(((int)c) ^ (b)) & 0xff] ^ (((c) >> 8) & 0x00FFFFFF))

/*
 * sample code to compute the CRC for a memory buffer:
 *
 * unsigned32 calc_crc32(unsigned8 *buffer,size_t len) {
 *   unsigned32 crc_val = 0;
 *   while (len-- > 0) {
 *     crc_val = UPDC32(*buffer,crc_val);
 *     buffer++;
 *   }
 *   return crc_val;
 * }
 */
#endif /* _CRCTAB_H */
