wes3rt@rt-x9250:~/git/utilities/flash/pgh_crc/test (master)> ./test_linux.cmd ../../build-crc_pgh-CCS_Qt5-Release/pgh_crc
../../build-crc_pgh-CCS_Qt5-Release/pgh_crc>file skm.hex, startadr=00000000, endadr=00000FFF, len=00001000
STARTING S192bin with fieldlen 4096 Byte
s192bin> kein Mototrola-S in Zeile 1 !
intelhex2bin> Anzahl_Bytes: 001000
intelhex2bin> Checksumme out: 8DE6
crc=0x68B1BF39
000000 000FFF 68B1BF39
ERG 0x68B1BF39 muss 0x68B1BF39 sein!!
###################################################################
../../build-crc_pgh-CCS_Qt5-Release/pgh_crc>file mpc555_trd.s19, startadr=003F9800, endadr=003FCFFF, len=00003800
STARTING S192bin with fieldlen 14336 Byte
s192bin> to_adr ............................. : 3F9800
s192bin> len ................................ : 003800
s192bin> Checksumme Daten mit 0xFF gef?llt out: E99F
s192bin> Checksumme gelesene Daten          in: 7D0F
crc=0x0D269A2B
3F9800 3FCFFF 0D269A2B
ERG 0x0D269A2B muss 0x0D269A2B sein!!
###################################################################
../../build-crc_pgh-CCS_Qt5-Release/pgh_crc>file globalecusw.s19, startadr=00400000, endadr=0047FFFF, len=00080000
STARTING S192bin with fieldlen 524288 Byte
s192bin> to_adr ............................. : 400000
s192bin> len ................................ : 080000
s192bin> Checksumme Daten mit 0xFF gef?llt out: 883F
s192bin> Checksumme gelesene Daten          in: 883F
crc=0xC8FE9759
400000 47FFFF C8FE9759
ERG 0xC8FE9759 muss 0xC8FE9759 sein!!
###################################################################
../../build-crc_pgh-CCS_Qt5-Release/pgh_crc>file globalecusw.s19, startadr=00800000, endadr=009FFFFF, len=00200000
STARTING S192bin with fieldlen 2097152 Byte
s192bin> to_adr ............................. : 800000
s192bin> len ................................ : 200000
s192bin> Checksumme Daten mit 0xFF gef?llt out: 7452
s192bin> Checksumme gelesene Daten          in: 7452
crc=0x52AA6E92
800000 9FFFFF 52AA6E92
ERG 0x52AA6E92 muss 0x52AA6E92 sein!!
###################################################################
../../build-crc_pgh-CCS_Qt5-Release/pgh_crc>file 1037604341_fbl.hex, startadr=80100000, endadr=8011FFFF, len=00020000
STARTING S192bin with fieldlen 131072 Byte
s192bin> kein Mototrola-S in Zeile 1 !
intelhex2bin> Anzahl_Bytes: 020000
intelhex2bin> Checksumme out: 2801
crc=0xEE03F1A8
80100000 8011FFFF EE03F1A8
ERG 0xEE03F1A8 muss 0xEE03F1A8 sein!!
###################################################################
../../build-crc_pgh-CCS_Qt5-Release/pgh_crc>file 1037604341_fbl.srec, startadr=80100000, endadr=8011FFFF, len=00020000
STARTING S192bin with fieldlen 131072 Byte
s192bin> to_adr ............................. : 80100000
s192bin> len ................................ : 020000
s192bin> Checksumme Daten mit 0xFF gef?llt out: 2801
s192bin> Checksumme gelesene Daten          in: 2801
crc=0xEE03F1A8
80100000 8011FFFF EE03F1A8
ERG 0xEE03F1A8 muss 0xEE03F1A8 sein!!
###################################################################
