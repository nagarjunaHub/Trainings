/* Datei "qactest.h": Automatisch generiert, nicht aendern ! */
/* */
/* */

#ifndef _QACTEST_H
#define _QACTEST_H

#endif /* _QACTEST_H */
