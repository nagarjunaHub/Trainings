# Rb_MetricsAnalysis.py
#
# C. Baudry (AE_BE/ENG3)
# 04.09.2013
#
# Description:
#   This script parses the QAC metrics files (*.met) from all modules
#   and from the CMA analysis (optional).
#   If the database filter is set, only the selected files from the project
#   analysis database will be taken into account. Thus the project has the possibility 
#   to remove non-required metric information (e.g. Matlab files)
#   This script calculates also metrics based on other metrics. 
#   It creates with the collected information html reports.
#   A JSON database is also generated: it can be later easily imported 
#   in another script.
#
# Parameters (inputs):
# - 1 - Path where to find the met files
# - 2 - CMA met file with its path
#           "Path\File"
#           No CMA analysis: "No" / "no"
# - 3 - Metrics configuration file
# - 4 - Project database (xlsx)
# - 5 - Database filter
#           "Yes"
#           "No"
# - 6 - Print error log on console
#           "Yes"
#           "No"
#
# Outputs:
# - JSON database containing all metrics
# - HTML reports:
#   - complete metrics report
#   - configured metrics report
#   - configured corrupted metrics report
# - CSV file for the Jenkins Plots plugin
# - error log
# - Metrics evaluation report
#
# Open points:
# - No open points
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 04.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 001.01 - 10.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Copy the MetricsAnalysis.csv file in the Jenkins workspace
#---------------------------------------------------------------------------
# Version 002.00 - 13.09.2013 -  C. Baudry (AE-BE/ENG3)
#  The metrics which have to be considered are listed in the lists:
#     - __allModuleMetricsList
#     - __allProjectMetricsList
#  Remove the csv analysis report (has been replaced with a JSON database 
#     and html reports)
#   Generate a JSON database containing the module metrics, the CMA metrics
#     and calculated metrics
#   Generate HTML reports
#---------------------------------------------------------------------------
# Version 002.01 - 16.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Correct files to be copied in the Jenkins workspace
#---------------------------------------------------------------------------
# Version 002.02 - 27.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Correct COMF metric calculation
#---------------------------------------------------------------------------
# Version 002.03 - 10.10.2013 -  C. Baudry (AE-BE/ENG3)
#   Add QAC metrics STXLN and STLIN
#---------------------------------------------------------------------------
# Version 002.04 - 11.10.2013 -  C. Baudry (AE-BE/ENG3)
#   Add sum of corrupted metrics in the plot file
#---------------------------------------------------------------------------
# Version 002.05 - 22.10.2013 -  C. Baudry (AE-BE/ENG3)
#   Add file path in the reports
#---------------------------------------------------------------------------
# Version 002.06 - 10.12.2013 -  C. Baudry (AE-BE/ENG3)
#   Replace the sum of all corrupted file per metric of the sum of all
#   violations per metric
#---------------------------------------------------------------------------
# Version 002.07 - 13.12.2013 -  C. Baudry (AE-BE/ENG3)
#   - In addition to the html report, a csv report is created for the complete 
#     metric list. This format can be used for version comparison
#   - Correct VOCF metric
#---------------------------------------------------------------------------
# Version 003.00 - 09.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add the support for the evaluated metric violations
#---------------------------------------------------------------------------
# Version 004.00 - 13.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add the project analysis database filter support
#   - Due to the database update, the compatible version is now the 4
#---------------------------------------------------------------------------
# Version 004.01 - 16.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version: 5
#     No changes required for this new version
#---------------------------------------------------------------------------
# Version 004.02 - 23.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add project metric (from the CMA analysis)
#   - In the case a file has not been found in the database, its metrics are 
#     used anyway: it may be a new file freshly added in the project.
#     (even if the database filter is used)
#   - Remove calculation of MODULE_STCYC: not required
#   - Remove preparation for project STCYC: we get it directly with STCYA
#---------------------------------------------------------------------------
# Version 004.03 - 30.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add function metric STUNR
#---------------------------------------------------------------------------
# Version 005.00 - 30.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - No crash in case the metric configuration file contains white spaces 
#     after the last line
#   - Improve the way the plot file is created
#   - Add the information in the plot file how many non-evaluated metric per
#     metric type
#   - Metric configuration with min condition: add support for float values
#   - The CMA analysis is configurable
#---------------------------------------------------------------------------
# Version 005.01 - 31.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add metrics description at the end of each html report
#---------------------------------------------------------------------------
# Version 005.02 - 12.03.2014 -  M. Hauser (AE-BE/ENG3)
#   - Correct error string
#---------------------------------------------------------------------------
# Version 005.03 - 06.06.2014 -  C.Baudry (AE-BE/ENG3)
#   - Use the project analysis database only if required
#---------------------------------------------------------------------------

''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

import shutil

import json

import datetime

if __name__ == '__main__':

    ''' inits '''
    __metFilesPath                  = sys.argv[1]
    __metFileCMA                    = sys.argv[2]
    __metConfigFile                 = sys.argv[3]
    __inputProjectDatabase          = sys.argv[4]
    __useDatabaseFilter             = sys.argv[5]
    __printErrorLog                 = sys.argv[6]
    __allModuleMetricsList          = ["STCYC","STCAL","STPTH","STGTO","STPAR","STST3","STMIF","STM19","STM21","STM20","STM28","STM22","STOPN","STOPT","STAV3","STXLN","STLIN","STUNR"]
    __allProjectMetricsList         = ["STM29","STNRA","STCYA","STNFA","STNEA"]
    __allMetricsList                = []                                   # list of all metrics supported by this script
    __metricsNotificationList       = []                                   # list of all metrics checked for violations
    __metDatabaseDict               = {}
    __strErrorLog                   = "\n"
    __csvStr                        = ""
    __csvPlotsStrTitles             = ""
    __csvPlotsStrValues             = ""
    __metricsDict                   = {}
    __corruptSumMetricDict          = {}                                   # dictionary which contains the total violations per metric
    __evaluatedCorruptSumMetricDict = {}                                   # dictionary which contains the total evaluated violations per metric
    __tempOutPath                   = os.environ.get("BCMF_TEMP_OUT")
#    __qacOutPath                    = os.environ.get("QAC-OUT_path")
#    __qacErrFile                    = os.environ.get("TARGET_ERR")
    __qacMetFile                    = os.environ.get("TARGET_MET")
    __strMetricsEvaluationReport    = ""
    __evaluatedMetrics              = 0
    __evaluatedCorruptedMetrics     = 0
    __columnFile                    = 0
    __columnFilterMetrics           = 9
    __now                           = datetime.datetime.now()	
    __messageExplainationMetrics = \
    "Metrics definition:<br>\
    <TABLE BORDER='0'><FONT FACE='Arial' SIZE=-1>\
	<TR><TD bgcolor='#D6D6D6' align='center'>QAC</TD><TD bgcolor='#D6D6D6' align='center'>HIS Metric</TD><TD bgcolor='#D6D6D6' align='center'>Description</TD></tr>\
	<TR><TD>STCYC</TD><TD>&nbsp;v(G)</TD><TD>&nbsp;Cyclomatic Complexity</TD></TR>\
    <TR><TD>STPTH</TD><TD>&nbsp;PATH </TD><TD>&nbsp;Number of non-cyclic paths in this function</TD></TR>\
    <TR><TD>STST3</TD><TD>&nbsp;STMT </TD><TD>&nbsp;Number of statements of considered function</TD></TR>\
    <TR><TD>STPAR</TD><TD>&nbsp;PARAM</TD><TD>&nbsp;Number of interface parameters of considered function</TD></TR>\
    <TR><TD>STMIF</TD><TD>&nbsp;LEVEL</TD><TD>&nbsp;Maximum nesting level inside considered function</TD></TR>\
    <TR><TD>STCAL</TD><TD>&nbsp;CALLS</TD><TD>&nbsp;Number of distinct function calls in considered function</TD></TR>\
    <TR><TD>STM19</TD><TD>&nbsp;RETURN</TD><TD>&nbsp;Number of exit points of this function</TD></TR>\
    <TR><TD>STGTO</TD><TD>&nbsp;GOTO</TD><TD>&nbsp;Number of gotos in considered function</TD></TR>\
    <TR><TD>STM29</TD><TD>&nbsp;CALLING</TD><TD>&nbsp;Number of functions calling this function (cross project)</TD></TR>\
    <TR><TD>STNRA</TD><TD>&nbsp;ap_cg_cycle</TD><TD>&nbsp;Number of call graph recursions across project</TD></TR>\
    <TR><TD>COMF</TD><TD>&nbsp;COMF</TD><TD>&nbsp;Ratio between comments and statements</TD></TR>\
    <TR><TD>VOCF</TD><TD>&nbsp;VOCF</TD><TD>&nbsp;Indicator of effort required to change/maintain functions </TD></TR>\
    </TABLE></FONT>\
    <br>You can find more information about SW metrics in this document: <a href='https://inside-ilm.bosch.com/irj/go/nui/sid/download/80342652-fb28-3110-ada7-d80b1fc801c1'>Powerpoint SW metrics</a><br><br>"


    ''' parse the project databases and check the project analysis database version if required '''
    if __useDatabaseFilter.lower() == "yes":
        import openpyxl # Excel 2007 library
        __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
        __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
        __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
        __worksheetGeneral         = __workbook.get_sheet_by_name('General')
        if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
            raise Exception("Error with the script Rb_MetricsAnalysis.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    
    ''' prepare the list of all possible metrics (will be used for some special analysis) '''
    for __element in __allModuleMetricsList:
        __allMetricsList.append(__element)
    for __element in __allProjectMetricsList:
        __allMetricsList.append(__element)
    
    
    ''' parse the metrics configuration file '''
    ''' file format: METRIC_NAME RANGE '''
    try:
        __metricConfigFileHandler = open(__metConfigFile)
        __metricsConfiguration = __metricConfigFileHandler.readlines()
        __metricConfigFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the metric config file " + __metConfigFile + "!!\n")

    #create a metric list for the notification based on the config file
    #and create a metrics dictionary which contains the thresholds
    for indexMetricConfig in range(len(__metricsConfiguration)):
        # remove trailing white-space
        __metricsConfiguration[indexMetricConfig] = __metricsConfiguration[indexMetricConfig].rstrip()
        if __metricsConfiguration[indexMetricConfig]:
            __metricsNotificationList.append(__metricsConfiguration[indexMetricConfig].split()[0])
            __metricsDict[__metricsConfiguration[indexMetricConfig].split()[0]] = __metricsConfiguration[indexMetricConfig].split()[1]
   
    
    ''' the violation sum dictionaries are initialised with the list of all metrics to be notified '''
    for __metricType in __metricsNotificationList:
        __corruptSumMetricDict[__metricType] = 0
        __evaluatedCorruptSumMetricDict[__metricType] = 0
   
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Met files analysis '''
    # Parse the met file directory looking for met files
    # Parse the met files and collect all required information
    # If the database filter is used (parameter): only the selected files in the project analysis database are analysed
    # In the case a file has not been found in the database, its metrics are used anyway: it may be a new file freshly 
    #    added in the project.
    
    for __root, __dirs, __files in os.walk(__metFilesPath):
        for __file in __files:
            if __file.endswith(".met"):
                
                if __useDatabaseFilter.lower() == "yes":
                    __fileFound    = False
                    __fileSelected = False
                    for __row in __worksheetDatabaseSources.rows:
                        # database and metrics file comparison
                        # -> compare the file name with the extension but without the .met second extension
                        if os.path.splitext(os.path.basename(__file).lower())[0] == os.path.basename(__row[__columnFile].value).lower():
                            __fileFound = True
                            try: # try/except used in the case the cell is empty
                                # check if the file is selected in the project database for the metrics analysis
                                if __row[__columnFilterMetrics].value.lower() == "x":
                                    __fileSelected = True
                            except:
                                pass
                            break
                    
                    # log: case the file has not been found
                    if __fileFound == False:
                        __strErrorLog += "-- Metrics analysis warning: the following file has not been found in the project database: %s\n" % __file
                    
                else: 
                    # all files are used if the database filter is not set 
                    __fileSelected = True
                
                ''' get the metric file content '''
                if __fileSelected or (__fileFound == False):
                    try:
#                        print "Reading the File lines: " + __metFilesPath + "\\" + __file + "\n"
                        __metFileHandler = open(__metFilesPath + "\\" + __file)
                        __metFileContent = __metFileHandler.readlines()
                        __metFileHandler.close()
                    except:
                        raise Exception("ERROR: Impossible to read the file " + __metFilesPath + "\\" + __file + "!!\n")
                    
                    for index in range(len(__metFileContent)):
                        
                        ''' we get the information for each function '''
                        if re.search("<S>STFIL",__metFileContent[index]):
                            
                            __loop = 0
                            __metricsStr = ""
                            __parametersCsv = []
                            
                            # function found in the metrics information, the metrics data can be read out from there
                            # the functions are separated with a new line
                            __fileName = __metFileContent[index].split()[1]
                            
                            
                            if not __fileName in __metDatabaseDict:
                                __metDatabaseDict[__fileName] = {}
                            
                            
                            while True:
                                
                                __loop += 1
                                
                                if (index + __loop) >= len(__metFileContent):
                                    break
                                if __metFileContent[index + __loop] == "<S>\n":
                                    break
                                
                                # look for the function name STNAM
                                if re.search("<S>STNAM",__metFileContent[index + __loop]):
                                    __functionName = __metFileContent[index + __loop].split()[1]
                                    #case module metric: the function name has the file name and is replaced with a "-"
                                    if __functionName == __fileName:
                                        __functionName = "-"
                                    if not __functionName in __metDatabaseDict[__fileName]:
                                        __metDatabaseDict[__fileName][__functionName] = {}
                                
                                for __element in __allModuleMetricsList:
                                    if re.search("<S>" + __element,__metFileContent[index + __loop]):
                                        __metDatabaseDict[__fileName][__functionName][__element] = __metFileContent[index + __loop].split()[1]
                                    else:
                                        if not __element in __metDatabaseDict[__fileName][__functionName]:
                                            __metDatabaseDict[__fileName][__functionName][__element] = "-"
                
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' CMA metrics analysis '''
    
    # the CMA metric analysis is done according to the script given parameter
    if __metFileCMA.lower() != "no":
    
        # Parse the CMA met file and collect all required information
        # If the database filter is used (parameter): only the selected files in the project analysis database are analysed
        # In the case a file has not been found in the database, its metrics are used anyway: it may be a new file freshly 
        #    added in the project. This use case is also useful for the project CMA analysis: the result file does not exist 
        #    as c file in the project database but has to be listed in the metrics results.

        ''' get the CMA metric file content '''
        try:
            __metFileHandler = open(__metFileCMA)
            __metFileContent = __metFileHandler.readlines()
            __metFileHandler.close()
        except:
            raise Exception("ERROR: Impossible to read the file " + __metFileCMA + "!!\n")

        for index in range(len(__metFileContent)):
            
            ''' we get the information for each file/function '''
            if re.search("<S>STFIL",__metFileContent[index]):
                
                __loop = 0
                __metricsStr = ""
                __parametersCsv = []
                
                # function found in the metrics information, the metrics data can be read out from there
                # the functions are separated with a "<S>\n"
                __fileName = __metFileContent[index].split()[1]
                
                # if the database filter is used (parameter): only the selected files in the project analysis database are analysed
                if __useDatabaseFilter.lower() == "yes":
                    # check if the file is selected in the project database for the metrics analysis
                    # in the CMA results it is also possible to have metrics contained in header files, so we have to check also the header tab in the database
                    __fileFound    = False
                    __fileSelected = False
                    
                    # look for the file in the database source tab
                    for __row in __worksheetDatabaseSources.rows:
                        # database and metrics file comparison
                        # -> compare the file name with the extension
                        if os.path.basename(__fileName).lower() == os.path.basename(__row[__columnFile].value).lower():
                            __fileFound = True
                            try: # try/except used in the case the cell is empty
                                if __row[__columnFilterMetrics].value.lower() == "x":
                                    __fileSelected = True
                            except:
                                pass
                            break
                    
                    # look for the file in the database header tab
                    if __fileFound == False:
                        for __row in __worksheetDatabaseHeaders.rows:
                            # database and metrics file comparison
                            # -> compare the file name with the extension
                            if os.path.basename(__fileName).lower() == os.path.basename(__row[__columnFile].value).lower():
                                __fileFound = True
                                try: # try/except used in the case the cell is empty
                                    if __row[__columnFilterMetrics].value.lower() == "x":
                                        __fileSelected = True
                                except:
                                    pass
                                break
                    
                    # log: case the file has not been found
                    if __fileFound == False:
                        __strErrorLog += "-- Metrics analysis warning: the following file has not been found in the project database: %s\n" % __fileName
                    
                else: 
                    # all files are used if the database filter is not set 
                    __fileSelected = True
                
                if __fileSelected or (__fileFound == False):
                
                    if not __fileName in __metDatabaseDict:
                        __metDatabaseDict[__fileName] = {}
                    
                    while True:
                        
                        __loop += 1
                        
                        if (index + __loop) >= len(__metFileContent):
                            break
                        if __metFileContent[index + __loop] == "<S>\n":
                            break
                        
                        # look for the function name
                        if re.search("<S>STNAM",__metFileContent[index + __loop]):
                            __functionName = __metFileContent[index + __loop].split()[1]
                            if not __functionName in __metDatabaseDict[__fileName]:
                                __metDatabaseDict[__fileName][__functionName] = {}
                            
                        for __element in __allProjectMetricsList:
                            if re.search("<S>" + __element,__metFileContent[index + __loop]):
                                __metDatabaseDict[__fileName][__functionName][__element] = __metFileContent[index + __loop].split()[1]
                            else:
                                if not __element in __metDatabaseDict[__fileName][__functionName]:
                                    __metDatabaseDict[__fileName][__functionName][__element] = "-"
                
                
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Special cases: metrics calculations '''    

    ''' Special case 1: COMF Comment density: STM28/STM22 '''
    __allMetricsList.append("COMF")
    for __file in __metDatabaseDict:
        __tempCOMF  = 0.0
        __tempSTM28 = 0
        __tempSTM22 = 0
        __functionToBeConsidered = 0
        for __function in __metDatabaseDict[__file]:
            for __metric in __metDatabaseDict[__file][__function]:
                if (__metric == "STM28") & (__metDatabaseDict[__file][__function][__metric] != "-"):
                    __tempSTM28 = int(__metDatabaseDict[__file][__function][__metric])
                    __functionToBeConsidered += 1
                if (__metric == "STM22") & (__metDatabaseDict[__file][__function][__metric] != "-"):
                    __tempSTM22 = int(__metDatabaseDict[__file][__function][__metric])
                    __functionToBeConsidered += 1
        if (__functionToBeConsidered == 2) & (__tempSTM22 != 0):
            #add a new element in the database with __function="-" containing COMF (in not exist)
            __tempCOMF = float(__tempSTM28) / float(__tempSTM22)
            if not "-" in __metDatabaseDict[__file]:
                __metDatabaseDict[__file]["-"] = {}
            __metDatabaseDict[__file]["-"]["COMF"] = "%.2f" % __tempCOMF
    
    
    ''' Special case 2: VOCF Sprachumfang: (STM21+STM20)/(STOPN+STOPT) '''
    __allMetricsList.append("VOCF")
    for __file in __metDatabaseDict:
        __tempVOCF  = 0
        __tempSTM21 = 0
        __tempSTM20 = 0
        __tempSTOPN = 0
        __tempSTOPT = 0
        __functionToBeConsidered = 0
        for __function in __metDatabaseDict[__file]:
            for __metric in __metDatabaseDict[__file][__function]:
                if (__metric == "STM21") & (__metDatabaseDict[__file][__function][__metric] != "-"):
                    __tempSTM21 = int(__metDatabaseDict[__file][__function][__metric])
                    __functionToBeConsidered += 1
                if (__metric == "STM20") & (__metDatabaseDict[__file][__function][__metric] != "-"):
                    __tempSTM20 = int(__metDatabaseDict[__file][__function][__metric])
                    __functionToBeConsidered += 1
                if (__metric == "STOPN") & (__metDatabaseDict[__file][__function][__metric] != "-"):
                    __tempSTOPN = int(__metDatabaseDict[__file][__function][__metric])
                    __functionToBeConsidered += 1
                if (__metric == "STOPT") & (__metDatabaseDict[__file][__function][__metric] != "-"):
                    __tempSTOPT = int(__metDatabaseDict[__file][__function][__metric])
                    __functionToBeConsidered += 1
        if __functionToBeConsidered == 4:
            #add a new element in the database with __function="-" containing VOCF
            try:
                __tempVOCF = (__tempSTM21 + __tempSTM20) / (__tempSTOPN + __tempSTOPT)
                if not "-" in __metDatabaseDict[__file]:
                    __metDatabaseDict[__file]["-"] = {}
                __metDatabaseDict[__file]["-"]["VOCF"] = __tempVOCF
            except:
                __strErrorLog += "-- Metrics analysis warning: issue with the metric VOCF, file %s\n" % __file
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Check the metrics evaluations in the project source files '''
    for __file in __metDatabaseDict:
    
        #open project source file to be parsed
        try:
            __currentFileHandler = open(__file)
            __currentFileContent = __currentFileHandler.readlines()
            __currentFileHandler.close()
        except:
            __strErrorLog += "-- Metrics evaluation warning: impossible to read the file " + __file + "!!\n"
    
        #parse the file looking for the functions
        for __function in __metDatabaseDict[__file]:
            if __function != "-":
                for __index in range(len(__currentFileContent)):
                    if re.search(__function, __currentFileContent[__index]):
                        #look for the evaluation patterns at the lines before
                        __indexTemp = __index
                        while True:
                            __indexTemp -= 1
                            __searchResult = re.search(".*//\s*METRIC\s+(.+)\s+EVAL\s*:\s*(.+)", __currentFileContent[__indexTemp])
                            if __searchResult:
                                __metric  = __searchResult.group(1)
                                __comment = __searchResult.group(2)
                                try:
                                    __metDatabaseDict[__file][__function][__metric] = __metDatabaseDict[__file][__function][__metric] + "***" + __comment
                                    __strMetricsEvaluationReport += "-- Metric evaluation: %s, function: %s, line: %s, metric type: %s\n" % (__file,__function,str(__indexTemp+1),__metric)
                                    __strMetricsEvaluationReport += "   %s\n\n" % __comment
                                    __evaluatedMetrics += 1
                                except:
                                    __strErrorLog += "-- Metrics evaluation warning: issue with the evaluation in the file %s, line %s\n" % (__file,str(__indexTemp+1))
                            else:
                                break
    
    #example to go through the dictionary
    #EX for __file in __metDatabaseDict:
    #EX     print __file
    #EX     for __function in __metDatabaseDict[__file]:
    #EX         print "  - " + __function
    #EX         for __metric in __metDatabaseDict[__file][__function]:
    #EX             print "   %s = %s" % (__metric,__metDatabaseDict[__file][__function][__metric])
    #EX 
    #EX for __file in __dictFileResponsibles:
    #EX     print "%s: %s" % (__file,__dictFileResponsibles[__file])
    
    
    #JSON export
    json.dump(__metDatabaseDict, open(__tempOutPath + "\\" + "projectMetricsExport.json", "w"),sort_keys=True, indent=4)
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Create reports with all metrics information (html + csv) '''
    
    #the csv report can be used to compare 2 result files
    
    __completeHtmlReport = "<FONT FACE='Arial' SIZE=-1><table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th align='left'>Function name</th>"
    __completeCsvReport  = "File name;Function name;"
    
    #dynamic columns names (depending on how many metrics are configured)
    for __metricName in __allMetricsList:
        __completeHtmlReport += "<th width='50'>%s</th>" % __metricName
        __completeCsvReport  += "%s;" % __metricName
    #end of html line
    __completeHtmlReport += "</tr>"
    __completeCsvReport  += "\n"
    for __file in __metDatabaseDict:
        for __function in __metDatabaseDict[__file]:
            __completeHtmlReport += "<tr><td align='left'>%s</td><td align='left'>%s</td>" % (__file,__function)
            __completeCsvReport  += "%s;%s;" % (__file,__function)
            #get the different metrics and their values
            for __metricName in __allMetricsList:
                __metricFound = False
                for __currentMetric in __metDatabaseDict[__file][__function]:
                    if __metricName == __currentMetric:
                        #separate the possible comment from the metric value 
                        try:
                            __metricValue = __metDatabaseDict[__file][__function][__currentMetric].split("***")[0]
                        except:
                            __metricValue = __metDatabaseDict[__file][__function][__currentMetric]
                        __completeHtmlReport += "<td align='center'>%s</td>" % __metricValue
                        __completeCsvReport  += "%s;" % __metricValue
                        __metricFound = True                
                #case no metric info for the given function or file: empty cell
                if __metricFound != True:
                    __completeHtmlReport += "<td align='center'>-</td>"
                    __completeCsvReport  += "-;"
            #end of html line
            __completeHtmlReport += "</tr>"
            __completeCsvReport  += "\n"
    __completeHtmlReport += "</table><br><br></FONT>%s" % __messageExplainationMetrics
    
    #create html file
    try:
        __tempFileHandler = open(__tempOutPath + "\\MetricsAnalysisReport.html", 'w')
        __tempFileHandler.write(__completeHtmlReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\MetricsAnalysisReport.html", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the html metrics analysis report file!!\n")
    
    #create csv file
    try:
        __tempFileHandler = open(__tempOutPath + "\\MetricsAnalysisReport.csv", 'w')
        __tempFileHandler.write(__completeCsvReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\MetricsAnalysisReport.csv", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the csv metrics analysis report file!!\n")
                
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Create a report with configured metrics and a report which contains only the corrupted functions '''
    
    #HTML report
    __configuredHtmlCorruptedReport = "<FONT FACE='Arial' SIZE=-1><table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th align='left'>Function name</th>"
    __configuredHtmlReport = "<FONT FACE='Arial' SIZE=-1><table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th align='left'>Function name</th>"
    #dynamic columns names (depending on how many metrics are configured)
    for __metricName in __metricsNotificationList:
        __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % __metricName
        __configuredHtmlReport += "<th width='50'>%s</th>" % __metricName
    #end of html line


    ###################    
    # New (sk): print Min and Max range in 2 next lines after colunmn headlins to HTML


    # 1x Empty column + Row-Name Min-Range
    __configuredHtmlCorruptedReport += "</tr><th width='50'>%s</th>" % " "
    __configuredHtmlReport += "</tr><th width='50'>%s</th>" % " "
    __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % "Min-Range"
    __configuredHtmlReport += "<th width='50'>%s</th>" % "Min-Range"
        
    # Min-Range Limits
    for __metricName in __metricsNotificationList:
        __checkCondition = __metricsDict[__metricName]
        #case the condition is a range

        if re.search("([0-9,*])-([0-9,*])",__checkCondition):
 #          __rangeMin = float(re.split("-",__checkCondition)[0])
            __rangeMin = re.split("-",__checkCondition)[0]
            __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % __rangeMin
            __configuredHtmlReport += "<th width='50'>%s</th>" % __rangeMin
        else:
            __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % " "
            __configuredHtmlReport += "<th width='50'>%s</th>" % " "
                
    #end of html line

    # 1x Empty column + Row-Name Max-Range
    __configuredHtmlCorruptedReport += "</tr>"
    __configuredHtmlReport += "</tr>"
    __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" " "
    __configuredHtmlReport += "<th width='50'>%s</th>" % " "
    __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % "Max-Range"
    __configuredHtmlReport += "<th width='50'>%s</th>" % "Max-Range"
        
    # Max-Range Limits
    for __metricName in __metricsNotificationList:
        __checkCondition = __metricsDict[__metricName]
        #case the condition is a range

        if re.search("([0-9,*])-([0-9,*])",__checkCondition):
 #          __rangeMax = float(re.split("-",__checkCondition)[1])
            __rangeMax = re.split("-",__checkCondition)[1]
            __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % __rangeMax
            __configuredHtmlReport += "<th width='50'>%s</th>" % __rangeMax
        else:
            __configuredHtmlCorruptedReport += "<th width='50'>%s</th>" % " "
            __configuredHtmlReport += "<th width='50'>%s</th>" % " "
    #################### 
                   
    #end of html line
        
    __configuredHtmlCorruptedReport += "</tr>"
    __configuredHtmlReport += "</tr>"
    __corruptSumm = 0
    for __file in __metDatabaseDict:
        for __function in __metDatabaseDict[__file]:
            __corruptedFunction = False
            __tmpFunctionReport = "<tr><td align='left'>%s</td><td align='left'>%s</td>" % (__file,__function)
            #get the different metrics and their values
            for __metricName in __metricsNotificationList:
                __metricFound = False
                for __currentMetric in __metDatabaseDict[__file][__function]:
                    if __metricName == __currentMetric:
                        #we ignore the metric if it has the value "-"
                        if __metDatabaseDict[__file][__function][__currentMetric] != "-":
                            
                            #get the metric value and the metric evaluation comment if present 
                            try:
                                __metricValue = __metDatabaseDict[__file][__function][__currentMetric].split("***")[0]
                                try:
                                    __metricEvaluationComment = __metDatabaseDict[__file][__function][__currentMetric].split("***")[1]
                                except:
                                    __metricEvaluationComment = ""
                            except:
                                __metricValue = __metDatabaseDict[__file][__function][__currentMetric]
                                __metricEvaluationComment = ""
                            
                            #color in the report: grey if the violation has not been evaluated, yellow if it has been.
                            if __metricEvaluationComment == "": 
                                __color = "#BDBDBD" #grey
                            else: 
                                __color = "#F2F5A9" #yellow
                            
                            __metricFound = True
                            
                            #get the configured metric condition
                            __checkCondition = __metricsDict[__metricName]
                            #case the condition is a range
                            if re.search("([0-9])-([0-9])",__checkCondition):
                                __rangeMin = float(re.split("-",__checkCondition)[0])
                                __rangeMax = float(re.split("-",__checkCondition)[1])
                                #check the metric value according to the configured range
                                if (__metricValue != "-"):								
                                    if (float(__metricValue) > __rangeMax) | (float(__metricValue) < __rangeMin): 
                                        #outside range! corrupted function
                                        __corruptedFunction = True
                                        __tmpFunctionReport += "<td bgcolor='%s' align='center'>%s</td>" % (__color, __metricValue)
                                        __corruptSumm += 1
                                        __corruptSumMetricDict[__metricName] += 1
                                        if __metricEvaluationComment != "":
                                            __evaluatedCorruptSumMetricDict[__metricName] += 1
                                    else:
                                        __tmpFunctionReport += "<td align='center'>%s</td>" % __metricValue
                                else:
                                    __tmpFunctionReport += "<td align='center'>%s</td>" % __metricValue
                            #case the condition is a min
                            if re.search("[0-9]+\.*[0-9]*-\*",__checkCondition):
                                __min = float(re.split("-",__checkCondition)[0])
                                #check the metric value according to the configured min value
                                if (float(__metricValue) < __min): 
                                    #outside range! corrupted function
                                    __corruptedFunction = True
                                    __tmpFunctionReport += "<td bgcolor='%s' align='center'>%s</td>" % (__color,__metricValue)
                                    __corruptSumm += 1
                                    __corruptSumMetricDict[__metricName] += 1
                                    if __metricEvaluationComment != "":
                                        __evaluatedCorruptedMetrics +=1
                                        __evaluatedCorruptSumMetricDict[__metricName] += 1
                                else:
                                    __tmpFunctionReport += "<td align='center'>%s</td>" % __metricValue          
                #case no metric info for the given function or file: empty cell
                if __metricFound != True:
                    __tmpFunctionReport += "<td align='center'>-</td>"
            #end of html line
            __tmpFunctionReport += "</tr>"
            __configuredHtmlReport += __tmpFunctionReport
            
            if __corruptedFunction == True:
                __configuredHtmlCorruptedReport += __tmpFunctionReport

    __configuredHtmlReport += "</table><br><br></FONT>"
	
#Report the Total Violations for each metric.
# __configuredHtmlReport += "<hr><B><U>"
    __configuredHtmlReport += "<FONT FACE='Arial' SIZE=-1><table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>Metric Name</th>"
    __violationsReport = "<tr BGCOLOR='#D6D6D6'><th align='left'>Total Violations</th>"

    for __metricName in __corruptSumMetricDict:
        __configuredHtmlReport += "<th width='50'>%s</th>" % __metricName
    __configuredHtmlReport += "</tr>"
    __configuredHtmlReport += "<tr><th align='left' BGCOLOR='#D6D6D6'>Total Violations</th>"	
    for __metricType in __corruptSumMetricDict:
        if (__corruptSumMetricDict[__metricType] > 0):
            __configuredHtmlReport += "<th width='50' BGCOLOR='#D6D6D6'>%s</th>" % str(__corruptSumMetricDict[__metricType])
        else:
            __configuredHtmlReport += "<th width='50'>%s</th>" % str(__corruptSumMetricDict[__metricType])		
    __configuredHtmlReport += "</tr></table></FONT>"
		
    __configuredHtmlCorruptedReport += "</table><br><br></FONT>%s" % __messageExplainationMetrics
    __configuredHtmlReport += "</table><br><br></FONT>%s" % __messageExplainationMetrics
    __configuredHtmlReport += "Report generated on: %s" % __now.strftime('%Y-%m-%d %H:%M:%S') 
    #report with all configured information
    try:
        __tempFileHandler = open(__tempOutPath + "\\qac_summary_me.html", 'w')	
        __tempFileHandler.write(__configuredHtmlReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if ((os.environ.get("WORKSPACE") != "") and (__qacMetFile == "cma_out_file")):
                shutil.copy(__tempOutPath + "\\qac_summary_me.html", os.environ.get("WORKSPACE")+ "\\qac_summary_me_"+datetime.date.today().strftime('%m-%d-%Y')+".html")
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the metrics analysis report file!!\n")
    #report with only configured information outside the ranges
    try:
        __tempFileHandler = open(__tempOutPath + "\\MetricsAnalysisConfiguredCorruptedReport.html", 'w')
        __tempFileHandler.write(__configuredHtmlCorruptedReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\MetricsAnalysisConfiguredCorruptedReport.html", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the metrics analysis report file!!\n")
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Plots plugin: sum all violations per metric type and create a csv file for that '''        
    
    ''' get the total violations per metric '''
    for __metricType in __corruptSumMetricDict:
        __csvPlotsStrTitles += __metricType + ","
        __csvPlotsStrValues += str(__corruptSumMetricDict[__metricType]) + ","
    
    ''' get the total non-evaluated violations per metric '''
    for __metricType in __evaluatedCorruptSumMetricDict:
        __csvPlotsStrTitles += __metricType + "_nonEvaluated,"
        __csvPlotsStrValues += str(__corruptSumMetricDict[__metricType]-__evaluatedCorruptSumMetricDict[__metricType]) + ","
    
    ''' add the sum of all violations '''
    __csvPlotsStrTitles += "Summ_Corrupted_Metrics,"
    __csvPlotsStrValues += str(__corruptSumm) + ","
    
    ''' add the sum of the corrupted and non-evaluated metrics in the CSV file '''
    #we have already the sum of all evaluated metrics. We can't use it for the sum of the corrupted non-evaluated metrics:
    #  it is possible that some CORRECT metrics have been evaluated: in this case the calculations would be wrong.
    #  For the calculations we use the variable __evaluatedCorruptedMetrics which has been calculated previously
    __corruptNonEvaluatedSumm = __corruptSumm - __evaluatedCorruptedMetrics
    __csvPlotsStrTitles += "Summ_Corrupted_Non_Evaluated_Metrics"
    __csvPlotsStrValues += str(__corruptNonEvaluatedSumm)
    
    ''' create the csv file for the plots plugin '''
    try:
        __tempFileHandler = open(__tempOutPath + '\\MetricsPlots.csv', 'w')
        __tempFileHandler.write(__csvPlotsStrTitles + "\n" + __csvPlotsStrValues)
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create the Metrics Plots csv file!!\n")  
    
    ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
    try:
        if os.environ.get("WORKSPACE") != "":
            shutil.copy(__tempOutPath + "\\MetricsPlots.csv", os.environ.get("WORKSPACE"))
    except:
        pass

    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' metrics evaluation report file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\MetricsEvaluationReport.txt", 'w')
        __tempFileHandler.write(__strMetricsEvaluationReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\MetricsEvaluationReport.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the metrics evaluation report file!!\n")
        
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\MetricsAnalysisErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\MetricsAnalysisErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Metrics Analysis error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    
    ''' end of file '''
