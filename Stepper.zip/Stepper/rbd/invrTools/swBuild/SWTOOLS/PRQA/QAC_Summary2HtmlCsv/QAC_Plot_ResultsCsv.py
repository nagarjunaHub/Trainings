''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess

import datetime

import shutil


if __name__ == '__main__':
	__qacErrorSummary = sys.argv[1]
	__qacPlotResultsCSV = sys.argv[2]
	__jenkinsWorkspace = os.environ.get("WORKSPACE")
	__tempOutPath                   = os.environ.get("BCMF_TEMP_OUT")	
	__csvPlotFile = __tempOutPath + "\\" + __qacPlotResultsCSV
	__strCSVtitle         = ""
	__strCSV              = ""
	__qacResults          = range(10)	
	__qacErrorSummaryModified,__ext = os.path.splitext(os.path.basename(__qacErrorSummary))
	__qacErrorSummaryReport= __qacErrorSummaryModified+"_"+datetime.date.today().strftime('%m-%d-%Y')+__ext
	
	''' if Jenkins is used:
				- copy the file in the Jenkins workspace
				- generate a csv file for the plot plugin '''
	### Check if the build was started from Jenkins or local PC.
	if __jenkinsWorkspace != None:
		shutil.copy(__qacErrorSummary, os.environ.get("WORKSPACE")+"\\"+__qacErrorSummaryReport)
	else:
		print __qacErrorSummaryReport
		print "executing from Local PC"	
	try:
		__qacErrorSummaryHandler = open(__qacErrorSummary)
		__qacErrorSummarydata = __qacErrorSummaryHandler.readlines()
		__qacErrorSummaryHandler.close()
	except:
		raise Exception("ERROR: The file " + __qacErrorSummary + " can not be read.\n") 
	
	for index in range(0,10):
		__strCSVtitle += "Level %s," % str(9-index)

	for __line in __qacErrorSummarydata:
		if re.search("Total +",__line):
			__resultLine = __line.split()
			for index in range(1,11):
				if (__resultLine[index] != "*"):				
					__strCSV += __resultLine[index] + ","
					__qacResults[10-index] = int(__resultLine[index])
				else:
					__strCSV += ","									
					__qacResults[10-index] = 0
			break
	
	#add a sum in the csv file
	#sum level 4 to 9
	# if os.path.isfile(__csvPlotFile):
		# print "csv file was removed ...	"
		# os.remove(__csvPlotFile)
	__sumTmp = 0

	for index in range(4,10):
		__sumTmp += __qacResults[index]
	__strCSVtitle += "SumLevels_4_to_9"
	__strCSV      += str(__sumTmp)
	
	try:
		__csvFileHandler = open(__csvPlotFile, "w")
		__csvFileHandler.write(__strCSVtitle + "\n" + __strCSV)
		__csvFileHandler.close()
	except:
		raise Exception ("ERROR: The file " + __csvPlotFile + " can not be written or created.\n")

	if __jenkinsWorkspace != None:
		print "Copying csv file to workspace ..."
		if os.path.isfile(os.environ.get("WORKSPACE") + "\\QAC_Plot_Results.csv"):
			os.remove(os.environ.get("WORKSPACE") + "\\QAC_Plot_Results.csv")
		shutil.copy(__csvPlotFile, os.environ.get("WORKSPACE"))		
		
		
	# if __jenkinsWorkspace == "Yes":
				
		# shutil.copy(__qacErrorSummary, os.environ.get("WORKSPACE"))
		
		# try:
			# __qacErrorSummaryHandler = open(__qacErrorSummary)
			# __qacErrorSummarydata = __qacErrorSummaryHandler.readlines()
			# __qacErrorSummaryHandler.close()
		# except:
			# raise Exception("ERROR: The file " + __qacErrorSummary + " can not be read.\n") 
		
		# for index in range(0,10):
			# __strCSVtitle += "Level %s," % str(9-index)

		# for __line in __qacErrorSummarydata:
			# if re.search("Total +",__line):
				# __resultLine = __line.split()
				# for index in range(1,11):
					# __strCSV += __resultLine[index] + "," 
					# __qacResults[10-index] = int(__resultLine[index])
				# break
		
		#add a sum in the csv file
		#sum level 4 to 9
		# __sumTmp = 0
		# for index in range(4,10):
			# __sumTmp += __qacResults[index]
		# __strCSVtitle += "SumLevels_4_to_9"
		# __strCSV      += str(__sumTmp)
				
		# try:
			# __csvFileHandler = open(__csvPlotFile, "w")
			# __csvFileHandler.write(__strCSVtitle + "\n" + __strCSV)
			# __csvFileHandler.close()
		# except:
			# raise Exception ("ERROR: The file " + __csvPlotFile + " can not be written or created.\n")
		
		# shutil.copy(__csvPlotFile, os.environ.get("WORKSPACE"))