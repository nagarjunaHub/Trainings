
''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' csv functions '''
import csv
import operator

''' Excel 2007 library '''
# import openpyxl

import shutil

import json

from collections import defaultdict
from array import *

if __name__ == '__main__':

    ''' inits '''
    __inputSummaryFile     = sys.argv[1]
    __tempNotificationOutPath = sys.argv[2]
    __flag = 0
    __startLevel           = int(sys.argv[3])	
    # __startLevel           = 3	
    __qacWarningsNotifier   = sys.argv[4]
    __correptAry=array('L',[0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    __jenkinsWorkspace = os.environ.get("WORKSPACE")
    __correptAryValues=array('L',[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    __mailMessageModule    = "<hr><B><U>QAC warnings notifications</U></B><br><br>For this project the QAC warnings from level %s have to be removed. The following listed files contain warnings from level %s.<br><br>\
    Warnings details:<br>\
    - Source files: You can directly access to the QAC html reports clicking on the files name in the table below.<br>\
    - Header files: A QAC module analysis of the related module has to be done via the BCMF GUI<br>\
    You can find the warnings of a given level searching with your browser the following pattern (e.g. for level 3): Msg(3" % ( str(__startLevel),str(__startLevel) )
    ''' parse the QAC summary file '''
    try:
        __summaryFileHandler = open(__inputSummaryFile)
        __summaryFileContent = __summaryFileHandler.readlines()
        __summaryFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the QAC summary file " + __inputSummaryFile + "!!\n")

    __strResultsUser = "<FONT FACE='Arial' SIZE=-1>%s<br><br>" % __mailMessageModule
    __strResultsUser += "<table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th width='50'>9</th><th width='50'>8</th><th width='50'>7</th><th width='50'>6</th><th width='50'>5</th><th width='50'>4</th><th width='50'>3</th><th width='50'>2</th><th width='50'>1</th><th width='50'>0</th><th width='50'>Total</th></tr>"
    for __line in __summaryFileContent:
		# if ((re.search("N:",__line) or re.search("C:",__line)) and not re.search("Report File Name:",__line)):
        if (__line.startswith(':\\',1, 3)):
            __folder = __line.rstrip()
            if __flag == 1:
                __flag = 0
                __strResultsUser += "</table><br><br><br></FONT>"
                __strResultsUser += "<FONT FACE='Arial' SIZE=-1>%s<br><br>" % __mailMessageModule
                __strResultsUser += "<table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th width='50'>9</th><th width='50'>8</th><th width='50'>7</th><th width='50'>6</th><th width='50'>5</th><th width='50'>4</th><th width='50'>3</th><th width='50'>2</th><th width='50'>1</th><th width='50'>0</th><th width='50'>Total</th></tr>"
			
        elif re.search("^\S+\.(c|h)",__line) and (__line.find("\\")==-1):
            __flag = 1
            __lineFound = __line.split()
            __fileName = __lineFound[0]
			
            ''' create hyperlink for __fileName if it is a .c file '''
            if re.search("\.c", __fileName):
				if re.search("_cc.c",__fileName):
					__fileName_href = __fileName.replace("_cc.c","_mr.html")
				else:
					__fileName_href = __fileName.replace(".c","_mr.html")				
				__strResultsUser += "<tr><td align='left'><a href='file:///%s\\%s'>%s</a></td>" % (__tempNotificationOutPath,__fileName_href,__fileName)
            else:
                __strResultsUser += "<tr><td align='left'>%s</td>" % __fileName
            __warningsLine = __line.split()
            __count = 0
            for value in range(1, len(__warningsLine)):
                if (__warningsLine[value] != "*" and __warningsLine[value] != "-"):
                    if (value<11-__startLevel and int(__warningsLine[value]) >0):
                        __strResultsUser += "<td bgcolor='BDBDBD' align='center'>%s</td>" % __warningsLine[value]
                        __correptAry[__count] = __correptAry[__count] + 1
                        __correptAryValues[__count] = __correptAryValues[__count] + int(__warningsLine[value])					
                    else:
                        __strResultsUser += "<td align='center'>%s</td>" % __warningsLine[value]
                        __correptAryValues[__count] = __correptAryValues[__count] + int(__warningsLine[value])											                        
                else:
                    __strResultsUser += "<td align='center'>%s</td>" % __warningsLine[value]
                
                __count = __count + 1
            __strResultsUser += "</tr>"
    __strResultsUser += "</table><br><br><br></FONT>"
    __strResultsUser += "<hr><B><U>"
    __strResultsUser += "<table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>Level</th><th width='50'>9</th><th width='50'>8</th><th width='50'>7</th><th width='50'>6</th><th width='50'>5</th><th width='50'>4</th><th width='50'>3</th><th width='50'>2</th><th width='50'>1</th><th width='50'>0</th></tr>"
    __strResultsUser += "<tr><td align='left'>Total Files With Violation(s)</td>"
    for element in range(0, 10, 1):
        if (__correptAry[element]>0):
            __strResultsUser += "<td bgcolor='BDBDBD' align='center'>%s</td>" % __correptAry[element]
        else:
            __strResultsUser += "<td align='center'>%s</td>" % __correptAry[element]		
    __strResultsUser += "</tr></FONT></table>"
	#Total violations table to display the total count of violations for specific error levels in all the files together
    __strResultsUser += "<hr><B><U>"
    __strResultsUser += "<table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>Level</th><th width='50'>9</th><th width='50'>8</th><th width='50'>7</th><th width='50'>6</th><th width='50'>5</th><th width='50'>4</th><th width='50'>3</th><th width='50'>2</th><th width='50'>1</th><th width='50'>0</th></tr>"
    __strResultsUser += "<tr><td align='left'>Total Violations</td>"
    for element in range(0, 10, 1):
        if (__correptAryValues[element]>0 and element<7):
            __strResultsUser += "<td bgcolor='BDBDBD' align='center'>%s</td>" % __correptAryValues[element]
        else:
            __strResultsUser += "<td align='center'>%s</td>" % __correptAryValues[element]		
    __strResultsUser += "</tr></FONT></table>"	
    ''' results log file '''
    try:
        __tempFileHandler = open(__tempNotificationOutPath + "\\" + __qacWarningsNotifier, 'w')
        __tempFileHandler.write(__strResultsUser)
        __tempFileHandler.close()
    except:
	
        raise Exception("ERROR: Impossible to create the QAC Warnings Notifier results log file:\n"+__tempNotificationOutPath + "\\" + __qacWarningsNotifier)
 	### Check if the build was started from Jenkins or local PC.
    if __jenkinsWorkspace != None:
		shutil.copy(__tempNotificationOutPath + "\\" + __qacWarningsNotifier, os.environ.get("WORKSPACE"))
    else:
		print "executing from Local PC"	