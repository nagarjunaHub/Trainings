''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess

import datetime

import shutil

import xml.etree.ElementTree as ET
from xml.dom import minidom

__qacSummary_ebmax = sys.argv[1]
__qacSummary_ebmin = sys.argv[2]
__qacXMLSummaryReport = sys.argv[3]
__strCSVtitle = ""
__strCSV = ""
__qacResults = range(10)
__jenkinsWorkspace = os.environ.get("WORKSPACE")
def printMisraWarnings( parent, regExMatch ):
	i = 9
	xml_file = ET.SubElement(parent, "file", name=regExMatch.group(1))
	for level in range(2,12):
		currentLevel = 'Level %d' % (i)
		numberWarnings = regExMatch.group(level)
		xmlObject = ET.SubElement(xml_file,"level",name=currentLevel).text = numberWarnings
		i -=1
#	print regExMatch.group(12)
	xmlObject = ET.SubElement(xml_file,"sum",name="Summary").text = regExMatch.group(12)
	return xmlObject


try:
	__qacSummary_ebmax_Handler = open(__qacSummary_ebmax)
	__qacSummary_ebmax = __qacSummary_ebmax_Handler.readlines()
	__qacSummary_ebmax_Handler.close()
except:
	raise Exception("ERROR: The file " + __qacSummary_ebmax + " can not be read.\n") 
try:
	__qacSummary_ebmin_Handler = open(__qacSummary_ebmin)
	__qacSummary_ebmin = __qacSummary_ebmin_Handler.readlines()
	__qacSummary_ebmin_Handler.close()
except:
	raise Exception("ERROR: The file " + __qacSummary_ebmin + " can not be read.\n") 

for index in range(0,10):
	__strCSVtitle += "Level %s," % str(9-index)

print "Transform qac_summary.txt to XML format"
root = ET.Element("QAC")
xml_ebmax = ET.SubElement(root, "EBMAX")
xml_ebmax_files = ET.SubElement(xml_ebmax, "files")
xml_ebmax_total = ET.SubElement(xml_ebmax, "total", name="Total")
xml_ebmax_multi = ET.SubElement(xml_ebmax, "multi", name="Multi-Location")

xml_ebmin = ET.SubElement(root, "EBMIN")
xml_ebmin_files = ET.SubElement(xml_ebmin, "files")
xml_ebmin_total = ET.SubElement(xml_ebmin, "total", name="Total")
xml_ebmin_multi = ET.SubElement(xml_ebmin, "multi", name="Multi-Location")

matchMisraLevels="([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)\s+([0-9*]+)$"

for __line in __qacSummary_ebmax:
	# print __line
	match = re.search("^([a-zA-Z_0-9]+\.[ch])\s+"+matchMisraLevels,__line)

	if match:
		printMisraWarnings(xml_ebmax_files, match)
	else:
		# No match, try to match total
		match = re.search("^(Total)\s*"+matchMisraLevels,__line)
		
		if match:
			#store total information in xml
			printMisraWarnings(xml_ebmax_total, match)
		else:
			# No match, try to match multiline
			match = re.search("^(Multi-Location)\s*"+matchMisraLevels,__line)
			if match:
				printMisraWarnings(xml_ebmax_multi, match)
				
for __line in __qacSummary_ebmin:
	# print __line
	match = re.search("^([a-zA-Z_0-9]+\.[ch])\s+"+matchMisraLevels,__line)

	if match:
		printMisraWarnings(xml_ebmin_files, match)
	else:
		# No match, try to match total
		match = re.search("^(Total)\s*"+matchMisraLevels,__line)
		
		if match:
			#store total information in xml
			printMisraWarnings(xml_ebmin_total, match)
		else:
			# No match, try to match multiline
			match = re.search("^(Multi-Location)\s*"+matchMisraLevels,__line)
			if match:
				printMisraWarnings(xml_ebmin_multi, match)


tree = ET.ElementTree(root)

xmlstr = minidom.parseString(ET.tostring(root)).toprettyxml(indent = "   ")

with open(__qacXMLSummaryReport, "w") as f:
    f.write(xmlstr)

f.close()

if __jenkinsWorkspace != None:
	print "Copying csv file to workspace ..."
	if os.path.isfile(os.environ.get("WORKSPACE") + "\\" + __qacXMLSummaryReport):
		os.remove(os.environ.get("WORKSPACE") + "\\" + __qacXMLSummaryReport)
	shutil.copy(__qacXMLSummaryReport, os.environ.get("WORKSPACE"))	
print "Done"


