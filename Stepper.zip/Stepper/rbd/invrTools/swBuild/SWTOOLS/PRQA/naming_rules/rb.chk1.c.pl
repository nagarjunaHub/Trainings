#!/bin/env perl
#
# Copyright (C) 2001 QA Systems GmbH, Stuttgart
#
# Name:        rb.chk1.c.pl
#
# Version:     v1.13
#
# Author:      B. Roeser
#
# purpose:     RB naming rules for C using QAC45
#              Compliant with Edition 07.06.2001
#
# created:     12.07.01
#
# design:      for Windows platforms should work for PERL in general
#
#
# Updates:
#
# Version | sign  | date     | doing
# --------+-------+----------+----------------------------------------
#    V000 | broes | 20010629 | create first version of zf naming rules
#    V001 | broes | 20010725 | insert new nameing rules for functions
#    V002 | broes | 20010824 | change error numbers > 6000
#     V003| Gaisser  | 20021111|  2. und 3. Stelle erg�nzt (Variablen und Funktionsnamen)
#                                             ba,cr,ct,dc,dx,fl,rc, da sich die NamingRules geaendert haben
#    V004 |Gaisser|20021112| rl fuer Funktionen ergaenzt
#    V005 |Gaisser|20021211| es fuer Endanschlag ergaenzt
#    V006 |Gaisser|20040122| Anpassung an ge�nderte Naming Rules Prefix und Postfix
#				cl,.. und Floating point
#    V007 |Gaisser|20040205| ml f�r Mathelib
#    V008 |Gaisser|20040209| lokale Variable und Funktionen sollen nicht geprueft werden
#    V009 |Gaisser|20040211| Funktionsgruppe fr, eb, fc erg�nzt
#    V010 |Gaisser|20040212| Meldung ERR_FUPT auskommentiert, da mit MISRA gepr�ft
#    V011 |Gaisser|20040213| Makros nur noch auf Grossbuchstaben pr�fen
#    V012 |Gaisser|20040216| Pruefung von enums
#    V013 | jbecht|20040219| use of QACOUTPATH environment var
#    V014 |Gaisser|20040219| line 344 deactivated (only for debug use), max. Wartezeit von 100000 auf 300000 erh�ht
#    V015 |Gaisser|20040322| Funktionsgruppe sy (Anforderung Hillenbrand)
#    V016 |Gaisser|20040406| Laengenberechnung des Funktionsnamens ohne Korrektur um - 1
#    V017 |Gaisser|20040419| zu Naming RUles 46-01, neue Funktionsgruppe DR
#    V018 |Gaisser|20040427| zu Naming Rules 46-02, neue Funktionsgruppen
#    V019 |Gaisser|20040507| zu Naming Rules 46-03, neue Funktionsgruppen
#    V020 |Gaisser|20040812| zu Naming Rules 49-02, neue Funktionsgruppen ft
#    V021 |Gaisser|20040813| zu Naming Rules 49-03, neue Funktionsgruppen ci und lk
#    V022 |Gaisser|20040923| zu Naming Rules 50-02, neue Funktionsgruppen cu und so
#    V023 |Gaisser|20040927| zu Naming Rules 50-03, neue Funktionsgruppen vs, ln, mp, ml entfernt
#    V024 |Gaisser|20041015| zu Naming Rules 51-01, enum-Typ und bit-Typ mit t, kein enum-Postfix
#    V025 |Gaisser|20041102| zu Naming Rules 51-03, Prefix: cp, fp, tf, ra,ta
#    V026 |Kemmler|20041102| Bessere Analyse von Typdefinitionen eingebaut �nderungen mit (jk)markiert
#    V027 |Kemmler|20041111| zu Naming Rules 51-04, Prefix: sm
#    V028 |Gaisser|20050216| zu Naming Rules 51-05, Prefix: sm
#    V029 |Gaisser|20050517| zu Naming Rules 51-09, Prefix: sr, pf,kt, tl, pc, pa
#    V030 |Gaisser|20050819| zu Naming Rules 52-02, Prefix: pm
#    V031 |Gaisser|20050819| zu Naming Rules 52-03, Prefix: sl
#    V032 |Kapfer |20060306| Anpassung fuer RB
#    V033 |Kapfer |20060406| rp fuer Funktion ergaenzt
#    V033 |Kapfer |20060420| pv fuer Funktion ergaenzt



# use of this package
# -------------------
use File::Basename;
use Win32;
use Getopt::Long;
use Env "QACOUTPATH"; # get output path for QAC
#use Env "QACBIN";     # get bin path for QAC

# keep flushing the output buffer
# -------------------------------
$| = 1;

# function forward declaration
# ----------------------------
sub generate_err;                      # enhance qac's warnings
sub dprint;                            # print/log debug output
sub MsgBox;                            # print message on gui terminal
sub test_output;                       # print all giving parameters on stdout (only for tests)

# check functions
sub check_input;                       # check input date
sub check_typedef;                     # check name of typedef
sub check_function;                    # check name convention of function
sub check_variable;                    # check name convention of varaiable
sub check_met;                         # get data from met file for checking naming rules
sub check_macro;		# check name convention of macros


# init global constants
# ---------------------
$usage              = "Call $0 -op=\"[OutputPath]\" \"C-file\" [-DEBUG]\nstopped"; # do not remove trailing space for " at filename line no" output
chomp ( $perlname   = basename( $0 ) );
$version            = "Copyright (C) 1999-2001 QA Systems GmbH, Stuttgart\n".$perlname." Revision: 1.0 Date: 2001/06/29\n";
$tool               = "qac"; # needed for errwrt argument specification
$qa_outpath = $QACOUTPATH;
%sourceExts         = qw (c 1 C 1 cpp 1 cxx 1);
$column             = 0;
$include_line       = 1;
$include_line_tmp   = 1;
$isWin              = (defined ($^O) && ($^O eq "MSWin32") )? TRUE: FALSE;
$IFTEST             = 0;                          # additional test output (0/1)
$FUNC_LEN_MIN       = 6;                          # min length of function names
$FUNC_LEN_MAX       = 34;                         # max length of function names
$VAR_LEN_MAX        = 49;                         # max length of variable names
$TYPE_GLOBAL     = "X";		#Link(age) ist global wenn in met-file ein X eingetragen ist
$MACRO = "(C_|M_)";			#Startzeichen f�r konstanten Makrowert
$TYPE_SIGN = "t";                                 #Startzeichen f�r Typ (jk)
$NAMESPACE_ID = "CS_";

#    my @ident_parts = ('','','');



# init prefix for naming convention from occupation one to four
# -------------------------------------------------------------

# first occupation (from steering) means a pyhsical range
$prefix_phys  = "(a|b|c|d|f|h|i|j|m|n|p|q|r|s|t|u|v|w|x|y|z)";
# second occupation (from steering) means belonging to a function (in a variable Name)

# Possible Component Abbreviations
# splitted because of String limitation
$funct_part1_comp_abbr_1 = "(Adc|ADtRp|Ass|BPT|BPTD|Can|CanCcp|CanIf|CanSM|CanTp|Com|CusIf|DbgM|Dcm|DEM|Dio|EcuM)";
$funct_part1_comp_abbr_2 = "(EngSpd|ErrLmp|FIM|HallS|HwVar|iBatt|Idx|Ipdum|IoHwAb|IoReg|iPha|MathL|MemIf|MemMap|MotMdl)";
$funct_part1_comp_abbr_3 = "(MPrg|MTrqA|MTrqC|NvM|OS|OutSt|PduR|PhaCoR|Port|PrgF|PrRunC|RotP|SchM|SplV|SplyV|SStR|StChk)";
$funct_part1_comp_abbr_4 = "(StdT|StAg|StTrq|SVR|SwId|SwTmr|SyAsic|SysDat|SysTi|Tmp|TmpF|TmpR|TLL|VehSpd|WdgM|Wdg|Xetk)";


# init postfix for naming convention
# usage of capital letters for constants and small letters for variables
$postfix_RAM = '([lsmgx])([dpa])([paesubo]|u8|u16|u32|s8|s16|s32|f32|f64)';
$postfix_ROM = '([LSMGX])([DPA])([PAESUBO]|U8|U16|U32|S8|S16|S32|F32|F64)';
$postfix     = "($postfix_RAM|$postfix_ROM)";

$special_signs = "(-|_|:)";

# for future use only
#      <=  left side are codes generated by Qac (Code Analyser)
#                 =>  right side are codes defined in the naming rules



%postfix_datatyp= (
       nc        => 's8',
       uc        => 'u8',
       ns        => 's16',
       ni        => 's16',
       nl        => 's32',
       us        => 'u16',
       ui        => 'u16',
       ul        => 'u32',
       fs        => 's64',
       ff        => 's64',
       fl        => 's64',
       struct    => 's',
       union     => 'u',
       enum      => '',
       '=nc'     => 'S8',
       '=uc'     => 'U8',
       '=ns'     => 'S16',
       '=ni'     => 'S16',
       '=nl'     => 'S32',
       '=us'     => 'U16',
       '=ui'     => 'U16',
       '=ul'     => 'U32',
       '=fs'     => 'S64',
       '=ff'     => 'S64',
       '=fl'     => 'S64',
       ne        => 'E',
       c_struct  => 'S',
       c_union   => 'U',
       c_enum    => 'E',
       void      => 'v',
       generic   => 'v',
       any       => '.'
       );
# for future use only!
# init used type names
#$type_names = "(tSI8|tSI16|tSI32|tUI8|tUI16|tUI32|tBOOL|tbit|t)";
# since sk06052006
#$type_names = "(tSI8|tSI16|tSI32|tUI8|tUI16|tUI32|eBOOL|bit|tF32|tF64|BitFalse|BitTrue)";

$type_names = "(sint8|sint16|sint32|uint8|uint16|uint32|boolean|float32|float64)";


#      <=  left side are codes generated by Qac (Code Analyser)
#                 =>  right side are codes defined in the naming rules

 %data_types= (
       nc        => 'sint8',
       ns        => 'sint16',
       nl        => 'sint32',
       uc        => 'uint8',
       us        => 'uint16',
       ul        => 'uint32',
       ne        => 'boolean',
       nb        => 'tBIT',
       nt	      => 't',
       any       => '.'
       );


# errornumbers + offset 5000 integration
# --------------------------------------

# errors on typedef
$ERR_TYPN = 1001;  # the names of this typedef is not allowed
$ERR_TYCN = 1002;  # Type name is not conform to the type
$ERR_TYMA = 1003;  # In the Type name the sign 't' is missing after '_<Component Abbrevation>_'
$ERR_TYMU = 1004;  # Macro Type definition shall have only uppercase letters after '_<Component Abbrevation>_t'
$ERR_TYMN = 1005;  # Macro shall not begin with a number
$ERR_TYRL = 1006;  # In the typedef the '_<Component Abbreviation>_' (2nd part, 3 to 6 letters) is missing or shall be registrated.


# errors on functions
#$ERR_FULC = 1102;  # the names of functions shall be written after Namespace-ID in first lowercase letter
# Nicht bei Autosar nur bei RB-Code
$ERR_FULC = 1102;  # Name of functions shall start with the Namespace-ID CS_
$ERR_FURL = 1103;  # In the function the '_<Component Abbreviation>_' (2nd part, 3 to 6 letters) is missing or shall be registrated
$ERR_FUPT = 1104;  # function prototypes shall be placed in headers
$ERR_FUMI = 1105;  # function name shall have at least six letters
$ERR_FUMA = 1106;  # function name shall have not more 34 letters
$ERR_FUUL = 1107;  # letter after '_<Component Abbrevation>_' shall have a upper case letter

# errors on variables or constants
# Nicht bei Autosar nur bei RB-Code
$ERR_VALC = 1201;  # Namespace-ID is wrong or variables shall be written in first lowercase letter
$ERR_VAMA = 1202;  # variable name shall have not more 49 letters
$ERR_VAPR = 1203;  # the first letter after the '_<Component Abbreviation>_' is not a part of a physical range (or 't' for typedefs).
# changed for autoSAR
# $ERR_VARL = 1204;  # the second and third letter after the Namespace-ID represents not the relevancy to a function
$ERR_VARL = 1204;  # In the const, variable or typedef the '_<Component Abbreviation>_' (2nd part, 3 to 6 letters) is missing or shall be registrated.
#not necesary for AutoSAR
#$ERR_VAUC = 1205;  # if no forth prefix after Namespace-ID is signed, the next letter must be a uppercase letter
#$ERR_VAAT = 1206;  # fourth prefix after Namespace-ID is false attribute
$ERR_VAAL = 1207;  # the <free-name> after '_<Component Abbreviation>_<physical range>' shall starts in uppercase.
$ERR_VAND = 1208;  # a <free-name> between prefix and postfix is missing.
$ERR_VANP = 1209;  # a postfix is missing or shall be registrated.



#################################################################
# purpose: main execute part                                    #
#          calls check sequence                                 #
#  inputs: none                                                 #
#  output: none                                                 #
#################################################################

# check input data
check_input;

# Create temporary file
open(TMP,">$temp_file") || die "\n$perlname: $temp_file: cannot open temporary file!\n";
dprint "errwrt script in $temp_file...\n";

# initialize system call return value
$res = 0;

# working only if OS is a WIN system !!!
if ( $isWin eq TRUE )
  {
  # read met file for actual source an call some checks
  # ---------------------------------------------------
  check_met;

  close TMP;

  # execute shell script with error writing function and remove shell script, if successful
  $Winnt = Win32::IsWinNT();
  #print"$Winnt\n";

  if ($Winnt != 0)
    {                                # WINNT
    $CmdSpec = $ENV{'ComSpec'};      # get command processor from DOS environment
    $CmdName= basename($CmdSpec);
    dprint"found command interpreter: $CmdSpec,$CmdName\n";

    # Check cmd.exe exists on %system%
    # --------------------------------
    if (! -x $CmdSpec )
      {
      MsgBox("1 QAC Postanalysis Subprocess", "$!: $CmdSpec", 64);
      exit(19);
      }

    require Win32::Process;
    Win32::Process::Create($ProcessObj, #object to hold process
                        "$CmdSpec", #executable
                        "$CmdName /Q /C $temp_file", # /Q echoing off
                        0, #no inheritance
                        0, #default process
                        ".") || die "Create: $!"; #current dir.
    $ProcessObj->Wait(300000);
    #$ProcessObj->Wait(10000);
    $ProcessObj->GetExitCode($res);

    if ( ($res & 0xFF) !=0 )
      {
      MsgBox("2 QAC Postanalysis Subprocess", "$temp_file: Subprocess died from signal $res", 64);
      }
    $res = $res >> 8; # exit value of the subprocess, truncated 8 bits represent signal
    dprint "$ProcessObj --- res: ?$res?\n";
    }
  else
    {                        # WIN95, 98
    open(TMP,"<$temp_file") || die "\n$perlname: $temp_file: cannot reopen temporary file!\n";

    while(<TMP>)
      {
      #print $_;
      $res= $res + system($_);
      }
    close TMP;
    } #  if ($Winnt != 0) ...
  } #  if ( $isWin eq TRUE ) ...

if ($res == 0)
  {
  dprint "Execution of batch $temp_file...succeeded\nRemoving $temp_file...done";
  unlink ($temp_file);
  }
else
  {
  dprint "Execution of batch $temp_file...failed\nKeeped $temp_file";
  MsgBox("3 QAC Postanalysis Subprocess", "$temp_file: Subprocess died with exit value $res", 64);
  }

exit($res);


# function definitions
# --------------------

sub check_input
#################################################################
# purpose: check input paramters                                #
#  inputs: input parameters                                     #
#  output: messages on STDOUT                                   #
#################################################################
{
  unless ($isWin eq TRUE )
    {
    print"$version\nThis version is designed for windows systems";
    exit(11);
    }

  # check no of params
  # ------------------
  if ( defined ($ARGV[0]) && $ARGV[0] eq "-v" )
    {
    print"$version\n";
    MsgBox("4 QAC Postanalysis Version Info", "$version", 64);
    exit(11);
    }

  unless( $#ARGV == 0 || $#ARGV == 1 || $#ARGV == 2 )
    {
    print "wrong number of parameters ($#ARGV)\n$usage";
    MsgBox("5 QAC Postanalysis Help", "wrong number of parameters ($#ARGV)\n$usage", 64);
    exit(11);
    }

  # extract the params
  # ------------------
  &GetOptions("-op=s" => \$outpath, "-DEBUG" => \$debug );

  # @ARGV contains now only non-option arguments
  # --------------------------------------------
  $source = $ARGV[0];
  $debug = (defined ($debug) && ($debug == 1 ) )? TRUE: FALSE;
  if ( $outpath eq "" )
    {
    # no '-op' on commandline specified
    # check to get it from environment
    if ( $qa_outpath eq "" )
      {
      print "Postanalysis Error: Postanalysis outputPath not specified\nSet environment variable 'QACOUTPATH' or specify '-op=' on parameter list.\n$usage\n";
      MsgBox("6 QAC Postanalysis Error", "outputPath not specified\n$usage", 64);
      exit(12);
      }
      # Get it from environment variable
      $outpath = $qa_outpath;
   #   MsgBox("7 QAC Debug info (Line 344)", "outputPath is set to: $outpath\n", 64);
    }

  # cut tailing / or \ from outpath and check it
  # --------------------------------------------
  unless( $outpath =~ /(.*[^\/|^\\])(\/|\\)*$/ )
    {
    print "Postanalysis outputPath not specified\n$usage";
    MsgBox("8 QAC Postanalysis Error", "outputPath not specified\n$usage", 64);
    exit(12);
    }

  $outpath = $1;
  unless( -d $outpath )
    {
    print "$!: $outpath\n$usage";
    MsgBox("9 QAC Postanalysis Error", "$!: $outpath\n$usage", 64);
    exit(12);
    }

  # check source-file, extract filename and extension, check legal extension
  # ------------------------------------------------------------------------
  unless( -r $source )
    {
    print "$!: $source\nstopped";
    MsgBox("10 QAC Postanalysis Error", "$!: $source\nstopped", 64);
    exit(13);
    }

  # filename and ext format setting
  # -------------------------------
  if ( $isWin eq TRUE )
    {
    fileparse_set_fstype("MSDOS"); # file specification syntax
# doesn't wort in NT 4 !!
#    `c:\programme\prqa\qac4.5.2\bin\errwrt`;
#    unless (($? >> 8) == 0)
#      {
    #  MsgBox("11 QAC Postanalysis Error", "$!: errwrt\nEnvironment variables not set\nstopped", 64);
    #  exit(14);
#      }
    }

  chomp ( ($srcBasename, $ext) = (fileparse ( $source, keys(%sourceExts) ) )[0, 2] );
  $srcBasename =~ s/\.$//g;        # remove extension separator

  # check hash element $ext in hash is true
  # ---------------------------------------
  unless( $sourceExts{$ext} )
    {
    print "wrong source extension: ($ext)\n$usage";
    MsgBox("12 QAC Postanalysis Error", "wrong source extension: ($ext)\n$usage\nstopped", 64);
    exit(15);
    }

  # check OS type and make settings
  # -------------------------------
  if ( $isWin eq TRUE )
    {
    $path_separator = "\\";
    $temp_file = "qac_$$.bat";

    if ( defined ($ENV{'TEMP'}) && (-d $ENV{'TEMP'}) )
      {
      $temp_dir = $ENV{'TEMP'};
      #$temp_dir =~ s/\\/\\\\/;

      unless ( $temp_dir =~ /\\$/ ) { $temp_dir = $temp_dir.$path_separator; }
      }
    elsif ( -d "C:\\temp"  )
      {
      $temp_dir = "C:\\temp$path_separator";
      }
    else
      {
      MsgBox("13 QAC Postanalysis Error", "$!: \%TEMP\% or C:\temp\nstopped", 64);
      exit(16);
      }

    $temp_file = $temp_dir.$temp_file;

    # get name of met-file and check
    # ------------------------------
    $metfile="$outpath\\$srcBasename.$ext.met";

    unless( -r $metfile )
      {
      MsgBox("14 QAC Postanalysis Error", "$!: $metfile\nstopped", 64);
      exit(17);
      }
  } # if ( $isWin eq TRUE ) ...
}


sub dprint
#################################################################
# purpose: print debug output if debug is set; bequiet otherwise#
#  inputs: message string                                       #
#          global variables: $debug                             #
#  output: messages on STDOUT                                   #
#################################################################
{
  # commend this line for no debug output
  if ( $debug eq TRUE )
    {
    print @_;
    }
}


sub MsgBox
#################################################################
# purpose: display a message box on screen                      #
#  inputs: caption                                              #
#          message string                                       #
#          global variables: $icon_buttons                      #
#  output: messages on GUI STDOUT                               #
#################################################################
{
  my ($caption, $message, $icon_buttons) = @_;
  my @return = qw/- Ok Cancel Abort Retry Ignore Yes No/;
  my $result = Win32::MsgBox($message, $icon_buttons, $caption);
  return $return[$result];
}


sub generate_err
#################################################################
# purpose: write .err file with extra warnings                  #
#  inputs: param1 = error code number                           #
#          global variables: $outpath $source $include_line ... #
#  output: shell script using 'errwrt' utility in temp file     #
#################################################################
{
  my $err_code = $_[0];
  my $qm_ident = "\"$ident\"";   # surround identifier with double quotes

  #print "Param transmitted:$ident, $err_code, $inc\n";

  if( defined ($inc) && ($inc eq "I") )
    {
    #include header warning
    dprint "errwrt $tool -op \"$outpath\" \"$source\" $include_line \"$filename\" $line $column $err_code $qm_ident;\n";
    print TMP "errwrt $tool -op \"$outpath\" \"$source\" $include_line \"$filename\" $line $column $err_code $qm_ident\n";
    }
  else
    {
    #source code warning
    dprint "errwrt $tool -op \"$outpath\" \"$source\" $line $column $err_code $qm_ident;\n";
    print TMP "errwrt $tool -op \"$outpath\" \"$source\" $line $column $err_code $qm_ident\n";
    }
}

sub check_met
#################################################################
# purpose: start analysis of .met file lines                    #
#          calls check functions                                #
#  inputs: read .met file lines                                 #
#  output: none                                                 #
#################################################################
{
  # open *met file for analysis
  # ---------------------------

  open(IN,"<$metfile") || die "$perlname: $metfile: $!\n";

  # doing some met checks
  # ---------------------
  while(<IN>)
    {
    # check of defines contained in .met file
    # ---------------------------------------
    if( /^\<DEFINE\>/ )
      {
      if ( /(\".*\")/ )
        {
        $filename = $1;
        ($ident, $rest ) = (split( /\s?\"\s?/) )[0, 2];     #extract all but filename
        $ident = (split(/ /))[1];                           #extract identifier
        ($line, $inc, $def, $space, $scope, $link, $type) = (split(/ /, $rest))[0, 1, 2, 3, 4, 5, 6];
        }
      else
        {
        ($ident, $filename, $line, $inc, $def, $space, $scope, $link, $type) = (split(/ /))[1, 2, 3, 4, 5, 6, 7, 8, 9];
        }

      @ident_parts = split( /_/, $ident);


      # test_output( $IFTEST, $ident, $filename, $line, $inc, $def, $space, $scope, $link, $type);

      print "$ident,$filename,$line,$inc,$def,$space,$scope,$link,$type\n";
      print "---->>>checking: $ident\n";

      # remove discovered "\n"
      # ----------------------
      if ( defined $type )
        {
        chomp($type);
        }

      if ( ($space =~ /OT/) || ($space =~ /TG/) )   #both typedef variants are checked (jk)
        {
        check_typedef;
        }
      elsif ( $space =~ /OF/ )
        	{
        	check_function;
        	}
          elsif ( $space =~ /OV/ )
        		{
        		check_variable;
        		# activate to check company wide prefix standard, disregard headers + enums
        		# -------------------------------------------------------------------------
        		# init_CompNamConv if ( $inc eq "N" && $type ne "ne" );
        		}

      elsif ($space =~ /OM/ )
         	{
	  check_macro;
	}


       else{;}
      } # if( /^\<DEFINE\>/ )

    # in case of include lines, check it's line_number $include_line
    # ----------------------------
    elsif (/^\<R\>I/ )
         	{
        ($c_filename_inc,$h_filename_inc,$include_line_tmp) = (split(/ /))[1, 2, 3];
        if ($c_filename_inc =~ /.c$/) {   #Nur Zeilennummern der in *.c includierten Headerfiles sind hier relevant (nicht *.h)
           print "Includeline number: $c_filename_inc,$h_filename_inc,$include_line_tmp\n";
           # make shure, that $include_line is converted to a number ...
           $include_line = $include_line_tmp + 0;
        }
      }


    # check of total unprepro. LOG
    # ----------------------------
    elsif( /^\<S\>STTPP\s+(\d+)/ )
      {
      # number of total unpreprocessed lines
      # ------------------------------------
      $STTPP = $1;
      }
    else
      {
      next;
      }
    } # while (<IN>)

  close IN;

  # do not forget to reset this global variable
  # -------------------------------------------
  $inc = "N";
}



sub check_typedef
#################################################################
# purpose: checks that typedef name is allowed                  #
#  inputs: global variables $type, $ident                       #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
#(jk)-Start---------------------------------------------------------------------------
  # check max length of type name
  # ---------------------------------
  $var_len = length($ident) - 1;             #attention:  length() include \n
  
#    my @ident_parts = ('','','');

#   @ident_parts = split( /_/, $ident);


  if( $var_len > $VAR_LEN_MAX )
     {
     test_output ($IFTEST, "The type name shall have not more then 49 signs" ,$ident);
     generate_err( $ERR_VAMA );
     }
     


   unless ($ident =~ /^$type_names$/ ) # sk05062007 added to avoid Namespace-Checks in standard types) 
      {
      
      
        # bei autosar gibt es nun Comp-Abbrev. (Punkt ist hier neu, im ident_Part2 (=[1])

          # check if ident_Part2 (=[1]) is o.k
          # ------------------------------------

          unless ( @ident_parts[1] =~ /^$funct_part1_comp_abbr_1$/
              || @ident_parts[1] =~ /^$funct_part1_comp_abbr_2$/
              || @ident_parts[1] =~ /^$funct_part1_comp_abbr_3$/
              || @ident_parts[1] =~ /^$funct_part1_comp_abbr_4$/  )         # V001
          {

             	     test_output ($IFTEST, "The Component Abbreviation of the typedef (2nd part, 3 to 6 letters) shall have registrated" ,$ident);
             	     generate_err( $ERR_TYRL );

          }
          else {

      
      
        #   # check if first prefix o.k
           # check if first sign (after component abbrev) is o.k
          # -------------------------
        #  	unless ( ($ident =~ /$TYPE_SIGN/ )  )
        	#  unless ( ($ident =~ /^.{0}$TYPE_SIGN/ )  )
        #	  unless ( ($ident =~ /^.{3}$TYPE_SIGN/ )  )
        	  unless ( (@ident_parts[2] =~ /^.{0}$TYPE_SIGN/ )  )
        	     {

        	        test_output ($IFTEST, "First sign after _<Component Abbrevation>_ is false!" ,$type); # debug output
        	        generate_err( $ERR_TYMA );

        	     }
           }

  # check if  characters are uppercase
  # -------------------------

#  $var_len_part = length(@ident_parts[2]) - 1;             #attention:  length() include \n



          # test character (now faster)
                  $tmp_var  = substr(@ident_parts[2],2);
	          unless ( uc($tmp_var) eq $tmp_var) {
        	    test_output ($IFTEST, "no uppercase!", $ident); # debug output
	            generate_err( $ERR_TYMU );
        	   }

	}
   else
      {
	      # It's a standard type, no additonal tests are neccessary
      }

#-----------------------------------------------------------------------------------
# init used type names
# $type_names = "(tSI8|tSI16|tSI32|tUI8|tUI16|tUI32|eBOOL|bit|t)";

#      <=  left side are codes generated by Qac (Code Analyser)
#                 =>  right side are codes defined in the naming rules

# %data_types= (
#       nc        => 'tSI8',
#       ns        => 'tSI16',
#       nl        => 'tSI32',
#       uc        => 'tUI8',
#       us        => 'tUI16',
#       ul        => 'tUI32',
#       ne        => 'eBOOL',
#       nb        => 'bit',
#       nt       => 't',
#       any       => '.'
#       );
#(jk)-End-----------------------------------------------------------------------------
  if ( $link =~ /$TYPE_GLOBAL/)
   {

    # allways defined types are allowed
    # ---------------------------------
    unless ($ident =~ /^$type_names$/ )
      {
	
             generate_err( $ERR_TYPN );
             my $text_parm = "Wrong basic data typedef: ";
             test_output ($ERR_TYPN, $text_parm ,$ident); # debug output
	
      }

    # type name is not conform to the type
    # ---------------------------------
    if ( !defined($data_types{$type}) )
      {
      generate_err( $ERR_TYCN );
      my $text_parm = "Type name is not conform to the type: ";
      test_output ($ERR_TYPN, $text_parm ,$ident); # debug output
      }

    # test if type is an an enum
#    if ($type =~ /^.{1}"e"/ )
#       {
#         # enum-type muss mit _E enden
#         unless ($ident =~ /^.*[_E]*/  )
#                    {
#                     generate_err( $ERR_TYCN );
#                    }
#       }

  }
}

sub check_function
#################################################################
# purpose: check for naming of functions                        #
#  inputs: $ident                                               #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
#  v001
#  print "function,checking lowercase case in first letter: $ident\n"; # debug output
#  if( $ident =~ /^[A-Z]/ )
#    {
#    my $text_parm = "First character in uppercase letters:";
#    test_output ($IFTEST, $text_parm ,$ident); # debug output
#    generate_err( $ERR_FULC );
#    }

  # check the Partsnumbers of Functionname divided by "_"
  # should be namespace_id_val, comp_abbr, phystype_and_freetext, postfix

#  ($namespace_id_val, $phystype_and_comp_abbr, $prest ) = (split( /_/) )

#    my @ident_parts = ('','','');

#   @ident_parts = split( /_/, $ident);


unless ( $ident =~ /^${NAMESPACE_ID}/ )
   {
   my $text_parm = "Namespace-ID is wrong";
   test_output ($IFTEST, $text_parm ,$ident); # debug output
   generate_err( $ERR_FULC );
   }

if ( $link =~ /$TYPE_GLOBAL/)
 {
  # check min. length of function name
  # -----------------------------
  $func_len = length($ident);             #attention:  length() include \n
#  $func_len = $func_len - 1;

  if( $func_len < $FUNC_LEN_MIN )
     {
     test_output ($IFTEST, "The function name shall have at least six signs" ,$ident, $func_len);
     generate_err( $ERR_FUMI );
     }

  # check max. length of function name
  # -----------------------------
  if( $func_len > $FUNC_LEN_MAX )
     {
     test_output ($IFTEST, "The function name shall have not more then 34 signs" ,$ident, $func_len);
     generate_err( $ERR_FUMA );
     }



# bei autosar gibt es nun Comp-Abbrev. (alt prefix_45) im ident_Part2 (=[2])

  # check if ident_Part2 (=[1]) is o.k
  # ------------------------------------
#  print "ident_Part1 $funct_part1_comp_abbr ";
#  print "ident_Part1a $funct_part1_comp_abbr1\n";
#  print "ident_Part1b @ident_parts[1]\n";

  unless ( @ident_parts[1] =~ /^$funct_part1_comp_abbr_1$/
      || @ident_parts[1] =~ /^$funct_part1_comp_abbr_2$/
      || @ident_parts[1] =~ /^$funct_part1_comp_abbr_3$/
      || @ident_parts[1] =~ /^$funct_part1_comp_abbr_4$/  )         # V001
     {

     	     test_output ($IFTEST, "The '_Component Abbreviation_' of the function (2nd part, 3 to 6 letters) shall have registrated" ,$ident);
     	     generate_err( $ERR_FURL );

     }



# folgende weitere Rules wurden/werden aktuell nicht geprueft:
#<free-name>	sprechende Bezeichnung beginnend mit einem Grossbuchstaben
#<postfix>		G�ltigkeitsbereich		1 Zeichen
#			Datenart			1 Zeichen
#			Datentyp			max. 3 Zeichen



#  # check the letter after the Comp-Abbrev. (alt after the prefix_45)
  # -------------------------
  if( @ident_parts[2] =~ /^.{0}[a-z]/
   || @ident_parts[2] =~ /^.{0}[0-9]/
   || @ident_parts[2] =~ /^.{0}$special_signs/ )
     {
       
                test_output ($IFTEST, "Next letter after _<Component Abbreveation>_ must be an uppercase letter" ,$ident);
                generate_err( $ERR_FUUL );
               
     }

  # print "function prototypes shall be placed in header files: $ident\n"; # debug output
  # -------------------------------------------------------------------------------------
  #if( $def  eq "DC" &&
  #    $link eq "X"  &&
  #    $inc  eq "N" )
  #  {
  #     
  #              #print "function w. exten. linkage in source: $ident\t"; # debug output
  #              generate_err( $ERR_FUPT );
  #             
  # }
 }
}

sub check_variable
#################################################################
# purpose: check for naming of variables                        #
#  inputs: $ident                                               #
#  output: calls generate_err in case of non conformance        #
#################################################################
{


if ( $link =~ /$TYPE_GLOBAL/)
 {

#    my @ident_parts = ('','','');
#   @ident_parts = split( /_/, $ident);


  if( $ident =~ /^.{3}}[A-Z]/ ) 
    {

                my $text_parm = "Namespace-ID is wrong or first character in uppercase letters:";
                test_output ($IFTEST, $text_parm ,$ident); # debug output
               generate_err( $ERR_VALC );
              
    }
   unless ( $ident =~ /^${NAMESPACE_ID}/ )
	{
                my $text_parm = "Namespace-ID is wrong or first character in uppercase letters:";
                test_output ($IFTEST, $text_parm ,$ident); # debug output
               generate_err( $ERR_VALC );
              
	}
 # if( $ident =~ /^urpSinOffsetInitS1_mdu16/ ) {
#		die "$ident found"
#	}



  # check max length of variable name
  # ---------------------------------
  $var_len = length($ident) - 1;             #attention:  length() include \n

  if( $var_len > $VAR_LEN_MAX )
     {
     test_output ($IFTEST, "The variable name shall have not more then 49 signs" ,$ident);
     generate_err( $ERR_VAMA );
     }


  # test if variable is an an enum element
 #   if ($type =~ /^"ne"/ )
 #      {
 #        # object is an enum
 #        # enum-variable muss mit _e enden
 #        unless ($ident =~ /^.*[_e]*/  )
 #                   {
 #                    generate_err( $ERR_TYCN );
 #                   }
 #      }
 # else
 #     {
  # object is a variable
  # check if prefix_4 o.k
  # -------------------------
##  unless ( $ident =~ /^.{3}$prefix_4/ )
##     {
##
##          test_output ($IFTEST, "First prefix (after Namespace-ID) it is false!"  #,$ident); # debug output
##          generate_err( $ERR_VAPR );
##
##     }


# bei autosar gibt es nun Comp-Abbrev. (alt prefix_56) im ident_Part2 (=[1])

  # check if ident_Part2 (=[1]) is o.k
  # ------------------------------------

  unless ( @ident_parts[1] =~ /^$funct_part1_comp_abbr_1$/
      || @ident_parts[1] =~ /^$funct_part1_comp_abbr_2$/
      || @ident_parts[1] =~ /^$funct_part1_comp_abbr_3$/
      || @ident_parts[1] =~ /^$funct_part1_comp_abbr_4$/  )         # V001
     {

     	     test_output ($IFTEST, "The Component Abbreviation of the const,variable or typedef (2nd part, 3 to 6 letters) shall have registrated" ,$ident);
     	     generate_err( $ERR_VARL );

     }

  # check if ident_Part3 (=[2]) is o.k
  # ------------------------------------
  # $prefix_phys (alt pefix_4)

  unless ( @ident_parts[2] =~ /^.{0}$prefix_phys/ )
     {

          test_output ($IFTEST, "The 1. letter after '_<Component Abbreviation>_' must be a part of a physical range or 't' for typdefs !"  ,$ident); # debug output
          generate_err( $ERR_VAPR );

     }


  # Descripton part must be available (starts at 2. Letter of Part 3 [=2])
  # ------------------------------------------------------------------
  if ( length(@ident_parts[2]) == 0)
     {

            test_output ($IFTEST, "No description part!", $ident); # debug output
            generate_err( $ERR_VAND );

     }


  # Descripton part must be start with an uppercase letter (2. Letter of Part 3 [=2])
  # ------------------------------------------------------------------
  if( @ident_parts[2] =~ /^.{1}[a-z]/
     || @ident_parts[2] =~ /^.{1}[0-9]/)
    {
         
              test_output ($IFTEST, "The description part (2. letter after '_<Component Abbreviation>_') shall starts in uppercase!", $ident); # debug output
             generate_err( $ERR_VAAL );
           
    }


  # sign before postfix must be a underscore
  # ----------------------------------------

  # check if postfix is defined
  # ---------------------------
#   unless( $ident =~ /^.*_$postfix.*$/ )
#    unless( $ident =~ /^.*[_]$postfix.*/ )
  unless( @ident_parts[3] =~ /^$postfix.*$/ )
    {
         
         test_output ($IFTEST, "No defined postfix in use" ,$ident);
         generate_err( $ERR_VANP );
           
    }

  }

} # sub check_variable


sub check_macro
#################################################################
# purpose: check for naming of macros                        #
#  inputs: $ident                                               #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
  $tmp_checkfunction_flag = 0;
 
      
  # check max length of macro name
  # ---------------------------------
  $var_len = length($ident) - 1;             #attention:  length() include \n

  if( $var_len > $VAR_LEN_MAX )
     {
     test_output ($IFTEST, "The macro name shall have not more then 49 signs" ,$ident);
     generate_err( $ERR_VAMA );
     }

  # check if first and second prefix o.k
  # -------------------------
  #unless ( ($ident =~ /$MACRO/ )  )
   #  {
    #   
     #     test_output ($IFTEST, "First and second prefix is false!" ,$ident); # debug output
      #    generate_err( $ERR_TYMA );
       # 
     #}

  
  # check if  characters are uppercase
  # -------------------------
  
 
   if ($ident =~ /^$type_names$/ ) {
       	# New sk29092008: Macro Name is like Typedef, no further Check neccessary (especially BitTrue and BitFalse)
     }
     else {
 
 
       for ($i = 0; $i <= $var_len; $i++)
        {
          # test character

          unless ( $ident =~ /^.{$i}[A-Z]/ || $ident =~ /^.{$i}$special_signs/ || $ident =~ /^.{$i}[0-9]/  ) 

           {

        	# New sk02042008: If lowercase, the Macro Name have to be confirm to function namingrules
                $tmp_checkfunction_flag = 1;
			
#            test_output ($IFTEST, "no uppercase!", $ident); # debug output
#            generate_err( $ERR_TYMU );
           }

        }

       	# New sk29092008: check_function is called only once, controlled by flag 
        unless  ($tmp_checkfunction_flag == 0   )
        {
  		check_function;
	}


      } 



     
} # sub check_macro



 sub test_output
#################################################################
# purpose: output of statements during developing source code   #
#          activate and deactivate with the first               #
#          parameter $IFTEST                                    #
#  inputs: $IFTEST (0,1) bool variable for printing             #
#          some variables                                       #
#  output: message on stdout                                    #
#################################################################
{
  # output of all parameters
  # ------------------------
  # my $print_error = @_[0];   # older version
  my $print_error = $_[0];
  # print $occurence;

  if ($print_error ne 0)
    {
    foreach(@_) {print "-> $_ <- \n";}
    }
}