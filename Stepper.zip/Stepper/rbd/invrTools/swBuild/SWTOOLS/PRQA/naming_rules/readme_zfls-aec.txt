ZFLS-AEC Post-Analysis for QA C Source Code Analyser
===================================================

README.HTML for QAC 4.5 & ZFLS-AEC Schwaebisch Gmuend Naming rules

This file contains important information that you should read
before you run QA C Source Code Analyser Post-Analysis scripts
on your system.

Unless otherwise noted, all materials provided in this Release are
Copyright (c) 2001 QASystems GmbH.

Table of Contents
=======================

1. Package Description
2. Installation Notes
3. Requirements
4. Getting started
5. Return codes


1. Package Description
=======================

Please refer to the following table that sets the target installation
directory for the QAC-ZFLS-AEC checking components.

This group of data files allows you to check the ZFLS-AEC naming rules using
QAC's Output, especially the generated symboltable (.met file).

Name                  Directory                 Purpose
===========================================================================
qac.usr.zf-aec        %QACPATH%/bin             extended QAC messages
zf.chk1.c.pl          %QACPATH%/ZFLS            postanalysis checks
ZFLS-AEC.p_s          %QACPATH%/person          warning listing (filter)
ZFLS-AEC.p_a          %QACPATH%/person          analyzer personality (QAC)
===========================================================================



2. Installation Notes
=======================

file: qac.usr.zf-aec
The delivered qac.usr.zf-aec user message file will enhance the qac.msg shipped with
the standard version.
This is done by specifying an extra message file in the message personality
dialog (Advanced settings), where you can browse to the correct directory and
specify the file extension: ZF-AEC (see ZF-AEC.p_s).
Qac.usr.zf-aec contains the ZFLS-AEC naming rules.
All the messages are are folded in "Naming Rules ZFLS-AEC"
for easier warning filter maintenance. QAC's original warning messages that do not
refer to the ZFLS-AEC naming rules, are kept in their original warning category folder.


file: zf.chk1.c.pl

The perl script zf.chk1.c.pl executes the post-analysis checks according to the ZFLS-AEC Naming rules.
The following is an extract of its usage message:

C:\ perl zf.chk.c.pl -op="<OutputPath" "C-file" [-DEBUG]

OutputPath should point to the analysis results directory containing .err
and .met files.
C-file is the file.c to be analysed.
-DEBUG option prints some extra debug information about the generated
errors on stdout.

Note:    A. use double quotes for pathes that contain spaces
         B. <QacppOutPath must not end with a "\" (backslash),
                    when double quotes are used.

On QAC GUI the combined command string typically looks like:

Win9x, NT   -   perl C:\QAC\zf.chk1.c.pl -op="C:\temp dir" <filename>



file: ZF-AEC.p_s, ZF-AEC.p_a

ZF-AEC.p_s and ZF-AEC.p_a shall be read by QAC by using the "-via" option or
by selection on GUI, i.e. can be merged with your own project specific configuration files.

These files are destinated to be read only and serve as original to copy.

file: bundle of xxxx.html

These files shall be placed in /help/messages directory from QAC.

Notice that the built-in links point to the html naming rules from ZFLS-AEC expected in the local directory.
You would have to modify the links to point to your intranet location.



3. Requirements
=======================

For purpose of automatic installation of command line environment during setup,
and later for execution of the ZFLS-AEC checks, you need an installed copy
of the perl interpreter. The perl script is not needed in case that an executable
has been compiled using perl2exe.

In order to start the ZFLS-AEC checks, the QAC command line needs to be enabled.
For Windows machines, if you've the appropriate admin rights, set the following
environment variable (best system wide, not only user wide):

-----------
QACPATH = C:\Programme....\Qac4.5              (Installation directory)
QACBIN = %QACPATH%\bin
QACHELPFILES = %QACPATH%\help
QACPERSONALITIES = %QACPATH%\person

PATH = ...;%QACBIN%
-----------

Hint: to be sure QAC's command line is activated, launch a dosshell
      and type "qac -set". Qac's output should then be a listing of the
      current default configuration.

Note: Variables like %QACBIN% may be explicitly expanded to the absolute
      directory location.
      Don't forget to reboot your machine to activate the system changes.


4. Getting started
=======================

-Create a QAC project or use an existing one.

-Select the ZF-AEC.p_s message personality and ZF-AEC.p_a analyser personality
from your 'folder parameter' properties. You will have to adjust the path settings given at "advanced settings"
in the message personality for 'User Message File' and 'Post-Analysis Command String' to your environment..
It is also important to correct the outputpath in 'Script File parameters' from postanalysis.

-Eventually, don't forget to propagate the folder settings to any sub-folders of your project.



5. Return codes
=======================

zf.chk1.c.pl / zf.chk1.c.exe

RETURN CODES
 EXPLANATION

0            Success.

1-10         Perl's internal exit codes.

11           Version string after usage is displayed, i.e. bad arguments or no file name etc.

12           Outputpath problem. output path specified by -op option is wrong or cannot be found on system.

13           Source file accessibility Problem.

14           Environment variables missing (needed for QAC/C++ utilitires).

15           Source file extension not allowed.

16           Temp directory for Postanalysis temporary output not available.

17           .met file accessibility Problem.

18           Status of system calls (errwrt, v_calltree).

19           No 'cmd.exe' found. Verify %ComSpec%.

Any other return codes are generated from perl interpreter. See perl's manual for explanation.












