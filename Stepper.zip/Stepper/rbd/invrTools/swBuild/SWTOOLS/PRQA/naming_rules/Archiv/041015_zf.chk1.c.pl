#!/bin/env perl
#
# Copyright (C) 2001 QA Systems GmbH, Stuttgart
#
# Name:        zf.chk1.c.pl
#
# Version:     v1.13
#
# Author:      B. Roeser
#
# purpose:     ZF naming rules for C using QAC45
#              Compliant with Edition 07.06.2001
#
# created:     12.07.01
#
# design:      for Windows platforms should work for PERL in general
#
#
# Updates:
#
# Version | sign  | date     | doing
# --------+-------+----------+----------------------------------------
#    V000 | broes | 20010629 | create first version of zf naming rules
#    V001 | broes | 20010725 | insert new nameing rules for functions
#    V002 | broes | 20010824 | change error numbers > 6000
#     V003| Gaisser  | 20021111|  2. und 3. Stelle erg�nzt (Variablen und Funktionsnamen)
#                                             ba,cr,ct,dc,dx,fl,rc, da sich die NamingRules geaendert haben
#    V004 |Gaisser|20021112| rl fuer Funktionen ergaenzt
#    V005 |Gaisser|20021211| es fuer Endanschlag ergaenzt
#    V006 |Gaisser|20040122| Anpassung an ge�nderte Naming Rules Prefix und Postfix
#				cl,.. und Floating point
#    V007 |Gaisser|20040205| ml f�r Mathelib
#    V008 |Gaisser|20040209| lokale Variable und Funktionen sollen nicht geprueft werden
#    V009 |Gaisser|20040211| Funktionsgruppe fr, eb, fc erg�nzt
#    V010 |Gaisser|20040212| Meldung ERR_FUPT auskommentiert, da mit MISRA gepr�ft
#    V011 |Gaisser|20040213| Makros nur noch auf Grossbuchstaben pr�fen
#    V012 |Gaisser|20040216| Pruefung von enums
#    V013 | jbecht|20040219| use of QACOUTPATH environment var
#    V014 |Gaisser|20040219| line 344 deactivated (only for debug use), max. Wartezeit von 100000 auf 300000 erh�ht
#    V015 |Gaisser|20040322| Funktionsgruppe sy (Anforderung Hillenbrand)
#    V016 |Gaisser|20040406| Laengenberechnung des Funktionsnamens ohne Korrektur um - 1
#    V017 |Gaisser|20040419| zu Naming RUles 46-01, neue Funktionsgruppe DR
#    V018 |Gaisser|20040427| zu Naming Rules 46-02, neue Funktionsgruppen
#    V019 |Gaisser|20040507| zu Naming Rules 46-03, neue Funktionsgruppen
#    V020 |Gaisser|20040812| zu Naming Rules 49-02, neue Funktionsgruppen ft
#    V021 |Gaisser|20040813| zu Naming Rules 49-03, neue Funktionsgruppen ci und lk
#    V022 |Gaisser|20040923| zu Naming Rules 50-02, neue Funktionsgruppen cu und so
#    V023 |Gaisser|20040927| zu Naming Rules 50-03, neue Funktionsgruppen vs, ln, mp, ml entfernt


# use of this package
# -------------------
use File::Basename;
use Win32;
use Getopt::Long;
use Env "QACOUTPATH"; # get output path for QAC
#use Env "QACBIN";     # get bin path for QAC

# keep flushing the output buffer
# -------------------------------
$| = 1;

# function forward declaration
# ----------------------------
sub generate_err;                      # enhance qac's warnings
sub dprint;                            # print/log debug output
sub MsgBox;                            # print message on gui terminal
sub test_output;                       # print all giving parameters on stdout (only for tests)

# check functions
sub check_input;                       # check input date
sub check_typedef;                     # check name of typedef
sub check_function;                    # check name convention of function
sub check_variable;                    # check name convention of varaiable
sub check_met;                         # get data from met file for checking naming rules
sub check_macro;		# check name convention of macros


# init global constants
# ---------------------
$usage              = "Call $0 -op=\"[OutputPath]\" \"C-file\" [-DEBUG]\nstopped"; # do not remove trailing space for " at filename line no" output
chomp ( $perlname   = basename( $0 ) );
$version            = "Copyright (C) 1999-2001 QA Systems GmbH, Stuttgart\n".$perlname." Revision: 1.0 Date: 2001/06/29\n";
$tool               = "qac"; # needed for errwrt argument specification
$qa_outpath = $QACOUTPATH;
%sourceExts         = qw (c 1 C 1 cpp 1 cxx 1);
$column             = 0;
$include_line       = 1;
$isWin              = (defined ($^O) && ($^O eq "MSWin32") )? TRUE: FALSE;
$IFTEST             = 0;                          # additional test output (0/1)
$FUNC_LEN_MIN       = 6;                          # min length of function names
$FUNC_LEN_MAX       = 34;                         # max length of function names
$VAR_LEN_MAX        = 49;                         # max length of variable names
$TYPE_GLOBAL     = "X";		#Link(age) ist global wenn in met-file ein X eingetragen ist
$MACRO = "(C_|M_)";			#Startzeichen f�r konstanten Makrowert


# init prefix for naming convention from occupation one to four
# -------------------------------------------------------------

# first occupation (from steering) means a pyhsical range
$prefix_1  = "(a|b|c|d|f|h|i|j|m|n|p|q|r|s|t|u|v|w|x|y|z)";
# second occupation (from steering) means belonging to a function
$prefix_23 = "(ad|an|ar|at|az|ba|bo|br|cc|ci|cl|cn|cr|ct|cu|da|dc|di|dp|dr|dx|eb|ec|ee|el|es|fc|fl|fr|ft|ic|in|io|lk|ln|mc|mp|nr|od|om|os|pd|pl|pn|pr|rc|rl|rs|rt|sa|sb|sc|sd|se|sf|si|so|st|sv|sy|tc|tp|ts|vs|p2|vr|vv|wd|_)";
# first occupation for function name is  the same as prefix as prefix_23
$prefix_12_lc = "(ad|an|ar|at|az|ba|bo|br|cc|ci|cl|cn|cr|ct|cu|da|dc|di|dp|dr|dx|eb|ec|ee|el|es|fc|fl|fr|ft|ic|in|io|lk|ln|mc|mp|nr|od|om|os|pd|pl|pn|pr|rc|rl|rs|rt|sa|sb|sc|sd|se|sf|si|so|st|sv|sy|tc|tp|ts|vs|p2|vr|vv|wd|_)";
# V001
$prefix_12_uc = "(Ad|An|Ar|At|Az|Ba|Bo|Br|Cc|Ci|Cl|Cn|Cr|Ct|Cu|Da|Dc|Di|Dp|Dr|Dx|Eb|Ec|Ee|El|Es|Fc|Fl|Fr|Ft|Ic|In|Io|Lk|Ln|Mc|Mp|Nr|Od|Om|Os|Pd|Pl|Pn|Pr|Rc|Rl|Rs|Rt|Sa|Sb|Sc|Sd|Se|Sf|Si|So|St|Sv|Sy|Tc|Tp|Ts|Vs|P2|Vr|Vv|Wd|_)";
# fourth occupation (from steering) means the attribute
$prefix_4  = "(a|d|e|f|g|i|m|o|s|u)";

# init postfix for naming convention
# usage of capital letters for constants and small letters for variables
$postfix_RAM = '([lsmgx])([dpa])([paesubo]|u8|u16|u32|u64|s8|s16|s32|s64|f32|f64|f80)';
$postfix_ROM = '([LSMGX])([DPA])([PAESUBO]|U8|U16|U32|U64|S8|S16|S32|S64|F32|F64|F80)';
$postfix     = "($postfix_RAM|$postfix_ROM)";

$special_signs = "(-|_|:)";

# for future use only
#      <=  left side are codes generated by Qac (Code Analyser)
#                 =>  right side are codes defined in the naming rules

%postfix_datatyp= (
       nc        => 's8',
       uc        => 'u8',
       ns        => 's16',
       ni        => 's16',
       nl        => 's32',
       us        => 'u16',
       ui        => 'u16',
       ul        => 'u32',
       fs        => 's64',
       ff        => 's64',
       fl        => 's64',
       struct    => 's',
       union     => 'u',
       enum      => 'e',
       '=nc'     => 'S8',
       '=uc'     => 'U8',
       '=ns'     => 'S16',
       '=ni'     => 'S16',
       '=nl'     => 'S32',
       '=us'     => 'U16',
       '=ui'     => 'U16',
       '=ul'     => 'U32',
       '=fs'     => 'S64',
       '=ff'     => 'S64',
       '=fl'     => 'S64',
       ne        => 'E',
       c_struct  => 'S',
       c_union   => 'U',
       c_enum    => 'E',
       void      => 'v',
       generic   => 'v',
       any       => '.'
       );
# for future use only!
# init used type names
$type_names = "(tSI8|tSI16|tSI32|tUI8|tUI16|tUI32|eBOOL|bit|t)";

#      <=  left side are codes generated by Qac (Code Analyser)
#                 =>  right side are codes defined in the naming rules

 %data_types= (
       nc        => 'tSI8',
       ns        => 'tSI16',
       nl        => 'tSI32',
       uc        => 'tUI8',
       us        => 'tUI16',
       ul        => 'tUI32',
       ne        => 'eBOOL',
       nb        => 'bit',
       nt	      => 't',
       any       => '.'
       );


# errornumbers + offset 5000 integration
# --------------------------------------

# errors on typedef
$ERR_TYPN = 1001;  # the names of this typedef is not allowed
$ERR_TYCN = 1002;  # Type name is not conform to the type
$ERR_TYMA = 1003;  # Macro name shall have a C or a M at first sign
$ERR_TYMU = 1004;  # Macro description name  shall begin with a uppercase letter
$ERR_TYMN = 1005;  # Macro shall not begin with a number


# errors on functions
$ERR_FULC = 1102;  # the names of functions shall be written in first lowercase letter
$ERR_FURL = 1103;  # the first and second letter represents not the relevancy to a function
$ERR_FUPT = 1104;  # function prototypes shall be placed in headers
$ERR_FUMI = 1105;  # function name shall have at least six letters
$ERR_FUMA = 1106;  # function name shall have not more 34 letters
$ERR_FUUL = 1107;  # letter after prefix shall have a upper case letter

# errors on variables or constants
$ERR_VALC = 1201;  # variables shall be written in first lowercase letter
$ERR_VAMA = 1202;  # variable name shall have not more 49 letters
$ERR_VAPR = 1203;  # the first letter of the prefix must be a part of a physical range
$ERR_VARL = 1204;  # the second and third letter represents not the relevancy to a function
$ERR_VAUC = 1205;  # if no forth prefix is signed, the next letter must be a uppercase letter
$ERR_VAAT = 1206;  # fourth prefix is false attribute
$ERR_VAAL = 1207;  # description name must be begin with a uppercase letter
$ERR_VAND = 1208;  # no description between prefix and postfix found
$ERR_VANP = 1209;  # no defined postfix in use



#################################################################
# purpose: main execute part                                    #
#          calls check sequence                                 #
#  inputs: none                                                 #
#  output: none                                                 #
#################################################################

# check input data
check_input;

# Create temporary file
open(TMP,">$temp_file") || die "\n$perlname: $temp_file: cannot open temporary file!\n";
dprint "errwrt script in $temp_file...\n";

# initialize system call return value
$res = 0;

# working only if OS is a WIN system !!!
if ( $isWin eq TRUE )
  {
  # read met file for actual source an call some checks
  # ---------------------------------------------------
  check_met;

  close TMP;

  # execute shell script with error writing function and remove shell script, if successful
  $Winnt = Win32::IsWinNT();
  #print"$Winnt\n";

  if ($Winnt != 0)
    {                                # WINNT
    $CmdSpec = $ENV{'ComSpec'};      # get command processor from DOS environment
    $CmdName= basename($CmdSpec);
    dprint"found command interpreter: $CmdSpec,$CmdName\n";

    # Check cmd.exe exists on %system%
    # --------------------------------
    if (! -x $CmdSpec )
      {
      MsgBox("QAC Postanalysis Subprocess", "$!: $CmdSpec", 64);
      exit(19);
      }

    require Win32::Process;
    Win32::Process::Create($ProcessObj, #object to hold process
                        "$CmdSpec", #executable
                        "$CmdName /Q /C $temp_file", # /Q echoing off
                        0, #no inheritance
                        0, #default process
                        ".") || die "Create: $!"; #current dir.
    $ProcessObj->Wait(300000);
    $ProcessObj->GetExitCode($res);

    if ( ($res & 0xFF) !=0 )
      {
      MsgBox("QAC Postanalysis Subprocess", "$temp_file: Subprocess died from signal $res", 64);
      }
    $res = $res >> 8; # exit value of the subprocess, truncated 8 bits represent signal
    dprint "$ProcessObj --- res: ?$res?\n";
    }
  else
    {                        # WIN95, 98
    open(TMP,"<$temp_file") || die "\n$perlname: $temp_file: cannot reopen temporary file!\n";

    while(<TMP>)
      {
      #print $_;
      $res= $res + system($_);
      }
    close TMP;
    } #  if ($Winnt != 0) ...
  } #  if ( $isWin eq TRUE ) ...

if ($res == 0)
  {
  dprint "Execution of batch $temp_file...succeeded\nRemoving $temp_file...done";
  unlink ($temp_file);
  }
else
  {
  dprint "Execution of batch $temp_file...failed\nKeeped $temp_file";
  MsgBox("QAC Postanalysis Subprocess", "$temp_file: Subprocess died with exit value $res", 64);
  }

exit($res);


# function definitions
# --------------------

sub check_input
#################################################################
# purpose: check input paramters                                #
#  inputs: input parameters                                     #
#  output: messages on STDOUT                                   #
#################################################################
{
  unless ($isWin eq TRUE )
    {
    print"$version\nThis version is designed for windows systems";
    exit(11);
    }

  # check no of params
  # ------------------
  if ( defined ($ARGV[0]) && $ARGV[0] eq "-v" )
    {
    print"$version\n";
    MsgBox("QAC Postanalysis Version Info", "$version", 64);
    exit(11);
    }

  unless( $#ARGV == 0 || $#ARGV == 1 || $#ARGV == 2 )
    {
    print "wrong number of parameters ($#ARGV)\n$usage";
    MsgBox("QAC Postanalysis Help", "wrong number of parameters ($#ARGV)\n$usage", 64);
    exit(11);
    }

  # extract the params
  # ------------------
  &GetOptions("-op=s" => \$outpath, "-DEBUG" => \$debug );

  # @ARGV contains now only non-option arguments
  # --------------------------------------------
  $source = $ARGV[0];
  $debug = (defined ($debug) && ($debug == 1 ) )? TRUE: FALSE;
  if ( $outpath eq "" )
    {
    # no '-op' on commandline specified
    # check to get it from environment
    if ( $qa_outpath eq "" )
      {
      print "Postanalysis Error: Postanalysis outputPath not specified\nSet environment variable 'QACOUTPATH' or specify '-op=' on parameter list.\n$usage\n";
      MsgBox("QAC Postanalysis Error", "outputPath not specified\n$usage", 64);
      exit(12);
      }
      # Get it from environment variable
      $outpath = $qa_outpath;
   #   MsgBox("QAC Debug info (Line 344)", "outputPath is set to: $outpath\n", 64);
    }

  # cut tailing / or \ from outpath and check it
  # --------------------------------------------
  unless( $outpath =~ /(.*[^\/|^\\])(\/|\\)*$/ )
    {
    print "Postanalysis outputPath not specified\n$usage";
    MsgBox("QAC Postanalysis Error", "outputPath not specified\n$usage", 64);
    exit(12);
    }

  $outpath = $1;
  unless( -d $outpath )
    {
    print "$!: $outpath\n$usage";
    MsgBox("QAC Postanalysis Error", "$!: $outpath\n$usage", 64);
    exit(12);
    }

  # check source-file, extract filename and extension, check legal extension
  # ------------------------------------------------------------------------
  unless( -r $source )
    {
    print "$!: $source\nstopped";
    MsgBox("QAC Postanalysis Error", "$!: $source\nstopped", 64);
    exit(13);
    }

  # filename and ext format setting
  # -------------------------------
  if ( $isWin eq TRUE )
    {
    fileparse_set_fstype("MSDOS"); # file specification syntax
# doesn't wort in NT 4 !!
#    `c:\programme\prqa\qac4.5.2\bin\errwrt`;
#    unless (($? >> 8) == 0)
#      {
    #  MsgBox("QAC Postanalysis Error", "$!: errwrt\nEnvironment variables not set\nstopped", 64);
    #  exit(14);
#      }
    }

  chomp ( ($srcBasename, $ext) = (fileparse ( $source, keys(%sourceExts) ) )[0, 2] );
  $srcBasename =~ s/\.$//g;        # remove extension separator

  # check hash element $ext in hash is true
  # ---------------------------------------
  unless( $sourceExts{$ext} )
    {
    print "wrong source extension: ($ext)\n$usage";
    MsgBox("QAC Postanalysis Error", "wrong source extension: ($ext)\n$usage\nstopped", 64);
    exit(15);
    }

  # check OS type and make settings
  # -------------------------------
  if ( $isWin eq TRUE )
    {
    $path_separator = "\\";
    $temp_file = "qac_$$.bat";

    if ( defined ($ENV{'TEMP'}) && (-d $ENV{'TEMP'}) )
      {
      $temp_dir = $ENV{'TEMP'};
      #$temp_dir =~ s/\\/\\\\/;

      unless ( $temp_dir =~ /\\$/ ) { $temp_dir = $temp_dir.$path_separator; }
      }
    elsif ( -d "C:\\temp"  )
      {
      $temp_dir = "C:\\temp$path_separator";
      }
    else
      {
      MsgBox("QAC Postanalysis Error", "$!: \%TEMP\% or C:\temp\nstopped", 64);
      exit(16);
      }

    $temp_file = $temp_dir.$temp_file;

    # get name of met-file and check
    # ------------------------------
    $metfile="$outpath\\$srcBasename.$ext.met";

    unless( -r $metfile )
      {
      MsgBox("QAC Postanalysis Error", "$!: $metfile\nstopped", 64);
      exit(17);
      }
  } # if ( $isWin eq TRUE ) ...
}


sub dprint
#################################################################
# purpose: print debug output if debug is set; bequiet otherwise#
#  inputs: message string                                       #
#          global variables: $debug                             #
#  output: messages on STDOUT                                   #
#################################################################
{
  # commend this line for no debug output
  if ( $debug eq TRUE )
    {
    print @_;
    }
}


sub MsgBox
#################################################################
# purpose: display a message box on screen                      #
#  inputs: caption                                              #
#          message string                                       #
#          global variables: $icon_buttons                      #
#  output: messages on GUI STDOUT                               #
#################################################################
{
  my ($caption, $message, $icon_buttons) = @_;
  my @return = qw/- Ok Cancel Abort Retry Ignore Yes No/;
  my $result = Win32::MsgBox($message, $icon_buttons, $caption);
  return $return[$result];
}


sub generate_err
#################################################################
# purpose: write .err file with extra warnings                  #
#  inputs: param1 = error code number                           #
#          global variables: $outpath $source $include_line ... #
#  output: shell script using 'errwrt' utility in temp file     #
#################################################################
{
  my $err_code = $_[0];
  my $qm_ident = "\"$ident\"";   # surround identifier with double quotes

  #print "Param transmitted:$ident, $err_code, $inc\n";

  if( defined ($inc) && ($inc eq "I") )
    {
    #include header warning
    dprint "errwrt $tool -op \"$outpath\" \"$source\" $include_line \"$filename\" $line $column $err_code $qm_ident;\n";
    print TMP "errwrt $tool -op \"$outpath\" \"$source\" $include_line \"$filename\" $line $column $err_code $qm_ident\n";
    }
  else
    {
    #source code warning
    dprint "errwrt $tool -op \"$outpath\" \"$source\" $line $column $err_code $qm_ident;\n";
    print TMP "errwrt $tool -op \"$outpath\" \"$source\" $line $column $err_code $qm_ident\n";
    }
}

sub check_met
#################################################################
# purpose: start analysis of .met file lines                    #
#          calls check functions                                #
#  inputs: read .met file lines                                 #
#  output: none                                                 #
#################################################################
{
  # open *met file for analysis
  # ---------------------------

  open(IN,"<$metfile") || die "$perlname: $metfile: $!\n";

  # doing some met checks
  # ---------------------
  while(<IN>)
    {
    # check of defines contained in .met file
    # ---------------------------------------
    if( /^\<DEFINE\>/ )
      {
      if ( /(\".*\")/ )
        {
        $filename = $1;
        ($ident, $rest ) = (split( /\s?\"\s?/) )[0, 2];     #extract all but filename
        $ident = (split(/ /))[1];                           #extract identifier
        ($line, $inc, $def, $space, $scope, $link, $type) = (split(/ /, $rest))[0, 1, 2, 3, 4, 5, 6];
        }
      else
        {
        ($ident, $filename, $line, $inc, $def, $space, $scope, $link, $type) = (split(/ /))[1, 2, 3, 4, 5, 6, 7, 8, 9];
        }

      # test_output( $IFTEST, $ident, $filename, $line, $inc, $def, $space, $scope, $link, $type);

      print "$ident,$filename,$line,$inc,$def,$space,$scope,$link,$type\n";
      print "---->>>checking: $ident\n";

      # remove discovered "\n"
      # ----------------------
      if ( defined $type )
        {
        chomp($type);
        }

      if ( $space =~ /OT/ )
        {
        check_typedef;
        }
      elsif ( $space =~ /OF/ )
        	{
        	check_function;
        	}
          elsif ( $space =~ /OV/ )
        		{
        		check_variable;
        		# activate to check company wide prefix standard, disregard headers + enums
        		# -------------------------------------------------------------------------
        		# init_CompNamConv if ( $inc eq "N" && $type ne "ne" );
        		}

      elsif ($space =~ /OM/ )
         	{
	  check_macro;
	}

       else{;}
      } # if( /^\<DEFINE\>/ )

    # check of total unprepro. LOG
    # ----------------------------
    elsif( /^\<S\>STTPP\s+(\d+)/ )
      {
      # number of total unpreprocessed lines
      # ------------------------------------
      $STTPP = $1;
      }
    else
      {
      next;
      }
    } # while (<IN>)

  close IN;

  # do not forget to reset this global variable
  # -------------------------------------------
  $inc = "N";
}



sub check_typedef
#################################################################
# purpose: checks that typedef name is allowed                  #
#  inputs: global variables $type, $ident                       #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
  if ( $link =~ /$TYPE_GLOBAL/)
   {

    # allways defined types are allowed
    # ---------------------------------
    unless ($ident =~ /^$type_names$/ )
      {
	
             generate_err( $ERR_TYPN );
             my $text_parm = "Wrong basic data typedef: ";
             test_output ($ERR_TYPN, $text_parm ,$ident); # debug output
	
      }

    # type name is not conform to the type
    # ---------------------------------
    if ( !defined($data_types{$type}) )
      {
      generate_err( $ERR_TYCN );
      my $text_parm = "Type name is not conform to the type: ";
      test_output ($ERR_TYPN, $text_parm ,$ident); # debug output
      }

    # test if type is an an enum
#    if ($type =~ /^.{1}"e"/ )
#       {
#         # enum-type muss mit _E enden
#         unless ($ident =~ /^.*[_E]*/  )
#                    {
#                     generate_err( $ERR_TYCN );
#                    }
#       }

  }
}

sub check_function
#################################################################
# purpose: check for naming of functions                        #
#  inputs: $ident                                               #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
#  v001
#  print "function,checking lowercase case in first letter: $ident\n"; # debug output
#  if( $ident =~ /^[A-Z]/ )
#    {
#    my $text_parm = "First character in uppercase letters:";
#    test_output ($IFTEST, $text_parm ,$ident); # debug output
#    generate_err( $ERR_FULC );
#    }

if ( $link =~ /$TYPE_GLOBAL/)
 {
  # check min. length of function name
  # -----------------------------
  $func_len = length($ident);             #attention:  length() include \n
#  $func_len = $func_len - 1;

  if( $func_len < $FUNC_LEN_MIN )
     {
     test_output ($IFTEST, "The function name shall have at least six signs" ,$ident, $func_len);
     generate_err( $ERR_FUMI );
     }

  # check max. length of function name
  # -----------------------------
  if( $func_len > $FUNC_LEN_MAX )
     {
     test_output ($IFTEST, "The function name shall have not more then 34 signs" ,$ident, $func_len);
     generate_err( $ERR_FUMA );
     }

  # check if first and second prefix o.k
  # ------------------------------------
  unless ( $ident =~ /^$prefix_12_lc/
      || $ident =~ /^$prefix_12_uc/ )         # V001
     {
	 
     	     test_output ($IFTEST, "The first two letters of the function name are false" ,$ident);
     	     generate_err( $ERR_FURL );
	   
     }

  # check the letter after the prefix_12
  # -------------------------
  if( $ident =~ /^.{2}[a-z]/
   || $ident =~ /^.{2}[0-9]/
   || $ident =~ /^.{2}$special_signs/ )
     {
       
                test_output ($IFTEST, "Next letter after prefix must be in uppercase letter" ,$ident);
                generate_err( $ERR_FUUL );
               
     }

  # print "function prototypes shall be placed in header files: $ident\n"; # debug output
  # -------------------------------------------------------------------------------------
  #if( $def  eq "DC" &&
  #    $link eq "X"  &&
  #    $inc  eq "N" )
  #  {
  #     
  #              #print "function w. exten. linkage in source: $ident\t"; # debug output
  #              generate_err( $ERR_FUPT );
  #             
  # }
 }
}

sub check_variable
#################################################################
# purpose: check for naming of variables                        #
#  inputs: $ident                                               #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
if ( $link =~ /$TYPE_GLOBAL/)
 {

  if( $ident =~ /^[A-Z]/ )
    {
	 
                my $text_parm = "First character in uppercase letters:";
                test_output ($IFTEST, $text_parm ,$ident); # debug output
               generate_err( $ERR_VALC );
              
    }

  # check max length of variable name
  # ---------------------------------
  $var_len = length($ident) - 1;             #attention:  length() include \n

  if( $var_len > $VAR_LEN_MAX )
     {
     test_output ($IFTEST, "The variable name shall have not more then 49 signs" ,$ident);
     generate_err( $ERR_VAMA );
     }


  # test if variable is an an enum element
 #   if ($type =~ /^"ne"/ )
 #      {
 #        # object is an enum
 #        # enum-variable muss mit _e enden
 #        unless ($ident =~ /^.*[_e]*/  )
 #                   {
 #                    generate_err( $ERR_TYCN );
 #                   }
 #      }
 # else
 #     {
  # object is a variable
  # check if first prefix o.k
  # -------------------------
  unless ( $ident =~ /^$prefix_1/ )
     {
       
          test_output ($IFTEST, "First prefix is false!"  ,$ident); # debug output
          generate_err( $ERR_VAPR );
        
     }

  # check if second prefix o.k
  # -------------------------
  unless ( $ident =~ /^.{1}$prefix_23/ )
     {
       
           test_output ($IFTEST, "Second Prefix isn't o.k!", $ident); # debug output
           generate_err( $ERR_VARL );
          
     }

  # check if fourth prefix o.k
  # -------------------------
  unless ( $ident =~ /^.{3}$prefix_4/)                                           {
     # the next letter must be in uppercase letters or in a number
     # -----------------------------------------------------------
     if ( $ident =~ /^.{3}[a-z]/
       || $ident =~ /^.{3}[\!\"\<\�\$\%\&\,\/\(\)\=\?\-]/)
       {
          
             test_output ($IFTEST, "False attribute for prefix_4!" ,$ident); # debug output
             generate_err( $ERR_VAAT );
            
       }
     }

  # if prefix4 is active, the fith letter must be in uppercase letters
  # ------------------------------------------------------------------
  if ( $ident =~ /^.{3}$prefix_4/)
    {
    if( $ident =~ /^.{4}[a-z]/
     || $ident =~ /^.{4}[0-9]/)
      {
         
              test_output ($IFTEST, "Fifth letter isn't uppercase!", $ident); # debug output
             generate_err( $ERR_VAAL );
           
      }
    }

  # after the prefix23 or prefix 4 it must be a description
  # -------------------------------------------------------
  if ( $ident =~ /^.{3}_$postfix.*/
     || $ident =~ /^.{4}_$postfix.*/ )
     {
        
            test_output ($IFTEST, "No description !", $ident); # debug output
            generate_err( $ERR_VAND );
          
     }

  # sign before postfix must be a underscore
  # ----------------------------------------

  # check if postfix is defined
  # ---------------------------
  if ($ident =~ /_/)
    {
#    unless( $ident =~ /^.*_$postfix.*$/ )
    unless( $ident =~ /^.*[_]$postfix.*/ )
      {
         
           test_output ($IFTEST, "No defined postfix in use" ,$ident);
           generate_err( $ERR_VANP );
           
      }
    # separate postfix from variable name
    # -----------------------------------
    if ($ident =~ /(.*)$/)
      {
      $var_postfix = $1;
      }
    }
 }

#   } # ende else

} # sub check_variable


sub check_macro
#################################################################
# purpose: check for naming of macros                        #
#  inputs: $ident                                               #
#  output: calls generate_err in case of non conformance        #
#################################################################
{
  
  # check max length of macro name
  # ---------------------------------
  $var_len = length($ident) - 1;             #attention:  length() include \n

  if( $var_len > $VAR_LEN_MAX )
     {
     test_output ($IFTEST, "The macro name shall have not more then 49 signs" ,$ident);
     generate_err( $ERR_VAMA );
     }

  # check if first and second prefix o.k
  # -------------------------
  #unless ( ($ident =~ /$MACRO/ )  )
   #  {
    #   
     #     test_output ($IFTEST, "First and second prefix is false!" ,$ident); # debug output
      #    generate_err( $ERR_TYMA );
       # 
     #}

  
  # check if  characters are uppercase
  # -------------------------
  
 

       for ($i = 0; $i <= $var_len; $i++)
        {
          # test character
          unless ( $ident =~ /^.{$i}[A-Z]/  || $ident =~ /^.{$i}$special_signs/ || $ident =~ /^.{$i}[0-9]/  )

           {
            test_output ($IFTEST, "no uppercase!", $ident); # debug output
            generate_err( $ERR_TYMU );
           }

        }
     
} # sub check_macro



 sub test_output
#################################################################
# purpose: output of statements during developing source code   #
#          activate and deactivate with the first               #
#          parameter $IFTEST                                    #
#  inputs: $IFTEST (0,1) bool variable for printing             #
#          some variables                                       #
#  output: message on stdout                                    #
#################################################################
{
  # output of all parameters
  # ------------------------
  # my $print_error = @_[0];   # older version
  my $print_error = $_[0];
  # print $occurence;

  if ($print_error ne 0)
    {
    foreach(@_) {print "-> $_ <- \n";}
    }
}