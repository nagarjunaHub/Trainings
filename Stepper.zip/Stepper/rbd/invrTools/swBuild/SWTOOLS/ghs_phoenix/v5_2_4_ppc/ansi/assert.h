/* $END_RBHEADER$ ******************* */
/* ********************************************************************* */
/* $Archive..: \pfa2si_view_main_latest_Y_LW\ED_PROZESS\development_environment\ImplementationSet\SWTOOLS\ghs_phoenix\v5_1_7_ppc\ansi\assert.h $ */
/* $Version..: \main\2 $ */
/* $Author...: Kapfer Stephan (AE/ENS3) $ */
/* $Date.....: 2011-11-4 11:58:6 $ */
/* $Comment..: EBRCM00441654  $ */
/* ********************************************************************* */


/*
			ISO C Runtime Library

	Copyright (c) 1983-2007 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.
*/

#ifdef __ghs__
#pragma ghs startnomisra
#endif
#ifdef __cplusplus
extern "C" {
#endif

#undef assert
#if defined(__STDC__) || defined(__PROTOTYPES__) || defined(__EDG__)
void assert(int);
#endif

#ifdef NDEBUG
# define assert(ignore)	((void)0)
#elif defined(__unix) || defined(__unix__) || defined(__linux__)
   /* This unix version is very portable and will work with any C library. */
#  include <stdio.h>		/* for stderr */
#  undef assert
#if defined(__ATTRIBUTES__)
void abort(void) __attribute__((__noreturn__));
#else
void abort(void);
#endif

#  if defined(__STDC__)
#   define assert(value)	((void)((value) || \
	    (fprintf(stderr, \
		"Assertion failed: " #value ", file " __FILE__ ", line %d\n", \
					__LINE__), abort(),0)))
#  else
#   define assert(value)	((void)((value) || \
	    (fprintf(stderr, "Assertion failed: \"value\", file %s, line %d\n", \
					__FILE__,__LINE__),exit(1),0)))
#  endif 
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 199901)
   int _assert_(const char *, const char *, int, const char *);
#  define assert(val)	((void)(((val)!=0)?0:_assert_(#val,__FILE__,__LINE__,__func__)))
#elif defined(__STDC__)		/* This version is compact for embedded */
   int _assert(const char *, const char *, int);
#  define assert(val)	((void)(((val)!=0)?0:_assert(#val,__FILE__,__LINE__)))
/*#define assert(val)	((void)(((val)!=0)||_assert(#val,__FILE__,__LINE__))) */
#else		/* would pass "val" here but that fails if val contains ".  */
#if defined(__PROTOTYPES__) || defined(__EDG__)
   int _assert(const char *, const char *, int);
#endif
#  define assert(val)	((void)((val)||_assert("val",__FILE__,__LINE__)))
#endif 

#ifdef __cplusplus
}
#endif
#ifdef __ghs__
#pragma ghs endnomisra
#endif
