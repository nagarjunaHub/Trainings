/* $END_RBHEADER$ ******************* */
/* ********************************************************************* */
/* $Archive..: \pfa2si_view_main_latest_Y_LW\ED_PROZESS\development_environment\ImplementationSet\SWTOOLS\ghs_phoenix\v5_1_7_ppc\ansi\ghcxx.h $ */
/* $Version..: \main\2 $ */
/* $Author...: Kapfer Stephan (AE/ENS3) $ */
/* $Date.....: 2011-11-4 13:30:20 $ */
/* $Comment..: EBRCM00441654  $ */
/* ********************************************************************* */


/*
		    ISO C/C++ Runtime Library

	Copyright 1983-2004 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.
*/
/*
    This file is #included at the top of every .c file output by C++ front
    end. The first use of this file is to solve problems related to stdarg.h,
    which tends to use builtin functions unknown to the C++ front end.  The
    solution is to change stdarg.h to produce something the C++ front end will
    accept, and then put additional macros here which convert that back into
    what the C compiler needs.  At first this is done for PowerPC.
*/

#ifndef _GHCXX_H
#ifdef __ghs__
#pragma ghs startnomisra
#endif
#define _GHCXX_H
#ifdef __cplusplus
 extern "C" {
#endif

#if defined(__ppc)
#  define __va1_sizeof __va_regtyp
#  define __va2_sizeof __va_float
#  define __gh_va_arg_macro(a,b,c,d) __gh_va_arg(a,__va1_ ## b,__va2_ ## c,d)
    struct va_list;
    char *__gh_va_arg(struct va_list *, int, int, int);
#endif

#ifdef __cplusplus
 }
#endif

#ifdef __ghs__
#pragma ghs endnomisra
#endif
#endif /* _GHCXX_H */
