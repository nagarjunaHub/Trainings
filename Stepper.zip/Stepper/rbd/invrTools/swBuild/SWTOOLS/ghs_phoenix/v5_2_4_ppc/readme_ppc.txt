MULTI for PowerPC v5.0.6

Please refer to release_notes.pdf for release notes.
