/* $END_RBHEADER$ ******************* */
/* ********************************************************************* */
/* $Archive..: \pfa2si_view_main_latest_Y_LW\ED_PROZESS\development_environment\ImplementationSet\SWTOOLS\ghs_phoenix\v5_1_7_ppc\ansi\interrupt.h $ */
/* $Version..: \main\2 $ */
/* $Author...: Kapfer Stephan (AE/ENS3) $ */
/* $Date.....: 2011-11-4 11:57:10 $ */
/* $Comment..: EBRCM00441654  $ */
/* ********************************************************************* */


/*
			ISO C Runtime Library

	Copyright (c) 1983-2007 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.

*/
#define interrupt __interrupt
