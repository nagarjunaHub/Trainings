/* $END_RBHEADER$ ******************* */
/* ********************************************************************* */
/* $Archive..: \pfa2si_view_main_latest_Y_LW\ED_PROZESS\development_environment\ImplementationSet\SWTOOLS\ghs_phoenix\v5_1_7_ppc\ansi\time.h $ */
/* $Version..: \main\2 $ */
/* $Author...: Kapfer Stephan (AE/ENS3) $ */
/* $Date.....: 2011-11-4 11:57:42 $ */
/* $Comment..: EBRCM00441654  $ */
/* ********************************************************************* */


/*
			ISO C Runtime Library

	Copyright (c) 1983-2010 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.
*/

#ifndef _TIME_H
#ifdef __ghs__
#pragma ghs startnomisra
#endif
#define _TIME_H
#include "ghs_null.h"		/* defines NULL and size_t */

#ifdef __cplusplus
extern "C" {
#endif

#if !defined(CLK_TCK) && (defined(_INTEGRITY_SOURCE) || \
	!defined(_POSIX_C_SOURCE) && !defined(_POSIX_SOURCE))
#define CLK_TCK     	60		/* should be sysconf(3) for POSIX */
#endif
#ifndef CLOCKS_PER_SEC
#define CLOCKS_PER_SEC	1000000
#endif

#define _TZ_UNKNOWN (-1)

#ifndef _CLOCK_T
#define _CLOCK_T
typedef long clock_t;
#endif

#ifndef _TIME_T
#define _TIME_T
typedef long time_t;
#endif

/* the library is not compiled with packing, so this must not be packed. */
#if (defined(__EDG__) || defined(__CCOM__)) && defined(__ghs_max_pack_value)
#pragma pack (push, __ghs_max_pack_value)
#endif
struct tm {
    int tm_sec; 	    /* seconds of the minute, [0,59] */
    int tm_min; 	    /* minutes of the hour, [0,59] */
    int tm_hour;	    /* hour of the day, [0,23] */
    int tm_mday;	    /* day of the month, [1,31] */
    int tm_mon; 	    /* months since Jan, [0,11] */
    int tm_year;	    /* years since 1900 */
    int tm_wday;	    /* days since Sun, [0,6] */
    int tm_yday;	    /* days since Jan 1, [0,365] */
    int tm_isdst;	    /* daylight savings time */
};
#if (defined(__EDG__) || defined(__CCOM__)) && defined(__ghs_max_pack_value)
#pragma pack(pop)
#endif

#if defined(__MISRA_20_12) && (__MISRA_20_12 == 2)
#  error "(Misra Rule 20.12): the header <time.h> not allowed"
#elif defined(__MISRA_20_12) && (__MISRA_20_12 == 1)
#  warning "(Misra Rule 20.12): the header <time.h> not allowed"
#endif

#if defined(__MISRA_127) && (__MISRA_127 == 2)
#  error "(Misra Rule 127): the header <time.h> not allowed"
#elif defined(__MISRA_127) && (__MISRA_127 == 1)
#  warning "(Misra Rule 127): the header <time.h> not allowed"
#endif

#if defined(__STDC__) || defined(__PROTOTYPES__)
#define __ARGS(x)		x
#else
#define __ARGS(x)		()
#endif
#if defined(__STDC_VERSION__) && (__STDC_VERSION__>=199901L)
#define __Restrict	restrict
#else
#define __Restrict
#endif

#ifdef __NoFloat
# define   difftime(t1,t0) ((t1)-(t0))
#else
#if defined(__ATTRIBUTES__)
  double   difftime	__ARGS((time_t, time_t)) __attribute__ ((__const__));
#else
  double   difftime	__ARGS((time_t, time_t));
#endif
# define   difftime(t1,t0) (((double)(t1))-((double)(t0)))
#endif
time_t	   time		__ARGS((time_t *));

#undef	__ARGS
#if defined(__STDC__) || defined(__PROTOTYPES__) || defined(__EDG__)
#define __ARGS(x)		x
#else
#define __ARGS(x)		()
#endif

clock_t	   clock	__ARGS((void));
time_t	   mktime	__ARGS((struct tm *));

char *	   asctime	__ARGS((const struct tm *));
char *	   asctime_r	__ARGS((const struct tm *, char *));
char *	   ctime	__ARGS((const time_t *));
char *	   ctime_r	__ARGS((const time_t *, char *));
struct tm *gmtime	__ARGS((const time_t *));
struct tm *gmtime_r	__ARGS((const time_t *, struct tm *));
struct tm *localtime	__ARGS((const time_t *));
struct tm *localtime_r	__ARGS((const time_t *, struct tm *));
#if defined(__CHECK_PRINTF__) && defined(__GNUC__)
size_t	   strftime	(char* __Restrict, size_t, const char* __Restrict, 
			const struct tm* __Restrict)
			__attribute__ ((__format__ (__strftime__, 3, 0)));
#else
size_t	   strftime	__ARGS((char*__Restrict, size_t,const char* __Restrict,
				const struct tm* __Restrict));
#endif

/* Most of the following declarations are suitable for any POSIX target. */
#if defined(__INTEGRITY)

#if defined(_INTEGRITY_SOURCE) || (!defined(_POSIX_C_SOURCE) && !defined(_POSIX_SOURCE)) 
# include <sys/time.h>
#endif

#if (defined(__EDG__) || defined(__CCOM__)) && defined(__ghs_max_pack_value)
#pragma pack (push, __ghs_max_pack_value)
#endif
typedef struct timespec
{
    time_t	tv_sec;
    long	tv_nsec;
} timespec_t;

typedef struct itimerspec
{
    struct timespec	it_interval;
    struct timespec	it_value;
} itimerspec_t;
#if (defined(__EDG__) || defined(__CCOM__)) && defined(__ghs_max_pack_value)
#pragma pack(pop)
#endif

typedef unsigned int	clockid_t;
typedef unsigned int	timer_t;

# define	CLOCK_REALTIME	3
#ifdef INT_178B
# define	CLOCK_MONOTONIC	4
#endif

# define	TIMER_ABSTIME	1

int clock_settime(clockid_t __clock_id, const struct timespec *_tp);
int clock_gettime(clockid_t _clock_id, struct timespec *_tp);
int clock_getres(clockid_t _clock_id, struct timespec *_res);
int nanosleep(const struct timespec *_rqtp, struct timespec *_rmtp);

typedef struct sigevent sigevent_t;

int timer_create(clockid_t _clock_id, sigevent_t *_evp,
                 timer_t *_timerid);
int timer_delete(timer_t _timerid);
int timer_settime(timer_t _timerid, int _flags,
                  const struct itimerspec *_value,
                  struct itimerspec *_ovalue);
int timer_gettime(timer_t _timerid, struct itimerspec *_value);
int timer_getoverrun(timer_t _timerid);

#if defined(_INTEGRITY_SOURCE) || (!defined(_POSIX_C_SOURCE) && !defined(_POSIX_SOURCE)) 
#define SECSPERMIN	60
#define MINSPERHOUR	60
#define HOURSPERDAY	24
#define DAYSPERWEEK	7
#define DAYSPERNYEAR	365
#define DAYSPERLYEAR	366
#define SECSPERHOUR	(SECSPERMIN * MINSPERHOUR)
#define SECSPERDAY	((long) SECSPERHOUR * HOURSPERDAY)
#define MONSPERYEAR	12
#define TM_YEAR_BASE	1900

#endif
#endif	/* __INTEGRITY */

#if !defined(__STRICT_ANSI__) || defined(_POSIX_SOURCE) || defined(_POSIX_C_SOURCE)
   void  tzset __ARGS((void));
   extern char *tzname[2];	/* set by tzset() */
#endif
#undef __ARGS
#undef __Restrict
#ifdef __cplusplus
}
#endif
#ifdef __ghs__
#pragma ghs endnomisra
#endif
#endif	/* _TIME_H */
