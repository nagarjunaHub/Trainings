/* $END_RBHEADER$ ******************* */
/* ********************************************************************* */
/* $Archive..: \pfa2si_view_main_latest_Y_LW\ED_PROZESS\development_environment\ImplementationSet\SWTOOLS\ghs_phoenix\v5_1_7_ppc\ansi\stddef.h $ */
/* $Version..: \main\2 $ */
/* $Author...: Kapfer Stephan (AE/ENS3) $ */
/* $Date.....: 2011-11-4 11:57:29 $ */
/* $Comment..: EBRCM00441654  $ */
/* ********************************************************************* */


/*
			ISO C Runtime Library

	Copyright (c) 1983-2010 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.
*/

#ifndef _STDDEF_H
#ifdef __ghs__
#pragma ghs startnomisra
#endif
#define _STDDEF_H

#include "ghs_null.h"		/* defines NULL and size_t */
#include "ghs_wchar.h"		/* defines wchar_t */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _PTRDIFF_T
#define _PTRDIFF_T
# if (__PTR_BIT <= __INT_BIT) || (__INT_BIT == __LONG_BIT)
typedef int ptrdiff_t;
# elif (__PTR_BIT <= __LONG_BIT) || (__LONG_BIT == __LLONG_BIT)
typedef long ptrdiff_t;
# else
typedef long long ptrdiff_t;
# endif
#endif	/* _PTRDIFF_T */

#if (!defined(__MISRA_20_6) || (__MISRA_20_6 != 2)) && (!defined(__MISRA_120) || (__MISRA_120 != 2)) && !defined(__SC3__)
#if defined(__cplusplus) || (defined(__EDG__) && !defined(__ONLY_STANDARD_KEYWORDS_IN_C))
#define offsetof(t, memb) 	(__INTADDR__(&(((t *)0)->memb)))
#else
#define offsetof(type,id)	((size_t)(((char*)&(((type *)16)->id))-((char*)((type *)16))))
#endif  /* __cplusplus */
#endif  /* __MISRA_20_6 */

#ifdef __cplusplus
}
#endif
#ifdef __ghs__
#pragma ghs endnomisra
#endif
#endif  /* _STDDEF_H */
