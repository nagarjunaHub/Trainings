/* $END_RBHEADER$ ******************* */
/* ********************************************************************* */
/* $Archive..: \pfa2si_view_main_latest_Y_LW\ED_PROZESS\development_environment\ImplementationSet\SWTOOLS\ghs_phoenix\v5_1_7_ppc\ansi\complex.h $ */
/* $Version..: \main\2 $ */
/* $Author...: Kapfer Stephan (AE/ENS3) $ */
/* $Date.....: 2011-11-4 11:58:8 $ */
/* $Comment..: EBRCM00441654  $ */
/* ********************************************************************* */


/*
			ISO C Runtime Library

	Copyright (c) 2003-2010 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.
*/

#ifndef _COMPLEX_H
#ifdef __ghs__
#pragma ghs startnomisra
#endif
#define _COMPLEX_H
#if !defined(__NoFloat) && defined(__EDG__)

#ifdef __cplusplus
#error complex.h is intended for C99. Use <complex> for C++ instead
#elif __STDC_VERSION__ < 199901L
#error complex.h requires ISO C99 support in the compiler
#endif

#define complex		_Complex
#define _Complex_I	((float _Complex)__I__)
#define imaginary	_Imaginary
#ifdef imaginary
# define _Imaginary_I	((float _Imaginary)__I__)
# define I		_Imaginary_I
#else
# define I		_Complex_I
#endif

/* #pragma STDC CX_LIMITED_RANGE on-off-switch */

double complex cacos(double complex);
float  complex cacosf(float complex);
double complex casin(double complex);
float  complex casinf(float complex);
double complex catan(double complex);
float  complex catanf(float complex);
double complex ccos(double complex);
float  complex ccosf(float complex);
double complex csin(double complex);
float  complex csinf(float complex);
double complex ctan(double complex);
float  complex ctanf(float complex);
double complex cacosh(double complex);
float  complex cacoshf(float complex);
double complex casinh(double complex);
float  complex casinhf(float complex);
double complex catanh(double complex);
float  complex catanhf(float complex);
double complex ccosh(double complex);
float  complex ccoshf(float complex);
double complex csinh(double complex);
float  complex csinhf(float complex);
double complex ctanh(double complex);
float  complex ctanhf(float complex);
double complex cexp(double complex);
float  complex cexpf(float complex);
double complex clog(double complex);
float  complex clogf(float complex);
double cabs(double complex);
float  cabsf(float complex);
double complex cpow(double complex, double complex);
float  complex cpowf(float complex, float complex);
double complex csqrt(double complex);
float  complex csqrtf(float complex);
double carg(double complex);
float  cargf(float complex);
double cimag(double complex);
float  cimagf(float complex);
double complex conj(double complex);
float  complex conjf(float complex);
double complex cproj(double complex);
float  complex cprojf(float complex);
double creal(double complex);
float  crealf(float complex);

#if 1
long double creall(long double complex);
long double complex cacosl(long double complex);
long double complex casinl(long double complex);
long double complex catanl(long double complex);
long double complex ccosl(long double complex);
long double complex csinl(long double complex);
long double complex ctanl(long double complex);
long double complex cacoshl(long double complex);
long double complex casinhl(long double complex);
long double complex catanhl(long double complex);
long double complex ccoshl(long double complex);
long double complex csinhl(long double complex);
long double complex ctanhl(long double complex);
long double complex cexpl(long double complex);
long double complex clogl(long double complex);
long double cabsl(long double complex);
long double complex cpowl(long double complex, long double complex);
long double complex csqrtl(long double complex);
long double cargl(long double complex);
long double cimagl(long double complex);
long double complex conjl(long double complex);
long double complex cprojl(long double complex);
long double creall(long double complex);
#endif	/* 1 */

#endif  /* !defined(__NoFloat) */
#ifdef __ghs__
#pragma ghs endnomisra
#endif

#endif  /* _COMPLEX_H */
