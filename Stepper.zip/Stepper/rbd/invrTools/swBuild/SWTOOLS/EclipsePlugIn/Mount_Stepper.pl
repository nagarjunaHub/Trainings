use File::Spec;
use Cwd;
use File::Basename;
$curdir = getcwd();
print "CurDir $curdir\n";
($drive,$view,$vob,$branc) = File::Spec->splitdir($curdir);
# my $vob_path2 = dirname($curdir);
# my $curdir2 = fileparse($curdir);

# print "vob_path2: $vob_path2\t curdir2: $curdir2\n";


# $vob_path = File::Spec->catdir($drive,$view,$vob);
$vob_path = $curdir;

$AlmCurdir = getcwd();
print "AlmCurdir:$AlmCurdir\n";
# ($AlmDrive, $AlmUsers, $AlmUser,$AlmSandbox,$AlmRws) = File::Spec->splitdir($AlmCurdir);
# $AlmRwsPath = "$AlmDrive\\$AlmUsers\\$AlmUser\\$AlmSandbox\\$AlmRws";

$AlmRwsPath = $AlmCurdir;
$AlmRws = fileparse($curdir);
print "AlmRwsPath: $AlmRwsPath\n";
print "AlmRws: $AlmRws\n";
$PerlPath = "S:\\Scripte\\SpecialToolsetEntry\\Perl\\bin\\perl";

print "\n***********************************************************************\n";
print "Selected View for Build is: $vob_path\n";
print "***********************************************************************\n";

# $Almcheck = "(!(-e "$curdir\\rbd\\invrTools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl")) && (!(-e "$curdir\\rbd\\EOLv850\\tools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper1.pl"))";

if(($vob ne "ED_EBI") && ($vob ne "PT_PVI") && ($vob ne "ED_ESG") && ($vob ne "ED_TT") && ($vob ne "ED_STUDY") && (!(-e "$curdir\\rbd\\invrTools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl")) && (!(-e "$curdir\\rbd\\EOLv850\\tools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl")) && ($vob ne "ED_FBL"))
{
 print "\n************************ Error in Software build *************************\n\n";
 print   "Please rerun the SWDE_Stepper from ImplementationSet of the associated VOB\n\n";
 print "Press <Enter> to close this window...!\n";
 print "\n**************************************************************************\n\n";
 <STDIN>;
 exit;
}

if(($vob eq "ED_EBI") || ($vob eq "ED_ESG") || ($vob eq "ED_TT") ||($vob eq "ED_STUDY") ||($vob eq "ED_FBL"))
{
 $make_dir = "ImplementationSet\\make\\mount_swtools_on_v.cmd";
 $mount = File::Spec->catdir($vob_path,$make_dir);
 system("$mount \"%1\"");
 print "Mount complete\n";
 $Tools = "ToolSet/SWTOOLS/Make/global_makefiles/SWDE_Stepper.pl";
 $StepperPath = File::Spec->catdir($vob_path,$Tools);
 $Alm_Flag = 0;
}

if($vob eq "PT_PVI")
{
 $make_dir = "SW_Software\\ImplementationSet\\make\\mount_swtools_on_v.cmd";
 $mount = File::Spec->catdir($vob_path,$make_dir);
 system("$mount \"%1\"");
 print "Mount complete\n";
 $Tools = "SW_Software/ToolSet/SWTOOLS/Make/global_makefiles/SWDE_Stepper.pl";
 $StepperPath = File::Spec->catdir($vob_path,$Tools);
 $Alm_Flag = 0;
}


if((-e "$curdir\\rbd\\invrTools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl") or (-e "$curdir\\rbd\\EOLv850\\tools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl"))

{
	
	($AlmBUnit, $AlmProject, $AlmPrjVariant,$AlmSw) = split('_', $AlmRws);
	if($AlmSw eq "sw") {
		$AlmToolsCfgPath = "$AlmBUnit\\$AlmProject\\$AlmPrjVariant\\sw\\tools_cfg";
	}
	else {
		$AlmToolsCfgPath = "$AlmBUnit\\$AlmProject\\$AlmPrjVariant\\tools_cfg";
	}
	
	$make_dir = "$AlmToolsCfgPath\\mount_swtools_on_v.cmd";
	# $mount = File::Spec->catdir($AlmRwsPath,$make_dir);
	# system("$mount \"%1\"");
	# print "Mount complete\n";
	if (-d "$AlmRwsPath\\rbd\\invrPPC\\tools\\swBuild") {
		$Tools = "rbd\\invrPPC\\tools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl";
		$PerlPath = "$AlmRwsPath\\rbd\\invrPPC\\tools\\swBuild\\SWTOOLS\\perl\\v5_8_8_817\\bin\\perl";
	}
	elsif (-d "$AlmRwsPath\\rbd\\invrTools\\swBuild") {
		$Tools = "rbd\\invrTools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl";
		$PerlPath = "$AlmRwsPath\\rbd\\invrTools\\swBuild\\SWTOOLS\\perl\\v5_8_8_817\\bin\\perl";
	}
	
	elsif (-d "$AlmRwsPath\\rbd\\EOLv850\\tools\\swBuild") {
		$Tools = "rbd\\EOLv850\\tools\\swBuild\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl";
		$PerlPath = "$AlmRwsPath\\rbd\\EOLv850\\tools\\swBuild\\SWTOOLS\\perl\\v5_8_8_817\\bin\\perl";
	}
	else {
		$Tools = "rbd\\invrPPC\\tools\\all\\SWTOOLS\\Make\\global_makefiles\\SWDE_Stepper.pl";
		$PerlPath = "$AlmRwsPath\\rbd\\invrPPC\\tools\\all\\SWTOOLS\\perl\\v5_8_8_817\\bin\\perl";
	}
	
	$StepperPath = "$AlmRwsPath\\$Tools";
	# $PerlPath = "C:\\toolbase\\_ldata\\perl\\5.14.4.1_3_ecl\\eclipse\\plugins\\com.bosch.ubk.perlinterpreter_5.14.4.1_3\\Perl\\perl\\bin\\perl
	# if SWDE-Stepper is compatible with new version, bestcase not only for ALM-Projects but then Toolbase is mandatory on each pc
	$Alm_Flag = 1;
}
#print "C:\\toolbase\\_ldata\\perl\\5.14.4.1_3_ecl\\eclipse\\plugins\\com.bosch.ubk.perlinterpreter_5.14.4.1_3\\Perl\\perl\\bin\\perl $StepperPath $Alm_Flag\n";
#system("C:\\toolbase\\_ldata\\perl\\5.14.4.1_3_ecl\\eclipse\\plugins\\com.bosch.ubk.perlinterpreter_5.14.4.1_3\\Perl\\perl\\bin\\perl $StepperPath $Alm_Flag");

print "executing cmd: $PerlPath $StepperPath $Alm_Flag\n";
system("$PerlPath $StepperPath $Alm_Flag");



