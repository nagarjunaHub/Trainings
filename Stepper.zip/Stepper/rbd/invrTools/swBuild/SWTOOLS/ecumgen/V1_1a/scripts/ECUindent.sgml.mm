//===================================================
  !TRANSFORMATION
//===================================================

//---------------------------------------------------
  !entity 
//---------------------------------------------------

[data=="<"] 
  !replace 
    <|gid:="lt"|>entity;

[data=="&"] 
  !replace  
    <|gid:="amp"|>entity;

[data=="manufacturing"] 
  !replace 
    <|gid:="production"|>entity;

[data=="engineering"] 
  !replace 
    <|gid:="engineering"|>entity;

[data==("to be done", "to be defined") ]  
  !replace 
    <|gid:="tbd"|>entity;

[data=="not applicable"] 
  !replace 
    <|gid:="na"|>entity;

[^gid]
    ("\nunhandeled entity: "||data||"\n").forceerror("error", "unhenditity");

//---------------------------------------------------
  !begin 
//---------------------------------------------------

[] 
    ("<!DOCTYPE "|| source.gid || " PUBLIC \"" || source.@pubid || "\"" || ">"),
    <|gid:=gid|>source;

//---------------------------------------------------
  info | mem 
//---------------------------------------------------

[left & ^_done ]  
  !replace 
    "\n\n\n",
    <|_done:=1|>self;

//---------------------------------------------------
  revision | history | distribution| project  | datablock
//---------------------------------------------------

[left & ^_done  ] 
  !replace 
    "\n",
    <|_done:=1|>self;

//---------------------------------------------------
submitter | receiver | session 
//---------------------------------------------------

[left & ^_done ] 
  !replace 
    "\n\n",
    <| _done:=1|>self;

//---------------------------------------------------
!default
//---------------------------------------------------

[p.child] 
    p.contents, 
    join(("\n",argument[?indent].data.join(" ".duplicate(that)).duplicate(count(self.ancestor))));

[p.contents[type=="string"].find("\n")]   
    "\n",
    p.contents,
    "\n";

//===================================================
  !ANNOTATION
//===================================================

//---------------------------------------------------
  l.norm | l.bigskip | l.skip | l.smallskip 
//---------------------------------------------------

[] 
    _txt:="prefix:";

//---------------------------------------------------
!default 
//---------------------------------------------------

[]
    _sgml := 
        "prefix:"
      ||join(("\n",argument[?indent].data.join(" ".duplicate(that)).duplicate(count(self.ancestor))));
