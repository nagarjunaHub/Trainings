#!perl
# Script liest eine Exceltabelle aus und zeigt den Inhalt im Browser

use strict;
use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
$Win32::OLE::Warn = 3;

my $Excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application', 'Quit');


my $Book = $Excel->Workbooks->Open('Z:\\ED_EPS_PP\DeploymentSet\Deliveries\SW_Deliveries_List.xls');
#my $Book = $Excel->Workbooks->Open('O:\ED_SSM\Deploymentset\Customer_Deliverables\SW_Deliveries_List.xls');
my $Sheet = $Book->Worksheets(1); # entspricht Tabelle1, erstes ABlatt
my $array = $Sheet->Range('A1:D22')->{'Value'};
$Book->Close;


foreach my $ref_array (@$array){
  foreach my $scalar (@$ref_array){ 
    print "$scalar;";
  }
  print "\n";
}



#print "content-type:text/html\n\n";
#print "<HTML><HEAD>
#<TITLE>Eine Excel Tabelle als HTML Tabelle</TITLE>
#</HEAD><BODY BGCOLOR=silver>";

#print "<h3>Eine Excel Tabelle �ffnen - als HTML Tabelle ausgeben:</h3>";

#print "<table border=1 align=center cellspacing=1>\n";
#foreach my $ref_array (@$array){
#  print "<tr>\n";
#  foreach my $scalar (@$ref_array){ 
#    print "<td>$scalar</td>\n";
#  }
#  print "</tr>\n";
#}
#print "</table>\n
#</body></html>";
