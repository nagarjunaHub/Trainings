#*************************************************************************************
#*                                                                                   *
#*  FILENAME:    delspacelines.pl                                                    *
#*                                                                                   *
#*  PROGRAMMTYP: Perl-Script-File                                                    *
#*                                                                                   *
#*  AUTOR:       ZFLS/ZEEF Rohmann                                                   *
#*                                                                                   *
#*  Aufgabe:     Loescht in bel. Textdateien alle Leerzeilen                         *
#*                                                                                   *
#*  Parameter:   ARGV[0] - enthaelt Lister der Parameter mit                         *
#*               - "-fp<Filepatter der zu suchenden Dateien>"                        *
#*               - "-log<Logdatei>                                                   *
#*																					 *
#*                                                                                   *
#*  In/Output:   																	 *
#*                                                                                   *
#*  AUFRUF:      perl delspacelines.pl -fp<Filepatter> -log<Logdatei>                *
#*                                                                                   *
#*  Kommentare:                                                                      *
#*                                                                                   *
#*************************************************************************************

######################################################################################
# Init ...

print "\n\n";
print " Loeschen von Leerzeichen in Textdateien:\n";
print " ========================================\n\n";

# Vorbelegungen
$RC_SUCCESS = 0;
$RC_ERRO    = 1;
$TRUE       = 0;
$FALSE      = 1;

# Argumente verarbeiten
@tmp_argv = split ' ', @ARGV[0];

printf "alle Argumente= @ARGV[0]\n\n";
printf "Argumente= @tmp_argv\n\n";

# Filepatter
@tmp1 = grep /-fp/i, @tmp_argv;
$file_patter = $tmp1[0];
substr ($file_patter, 0, 3) = "";

# LOG-Datei
@tmp1 = grep /-log/i, @tmp_argv;
$log_file = $tmp1[0];
substr ($log_file, 0, 4) = "";


######################################################################################
# Oeffner LOG-Datei und erste Daten eintragen

open (LOGFILE, "+>$log_file") or die "FEHLER: Oeffnen Logdatei: $log_file";

print " [notwendig -fp] Filepatter= $file_patter\n";
print " [notwendig -log] LOG-Datei= $log_file\n";

print LOGFILE "$0\n\n";
print LOGFILE " [notwendig -fp] Filepatter= $file_patter\n";
print LOGFILE " [notwendig -log] LOG-Datei= $log_file\n\n";


######################################################################################
# File Grap:

@liste = glob $file_patter;

print LOGFILE " Liste der gefundenen Files= @liste";

# Alle Elemente der Liste durchgehen ...
foreach $elem (@liste)
{
  print ".";
  print LOGFILE "  Element= $elem";

  # Rename Element (*.i -> *.tmp)
  $new_name = $elem;
  $new_name =~ s/(.i)$/.tmp/;

  print LOGFILE "     Neuer Name= $new_name\n";   

  rename $elem,$new_name;

  open (INFILE, "<$new_name") or die "FEHLER: Oeffnen temp. Datei: $new_name";
  open (OUTFILE, ">$elem") or die "FEHLER: Oeffnen Datei: $elem";

  # Schleife ueber alle Zeilen (bis EOF)
  $counter_org = 0;
  $counter_new = 0;
  while ( $line = <INFILE> )
  {
   	chomp $line;
    ++$counter_org;
 
	$len_line = length $line;
    print ">";
#    print "  Zeile[$counter_org]= $line; L= $len_line\n";

    # ist Zeile > 0 ?
    if ( $len_line > 0 )
	{ # JA: weiter ..

      # pruefen, ob Zeile "nur" aus Leerzeichen besteht ..
      $temp_line = $line;
      $temp_line =~ s/^( )+//;
#	  print "    TempLine= $temp_line; L= ", , "\n";

      # Zeile besteht "aus mehr wie nur" Leerzeichen ...
      if ( length ($temp_line) > 0 )
      { 
        ++$counter_new;
        print OUTFILE "$line\n";
		# end IF (LENGTH)
	  }
      # end IF (len_line)
	}
    
    # end WHILE (line)
  }

  close (INFILE);
  close (OUTFILE);

  print LOGFILE "  Anzahl Zeilen: gelesene= $counter_org; geschrieben= $counter_new\n";

  # end FOREACH (elem)
}



######################################################################################
# Log-Datei wird wieder geschlossen & ENDE

close (LOGFILE);

exit($ret_code);

