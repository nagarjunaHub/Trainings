#*************************************************************************************
#*                                                                                   *
#*  FILENAME:    delspacelines.pl                                                    *
#*                                                                                   *
#*  PROGRAMMTYP: Perl-Script-File                                                    *
#*                                                                                   *
#*  AUTOR:       ZFLS/ZEEF                                                   *
#*                                                                                   *
#*  Aufgabe:     Loescht in bel. Textdateien alle Leerzeilen                         *
#*                                                                                   *
#*  Parameter:   ARGV[0] - enthaelt Lister der Parameter mit                         *
#*               - "-fp<Filepatter der zu suchenden Dateien>"  						 *
#*               - "-fo<Outputfile"                                                  *															
#*               - "-log<Logdatei>                                                   *
#*																					 *
#*                                                                                   *
#*  In/Output:   																	 *
#*                                                                                   *
#*  AUFRUF:      perl delspacelines.pl -fp<Filepatter> -fo<Outputfile> -log<Logdatei> *
#*                                                                                   *
#*  Kommentare:                                                                      *
#*                                                                                   *
#*************************************************************************************

######################################################################################
# Init ...

print "\n\n";
print " Loeschen von Leerzeichen in Textdateien:\n";
print " ========================================\n\n";

# Vorbelegungen
$RC_SUCCESS = 0;
$RC_ERRO    = 1;
$TRUE       = 0;
$FALSE      = 1;

# Argumente verarbeiten
@tmp_argv = split ' ', @ARGV[0];

printf "Argumente= @tmp_argv\n\n";

# Filepatter  In
@tmp1 = grep /-fp/i, @tmp_argv;
$file_patter = $tmp1[0];
substr ($file_patter, 0, 3) = "";

# Filepattern out 
@tmp1 = grep /-fo/i, @tmp_argv;
$new_file = $tmp1[0];
substr ($new_file, 0, 3) = "";

# LOG-Datei
@tmp1 = grep /-log/i, @tmp_argv;
$log_file = $tmp1[0];
substr ($log_file, 0, 4) = "";

######################################################################################
# Oeffner LOG-Datei 
open (LOGFILE, "+>$log_file") or die "FEHLER: Oeffnen Logdatei: $log_file";

print " [notwendig -fp] Filepatter= $file_patter\n";
print " [notwendig -fo] Filepatter= $new_file\n"; 
print " [notwendig -log] LOG-Datei= $log_file\n";

######################################################################################

# Schleife ueber alle Zeilen (bis EOF)
$counter_org = 0;
$counter_new = 0;
open (INFILE, "<$file_patter") or die "FEHLER: Oeffnen der Input-Datei: $file_patter";
open (OUTFILE, ">$new_file") or die "FEHLER: Oeffnen der OutputDatei: $new_file";
while ( $line = <INFILE> )
  {
   	chomp $line;
    ++$counter_org;
 
     $len_line = length $line;
    # print ">";
    # print "  Zeile[$counter_org]= $line; L= $len_line\n";

    # ist Zeile > 0 ?
    if ( $len_line > 0 )
	{ # JA: weiter ..				

      # pruefen, ob Zeile mit Leerzeichen beginnt ..
      $temp_line = $line;
      if ($temp_line =~/^(\s+)/)
	  {	 
	   	     #  print " gelesene Zeile = $temp_line\n";
	  }
	  else
	  {
	       print OUTFILE "$temp_line\n";      
	  }
      # end IF (len_line)
	}
    
    # end WHILE (line)
  }

  close (INFILE);
  close (OUTFILE);
  
  print LOGFILE "  Anzahl Zeilen: gelesene= $counter_org; geschrieben= $counter_new\n";



######################################################################################
# Log-Datei wird wieder geschlossen & ENDE

close (LOGFILE);

exit($ret_code);

