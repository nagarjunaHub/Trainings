#*************************************************************************************
#*                                                                                   *
#*  FILENAME:    find_complink_files.pl                                              *
#*                                                                                   *
#*  PROGRAMMTYP: Perl-Script-File                                                    *
#*                                                                                   *
#*  AUTOR:       ZFLS/ZEEF Rohmann 
#* 		 Erweiterung sk090905 Betriebsart B, C                               *
#* 		 Erweiterung sk210206 Betriebsart B, D                               *
#*                                                                                   *
#*  Aufgabe:     Sucht in def. Verzeichnis nach Compiler- und Linker-Files. Es wird  *
#*               immer nach allen Typen gesucht. Die gefundenen Dateien werden in    *
#*               eine Macro-Datei fuer die Buildumgebung geschrieben                 *
#*                                                                                   *
#*  Parameter:   ARGV[0] - enthaelt Lister der Parameter mit                         *
#*               - "-vm<Makeverzeichnis im Vob>" (z.B. "x:\vob\make")				 *
#*               - "-sl<Liste der zu suchenden Typen>" (z.B. "cf af lf sl ..."       *
#*               - "-ml<Liste der zu den Typen aequivalenten Makros>"                *
#*               - "-of<Ausgabedatei der Makros>"                                    *
#*               - "-log<Logdatei>                                                   *
#*																					 *
#*                                                                                   *
#*  In/Output:   
#*                                                                                   *
#*  AUFRUF:      
#*                                                                                   *
#*  Kommentare:  Ohne Dialogbox, wenn keine Options gefunden werden                  *
#*                                                                                   *
#*************************************************************************************

#####################
#sub vergl_complink_files Funktions-Beispiel


#{
# 	local ($test,$test2) = @_;
#
#
#	print "\nt1:$test $test2";
#	substr ($test, 0, 3) = "";
#	return $test;
#
#}
#
#$Erg = "";
#
#$Erg = vergl_complink_files("xxxTest",3);
#
# print "\nt2:$Erg";
#######################################################################################

sub print_OUT_u_LOGFILE
{
   	local ($printStr) = @_;
 	print $printStr;	 
 	print OUTFILE $printStr;	 
 	print LOGFILE $printStr;	 
}
#######################################################################################
sub print_LOGFILE
{
   	local ($printStr) = @_;
 	print $printStr;	 
 	print LOGFILE $printStr;	 
}
#######################################################################################

sub print_para_info
{
   	local ($printOUTFILE) = @_;

print $printOUTFILE "Betriebsart A): find complink files (Parameter -sl)\n";
print $printOUTFILE " [notwendig -vm] View-Projekt-VOB - Make-Dir = $make_dir\n";
print $printOUTFILE " [notwendig A) -sl] Typen-Liste              = $search_list\n";
print $printOUTFILE " [notwendig -ml] Makro-Liste                 = $makro_liste\n";
print $printOUTFILE " [notwendig -of] Ausgabedatei fuer Makros    = $out_file\n";
print $printOUTFILE " [notwendig -log] LOG-Datei                  = $log_file\n\n";

print $printOUTFILE "Betriebsart B): find mak/mod files (Parameter -mk)\n";
print $printOUTFILE " suche nach Suchdatei-Krit.in mak/mod files u. Vergleicht \n mit tats. vorhanden\n";
print $printOUTFILE " [notwendig -vm] View-Projekt-VOB - Make-Dir = $make_dir\n";
print $printOUTFILE " [notwendig B) -mk] Mak/Mod-Datei-Kriterium z.B \"*.mak,*.mod\"     = $makmod_list\n";
print $printOUTFILE " [notwendig -ml] Suchdatei-Parameter z.B \".c\"  = $makro_liste\n";
print $printOUTFILE " [notwendig -of] Ausgabedatei fuer Makros    = $out_file\n";
print $printOUTFILE " [notwendig -log] LOG-Datei                  = $log_file\n\n";

print $printOUTFILE "Betriebsart C): find c/h files (Parameter -ch)\n";
print $printOUTFILE " suche nach Suchdatei-Krit. tats. vorhandene files u. \n vergleicht mit mak/mod Eintraege\n";
print $printOUTFILE " [notwendig -vm] View-Projekt-VOB - Make-Dir = $make_dir\n";
print $printOUTFILE " [notwendig C) -ch] Mak/Mod-Datei-Kriterium z.B \"*.mak,*.mod\"     = $ch_list\n";
print $printOUTFILE " [notwendig -ml] Suchdatei-Parameter z.B \"c:\\\\600\\\\*.c\"  = $makro_liste\n";
print $printOUTFILE " [notwendig -of] Ausgabedatei fuer Makros    = $out_file\n";
print $printOUTFILE " [notwendig -log] LOG-Datei                  = $log_file\n\n";

print $printOUTFILE "Betriebsart D): find *ih.h files (Parameter -ih)\n";
print $printOUTFILE " suche nach Suchdatei-Krit. tats. vorhandene files u. schreibe Verzeichnisse in Datei\n";
print $printOUTFILE " [notwendig -vm] View-Projekt-VOB - Make-Dir = $make_dir\n";
print $printOUTFILE " [notwendig D) -ih] Includeheader-Kriterium z.B \"*ih.h\"     = $ch_list\n";
print $printOUTFILE " [notwendig -of] Ausgabedatei fuer Makros    = $out_file\n";
print $printOUTFILE " [notwendig -log] LOG-Datei                  = $log_file\n\n";



}

#######################################################################################

sub vergl_complink_files

#*  Aufgabe:     Sucht in def. Verzeichnis nach Compiler- und Linker-Files. Es wird  *
#*               immer nach allen Typen gesucht. Die gefundenen Dateien werden in    *
#*               eine Macro-Datei fuer die Buildumgebung geschrieben                 *


{
  local ($act_typ,$act_macro, $actnum) = @_;


  print "  Typ[$actnum]= $act_typ - Makro= $act_macro\n";
  print LOGFILE "  Typ[$actnum]= $act_typ - Makro= $act_macro\n";


# File Grep allgemein nur Typ, ohne AGA-Namen:
#-> Org:  $file_grep = "$make_dir*_$act_typ.*";
  $file_grep = "$make_dir\\$act_typ.*";
  print "  FileGrep= $file_grep\n";
  print LOGFILE "  FileGrep= $file_grep\n";
  @liste = glob $file_grep;
  $len_found = scalar(@liste);
  print "Liste= @liste\n   Laenge= ", $len_found , "\n\n";
  print LOGFILE "Liste= @liste\n   Laenge= ", $len_found , "\n\n";
  if ($len_found > 1 )
  { 
    $error_string = "FEHLER: Anzahl gefundener Optionsdateien zu gross, siehe Liste";
    print LOGFILE "\n$error_string\n";
    system ("clearprompt yes_no -type error -mask yes -prompt \"$error_string:\\n@liste\" -newline");
    $ret_code = $RC_ERROR;
	# end IF (len_found)
  }
  elsif ($len_found == 1 )
  {
    print LOGFILE " ... Eintrag in Makroliste ...";
    print OUTFILE "$act_macro=@liste[0]\n";
	# end ELSIF (len_found)
  }
  else
  { # Laenge = 0: nichts gefunden ...
    #-> $error_string = "FEHLER: Keine Optionsdatei gefunden - Typ: $act_typ";
    #-> print LOGFILE "\n$error_string\n";
    #-> system ("clearprompt yes_no -type error -mask yes -prompt \"$error_string\" -newline");
    #-> $ret_code = $RC_ERROR;
	# end else (len_found)
  }



}

###########################################################################################


sub ErgaenzePfad
# ersetzt in einer Zeile Makros durch Pfade/Umgebungsvariablen, 
# soweit vorhanden und l�scht alles nach Leerzeichen.
{
	local ($Zeile) = @_;

#$Zeile = "\$(VAR_PATH)\$(VAR_NAME)id.c";
#$Zeile = "aa\$(VAR_PATH)zz\$(VAR_NAME)id.c";

	$suchstr1 = "\$(";
	$suchstr2 = ")";
#	print "$Zeile\n";


	$Erg = "";

# Nach den Anfaengen der Makros "$(" suchen, bis keiner mehr vorhanden 
	while ($Zeile =~ /\Q$suchstr1/)  { 
#		print "\nf:$`\n2:$'\n\n";
		$VorneStr=$`;
# Nach Macroende ")" suchen 
		if ($' =~ /\Q$suchstr2/) {
#			print "$`\n";
#			print "$ENV{$`}\n";
# Wenn bekannt, Macro durch Pfad aus Umgebungsvariable ersetzen
			if (!$ENV{$`}) {
				print "Warnung: Umgebungsvar. \"\$($`)\" nicht definiert\n";
				print LOGFILE "Warnung: Umgebungsvar. \"\$($`)\" nicht definiert\n";
				$Erg = sprintf("$Erg$VorneStr\$($`)"); 
			}
			else {
				$Erg = sprintf("$Erg$VorneStr$ENV{$`}"); 
			}
			$Zeile = $';			
		}
		else {
			die "Fehler: Macro-Ende \")\" nicht gefunden";
		}
	

	} 


# Zuletzt alles nach Leerzeichen entfernen, um Vergleich zu erm�glichen";
	if ($Zeile =~ /\s+/) {
		$Erg = sprintf("$Erg$`"); 
	}
	else {
		$Erg = sprintf("$Erg$Zeile"); 
	}
	return $Erg
}

###########################################################################################
sub open_makmod_files	
# Werte Datei aus, nach Suchkriterien (Parameter -ml), ersetzes Makros durch Pfade 
#(Funktion ErgaenzePfad), und schreibe nicht vorhandene Dateien in Ergebnisdatei (-of).

{
	local ($dateiname, $Suchstring) = @_;
	
#	print "Test:$dateiname, $Suchstring\n";
	open(DATEI, $dateiname) or die "Fehler: Kann Datei \n'$name'\nnicht einlesen.";

	while(<DATEI>){

# funktioniert nicht mit wildcards
#		if (/\Q$Suchstring\E/) {
#			print "$_";
#			if (substr($_,0,1) eq '!') {
#				print "Kommentarzeile wird nicht ausgewertet";
#			}
#			else {
#				$ErgDatei=ErgaenzePfad($_);
#				print $ErgDatei;
#				if (-e "$ErgDatei"){ 
#  					 print "Datei ist vorhanden"; 
#					print OUTFILE "$ErgDatei vorhanden!\n";
#				} 
#				else {
#					print OUTFILE "$ErgDatei fehlt!\n";
#				}
#			}
#			print "\n";
#		}

		$ErgDatei=ErgaenzePfad($_);

		if (($Suchstring=~/\*/) | ($ErgDatei eq $Suchstring)) {
		    $Suchstr2= $';
#		    print "$Suchstring:suchstr2=$Suchstr2-\n";

		if ((($ErgDatei=~/^$`/) | (substr($SuchString,0,1) eq "*")) & ($ErgDatei=~/$Suchstr2$/)) {
		print "$_";
		push(@makmod_erg_liste, $ErgDatei);
			if (substr($ErgDatei,0,1) eq '!') {
				print "Kommentarzeile wird nicht ausgewertet";
			}
			else {

				if (-e "$ErgDatei"){ 
					print "$ErgDatei vorhanden\n";
					print LOGFILE "$ErgDatei vorhanden!\n";
#	Wenn -ch Parameter nicht gesetzt, Ergebnis in Datei schreiben
#  			  		if ($ch_list eq "" ) {
#						print_LOGFILE "$ErgDatei vorhanden\n";
#					}
				} 
				else {
					print "$ErgDatei fehlt!\n";
					print LOGFILE "$ErgDatei fehlt!\n";
#	Wenn -ch Parameter nicht gesetzt, Ergebnis in Datei schreiben
	  			  	if ($ch_list eq "" ) {
						print_OUT_u_LOGFILE("$ErgDatei\n");
					}
				}
			}
			print "\n";
		}

		}

	}close DATEI;

}

###########################################################################################


sub vergl_makmod_files
#*  Aufgabe:     suche nach Suchdatei-Krit.in mak/mod files u. Vergleicht mit tats.  *
#*		 vorhanden							     *


{
  local ($act_typ, $act_macro, $actnum) = @_;
  @liste = ();



  print "  Typ[$actnum]= $act_typ\n";
  print LOGFILE "  Typ[$actnum]= $act_typ\n";
  $act_macro=~ s/\\/\\\\/g;
#  $act_macro=~ s/\./\\\./g;



# File Grep allgemein nur Typ, ohne AGA-Namen:
#-> Org:  $file_grep = "$make_dir*_$act_typ.*";
# Hinweis: wird hier nicht mehr verwendet, da Sub-Dir's nicht 
# erfasst werden ...
#  $file_grep = "$make_dir\\$act_typ";
#  print "  FileGrep= $file_grep\n";
#  print LOGFILE "  FileGrep= $file_grep\n";

# Suche alle Dateien mit Parameter -mk (*.mak/*.mod) und schreibe diese in Liste
  use File::Find;
  find(\&searched, $make_dir);
  sub searched {
#     if (/\mod$/) 
     if (/\Q$act_typ\E/) 
       	{ 
#		print "$_\n";
#		print "$File::Find::dir\n";
#		print "$File::Find::name\n";
#		print "$File::Find::dir\\$_\n"; 
#		push @liste, $File::Find::name;
		push @liste, sprintf("$File::Find::dir\\$_\n");

  	}
  }

#	find sub { print $File::Find::name, -d && '/', "\n" }, @make_dir;
#	find sub { push @DirArray, $File::Find::name }, @Dir;

#  find { 
#	if ((-e $_) && ( $_ =~/html$/)) {print "$_\n"}
#	if ((-e $_) && ( $_ =/\.mod$/)) {print "$_\n"}
#  }  @make_dir;


#  @liste = glob $file_grep;
  $len_found = scalar(@liste);
  print "Liste=\n @liste\n   Laenge= ", $len_found ," Such-Krit.= ", $act_macro , "\n\n";
  print LOGFILE "Liste= @liste\n   Laenge= ", $len_found , "\n\n";




# Durchsuche die Datei-Liste, und werte die Dateien nach Suchkriterien 
# (Parameter -ml) aus, �ber Funktion open_makmod_files. 

  if ($len_found >= 1 )
  {
	
	for ( $filenum = 0; $filenum < $len_found; $filenum++)
	{
#		print LOGFILE " ... Eintrag in Ergebnisliste ...\n";
#		print "Liste= @liste[$filenum]\n";
		print LOGFILE "Liste= @liste[$filenum]\n";
#		print OUTFILE "@liste[$filenum]\n";
		&open_makmod_files(@liste[$filenum],$act_macro);		
  	# end FOR (filenum)
	}


  }
  else
  { # Laenge = 0: nichts gefunden ...
    #-> $error_string = "FEHLER: Keine Optionsdatei gefunden - Typ: $act_typ";
    #-> print LOGFILE "\n$error_string\n";
    #-> system ("clearprompt yes_no -type error -mask yes -prompt \"$error_string\" -newline");
    #-> $ret_code = $RC_ERROR;
	# end else (len_found)
  }



}






######################################################################################
# Hier m�ssen Laufwerksbuchstabe des Views (der auf ein Label konfiguriert ist) und
# Pfad (VOB Name) initialisiert werden. Dies wird dann zum Ausf�hrungverzeichnis:

print "\n\n";
print " Suche Compiler/Linker-Dateien:\n";
print " ==============================\n\n";

# Vorbelegungen
$RC_SUCCESS = 0;
$RC_ERRO    = 1;
$TRUE       = 0;
$FALSE      = 1;

# Argumente verarbeiten
@tmp_argv = split ' ', @ARGV[0];

printf "Argumente= @tmp_argv\n\n";

# Makeverzeichnis im VOB (F�hrende Parameter l�schen): 

@tmp1 = grep /-vm/i, @tmp_argv;
$make_dir = $tmp1[0];
substr($make_dir, 0, 3) = "";

print "\n\n  -> MAke-Dir VOR Aenderung= $make_dir\n";

$make_dir_tmp = $make_dir;

# $make_dir_tmp = ~ s/p:/aa/ ;
#print "\n\n  -> MAke-Dir NACH Aenderung= $make_dir_tmp\n";

# �berpr�fen auf Letztes Zeichen = "\" und ggf. l�schen
$LastChar = substr ($make_dir, -1, 1);
print "Last Char= $LastChar\n\n";
if ( $LastChar eq "\\" )
{
  $string_len = length $make_dir;
  substr ($make_dir, -1, 1) = "";
}
print "\n\n  -> MAke-Dir NACH Aenderung= $make_dir\n";

# Liste der zu suchenden Typen
@tmp1 = grep /-sl/i, @tmp_argv;
$search_list = $tmp1[0];
substr ($search_list, 0, 3) = "";
@search_list = split /,/, $search_list;

# Liste der zu suchenden Typen
@tmp1 = grep /-mk/i, @tmp_argv;
$makmod_list = $tmp1[0];
substr ($makmod_list, 0, 3) = "";
@makmod_list = split /,/, $makmod_list;

# Liste der zu suchenden Typen
@tmp1 = grep /-ch/i, @tmp_argv;
$ch_list = $tmp1[0];
substr ($ch_list, 0, 3) = "";
@ch_list = split /,/, $ch_list;

# Liste der zu suchenden Typen
@tmp1 = grep /-ih/i, @tmp_argv;
$ih_list = $tmp1[0];
substr ($ih_list, 0, 3) = "";
@ih_list = split /,/, $ih_list;


# Makroliste zu den zu suchenden Typen
@tmp1 = grep /-ml/i, @tmp_argv;
$makro_liste = $tmp1[0];
substr ($makro_liste, 0, 3) = "";
@makro_liste = split /,/, $makro_liste;

# Ausgabedatei fuer Makros
@tmp1 = grep /-of/i, @tmp_argv;
$out_file = $tmp1[0];
substr ($out_file, 0, 3) = "";

# LOG-Datei
@tmp1 = grep /-log/i, @tmp_argv;
$log_file = $tmp1[0];
substr ($log_file, 0, 4) = "";

print_para_info(STDOUT);



# Laenge der Listen
$len_sl = scalar(@search_list); # wird ggf. ueberschrieben 
$len_ml = scalar(@makro_liste);
print "Makmod= (@makmod_list)\n";

# 	Test der Variablen:
if ($search_list eq "") {
	if ($makmod_list eq "") {
		if (($make_dir eq "") || ($ch_list eq "")
 || ($makro_liste eq "") || ($out_file eq "")) {
			if (($make_dir eq "") || ($ih_list eq "")
			  || ($out_file eq "")) {
			  print "FEHLER C): Parameter fehlen (siehe oben) ! \n\n";
			  close (LOGFILE);
			  exit($RC_ERROR);
			}
			else {
		        	$len_sl = scalar(@ih_list);
				@makmod_list = @ih_list;
			}

 		}
		else {
	        	$len_sl = scalar(@ch_list);
			@makmod_list = @ch_list;
		}
	}
	else {

		if (($make_dir eq "") || ($makro_liste eq "") || ($out_file eq "")) {
		  print "FEHLER B): Parameter fehlen (siehe oben) ! \n\n";
		  close (LOGFILE);
		  exit($RC_ERROR);
 		}
	        $len_sl = scalar(@makmod_list);
	}

} 
else {

	if (($make_dir eq "") || ($search_list eq "") || ($makro_liste eq "") || ($out_file eq "") ||
    ($log_file eq "" ) || ($len_sl != $len_ml))
	{
	  print "FEHLER A): Parameter fehlen (siehe oben) ! \n\n";
	  close (LOGFILE);
	  exit($RC_ERROR);
	}
	else {


	}
}

######################################################################################
# Oeffner LOG-Datei und erste Daten eintragen

open (LOGFILE, ">$log_file") or die "FEHLER: Oeffnen Logdatei";

print LOGFILE "$0\n\n";
print_para_info(LOGFILE);




# Ausgangs- (=Makro-) Datei oeffnen
open (OUTFILE, ">$out_file") or die "FEHLER: Oeffnen Makro-Datei";




#print OUTFILE "\n";
# sk210206 deaktiviert wg. IncludeHeader Pfad


if ($search_list eq "") {
	if (!$ch_list eq "" ) {
# Abgleich Sourcen mit Modfile (Variante c))
		print_OUT_u_LOGFILE("# *** Abgleich Sourcen mit Modfile ***\n");
		print_OUT_u_LOGFILE("# Suche alle Dateien \"@makro_liste\" Dateien:\n");
		print_OUT_u_LOGFILE("# vergleiche mit Liste-Dateien \"@ch_list\"\n");
		print_OUT_u_LOGFILE("# und schreibe darin nicht vorhandene in Liste:\n");
		
	} 
	else {
# Abgleich Modfile mit Sourcen (Variante B))
		print_OUT_u_LOGFILE("# *** Abgleich Modfile mit Sourcen ***\n");
		print_OUT_u_LOGFILE("# Untersuche \"@makmod_list\"-Dateien nach\n"); 
		print_OUT_u_LOGFILE("# enthaltenen Dateien @makro_liste\n");
		print_OUT_u_LOGFILE("# und schreibe auf Datentr�ger nicht vorhandene in Liste:\n");
	}
}

print "make_dir: $make_dir\n";
use File::Find;
$ret_code = $RC_SUCCESS;

######################################################################################
# Schleife ueber alle Typen: Befehl ausf�hren ...

print "Schleife ueber alle Typen....\n";
for ( $actnum = 0; $actnum < $len_sl; $actnum++)
{

######################################################################################

# 	Betriebsart A) (-sl definiert)
	if (!$search_list eq "") {

	  	&vergl_complink_files (@search_list[$actnum], @makro_liste[$actnum], $actnum) ;
	} 
######################################################################################
# 	Betriebsart B) oder C) Schritt 1 (-sl nicht definiert, daf�r -mk oder -ch)
	else {

		if (!$ch_list eq "" ) {
			# Abgleich Sourcen mit Modfile (Variante C)) Schritt 1
			print_OUT_u_LOGFILE("# -  Untersuche \"@makmod_list[$actnum]\"-Dateien ...\n");
		}

	 	if ((!$makmod_list eq "") | (!$ch_list eq "" )) {
# Schleife ueber alle Suchkriterien
			for ( $mlnum = 0; $mlnum < $len_ml; $mlnum++) {
			  &vergl_makmod_files (@makmod_list[$actnum], @makro_liste[$mlnum], $actnum);
			}
		}		
	}
	
  # end FOR (actnum)
}



######################################################################################
# 	Betriebsart C) Schritt 2 (-ch definiert)


if (!$ch_list eq "" ) {

    $len_found = scalar(@makmod_erg_liste);
    print_LOGFILE("Anzahl Eintraege in Zwischenergebnisliste: $len_found\n");

    for ( $mlnum = 0; $mlnum < $len_ml; $mlnum++) {

	print_OUT_u_LOGFILE("# -  Untersuche \"@makro_liste[$mlnum]\"-Dateien, ob vorhanden\n");
        print_OUT_u_LOGFILE("#    und pruefe, ob in \"@makmod_list\" enthalten ...\n");

 	$makro_tmp = @makro_liste[$mlnum];
# '.' wird durch '\.' ersetzt, da dieser sonst bei Suche nicht erkannt wird.
	$makro_tmp =~ s/\./\\\./g;
# Untersuche nach Wildcard '*', Behandlung von Vorderer TeilStr und hinterer TeilStr getrennt
	if ($makro_tmp=~/\*/) {
	    $Suchstr2= $';
	    $temp_dir=$`;
#	    print "temp_dir: $temp_dir\n";

	    find(\&searched2, $temp_dir);
	    sub searched2 {

		$ErgStr= sprintf("$File::Find::dir\\$_");

		if ($ErgStr =~/$Suchstr2$/ ) {
# konvertieren von \\ oder / nach \
#  			print "$ErgStr vor Umwandlung\n";

			$ErgStr=~ s/\//\\/g;
			$ErgStr=~ s/\\\\/\\/g;

			$InListe = 0;
# in Verzeichnis gefundene Datei �berpr�fen, ob in mak/Mod-Liste enthalten
			for ( $actnum = 0; ($actnum < $len_found) & (!$InListe); $actnum++) {
				$makmod_tmp = @makmod_erg_liste[$actnum];


#				print_LOGFILE("mm_erg$actnum: $makmod_tmp\n");

				if (lc($makmod_tmp) eq lc($ErgStr)) {
#					print "$ErgStr in Suchliste (Mak/Mod) gefunden\n";
#					print "$File::Find::dir\\$_ in Suchliste (Mak/Mod) gefunden\n";
					$InListe=1;	
				}
			}
			if ($InListe) {
				print_LOGFILE("$ErgStr in Suchliste (Mak/Mod) gefunden\n");
			} 
			else {
#				print_LOGFILE("$ErgStr in Suchliste (Mak/Mod) nicht gefunden!\n");
				print_OUT_u_LOGFILE("$ErgStr\n");
			}
			
		}

	  }
	}

   }
}

######################################################################################
# 	Betriebsart D) (-ih definiert)

if (!$ih_list eq "" ) {


    $len_ih = scalar(@ih_list);

    print_LOGFILE("Anzahl Eintraege in Suchliste: $len_ih\n");

    for ( $mlnum = 0; $mlnum < $len_ih; $mlnum++) {

	print_OUT_u_LOGFILE("# -  Untersuche \"@ih_list[$mlnum]\"-Dateien, ob vorhanden\n");
        print_OUT_u_LOGFILE("#    und schreibe ggf. Verzeichnis in Datei ...\n");


 	$makro_tmp = sprintf("$make_dir@ih_list[$mlnum]");
# '.' wird durch '\.' ersetzt, da dieser sonst bei Suche nicht erkannt wird.
	$makro_tmp =~ s/\./\\\./g;
	    print "makro_tmp: $makro_tmp\n";
	
# Untersuche nach Wildcard '*', Behandlung von Vorderer TeilStr und hinterer TeilStr getrennt
	if ($makro_tmp=~/\*/) {
	    $Suchstr2= $';
	    $temp_dir=$`;
	    print "temp_dir: $temp_dir\n";

	    find(\&searched2, $temp_dir);
	    sub searched2 {

		$ErgStr= sprintf("$File::Find::dir\\$_");
		$ErgStr2= sprintf("$File::Find::dir");



		if ($ErgStr =~/$Suchstr2$/ ) {
# konvertieren von \\ oder / nach \
  			print "$ErgStr vor Umwandlung\n";

#			$ErgStr=~ s/\//\\/g;
#			$ErgStr=~ s/\\\\/\\/g;

			$InListe = 0;
				print_LOGFILE("$ErgStr2 \n");
				print_OUT_u_LOGFILE("$ErgStr2\n");
			
			
		}

	  }
	}

   }
}


close (OUTFILE);

######################################################################################
# Log-Datei wird wieder geschlossen & ENDE

close (LOGFILE);

exit($ret_code);

