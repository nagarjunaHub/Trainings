# erwartet als �bergabeparameter den Pfad einer Datei und gibt
# - den Username aus ENV-Variable, 
# - aktuelles Datum und Uhrzeit
# - letztes Label der �bergebenen Datei


# Argumente verarbeiten
@tmp_argv = split ' ', @ARGV[0];

# Dateiname und Pfad
@tmp1 = grep /-if/i, @tmp_argv;
$in_file = $tmp1[0];
substr ($in_file, 0, 3) = "";



print "#*************************************************************\n";
print "# Generiert von project_info.pl\n";
print "#    Suche Label $in_file\n";
print "#*************************************************************\n";

#open (PS, "net user $ENV{USERNAME} /domain  |"); 
#$cnt = 0;
#while ($line = <PS>) {
#    $cnt = $cnt +1; 
#($user, $pid, $cpu ) = split(/\s+/, $line); 
##print "$line" if $cmd =~ /httpd/; 
#  if ( $cnt eq 5) {
#     #"Full Name" or "Vollst�ndiger Name"
#    $Pos = index $line, "ame"; 
#    $Name = substr $line, $Pos + 3;
#    $Name=~ s/^\s+//; 
##    print "$Name";
#    print "ENV_USER = $ENV{USERNAME}\n"; 
#
#  }


#} 
#close PS;

print "ENV_USER = $ENV{USERNAME}\n"; 


open (PS, "cleartool describe $in_file  |"); 
$cnt = 0;
$labelseek = 0;
while ($line = <PS>) {
   $cnt = $cnt +1; 
   $Label= $line;
   $Label=~ s/^\s+//; 
      if ($Label =~ /\n/)
     {
  	chop($Label);
     }

  if ($labelseek eq 1) {
    print "SW_RELEASE_LABEL_CC = $Label" ; 
    $labelseek = 2;
  }

  if ( $Label eq "Labels:") {
    $labelseek = 1; 
  }

}
if ($labelseek eq 2) {
}
else {
    print "SW_RELEASE_LABEL_CC = CC_LABEL_UNKOWN" ; 
}
 
close PS;


       @months = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
       @weekDays = qw(Sun Mon Tue Wed Thu Fri Sat Sun);
        ($second, $minute, $hour, $dayOfMonth, $month, $yearOffset, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
        $year = 1900 + $yearOffset;
#        $theTime = "$hour:$minute:$second, $weekDays[$dayOfWeek] $months[$month] $dayOfMonth, $year";
       
        print "$theTime\n"; 
#    printf ("%4d/%02d/%02d %02d:%02d:%02d", $year, $month + 1, $dayOfMonth, $hour, $minute, $second);	
    printf ("SW_MAKE_DATE = %4d/%02d/%02d\n", $year, $month + 1, $dayOfMonth);	
    printf ("SW_MAKE_TIME = %02d:%02d:%02d\n", $hour, $minute, $second);	




