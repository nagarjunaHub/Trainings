#*************************************************************************************
#*                                                                                   *
#*  FILENAME:    a2l_change_seg_nr.pl                                                *
#*                                                                                   *
#*  PROGRAMMTYP: Perl-Script-File                                                    *
#*                                                                                   *
#*  AUTOR:       AE/ENS                                                              *
#*                                                                                   *
#*  Aufgabe:     �ndert/Ergaenzt in a2l-File                                         *
#"               1.  Das zuvor vom make Prozess generierte agi_xetk_mem_ram_info.aml *
#"               im Damos-Pfad wurde zun�chst mit den Trigger-Variablen              *
#"               aus  Xetk_TraceValues.mak ersetzt                                   *
#*               2. die XETK-Info's nach MemorySegement DST und RAM mit Patches      *
#*               aus DST/Ram-Info-File, ersetzt danach die Adressen (z.T auch        *
#*                 umgerechnete Adresssize  f�r  CS_Xetk_TraceWindow                 *
#*               ( bzw. zugehoerige Variablen) mit denen aus REF-File                *
#*               3.  ausserdem wird der 0x00 XCP-Wert in Zeile mit dem Kommentar:    *
#"               "/* segment logical number */" von 0x00 nach fortlaufend ersetzt    *
#*                                                                                   *
#*  Parameter:   ARGV[0] - enthaelt Lister der Parameter mit                         *
#*               - "-fp<Filepatter/Inputfile>"  				     *
#*               - "-fo<Outputfile"                                                  *
#*               - "-fd<DstInfofile"                                                 *
#*               - "-ad<DstAddress"                                                  *
#*               - "-as<DstSize"                                                  *
#*               - "-fr<RamInfofile"                                                 *
#*               - "-ar<RamAdress"                                                   *
#*               - "-rf<Ref-file (from map)"                                         *
#*               - "-log<Logdatei>                                                   *
#*										     *
#*                                                                                   *
#*  In/Output:   *
#*                                                                                   *
#*  AUFRUF:      perl a2l_change_seg_nr.pl -fp<Inputfile> -fo<Outputfile> -fd<DstInfofile> -ad<DstAdress> -fr<RamInfofile> -ar<RamAdress>  -rf<Ref-File> -log<Logdatei> *
#*										     *
#*   Beispiel     V:\swtools\perl\v5_8_8_817\bin\perl.exe V:\swtools\skripte\perl\a2l_add_memory_xetk_info.pl "-fpC:\400\\bas\\A0200\\A40002rb.a2l_tmp *
#*                     -foC:\400\\bas\\A0200\\A40002rb.a2l -fdV:\swtools\\Make\Global_makefiles\agi_xetk_mem_dst_info.aml -ad38000 -as2000 *
#*                     -frC:\400\\400\\A0201\Damos\agi_xetk_mem_ram_info.aml -ar40002000 -rfC:\400\\400\\A0201\\A4000201.map -logC:\400\\400\\A0201\\pl.log" *
#*                                                                                   *
#*  Kommentare:  Patch skript fuer XCP bzw. XETK erforderlich, siehe oben Aufgabe:    *
#*                                                                                   *
#*************************************************************************************

######################################################################################


# Funktion adress_substituted_line
# Auswertung und Adressersetzung f�r  "0x0 ... CS_Xetk_TraceWindow ..."
# Abfrage aktuell gedoppelt, da String etwas verschieden  "PHYSICAL_ADDRESS 0x0 ... CS_Xetk_TraceWindow"


sub adress_substituted_line  {
	my $loc_line = $_[0];
	my $loc_CS_Xetk_list_name = $_[1];
	my $loc_CS_Xetk_list_adress = $_[2];
	my $loc_CS_Xetk_list_size = $_[3];
    # bestimmmen des Variablen-Suchstring nach " will substituted by Perl-Script with ", abgeschlossen von einem Leerzeichen
	my ($loc_line_Teil1,$searchstr) = split m/ will substituted by Perl-Script with /, $loc_line, 2; # getrennt durch
	my ($search_str,$loc_line_Teil3,) = split m/ /, $searchstr, 2; # getrennt durch ' '
	# $searchstr=~ s/ *//;
	$counter_Xetk_addr = 0;
	# print "as2: @$loc_CS_Xetk_list_name\n";
	# ermitteln der Adresse zur gefundenen Variable �ber �bergebenen Sting-Arrays (name, adress)
	foreach my $key (@$loc_CS_Xetk_list_name) {
		# print "Durchsuche Element $key nach $search_str\n";
		# if($key =~ m/$search_str/) {
		if($key eq $search_str) {
			$search_adr=@$loc_CS_Xetk_list_adress[$counter_Xetk_addr];
			$search_size=@$loc_CS_Xetk_list_size[$counter_Xetk_addr];
			print "$search_str gefunden: $counter_Xetk_addr ,$search_adr, $search_size\n";
			# ermitteln des Prefix (da z.T unterschiedlich)
			($prefix,$Rest) = split m/0x0/, $loc_line, 2;
			if(($loc_line =~ m/\* !!!! Variable size/) || ($loc_line =~ m/\* ---- Variable size/)){
				$loc_line = $prefix."0x$search_size    \/\* !!!! Variable size substituted by Perl-Script with @$loc_CS_Xetk_list_name[$counter_Xetk_addr] ... !!!! \*\/\n"
			}
			else {
			   $loc_line = $prefix."0x$search_adr    \/\* !!!! Variable adress substituted by Perl-Script with @$loc_CS_Xetk_list_name[$counter_Xetk_addr] ... !!!! \*\/\n"
			}
		}
		++$counter_Xetk_addr;
	}
	# print "as3a:$loc_line\n";
	return $loc_line;
}


######################################################################################

# Init ...


print "\n\n";
print " Patchen von Damos-A2L-Files wegen XETK\n";
print " und Patchen von Damos-A2L-Files wegen XCP, segement logical number:\n";

print " ========================================\n\n";

# Vorbelegungen
$RC_SUCCESS = 0;
$RC_ERRO    = 1;
$TRUE       = 0;
$FALSE      = 1;

$TRACE_TRIG_CNT      = 0;

# Argumente verarbeiten
@tmp_argv = split ' ', @ARGV[0];

printf "Argumente= @tmp_argv\n\n";

# Filepatter  In
@tmp1 = grep /-fp/i, @tmp_argv;
$file_patter = $tmp1[0];
substr ($file_patter, 0, 3) = "";

# Filepattern out
@tmp1 = grep /-fo/i, @tmp_argv;
$new_file = $tmp1[0];
substr ($new_file, 0, 3) = "";

# Filepattern XETK MemorySegement DST
@tmp1 = grep /-fd/i, @tmp_argv;
$mem_dst_infofile = $tmp1[0];
substr ($mem_dst_infofile, 0, 3) = "";

# Adress XETK MemorySegement DST
@tmp1 = grep /-ad/i, @tmp_argv;
$mem_dst_adress = $tmp1[0];

substr ($mem_dst_adress, 0, 3) = "";

# Adress XETK MemorySegement DST-Size
@tmp1 = grep /-as/i, @tmp_argv;
$mem_dst_size = $tmp1[0];
substr ($mem_dst_size, 0, 3) = "";

# Filepattern XETK MemorySegement RAM
@tmp1 = grep /-fr/i, @tmp_argv;
$mem_ram_infofile = $tmp1[0];
substr ($mem_ram_infofile, 0, 3) = "";

# Adress XETK MemorySegement RAM
@tmp1 = grep /-ar/i, @tmp_argv;
$mem_ram_adress = $tmp1[0];
substr ($mem_ram_adress, 0, 3) = "";

# REF-File for CS_Xetk_...-Adresses
@tmp1 = grep /-rf/i, @tmp_argv;
$Ref_File = $tmp1[0];
substr ($Ref_File, 0, 3) = "";


# LOG-Datei
@tmp1 = grep /-log/i, @tmp_argv;
$log_file = $tmp1[0];
substr ($log_file, 0, 4) = "";

######################################################################################
# Oeffne LOG-Datei
open (LOGFILE, "+>$log_file") or die "FEHLER: Oeffnen Logdatei: $log_file";

print " [notwendig -fp] AML-IN-File= $file_patter\n";
print " [notwendig -fo] AML-OUT-File= $new_file\n";
print " [notwendig -fd] AML-DST-Patch-File= $mem_dst_infofile\n";
print " [notwendig -ad] Adress-DST = $mem_dst_adress\n";
print " [notwendig -as] Size-DST = $mem_dst_size\n";
print " [notwendig -fd] AML-RAM-Patch-File= $mem_ram_infofile\n";
print " [notwendig -ar] Adress-RAM= $mem_ram_adress\n";
print " [notwendig -rf] Ref-File fuer CS_Xetk_... -Adressen= $Ref_File\n";
print " [notwendig -log] LOG-Datei= $log_file\n";

######################################################################################

# Schleife ueber alle Zeilen (bis EOF)
$counter_org = 0;
$counter_new = 0;
open (INFILE, "<$file_patter") or die "FEHLER: Oeffnen der Input-Datei: $file_patter";
open (OUTFILE, ">$new_file") or die "FEHLER: Oeffnen der OutputDatei: $new_file";

# Lese Adressen aus MAP-(alt REF-)File ein
print "Read Adresses Mapfile $Ref_File\n";

open (REFFILE, "<$Ref_File") or die "FEHLER: Oeffnen der Ref-Datei: $Ref_File";
while ( $line = <REFFILE> )
{
	if (($line =~/^ .CS_IDAMRA/) || ($line =~/^ .CS_NDAMRA/)) {
		my ($temp_line_1,$temp_mem_seg,$temp_line_adress_and_size,$temp_line_name) = split m/\s+/, $line, 4; # getrennt durch Steuerzeichn z.B Tab
        # !!! letzen beiden zeichen liessen sich leider nicht mit chomp entfernen, aber -2 geht zumindest bei GHS-Reffile. !!!
        $temp_line_name = substr($temp_line_name,0,length($temp_line_name)-1);
        push (@CS_Xetk_list_name,$temp_line_name);
		# print ":$temp_line_name:\n";
        my ($temp_line_adress,$temp_line_size) = split m/\+/, $temp_line_adress_and_size, 2; # getrennt durch +
        push (@CS_Xetk_list_adress,$temp_line_adress);
		# print ":$temp_line_adress:\n";
        $temp_line_size = substr($temp_line_size,length($temp_line_size)-2);
		# print ":$temp_line_size:\n";
        push (@CS_Xetk_list_size,$temp_line_size);
        print " .CS_?DAMRA* name:$temp_line_name, adr:$temp_line_adress, size:$temp_line_size:\n";
	}

	if ($line =~/^  .XETK_/) {
	# print "::$line:\n";
		my ($temp_line_1,$temp_line_name,$temp_line_adress,$temp_line_size,) = split m/\s+/, $line, 5; # getrennt durch Steuerzeichn z.B Tab
        # !!! letzen beiden zeichen liessen sich leider nicht mit chomp entfernen, aber -2 geht zumindest bei GHS-Reffile. !!!
		# $temp_line_name = substr($temp_line_name,1,length($temp_line_name)-3);
        push (@CS_Xetk_list_name,$temp_line_name);
		# print ":name:$temp_line_name:\n";
		# my ($temp_line_adress) = substr($temp_line_adress,length($temp_line_adress)-2);
        push (@CS_Xetk_list_adress,$temp_line_adress);
		# print ":adr:$temp_line_adress:\n";

		# special Size calculation (Size in Bytes from Mapfile / 4 Bytes per Value - 8 additional Bytes):
        if ((($line =~/^  .XETK_Trigger1AddressTable_SDA/) || ($line =~/^  .XETK_Trigger2AddressTable_SDA/)) && ($temp_line_size >= 12) ) {
			# print ":size:$temp_line_size:size:$temp_line_size_new:\n";
			$temp_line_size = sprintf "%.8x",int(hex($temp_line_size)-8)/4;
        }
        push (@CS_Xetk_list_size,$temp_line_size);
        print " .XETK_* name:$temp_line_name, adr:$temp_line_adress, size:$temp_line_size:\n";
	}
}

close (REFFILE);


#while ( $line = <REFFILE> )
#  {
#      if ($line =~/CS_Xetk_TraceWindow/) {
#        my ($temp_line_name,$temp_line_adress) = split m/\s+/, $line, 2; # getrennt durch Steuerzeichn z.B Tab
#        push (@CS_Xetk_list_name,$temp_line_name);
        # !!! letzen beiden zeichen liessen sich leider nicht mit chomp entfernen, aber -2 geht zumindest bei GHS-Reffile. !!!
#        $temp_line_adress = substr($temp_line_adress,1,length($temp_line_adress)-2);
#        push (@CS_Xetk_list_adress,$temp_line_adress);
#	}
#  }

close (REFFILE);


open (DST_INFOFILE, "<$mem_dst_infofile") or die "FEHLER: Oeffnen Memory_DST_INFOFILE: $mem_dst_infofile";
open (RAM_INFOFILE, "<$mem_ram_infofile") or die "FEHLER: Oeffnen Memory_RAM_INFOFILE: $mem_ram_infofile";

while ( $line = <INFILE> )
{
   	chomp $line;
    ++$counter_org;
	$len_line = length $line;
    # print ">";
    # print "  Zeile[$counter_org]= $line; L= $len_line\n";

    # ist Zeile > 0 ?
	if ( $len_line > 0 ) {
		# JA: weiter ..
		# pruefen, ob Zeile mit Leerzeichen beginnt ..
		$temp_line = $line;

		# Pruefen ob Schl�sselwort fuer segment logical number Patch
		if ($temp_line =~/\/\* segment logical number \*\//) {
			# Wert durch fortlaufende Nummer ersetzen
			$prep_val=sprintf("%02d", $counter_new);
			$temp_line =~ s/0x00/0x$prep_val/;
			#  print " gelesene Zeile = $temp_line\n";
			print OUTFILE "$temp_line\n";
			++$counter_new;
		}
		else {
			if ($temp_line =~/        TRACE_TRIGGER \d 0x0 /) {
				print OUTFILE &adress_substituted_line($temp_line,
						   \@CS_Xetk_list_name,
						   \@CS_Xetk_list_adress,
						   \@CS_Xetk_list_size);
			}
			else {
				# Pruefen ob Schluesselwort fuer "wpMemBaseAddress ..."
				if (($temp_line =~/CONFIG \"WpMemBaseAddress\" \"0x0\"  \/\*!!!! Variable will substituted by Perl-Script with DamXETKRamAddress !!!!\*\//) || ($temp_line =~/CONFIG \"WpMemBaseAddress\" \"0x0\"  \/\*---- Variable will substituted by Perl-Script with DamXETKRamAddress ----\*\//)) {
					print OUTFILE "          CONFIG \"WpMemBaseAddress\" \"0x$mem_ram_adress\" /*! substituted by Perl-Script with value from DamXETKRamAddress !*/\n";
				} 
				else {
					# Pruefen ob Schluesselwort fuer "wpMemSize ..."
					if (($temp_line =~/CONFIG \"WpMemSize\" \"0x0\"  \/\*!!!! Variable will substituted by Perl-Script with DamCalibHandleLaenge !!!!\*\//) || ($temp_line =~/CONFIG \"WpMemSize\" \"0x0\"  \/\*---- Variable will substituted by Perl-Script with DamCalibHandleLaenge ----\*\//)){
						print OUTFILE "          CONFIG \"WpMemSize\" \"0x$mem_dst_size\" /*! substituted by Perl-Script with value from DamCalibHandleLaenge !*/\n";
					} 
					else {
						if (($temp_line =~/0x0                     \/\* !!!! Variable/) || ($temp_line =~/0x0                     \/\* ---- Variable/)) {
							print OUTFILE &adress_substituted_line($temp_line,
											 \@CS_Xetk_list_name,
											 \@CS_Xetk_list_adress,
											 \@CS_Xetk_list_size);

						}
						else {
						   print OUTFILE "$temp_line\n";
						}
					}
				}
			}
		}

		# Pruefen ob Schluesselwort fuer Memorysegment DSTxxx (xxx = reale Adresse aus o:\...project_variables.mak)
		if ($temp_line =~/\/begin MEMORY_SEGMENT Dst$mem_dst_adress/)
		{
			# XETK Erweiterung aus Infofile einf�gen
			while ( $dst_line = <DST_INFOFILE> ) {
				# Ersetzung der Adresse f�r DSTxxx
				if (($dst_line =~/PHYSICAL_ADDRESS 0x0 \/\*!!!! Variable will substituted by Perl-Script with MEMORY_SEGMENT !!!!\*\//) || ($dst_line =~/PHYSICAL_ADDRESS 0x0 \/\*---- Variable will substituted by Perl-Script with MEMORY_SEGMENT ----\*\//)) {
					print OUTFILE "          PHYSICAL_ADDRESS 0x$mem_dst_adress /*! substituted by Perl-Script with value from MEMORY_SEGMENT !*/\n";
				}
				else {
					print OUTFILE "$dst_line";
				}
			# end WHILE (line)
			}
		}

		# Pruefen ob Schluesselwort fuer Memorysegment RAMxxx (xxx = reale Adresse aus o:\...project_variables.mak)
		if ($temp_line =~/\/begin MEMORY_SEGMENT Ram$mem_ram_adress/)
		{
			# XETK Erweiterung aus Infofile einf�gen
			while ( $ram_line = <RAM_INFOFILE> ) {
				# Ersetzung der Adresse f�r RAMxxx
				if (($ram_line =~/PHYSICAL_ADDRESS 0x0  \/\*!!!! Variable will substituted by Perl-Script with MEMORY_SEGMENT !!!!\*\//) || ($ram_line =~/PHYSICAL_ADDRESS 0x0  \/\*---- Variable will substituted by Perl-Script with MEMORY_SEGMENT ----\*\//)){
					print OUTFILE "          PHYSICAL_ADDRESS 0x$mem_ram_adress /*! substituted by Perl-Script with value from MEMORY_SEGMENT !*/\n";
				}
				else {
					# Auswertung und Adressersetzung f�r  "0x0 ... CS_Xetk_TraceWindow ..."
					# Abfrage aktuell gedoppelt, da String etwas verschieden  "PHYSICAL_ADDRESS 0x0 ... CS_Xetk_TraceWindow"
					# Neu: Variable und Variablengroesse if ($ram_line =~/0x0                     \/\* !!!! Variable will substituted by Perl-Script with CS_Xetk_TraceWindow/)
					if (($ram_line =~/0x0                     \/\* !!!! Variable/) || ($ram_line =~/PHYSICAL_ADDRESS 0x0    \/\* !!!! Variable will substituted by Perl-Script with/) || ($ram_line =~/0x0                     \/\* ---- Variable/) || ($ram_line =~/PHYSICAL_ADDRESS 0x0    \/\* ---- Variable will substituted by Perl-Script with/)) {
						print "Analyse matching 3A: $ram_line\n";
							print OUTFILE &adress_substituted_line($ram_line,
										 \@CS_Xetk_list_name,
										 \@CS_Xetk_list_adress,
										 \@CS_Xetk_list_size);
					}
					else {
						print OUTFILE "$ram_line";
					}
				}
			# end WHILE (line)
			}
		}
	# end IF (len_line)
	}
# end WHILE (line)
}

close (INFILE);
close (OUTFILE);

close (DST_INFOFILE);
close (RAM_INFOFILE);


print LOGFILE "  Anzahl Zeilen: gelesene= $counter_org; geschrieben= $counter_new\n";



######################################################################################
# Log-Datei wird wieder geschlossen & ENDE

close (LOGFILE);

exit($ret_code);