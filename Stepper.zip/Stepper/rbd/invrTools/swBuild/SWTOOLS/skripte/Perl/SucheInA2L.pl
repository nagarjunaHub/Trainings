#########################################################
# Filename: SucheInA2L
# Purpose: In A2L nicht ersetzte Adressen suchen und ersetzen, A2ML einf�gen
# Author: Silvester R��ner EEEF
# Date_Created: 2004-11-10 15:54
##########################################################

=head1 Dokumentation SucheInA2L.pl
=head2 Nutzen
Das vorliegende Skript durchsucht ein oder mehrere A2L Dateien nach Adressen (0x[0-9a-fA-F]+) und ersetzt diese durch
Adressen aus der Ref Datei, falls diese in der Ref Datei vorhanden sind. In die Ergebnis A2L flie�en alle gefundenen Blocke aus den einzelnen A2L Dateien ein (merge).
Ausserdem wird der Inhalt der A2ML Datei in das Ergebnis eingef�gt.

Auf welche Bl�cke das Skript reagiert, steht in einer Variablen (%BeginWort). Dadurch l��t sich das Skript leicht auf neue Gegebenheinten anpassen.
Der ganze Block ab "/begin BeginWort" bis "/ende BeginWort" flie�t zuerst in einen Hash (%Block) und dann in die Ergebnis A2L.

Mit den zu ersetzenden Adressen verh�lt es sich �hnlich. 
Das Skript sucht eins von mehreren Schl�sselw�rtern (%SchluesselWort), die vor der Adresse stehen,
und interpretiert das darauf folgende Wort als Adresse.
Ist diese 0x0+, wird sie durch die Adresse aus der Ref-Datei ersetzt.

Das Skript ist aber kein vollst�ndiger Parser, es ist auf die Nettigkeit der A2L Dateien angewiesen.
Es erkennt z.B. nicht, wenn Text in "" eingeschlossen ist. Das Skript interpretiert diesen Text genauso wie den Rest der A2L-Datei.
Es k�nnte also zu Seiteneffekten kommen. Ich gebe aber gen�gend Warnungen aus, so dass dies auffallen sollte. 
=cut

=head1 Geschichte
=head2 �nderungen zu 20041111
Suche jetzt auch nach ".bss" in der Map-Datei.

Die Fehlermeldungen wandern jetzt auch in die Standard-Ausgabe (STDOUT) und nicht mehr in die Standard-Fehlerausgabe (STDERR).

06.07.2006 ZFLS-ms   : Es werden nun ALLE Adressen in den A2L Dateien durch jene von der Ref Datei ersetzt, sofern die Variablen
                       in der Ref Datei vorhanden sind.
=cut

=head1 Benutzte Module
i<strict> hilft uns, ein wenig sauberer zu programmieren, 
i<Englisch> macht aus den unleserlichen Spezialvariablen etwas Leserlicheres 
und i<Getopt::Long> nutzen wir zum einlesen der Kommandozeilen-Optionen.
=cut

use strict;
use English;
use Getopt::Long;

=head1 Globale Variablen
=cut

#/begin IF_DATA ASAP1B_CCP

=pod
i<$DEBUG> steuert die Ausgagbe von Debug-Informationen. 0 bedeutet keine Ausgabe.
Je gr��er der Wert ist, desto mehr Informationen purzeln aus dem Skript.
=cut

my $DEBUG = 0;

=pod
In i<%BeginWort> stehen die W�rter, die das Skript alarmieren. Folgen sie auf ein "/begin", so merkt sich das
Skript die Position im Text und such das n�chste Wort. Dieses Wort dient als Variablennamen.

Der Zahlenwert bestimmt die Reihenfolge, in der das Skript die Bl�cke in die Ergebnis A2L schreibt. Zuerst dran kommen kleine Zahlen.
Gibt es eine Zahl mehrfach, so die Reihenfolge der zugeh�rigen BeginWort nicht festgelegt.
=cut


# Nur Begin mit diesen Worten l�sen einen Alarm aus.

# sk30102009 Wichtig: Damit "/begin A2ML" aus HAuPT-A2L nicht weggefiltert wird, muss Schl�sselwort A2ML hier herausgenommen werden.
# Allerdings wird nun nicht mehr eine evtl. mit Parameter --A2ML definierte Kommentar oder Basis-A2L-Datei ausgegeben.
# wird aber sowiso nicht verwendet. 

my %BeginWort =  qw(CHARACTERISTIC 1
					MEASUREMENT 6
					FUNCTION 3
					RECORD_LAYOUT 3
					COMPU_METHOD 4
#					A2ML 5
					AXIS_PTS 2

					);


=pod
Nach einem der W�rter in i<%SchluesselWort> folgt die Adresse, die eventuell ersetzt werden muss.
=cut

# Nur bei diesen Schluesselworten wird die Adresse ersetzt.
my %SchluesselWort = qw(ECU_ADDRESS - 
						MAP - 
						VALUE - 
						CURVE - 
						VAL_BLK -
						);


=pod
i<%Inhalt> nimmt den gesamten Inhalt einer Datei als String auf. Der Schluessel des Hashs ist der Datei-Name mit Pfad.
Wird die gleiche Datei mehrfach eingelesen, gibt es daher trotzdem nur einen Eintrag im Hash. 
Was auch so gewollt ist, damit keine Bl�cke doppelt vorkommen, nur weil aus Versehen eine Datei mehrfach in der Kommandozeile angegeben ist.

=cut

my %Inhalt;	# Der Inhalt der einzelnen Dateien. $Inhalt{$HauptA2L} = $

=pod
In i<%Adressen> legt das Skript die Adressen aus der Ref Datei ab.
=cut

my %Adressen;	# Hier liegen die im Ref-File gefundenen Variablennamen und die Adressen $Adressen{Variablennamen} = $Adresse;

=pod
i<%Block> nimmt die Bl�cke auf. Damit ist der ganze Text von "/begin BLOCKNAME" bis "/ende BLOCKNAME" (einschlie�lich) gemeint. 
Gespeichert sind die Bl�cke in i<$Block{Variablenname}{Text}>, wobei i<Variablennamen> der vom Skript gefundenen Variablennamen entspricht.

In i<$Block{Variablenname}{ErsterTreffer}> steht der FileName, aus dem der Block stammt.

Au�erdem nimmt i<$Block{Variablenname}{ErsterTreffer}> tempor�r die Textposition auf, an sich die zu ersetzende Adresse befindet.
Tempor�r deswegen, da die Adresse schon ersetzt wird, bevor der Block in i<%Block> wandert. In i<%Block> stehen also nur schon ersetzte Adressen.
=cut

my %Block; # Die gefundenen Bl�cke $Block{Variablenname}{Text} = $Text; $Block{Variablenname}{ErsterTreffer} = $FileName

=pod
Die Regul�ren Ausdr�cke nutzen i<$Space> als Abk�rzung f�r: Finde entweder Leerzeichen oder Kommentare (alles zwischen i</*> und i<*/>).
=cut

my $Space =  '
				  (?:				# Grupiere das folgende, aber belege keine $1 Variable.
				  	\\s				# Es d�rfen Leerstellen 
				   	|
				   	/\*.*?\*/ 	# oder Kommentare kommen
				  )
			 '; 

#print "Space: $Space :Space\n";exit;

=pod
Hier noch ein paar globale Variablen, die f�r das Skript n�tzlich sind. Besser w�re es, sie in eine Datenstruktur zu verbergen. Aber
das Skript ist bisher �berschaubar;) 
=cut

my ($HauptA2L, @NebenA2L, $A2ML, $ErgebnisA2L, $Ref); # Hier stehen die Dateinamen drin
my $Warnungen = 0; # Erh�ht bei jeder Ausgabe einer Warnung
my $Ersetzungen = 0; # Erh�ht beim Ersetzten einer Adresse





















=head1 Unterprogramme
=cut

=head2 i<warnung>
ist nur eine Abk�rzung. Gibt alle �bergebenen Argumente auf STDERR aus und z�hlt i<$Warnungen> hoch.
=cut

sub warnung
{
	$Warnungen++;
	#print STDERR @_;
	print @_;
}

=head2 i<fehler>
ist nur eine Abk�rzung. Gibt alle �bergebenen Argumente auf STDERR aus.
=cut

sub fehler
{
	#print STDERR @_;
	print @_;
}


=head2 i<zieheArgumente>
Holt sich alle Kommandozeilenargumente (nutzt das Module i<use Getopt::Long>, was deswegen importiert sein muss) und speichert
das Ergebnis in globalen Variablen ab.

Pr�ft au�erdem, ob alle geforderten Argumente angegeben sind. Falls nicht, bricht es mit einer Fehlermeldung ab.

Gibt eine Warnung aus, wenn optionale Argumente fehlen.
=cut

sub zieheArgumente
{
	# 	Folgendes muss global deklariert sein.
	#	my ($HauptA2L, @NebenA2L, $A2ML, $ErgebnisA2L, $Ref);
	&GetOptions('HauptA2L|haupt|main=s' => \$HauptA2L,
				'NebenA2L|neben|include|i=s@' => \@NebenA2L,
				'A2ML|a=s' => \$A2ML,
				'ErgebnisA2L|erg|e|out|o=s' => \$ErgebnisA2L,
				'Ref|Adressen|Adr=s' => \$Ref,
				)
		or die "Fehler: Kann Argumente nicht interpretieren.";

	print "Haupt: $HauptA2L\n", join("\n", "Neben:", @NebenA2L, ""), "A2ML: $A2ML\n", "Ergebnis: $ErgebnisA2L\n"
		if $DEBUG > 100;

	my $die = 0;
	if (!defined $HauptA2L)    {fehler("Fehler: Keine Haupt A2L angegeben. Bitte mit Option --HauptA2L angeben.\n"); $die = 1;}
	if (!defined $A2ML)        {warnung("Warnung: A2ML nicht angegeben. Falls gew�nscht, mit Option --A2ML angeben.\n");}
	if (!defined $Ref) 		   {fehler("Fehler: REF Datei nicht angegeben. Bitte mit Option --Ref angeben.\n"); $die = 1;}
	if (!defined @NebenA2L)    {warnung("Warnung: Keine A2Ls zum einf�gen angegeben. Falls gew�nscht, mit Option --NebenA2L angeben.\n");} 
	if (!defined $ErgebnisA2L) {fehler("Fehler: Ausgabedatei nicht angegeben. Bitte mit Option --ErgebnisA2L angeben.\n"); $die = 1;}
	if ($die) {die;}
}

=head2 i<fuelleSpeicher(\%Inhalt)>
Zieht den Inhalt der globalen Variablen als einen einzigen String in den als Referenz �bergebenen Hash.
Der Hash-Index ist der Dateiname i<$Inhalt{FileName) = $Text>

Schafft auch gleich einen Hash-Eintrag f�r die Ergebnis A2L.
=cut

sub fuelleSpeicher($)
{
	my $Inhalt = shift;
	my $name;


	if (!defined $A2ML) {        
		foreach $name ($HauptA2L, $Ref, @NebenA2L)
        	{

			my @i;

			open(DATEI, $name) or die "Fehler: Kann Datei \n'$name'\nnicht einlesen.";
		    @i =  <DATEI>;
			$Inhalt->{$name} = join("", @i);
			print "Angezogen: $name, Zeilen: ", scalar @i, "\n" if $DEBUG;
		}

	}
        else {
		foreach $name ($HauptA2L, $A2ML, $Ref, @NebenA2L)
        	{

			my @i;

			open(DATEI, $name) or die "Fehler: Kann Datei \n'$name'\nnicht einlesen.";
		    @i =  <DATEI>;
			$Inhalt->{$name} = join("", @i);
			print "Angezogen: $name, Zeilen: ", scalar @i, "\n" if $DEBUG;
		}
	}



	$Inhalt->{$ErgebnisA2L} = "";	# Platz machen f�r das Ergebnis
}


=head2 i<durchsucheREF(\%Inhalt, \%Adressen)>
Durchsucht die REF-Datei nach Variablennamen und deren dazugeh�renden Adressen.

Eine Zeile, auf die das Skript reagiert, sieht wie folgt aus:

ichbineineVariable            03ffffff
       |                           |--------> genau 8 Hexadezimalziffern, welche die gesuchte Adresse darstellen
       |---> der Variablenname
=cut

sub durchsucheREF($$)
{
    my ($Inhalt, $Adressen) = @_ ;

	print "Durchsuche REF File.\n" ;
















	
	while ($$Inhalt =~ m/
	                    ^\s*?           # Die Zeile darf mit einem Leerzeichen beginnen,
						(\S*)			# dann muss der Variablennamen kommen (gespeichert in $1).

						\s+?			# Durch mindestens ein Leerzeichen
						([0-9a-f]{8})	# ist die Hexadresse, die aus genau 8 Ziffern bzw. Buchstaben besteht, abgesetzt ($2).
						\s*$			# Bis zum Zeilenende darf nichts mehr kommen.
	                    /igxm)			# Ignoriere Gro�-/Kleinschreibung, durchsuche komplette Liste, Modus "Freie Form", Modus Mehrzeilenmodus
	{
	    $Adressen->{$1} = "0x" . $2 ;
		print "Gesaugt: $1 = 0x$2\n" if $DEBUG ;
	}
	print "Habe interessante Variablen aus REF File herausgesucht.\n" ;
}





=head2 i<holeBlock(\%$Inhalt, $FileName, \%Block, \%Adressen)>
Sucht aus I<$Inhalt->{$FileName}{Text}> die interessanten Blocke heraus ("/begin blabla .... /end blabla"), ersetzt
die Adressen in diesen Bl�cken und legt das Ergebnis in I<$Block->{Variablenname}{Text} = $Text> ab.

Alles, was nicht in I<$Block->{Variablenname}{Text}> wandert, wird als R�ckgabewert zur�ckgegeben. Das hei�t, der
R�ckgabewert entspricht dem Ursprungstext, aus dem die Blocke herausgeschnitten sind.
Der Ursprugnstext in I<$Inhalt->{$FileName}{Text}> selbst bleibt aber unver�ndert.
=cut

sub holeBlock($$$$)
{
	my ($Inhalt, $FileName, $Block, $Adressen) = @_;
	my $Tiefe = 0;					# Die Tiefe der Schachtelung. Bei jedem /begin $Tiefe++, bei jedem /end $Tiefe--
	my $Alarm  = -1;				# Sobald auf ein /begin ein %SchluesselWort folgt, wird $Alarm = $Tiefe gesetzt. Der Block beginnt
									# jetzt. kommt ein /end bei der passenden Schachtelungstiefe, ist der Block zu ende.
	my $AlarmVar;					# Sobald $Alarm gesetzt ist, ist auch die dazugeh�rige Variable hier abgelegt.
	my $SuchString;					# Nimmt den gesamten Suchstring auf, s.u.
	my (%Temp, $PosStart, $PosEnd);	# %Temp ist eine allgemeine tempor�re Variable, $PosStart und $PosEnd ist die Position von /begin und /end
	my ($ZaehlerBlock);				# Summiert die Anzahl der Zeichen in den gefundenen Bl�cken.
	my $Erg;					    # Da kommt alles rein, was kein erkannter Block ist.

	print "Hole Block aus $FileName\n";

=pod
Der I<$SuchString> ist zusammengesetzt aus den festen Vorgaben ("/begin", "/end" und "/*" (Kommentaranfang)) und den variablen Vorgaben aus
der I<%SchluesselWort> (keys).
=cut

	$SuchString = '			# suche
				  /begin
		   		  |			# oder
		   		  /end
				  |
				  /\*		# Kommentaranfang
				  ';

	$SuchString .= "|" . join("|", keys(%SchluesselWort)); # bzw. eins der Worter in SchluesselWort

	#print "Suchstrin:\n$SuchString\n:Suchstrin\n";

=pod
Jetzt beeginnt die Suche. Deshalb erst mal alle Z�hler zur�cksetzen.
=cut

	$PosEnd = 0;
	$ZaehlerBlock = 0;
	
=pod
Die Schleife sucht alle Vorkommen der in I<$SuchString> enthaltenen Ausdr�cke.
=cut

	while ($$Inhalt =~ m<\s*
		   				($SuchString)	# in $1 speichern
		   				(?=\s)			# gefolgt von einem Leerzeichen. Das aber nicht merken!
		   	 			>igsx)
	{

=pod
I<pos($$Inhalt)> gibt die aktuelle Position im Text B<nach> der Suche zur�ck.
Zieht man davon die L�nge des aktuell gefundenen Textes ab (I<$MATCH>), hat man die Position des "/" von z.B.  "/begin".
Diese Position erst mal merken. 
=cut

		$Temp{PosStart} = pos($$Inhalt) - length($MATCH); # Aktuelle Position im String.
		#print "Ausschnitt: '", substr($$Inhalt, $Temp{PosStart}, 6), "'\n";


	
				 
		if ($1 =~ m'/begin')
		{

			$Tiefe++;	# Jedes /begin erh�ht die Schachtelungstiefe
			#print "($Tiefe";



			if ($$Inhalt =~ m<				# Vorsicht! hier wird alles weggesaugt, auch ein /end oder /begin! Aber wir pr�fen ja die Schachteltiefe
							\s*	     		# nach einem /begin muss mindestens ein Leerzeichen vor
							(\S+)			# dem Namen des Blocks kommen ($1),
							\s				# der durch ein Leerzeichen abgegrenzt ist.
							>igsx)			
			{
				if (exists $BeginWort{$1})	   # Muss ich darauf reagieren?
				{

=pod
Jetzt wird es interessant. Ein I<%BeginWort> ist erkannt. 

Aber gleich mosern, falls auf ein "/begin SchluesselWort" noch ein "/begin SchluesselWort" kommt. Das darf eigentlich nicht vorkommen.
(Tritt es aber doch auf, schmeiss ich den �u�eren Block einfach weg.)

Die aktuelle Schachtelungstiefe merken, die Position von "/begin" aus der tempor�ren Variable in I<$PosStart> kopieren.
Tritt sp�ter ein "/end" auf der gleichen Schachtelungstiefe auf, wei� ich, dass der Block zu Ende ist. Dann kann ich
den Block Dank I<$PosStart> herausschneiden.
=cut

					warnung("Warnung: Begins geschachtelt. Erebnis kann fehlerhaft sein.\n")
						if $Alarm != -1;

					$Alarm = $Tiefe;
					$PosStart = $Temp{PosStart};
					$Temp{BeginWort} = $1;

					unless ($Temp{BeginWort} eq "AML")
					{
						$$Inhalt =~ m<				# Vorsicht! hier wird alles weggesaugt, auch ein /end oder /begin! Aber wir pr�fen ja die Schachteltiefe
									\s*	  		    # nach dem Blocknamen muss mindestens ein Leerzeichen kommen (eins habe ich oben schon abgepr�ft!).
									(\S+)			# Dann folgt der Variablenname,
									\s				# der durch ein Leerzeichen abgeschlossen ist.
									>igsx;

						$AlarmVar = $1;
					}

=pod
Eine Besonderheit ist der Block "/begin A2ML". Hier folgt dem Blocknamen kein Variablenname. Deshalb setzte ich hier den
Variablennamen einfach auf "A2ML". Falls es mal wirklich eine Variable mit diesem Namen geben sollte, kracht es hier. Aber
ich geb ja ne Warnung aus.
=cut

					else
					{
						$AlarmVar = "A2ML";
					}

=pod
Um sp�ter die Ausgabe der Bl�cke sortiert machen zu k�nnen, merke ich mir zu jeder Variable das I<$Temp{BeginWort}>. Dann kann ich
z.B. zuerst alle "CHARACTERISTIC" ausgeben, dann alle "..." usw. 
=cut

					$Block->{$AlarmVar}{BeginWort} = $Temp{BeginWort};
					#print "Alarm = $Alarm $AlarmVar\n" if $DEBUG;
				} 
			}
		}
		elsif ($1 eq '/end')
		{

	

			#print "$Tiefe)";
			$Tiefe--;		# Jedes /end verringert die Schachtelungstiefe

			if ($Alarm > $Tiefe)
			{

=pod
Falls ich ein "/begin" gefunden hatte, ist ja I<$Alarm> auf die damaligen Schachtelungstiefe gesetzt. 
Sobald dann ein "/end" die Schachtelungstiefe wieder bis auf I<$Alarm > $Tiefe$> zur�ckf�hrt, habe ich das Blockende gefunden. 

Dann sauge ich noch den Bezeichner nach "/end" (z.B. "/end CHARACTERISTIC " und kann den Block herausschneiden (zuerst in I<$Temp{PosEnd}> merken).
=cut

				$$Inhalt =~ m<				# Vorsicht! hier wird alles weggesaugt, auch ein /end oder /begin! Aber wir pr�fen ja die Schachteltiefe
						 	\s*				# nach einem /begin muss mindestens ein Leerzeichen vor
						 	(\S+)			# dem Namen des Blocks kommen ($1),
						 	\s+  			# der durch mindestens ein Leerzeichen abgegrenzt ist.
						 	>igsx;
				$Temp{PosEnd}   = pos $$Inhalt;
				#$Temp{PosEnd} -= 1;

				$Erg .= substr($$Inhalt, $PosEnd, (($PosStart - 1) - $PosEnd) + 1);	# Alles zwischen den Blocken in das Ergebnis, aber nicht die Blocke selbst!
				$PosEnd = $Temp{PosEnd};	# Neues PosEnd!

				if (defined $AlarmVar)
				{
					if ((exists $Block->{$AlarmVar}{ErsterTreffer}) and ($AlarmVar ne "A2ML")) # Ein A2ML kann mehrfach vorkommen. 
					{
						warnung("Warnung: Mehrfaches Vorkommen:\n    $AlarmVar\n  kommt in\n    $FileName\n  und in\n    $Block->{$AlarmVar}{ErsterTreffer}\n  vor!\n");
					}
					else
					{

=pod
So. Es gibt die Blockvariable I<$AlarmVar> und es liegt kein Doppeltreffer vor.
Dann merke ich mir den Dateinamen in I<$Block->{$AlarmVar}{ErsterTreffer}> und kopiere den Block nach I<$Block->{$AlarmVar}{Text}>.

Die Position im String berechnet sich aus 

	 --> I<$PosStart> zeigt auf den "/" von "/begin"
	 |
    "/begin  CHARACTERISTIC "

	

	"/end CHARACTERISTIC "
						|
						|--> I<$PosEnd - 1> zeigt auf das erste Leerzeichen nach dem Blocknamen (z.B. CHARACTERISTIC)

	(($PosEnd -1) - $PosStart) + 1)
		ist deswegen die Anzahl der Zeichen des Blocks. +1 ist n�tig, da die Null mitz�hlt
	    (Zwischen Index 0 und Index 0 gibt es ein Zeichen, das auf Index 0).
=cut

						my $Text = \$Block->{$AlarmVar}{Text};  # nur ein Alias, damit ich nicht soviele Tippfehler mache
						#print "Habe mir einen Block gemacht: $AlarmVar\n" if $DEBUG;
						$Block->{$AlarmVar}{ErsterTreffer} = $FileName;
						$$Text = substr($$Inhalt, $PosStart, (($PosEnd -1) - $PosStart) + 1);
						$ZaehlerBlock += length($$Text);
						#print "      Block: Von ", $PosStart, " Bis ", $PosEnd - 1, " Laenge ", length($$Text), " Gesamt ", $ZaehlerBlock, "\n";

						if (exists $Block->{$AlarmVar}{ErsetzenPos})
						{
							if (exists $Adressen->{$AlarmVar})
							{

=pod
Es gibt eine Adresse (0x[0-9a-fA-F]+), die zu ersetzen ist und auch eine passende Variable in der Ref Datei.
Also ersetzte ich auch die Adresse.

Ich fange im Text (I<$Block->{$AlarmVar}{Text}>) gleich an der richtigen Stelle an zu suchen, n�mlich unmittelbar vor 0x0+. 
Die Position habe ich zuvor schon in I<$Block->{$AlarmVar}{ErsetzenPos}> gespeichert. I<pos $$Text> kann ich einen Wert zuweisen,
der dann als aktuelle Suchposition f�r Regul�re Ausdr�cke gilt.
=cut

								my $EPos = $Block->{$AlarmVar}{ErsetzenPos};
								#print "Hier muesste ich die Adresse einf�gen: '", substr($Text, $EPos, 4), "'\n" if $DEBUG;
								#print "Und zwar '$AlarmVar', '", 	$Adressen->{$AlarmVar}, "'\n";
								#print "Alter Block:\n", $Text, "\n:Alter Block\n";
								pos $$Text = $EPos;
								# Hier werden die Adressen in der A2L Datei durch jene von der Ref Datei ersetzt.
								# Es wird dabei immmer die erste Adresse der Form 0x[0-9a-fA-F]+ ersetzt, allerdings nicht wenn BIT_MASK davor steht
								$$Text =~ s/(?<!BIT_MASK\s)0x[0-9a-fA-F]+(?=\s)/$Adressen->{$AlarmVar}/;
								$Ersetzungen++;
								#print "Neuer Block:\n", $Text, "\n:Neuer Block\n";
							}
							else
							{
								warnung("Warnung: Habe die Variable\n    '$AlarmVar'\n  nicht im MAP-File gefunden und habe deshalb nichts ersetzt.\n");
							}
						}	  
						#print "Block gefunden:\n", $$Text, "\n:Block gefunden\n" if $DEBUG;
					}
				}
				else
				{
					warnung("Warnung: Ich habe zwar einen Block herausgeschnitten, kann ihn aber nicht speichern, weil der Variabelnname fehlt!\n");
				}

=pod
Bereit machen f�r den n�chste Block.
=cut				

				$Alarm = -1;
				$AlarmVar = undef;
			}
		}
		elsif ($1 eq '/*')		# Kommentare ignorieren
		{

=pod
Kommentare ignoriere ich einfach, indem ich das n�chste Kommentarende suche. Damit wird die akteulle Suchposition auf das Zeichen hinter
dem Kommentarende gesetzt. Schon ist der Kommentar weg.
=cut

			#my $Pos = pos $$Inhalt;
			$$Inhalt =~ m<
						  \*/	# Kommentarende
					 	 >igsx;
			#my $Pos2 = pos $$Inhalt;
			#print "Kommentar $Pos $Pos2:\n", substr($$Inhalt, $Pos - 2, (($Pos2) - ($Pos - 1) + 1)), "\n:Kommentar\n";
			
		}
		elsif (($Alarm == $Tiefe) and (defined $AlarmVar) and exists $SchluesselWort{$1})
		{


=pod
Falls ein Schl�sselwort f�r eine Adresse auf der richtigen Tiefe auftaucht,
suche ich nach der Adresse, die nach diesem Schlusselwort kommt. 

Zwischen Sch�sselwort und Adresse darf I<$Space> vorkommen. Alles andere wird als Adresse
interpretiert.

Ist diese Adresse gleich 0x0+, so muss ich sie durch die Adresse in der Ref-Datei ersetzen.
Aber nicht hier, sondern erst wenn ich den gesamten Block gefunden habe. Deshalb merke ich mir
die Position, an der die zu ersetzende Adresse steht.

Und zwar berechne ich die Position gleich relativ zum "/begin".

....    /begin  CHARACTERISTIC ..... 0x0 ....
|	 	|       				    ||  |
----------------------------------------^  pos $$Inhalt
|		|							||	|
|		|						    |<-->  - length($NullAdresse) + 1
------------------------------------^	   = zeigt eins vor Adresse
|		|							|
--------^							|	   - I<$PosStart> zeigt auf den "/" von "/begin"
|		|							|
|		----------------------------^	   = Position relativ zu "/begin"
|		|
|		^  Index 0 bezogen auf $Block->{Text}
|
^  Index 0 bezogen auf $$Inhalt.

=cut

			if ($$Inhalt =~ m[
							  $Space*	# Nach dem Schluesselwort d�rfen Leerstellen oder Kommentare kommen
			   				  (\S*)	    # gefolgt von der Adresse
			   			 	  \s		# eingeschlossen von Leerstelle
			   		 		 ]gsx)
 		 		  {
 		 		  	#print "Adresse: $AlarmVar = $1\n";
 		 		  }

			my $NullAdresse = $1;

			if ($1 =~ m/^0x[0-9a-fA-F]+$/)
			{
				# Ich hab ne Adresse zum Ersetzen gefunden. Aber nicht in $Inhalt ersetzen, sonst geht die Suche von vorne los!
				#print "Adresse zum Ersetzen gefunden: $AlarmVar = $NullAdresse\n";
				if (exists $Block->{$AlarmVar}{ErsetzenPos}) {warnung("Warnung: Habe mehr als eine Adresse pro Variable ersetzt!");}
				$Block->{$AlarmVar}{ErsetzenPos} = (pos $$Inhalt) - (length($NullAdresse) + 1) - $PosStart;	# Hier muss was ersetzt werden, schon bezogen auf /begin
			}
		}

	}

=pod
Jetzt gibt es keine weiteren Fundstellen. Den Rest des Textes einfach an I<$Erg> h�ngen und zur�ckgeben.

Zur Sicherheit pr�fe ich, ob meine Schachtelungstiefe wieder Null ist. Sonst hab ich ja irgendetwas falsch gemacht oder die A2L stimmt nicht.

Ebenso pr�fe ich, ob ich Zeichen verloren habe. Die Summer der Zeichen in den Bl�cken plus die Zeichen im Resttext (I<$Erg>) muss gleich dem Orginal
sein, sonst stimmt der Code nicht.
=cut

	if ($Tiefe > 0) {warnung("Warnung: Habe nicht gen�gend /end gefunden. Ergebnis kann falsch sein!\n");}
	if ($Tiefe < 0)	{warnung("Habe nicht gen�gend /begin gefunden. Ergebnis kann falsch sein!\n");}
#	if ($Tiefe == 0) {print "Gut.\n";}

	$Erg .= substr($$Inhalt, $PosEnd);
	# print "  Laenge: ", length($t), " - ", length($Erg), "\n";

	if (($ZaehlerBlock + length($Erg)) != length($$Inhalt))
	{
		warnung("Warnung: Ich habe Zeichen verloren: Orginal ", length($$Inhalt), " Ergebnis ", $ZaehlerBlock + length($Erg), "\n");
	}

	#print "Ergebnis = ", length($Erg), " Block = ", $ZaehlerBlock, "\n";

	return $Erg;
}



=head2 i<schreibeErgebnis(\$Haupt, $FileName, \%Block)>
Speichert I<$$Haupt> in einer neuen Datei I<$FileName> ab. Zurvor werden alle Bl�cke sortiert
in I<$$Haupt> eingef�gt, und zwar vor (dem Ersten) "/end MODULE".

Die Bl�cke sind sortiert nach I<$BeginWort{BlockName}>.
=cut

sub schreibeErgebnis($$$)
{
	my ($Haupt, $FileName, $Block) = @_;
	my ($Pos, $BeginWort, $Erg, $Var, @Sortiert);

	print "Schreibe Ergebnis-A2L.\n";

=pod
Zuerst kommen alle Bl�cke in I<$Erg> rein.

=cut

 	@Sortiert = sort {$BeginWort{$a} <=> $BeginWort{$b}} keys %BeginWort;

	$Erg .= "\n"; #sk06092011 wg. fehlendem Zeilenumbruch 1. Block "begin CHARACTERISTIC"
	
	foreach $BeginWort (@Sortiert)
	{
		#print "Speichere $BeginWort ", $BeginWort{$BeginWort}, " \n";
		foreach $Var (keys(%$Block))
		{
			if ($Block->{$Var}{BeginWort} eq $BeginWort)
			{
				$Erg .= $Block->{$Var}{Text};
			    #print "  $Var\n";

			}
		}
	}

	#print "Haupt = ", length($$Haupt), "\n";	

=pod
Dann suche ich "/end MODULE" in I<$$Haupt> und f�ge davor I<$Erg> ein. Das ist schon das Endergebnis,
was ich dann speichre.
=cut

	pos $$Haupt = index $$Haupt, '/end MODULE';
	$Erg .= "/end MODULE";
	$$Haupt =~ s|/end MODULE|$Erg|;
	#print "Erg = ", length($$Haupt), "\n";	

	open(ERG, ">$FileName") or die "Fehler: Kann \n  '$FileName'\n  nicht zum schreiben �ffnen!\n"; 
	print ERG $$Haupt;
	close ERG;	
}





sub ersetze0x0($$)
{
	my ($BeginWort, $Block) = @_;
	my ($Var);

	foreach $Var (keys(%$Block))
	{
		if (($Block->{$Var}{BeginWort} eq $BeginWort) and (exists $Adressen{$Var}))
		{
			$Block->{$Var}{Text} =~ s/($Space+)0x[0-9a-f]+($Space+)/$1$Adressen{$Var}$2/isx	;
		}
	}
}





=head1 Hauptprogramm
Hier rufe ich nur die Unterprogramme in der richtigen Reihenfolge auf.

Als einzigste richtige Aufgabe f�gt das Hauptprogramm den Inhalt von 
der Datei I<$A2ML> in I<$Block{A2ML}{Text}> ein. Aber erst, nach dem 
alle A2Ls eingelesen sind.

Damit ist sichergestellt, dass der Ersatztext tats�chlich in das Ergebnis einflie�t.
dass 
=cut
#
# Hauptprogramm
#

#my $Text = "0123456789";
#print "-", substr($Text, 0, 0), "-\n";
#print "-", substr($Text, 0, 1), "-\n";
#print "-", substr($Text, 0, 2), "-\n";
#print "-", substr($Text, 2, 0), "-\n";
#print "-", substr($Text, 2, 1), "-\n";
#exit;

zieheArgumente();
fuelleSpeicher(\%Inhalt);
durchsucheREF(\$Inhalt{$Ref}, \%Adressen);

my $Erg = holeBlock(\$Inhalt{$HauptA2L}, $HauptA2L, \%Block, \%Adressen);
foreach (@NebenA2L) {holeBlock(\$Inhalt{$_}, $_, \%Block, \%Adressen);}

if (defined $A2ML)	# A2ML-Einf�gen
{
	#print "A2ML alt:\n", $Block{A2ML}{Text}, "\n:A2ML alt\n";
	$Block{A2ML}{Text} = $Inhalt{$A2ML};
	$Block{A2ML}{BeginWort} = "A2ML";
	#print "A2ML neu:\n", $Block{A2ML}{Text}, "\n:A2ML neu\n";
}

ersetze0x0("AXIS_PTS", \%Block);

schreibeErgebnis(\$Erg, $ErgebnisA2L, \%Block);

warnung("Warnung: DEBUG Informationen k�nnen im Ergebnis enthalten sein. Nicht f�r den Prozess geeingnet!\n") if $DEBUG;

if ($Warnungen) {print "Warnung: Es sind $Warnungen Warnungen aufgetreten. Siehe STDERR.\n";}
else {print "Durchlauf erfolgreich ohne Warnungen.\n";}
print "Insgesamt $Ersetzungen Adressen eingesetzt.\n";

exit;

