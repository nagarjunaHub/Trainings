#
#  This script is used for validating the tools installation required for the Software Build.
#
#  The correct command looks like:
#  <path of the perl.exe>\perl.exe tools_verification.pl ListOfToolset OutputFileForVerificationReport
#
#  For example:
#  perl.exe C:\Users\nbd5kor\rtc_sandbox\rbd_briBk10_pf_sw_Development_RWS_NBD5KOR\rbd\invrPPC\tools\swBuild\SWTOOLS\skripte\Perl\tools_verification.pl $(TOOL_SET) $(loc_set)\Tools_installation_Check.log
#
#
#  Does not work? Then you should check the next points.
#  1. Did you chose the right path for your perl.exe?
#  2. Is it really available?
#
#  AUTOR:   Nagarjuna Badigunchala
#  DATE:    2016.12.02
#  FILE:    tools_verification.pl
#  VERSION: 1.0
#

use strict;
use warnings;
use Data::Dumper qw(Dumper);

my $fd;
print "total arguments is: ".scalar(@ARGV)."\n";
print "last argument is:".$ARGV[scalar(@ARGV)-1]."\n";
my $ToolsVerificationReport = $ARGV[scalar(@ARGV)-1];
unlink ($ToolsVerificationReport) if -e $ToolsVerificationReport;
foreach my $Tool (@ARGV) {
	if ($Tool ne $ToolsVerificationReport) {
		print "Checking for $Tool\n";
		if (! -f $Tool) {
			if (! -f $ToolsVerificationReport) {
				open($fd, ">>$ToolsVerificationReport");
			}
			print $fd "$Tool doesn't exists\n";
		}	
	}
}
if (-f $ToolsVerificationReport) {
	print "ERROR: Some of the tools were not installed. Please check $ToolsVerificationReport and install the missing tools before proceeding...\n";
	exit 1;
}