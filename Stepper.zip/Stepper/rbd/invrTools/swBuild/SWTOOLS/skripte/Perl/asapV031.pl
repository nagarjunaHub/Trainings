#################################################################################
# Datei:									#
#	asapV03.pl								#
#										#
# Beschreibung:									#
#	1.) liest alle Variablen aus der ASAP-Datei				#
#	2.) l�scht alle nicht aufgef�hrten Variablen einer Liste aus einer	#
#		ASAP-Datei							#
#	oder									#
#	3.) l�scht alle aufgef�hrten Variablen einer Liste aus der ASAP-Datei	#
#										#
# Aufruf:									#
#	perl asap.pl -l -iASAPDATEI -oVARIABLENDATEI				#
#		liest ASAPDATEI aus und erstellt VARIABLENDATEI			#
#										#
#	perl asap.pl -s -iASAPDATEI -vVARIABLENDATEI -oNEUEASAPDATEI		#
#		liest ASAPDATEI, l�scht alle Variablen, die in VARIABLENDATEI	#
#		stehen und schreibt Ergebnis nach NEUEASAPDATEI			#
#										#
#	perl asap.pl -sn -iASAPDATEI -vVARIABLENDATEI -oNEUEASAPDATEI		#
#		liest ASAPDATEI, l�scht alle Variablen, die NICHT in		#
#		VARIABLENDATEI stehen und schreibt Ergebnis nach NEUEASAPDATEI	#
#										#
# History:									#
#	Version:	Datum:		Autor:		Hinweis:		#
#	----------------------------------------------------------------------	#
#	0.1		99/03/29	Huttenlocher	Erster Schuss		#
#	0.2		99/03/30	Huttenlocher	Ausweitung auch auf	#
#							RAM-Groessen		#
#	0.3		99/04/01	Huttenlocher	Optimierung		#
#	0.31		00/05/03	Huttenlocher	exit()			#
#										#
#################################################################################

#################################################################################
# definiere Suchstrings								#
# neue Stringbereiche mit Anfang und Ende definieren und in startref und endref #
# eintragen									#
#################################################################################

$rom_start = "/begin CHARACTERISTIC";
$rom_ende  = "/end CHARACTERISTIC";
$ram_start = "/begin MEASUREMENT";
$ram_ende  = "/end MEASUREMENT";

@startref	=	($rom_start,$ram_start);
@endref 	= 	($rom_ende,$ram_ende);

# ermittele Anzahl der Eintr�ge
$anzahl_bereiche = @startref;


#################################################################################
# Einlesen und pr�fen der �bergabeparameter					#
#################################################################################

# alle Parameter auslesen
while (@ARGV)
{
	# hole n�chsten Parameter uns speichere diesen nach "parameter"
	push @parameter, shift @ARGV;
}


# pr�fe, ob lesen oder schreiben
$mode = 0;
foreach $para (@parameter)
{
	if ($para =~ /-l/)
	{
		# lesemode
		$mode = $mode | 1;
	}

	if ($para =~ /-s/)
	{
		# schreibmode
		$mode = $mode | 2;
	}
}

# verzweigen zur jeweiligen Funktion
if ($mode == 1)
{
	asap_lesen();
}
elsif ($mode == 2)
{
	asap_schreiben();
}
else
{
	fehler();
	exit 1;
}

#################################################################################
# asap-datei auslesen und Variablenliste erzeugen				#
#################################################################################
sub asap_lesen
{
	$eingabe_ok = 0;
	foreach $para (@parameter)
	{
		# suche nach ASAPDATEI-Eintrag
		if ($para =~ /-i/)
		{
			# -i l�schen
			$para =~ s/-i//;

			# Dateiname speichern
			$iasap = $para;

			$eingabe_ok = $eingabe_ok | 1;
		}

		# suche nach VARIABLENDATEI-Eintrag
		if ($para =~ /-o/)
		{
			# -o l�schen
			$para =~ s/-o//;

			# Dateiname speichern
			$ovar = $para;

			$eingabe_ok = $eingabe_ok | 2;
		}

	}

	# Parameter ok ?
	if ($eingabe_ok == 3)
	{
		# Dateien �ffnen
		open (ASAPIN,"<$iasap") || die ("Die Datei $iasap existiert nicht.");
		open (VAROUT,">$ovar") || die ("Die Datei $ovar kann nicht angelegt werden.");
		
		# Meldung ausgeben
		print "\nLese $iasap";

		# alle zeilen einlesen
		while (<ASAPIN>)
		{
			for ($i = 0; $i <= ($anzahl_bereiche-1); $i++)
			{
				# sucht alle startref-elemente
				if (/$startref[$i]/)
				{
					# Variablenname steht immer nach einer Leerzeile
					# n�chste Leerzeile einlesen
					$zeile = <ASAPIN>;

					# Variablenname einlesen und schreiben
					$zeile = <ASAPIN>;
					print VAROUT $zeile;
				}
			}
		}

		# Dateien schliessen
		close (VAROUT);
		close (ASAPIN);

		# Meldung ausgeben
		print "\nSchreibe $ovar";

		exit 0;
	}
	else
	{
		fehler();
		exit 1;
	}
}

#################################################################################
# neue asap-datei schreiben							#
#################################################################################
sub asap_schreiben
{

	# pr�fe Schreibmode
	$schreibmode = 0;
	foreach $para (@parameter)
	{
		if ($para =~ /-sn/)
		{
			# schreibmode
			$schreibmode = 1;
		}
	}

	# Dateinamen holen
	$eingabe_ok = 0;
	foreach $para (@parameter)
	{
		# suche nach ASAPDATEI-Eintrag
		if ($para =~ /-i/)
		{
			# -i l�schen
			$para =~ s/-i//;

			# Dateiname speichern
			$iasap = $para;

			$eingabe_ok = $eingabe_ok | 1;
		}

		# suche nach VARIABLENDATEI-Eintrag
		if ($para =~ /-v/)
		{
			# -v l�schen
			$para =~ s/-v//;

			# Dateiname speichern
			$ivar = $para;

			$eingabe_ok = $eingabe_ok | 2;
		}

		# suche nach NEUEASAPDATEI-Eintrag
		if ($para =~ /-o/)
		{
			# -o l�schen
			$para =~ s/-o//;

			# Dateiname speichern
			$oasap = $para;

			$eingabe_ok = $eingabe_ok | 4;
		}

	}

	# alle Eingaben ok ?
	if ($eingabe_ok == 7)
	{

		# Einlesen der Variablennamen aus VARIABLENDATEI
		open (IVAR,"<$ivar") || die ("Die Datei $ivar existiert nicht.");
		
		print "\nLese $ivar";

		while(<IVAR>)
		{
			push @varnamen, $_;
		}

		close (IVAR);

		# Dateien �ffnen
		open (ASAPIN,"<$iasap") || die ("Die Datei $iasap existiert nicht.");
		open (ASAPOUT,">$oasap") || die ("Die Datei $oasap kann nicht angelegt werden.");

		print "\nLese $iasap";
		print "\nSchreibe $oasap";

		# alle Zeilen des NEUEASAPDATEI lesen
		while ($izeile = <ASAPIN>)
		{

			$nichts_gefunden = 0;

			for($i=0;$i<=($anzahl_bereiche-1);$i++)
			{
				# sucht alle "/begin CHARACTERISTIC"
				if ($izeile =~ /$startref[$i]/)
				{
					# n�chste leerzeile lesen
					$leerzeile = <ASAPIN>;

					# Variablenname lesen
					$varname = <ASAPIN>;
	
					# Treffermerker l�schen
					$treffer = 0;

					# teste alle Variablennamen
					foreach $vartest (@varnamen)
					{
						if ($varname eq $vartest)
						{
							# Variable der ASAPDATEI ist in Liste
							$treffer = 1;
						}
					}

					if ($schreibmode == 0)
					{
						# Treffer l�schen
						if ($treffer == 1)
						{
							# Block zu Ende lesen, aber nicht schreiben
							until (($izeile = <ASAPIN>) =~ /$endref[$i]/)
							{
								;
							}

							# anschliessende Leerzeile auch noch lesen
							$izeile = <ASAPIN>;
						}
						else
						{
							print ASAPOUT $izeile;
							print ASAPOUT $leerzeile;
							print ASAPOUT $varname;

							# den Rest natuerlich auch
							until (($izeile = <ASAPIN>) =~ /$endref[$i]/)
							{
								print ASAPOUT $izeile;
							}

							print ASAPOUT $endref[$i];
							print ASAPOUT "\n";
						}
					}
					else
					{
						# Nichttreffer l�schen
						if ($treffer == 0)
						{
							# Block zu Ende lesen, aber nicht schreiben
							until (($izeile = <ASAPIN>) =~ /$endref[$i]/)
							{
								;
							}

							# anschliessende Leerzeile auch noch lesen
							$izeile = <ASAPIN>;
						}
						else
						{
							print ASAPOUT $izeile;
							print ASAPOUT $leerzeile;
							print ASAPOUT $varname;

							# den Rest natuerlich auch
							until (($izeile = <ASAPIN>) =~ /$endref[$i]/)
							{
								print ASAPOUT $izeile;
							}

							print ASAPOUT $endref[$i];
							print ASAPOUT "\n";

						}
					}
				}
				else
				{
					$nichts_gefunden++;
				}
			}

			if ($nichts_gefunden == $anzahl_bereiche)
			{
				print ASAPOUT $izeile;
			}
		}

		# Dateien schliessen
		close (ASAPOUT);
		close (ASAPIN);

		exit 0;
	}
	else
	{
		fehler();
		exit 1;
	}
}

#################################################################################
# Fehlermeldung									#
#################################################################################
sub fehler
{
	print "ASAP.PL V0.3\n\n";
	print "Falsche Eingabeparameter!\n";
	print "Aufruf:\n";
	print "   [PERLPFAD\\]perl asap.pl -l -iASAPDATEI -oVARIABLENDATEI\n";
	print "      liest ASAPDATEI aus und erstellt VARIABLENDATEI\n";
	print "\n";
	print "   [PERLPFAD\\]perl asap.pl -s -iASAPDATEI -vVARIABLENDATEI -oNEUEASAPDATEI\n";
	print "      liest ASAPDATEI, loescht alle Variablen, die in VARIABLENDATEI\n";
	print "      stehen und schreibt Ergebnis nach NEUEASAPDATEI\n";
	print "\n";
	print "   [PERLPFAD\\]perl asap.pl -sn -iASAPDATEI -vVARIABLENDATEI -oNEUEASAPDATEI\n";
	print "      liest ASAPDATEI, loescht alle Variablen, die NICHT in VARIABLENDATEI\n";
	print "      stehen und schreibt Ergebnis nach NEUEASAPDATEI\n";
	print "\n";
	print "   Hinweis:\n";
	print "      Die Namen in VARIABLENDATEI !!!MUESSEN!!! mit CR/LF abgeschlossen sein,\n";
	print "      d.h. am Ende der Datei steht eine Leerzeile!!!\n";
	print "\n\n";
	print "Anregungen, Fehlermeldungen oder Lob bitte an:\n";
	print "Peter Huttenlocher (AEE, Tel. 4481)\n";
}