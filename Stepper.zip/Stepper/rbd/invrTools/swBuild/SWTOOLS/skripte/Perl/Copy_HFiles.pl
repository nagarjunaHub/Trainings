#
#  This script copies the header files from clearcase view to local workspace to reduce the build time. It also supports blocking of header files which we don't want to copy to local workspace.
#
#  The correct command looks like:
#  <path of the perl.exe>\perl.exe Copy_Hfiles.pl rbd_path AlmProjectPath local_workspace_path
#
#  For example:
#  C:\Users\nbd5kor\rtc_sandbox\rbd_invrPPC_tools-swBuild-briBk1_integration_RWS_NBD5KOR\rbd\invrPPC\tools\swBuild\SWTOOLS\perl\v5_8_8_817\bin\perl.exe C:\Users\nbd5kor\rtc_sandbox\rbd_invrPPC_tools-swBuild-briBk1_integration_RWS_NBD5KOR\rbd\invrPPC\tools\swBuild\SWTOOLS\skripte\Perl\Copy_HFiles.pl $(AlmRWSPath) $(AlmProjectPath) $(loc_set)\include
#
#
#  Does not work? Then you should check the next points.
#  1. Did you chose the right path for your perl.exe?
#  2. Is it really available?
#  3. Are the case of the letters in the paths correct?
#
#  AUTOR:   Nagarjuna Badigunchala
#  DATE:    2015.09.14
#  FILE:    Copy_HFiles.pl
#  VERSION: 1.0
#


use strict;
use warnings;
use File::Find;
use File::Copy;
use File::Compare;
my $AlmRwsPath              = $ARGV[0];
my $AlmProjectPath          = $ARGV[1];
my $AlmPrjVarPath           = $ARGV[2];
my $IncludePath             = $ARGV[3];
my $AlmWorkspacePath        = $ARGV[4];
my $AlmDepPath              = "$AlmRwsPath\\dep";
my $FileName_BlackList      = "HFiles_BlackList.txt";
my $FileName_Include        = "HFiles_Include.txt";
my $PathFile_BlackList      = "$AlmPrjVarPath\\tools_cfg\\swBuild\\$FileName_BlackList";
my $HFiles_Include_Path     = "$AlmPrjVarPath\\tools_cfg\\swBuild\\$FileName_Include";
my @list;
open (MYFILE, $HFiles_Include_Path);
 while (<MYFILE>) {
    chomp;
    my $prj_path = $AlmWorkspacePath."\\".$_;
    print "reading the hfilesinclude file $prj_path\n";
    my @prj_hfiles = find_h_files($prj_path);
    print "header files from $_: ".scalar(@prj_hfiles)."\n";
    push(@list, @prj_hfiles);

 }
my @prj_h_list = ();
print "Total Header List: ".@list."\n";
open FILE, "<", $PathFile_BlackList or die $!;
my @blocked_list = <FILE>;
close FILE;

my @Real_blocked_list;
my %hash;


foreach my $blockfile (@blocked_list) {
    chomp($blockfile);
    $blockfile =~ /^#/ and next;
    $blockfile =~ s/\Q$(AlmProjectPath)\E/$AlmProjectPath/g;
    $blockfile =~ s/\Q$(AlmDepPath)\E/$AlmDepPath/g;
    $blockfile =~ s/\Q$(AlmRwsPath)\E/$AlmRwsPath/g;
    $blockfile =~ s/\Q$(AlmWorkspacePath)\E/$AlmWorkspacePath/g;

    if (-f $blockfile) {
        if(-e $blockfile) {
            push (@Real_blocked_list, $blockfile);
        }
    }
    if (-d $blockfile) {
        push (@Real_blocked_list, find_h_files($blockfile));
    }
}

print "Blocked Header List: ".@Real_blocked_list."\n";
my %temp;
@temp{ map { lc } @Real_blocked_list } = ();
@list = grep { !exists $temp{lc $_} } @list;


# $hash{$_} = undef foreach (@Real_blocked_list);
# @list = grep { not exists $hash{$_} } @list;


undef @prj_h_list;
foreach my $hfile (@list) {
    my @fields = split /\\/, $hfile;
    push (@prj_h_list, $fields[-1]);
}

my @dupes = ();
my %cnt;
$cnt{lc($_)}++ for @prj_h_list;
push(@dupes, lc($_)) for grep $cnt{$_} > 1, keys %cnt;

if(@dupes) {
    print "Error: The following header files are found as duplicates\n";
    foreach my $dup (@dupes) {
        foreach my $hfile (@list) {
            if (index(lc($hfile), $dup) != -1) {
                print "$hfile\n";
            }
        }
    }
    exit 1;
}

foreach my $hfile (@list) {
    copy("$hfile",$IncludePath) or die "Copy failed: $!";
}
print "Copied Header List: ".@list."\n";
sub find_h_files {
    my $dir = shift;
    my @text_files;
    my $tf_finder = sub {
        return if ! -f;
        return if ! /\.h\z/;
        my $filename = $File::Find::name;
        $filename =~ tr{/}{\\};
        push @text_files, $filename;
    };
    find({ wanted => $tf_finder, no_chdir => 1 }, $dir );
    return @text_files;
}
