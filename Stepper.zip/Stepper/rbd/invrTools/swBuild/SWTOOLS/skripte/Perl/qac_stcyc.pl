#!/usr/bin/perl

use strict;
use File::Basename;
use File::Find;
use FileHandle;

 
# History:
# ********
# 04.10.2010 V1.0 Becker:  initialise File
# 05.10.2010 V1.1 Becker:  faster script, use of split
# ****************************************************************************
# Call of the Module as follow:
# qac_stcyc.pl " -i$InputFile_MetFile -logpl.log 


my @Temp_Argv;
my @Temp_Var;

print "\n\n Identify max STCYC \n";
print " ==================\n";
       
my $Time_Stamp = WriteActualTime();

# Read Arguments from calling string
@Temp_Argv = split ' ', @ARGV[0];
print " All Arguments= @Temp_Argv\n\n";

# Input-File
# **********
@Temp_Var = grep /-i/i, @Temp_Argv;
my $InputFile_MetFile = $Temp_Var[0];
substr ($InputFile_MetFile, 0, 2) = "";

# Log File
# ********
@Temp_Var = grep /-log/i, @Temp_Argv;
my $LogFile = $Temp_Var[0];
substr ($LogFile, 0, 4) = "";


# Print used Parameter in STDOUT
print " [necessary -i]      QAC-OutputFile       = $InputFile_MetFile\n";
print " [necessary -log]    LOG-Datei            = $LogFile\n";

# open Log file
open (LOGFILE, '>' ,$LogFile) || die "Error: Open Log-File: $LogFile";
# write parameter in log file
#print LOGFILE "\n\n**********************************************************\n$0\n";
#print LOGFILE "Running $Time_Stamp\n\n";
#print LOGFILE "All Arguments = @Temp_Argv\n";
#print LOGFILE "[necessary -i]      QAC-OutputFile       = $InputFile_MetFile\n";
#print LOGFILE "[necessary -log]    LOG-Datei            = $LogFile\n";


open (DATEI, '<', $InputFile_MetFile) || die "Can't open $InputFile_MetFile";
my @met_file = <DATEI>;
close (DATEI);

@Temp_Var = grep /STCYC/i, @met_file;
#print "All Arguments1= @Temp_Var\n\n";

my $TempNumber;
my $f_StringLength;
my $MaxNumber=0;
my $Rubbish;

foreach(@Temp_Var)
{
   # delete new line
   chomp($_);

   # remove double ' '
   $_ =~ s/ \s/ /g;

   # split string, split for ' ' and create only 2 segments
   ($Rubbish, $TempNumber) = split(/ /,$_);

#   print LOGFILE "String: $_\tMax Number: $MaxNumber\tActual Number: $TempNumber\n";
   # check if the actual number is bigger than the one before
   if ($MaxNumber <= $TempNumber)
   {
      # actual number is bigger, store it
      $MaxNumber = $TempNumber;
   }
    
}

# print the max number
print " *****************\n";
print "  STCYC max = $MaxNumber\n";
print " *****************\n";



print LOGFILE "<HTML><BODY>\n";
print LOGFILE "<PRE STYLE=\"margin-top:0;margin-bottom:0\">\n";
print LOGFILE "\n";
print LOGFILE " *****************\n";
print LOGFILE "  STCYC max = $MaxNumber\n";
print LOGFILE " *****************\n";
print LOGFILE "</PRE>\n";
print LOGFILE "</BODY></HTML>\n";



# Call: WriteActualTime();
# ************************
# function calculates the actual date and time
sub WriteActualTime
{
   my ($Sekunden, $Minuten, $Stunden, $Monatstag, $Monat, $Jahr, $Wochentag, $Jahrestag, $Sommerzeit) = localtime(time);
   $Monat += 1;
   $Monat = $Monat < 10 ? $Monat = "0".$Monat : $Monat;
   $Monatstag = $Monatstag < 10 ? $Monatstag = "0".$Monatstag : $Monatstag;
   $Stunden = $Stunden < 10 ? $Stunden = "0".$Stunden : $Stunden;
   $Minuten = $Minuten < 10 ? $Minuten = "0".$Minuten : $Minuten;
   $Sekunden = $Sekunden < 10 ? $Sekunden = "0".$Sekunden : $Sekunden;
   $Jahr += 1900;

   # return value looks like: 
   # Date: 29.06.2010 Time: 13:38:18
   return ("Date: $Monatstag.$Monat.$Jahr Time: $Stunden:$Minuten:$Sekunden");
}