#!/usr/bin/perl
use strict;
use File::Basename;
use File::Find;
use FileHandle;

#############################################################
# Function: Creates Polyspace DRS-File from Damos-Variables
#############################################################
#
# please check the global paths
#
# History:
# ********
# 10.05.2010 V1.0 Becker:  initialise File
# 10.06.2010 V1.1 Becker:  extract Ram and Rom with the same functions
# 29.06.2010 V1.2 Becker:  serach module DRS files, copy content into global DRS
# 28.07.2010 V1.3 Becker:  setting for use with SWDE Stepper
# 29.09.2011 V1.4 Becker:  new conversion formular format (file *.xmo)
# 24.10.2011 V1.5 Becker:  further adaption
# 15.03.2012 V1.6 Becker:  further adaption and correction of the conversion
# 12.08.2014 V1.7 Becker:  add test_wert, new calculation methods, use phys value of no "umrechnug" formula
my $G_ScriptVersion = 1.7;
# ****************************************************************************
# Call of the Module as follow:
# CreateDRSFile.pl "-i$(DAMOS_C_PATH)kgt_filelist.kgl -o$(loc_obj_set)\\drs_range.txt -iDamos$(DAMOS_C_PATH)damos.osp -s$(test_set)\\Module -logpl.log -cyg$(CYGWIN_PATH) -obj$(OBJ_BASE) -spMinMax"
#
# global arrays
# *************
my @DRS_File;
my @XMO_File;
my @Temp_Argv;
my @Temp_Var;

print "\n\n Creation of DRS - Range File\n";
print " ============================\n";

my $Time_Stamp = WriteActualTime();

# Read Arguments from calling string
@Temp_Argv = split ' ', $ARGV[0];       #@ARGV[0];
print "All Arguments= @Temp_Argv\n\n";

# Input-File
# **********
@Temp_Var = grep /-i/i, @Temp_Argv;
my $InputFile_kgtfilelist = $Temp_Var[0];
substr ($InputFile_kgtfilelist, 0, 2) = "";

# Output-File
# ***********
@Temp_Var = grep /-o/i, @Temp_Argv;
my $DRSDestPathAndFileName = $Temp_Var[0];
substr ($DRSDestPathAndFileName, 0, 2) = "";

# Damos-Input-File
# ****************
@Temp_Var = grep /-iDamos/i, @Temp_Argv;
my $InputDamosXmoFile = $Temp_Var[0];
substr ($InputDamosXmoFile, 0, 7) = "";

# DRS File Search Path
# ********************
@Temp_Var = grep /-s/i, @Temp_Argv;
my $DRSFilesPath = $Temp_Var[0];
substr ($DRSFilesPath, 0, 2) = "";

# Log File
# ********
@Temp_Var = grep /-log/i, @Temp_Argv;
my $LogFile = $Temp_Var[0];
substr ($LogFile, 0, 4) = "";

# Cygwin Path
# ***********
@Temp_Var = grep /-cyg/i, @Temp_Argv;
my $CygPath = $Temp_Var[0];
substr ($CygPath, 0, 4) = "";

# OBJ Path
# ********
@Temp_Var = grep /-obj/i, @Temp_Argv;
my $OBJPath = $Temp_Var[0];
substr ($OBJPath, 0, 4) = "";

# Search Parameter (Test_wert or MinMax)
# ****************
@Temp_Var = grep /-sp/i, @Temp_Argv;
my $SearchParameter = $Temp_Var[0];
substr ($SearchParameter, 0, 3) = "";
$SearchParameter = lc($SearchParameter);

# Print used Parameter in STDOUT
print "[necessary -i]      KGT-File-Liste       = $InputFile_kgtfilelist\n";
print "[necessary -o]      DRS-Output-File      = $DRSDestPathAndFileName\n";
print "[necessary -iDamos] Damos-XMO-Input-File = $InputDamosXmoFile\n";
print "[necessary -s]      Module-DRS-File      = $DRSFilesPath\n";
print "[necessary -log]    LOG-Datei            = $LogFile\n";
print "[necessary -cyg]    Cygwin-Path          = $CygPath\n";
print "[necessary -obj]    OBJ-Path             = $OBJPath\n";
print "[necessary -sp]     Search-Parameter     = $SearchParameter\n";

# open Log file
open (LOGFILE, '>>' ,$LogFile) || die "Error: Open Log-File: $LogFile";
# write parameter in log file
print LOGFILE "\n\n**********************************************************\n$0\n";
print LOGFILE "Running $Time_Stamp\n";
print LOGFILE "Script Version $G_ScriptVersion\n\n";
print LOGFILE "All Arguments = @Temp_Argv\n";
print LOGFILE "[necessary -i]      KGT-File-Liste       = $InputFile_kgtfilelist\n";
print LOGFILE "[necessary -o]      DRS-Output-File      = $DRSDestPathAndFileName\n";
print LOGFILE "[necessary -iDamos] Damos-XMO-Input-File = $InputDamosXmoFile\n";
print LOGFILE "[necessary -s]      Module-DRS-File      = $DRSFilesPath\n";
print LOGFILE "[necessary -log]    LOG-Datei            = $LogFile\n";
print LOGFILE "[necessary -cyg]    Cygwin-Path          = $CygPath\n";
print LOGFILE "[necessary -obj]    OBJ-Path             = $OBJPath\n";
print LOGFILE "[necessary -sp]     Search-Parameter     = $SearchParameter\n";

# settings for module DRS file
# ****************************
my $G_ModuleDRSextension      = '*_pd.txt';

# settings for KGT files
# **********************
my $G_KeywordSeperator        = "\t";  # allowed are the following 4: , ; TAB SPACE
my $G_ConversionIdentifier    = "umrechnung";
my $G_TestWertIdendifier      = "test_wert";
my $G_TestWertPhyIdendifier   = "test_wertp";
my $G_MinPhysIdentifier       = "minp_w";
my $G_MaxPhysIdentifier       = "maxp_w";
my $G_MinIdentifier           = "min_w";
my $G_MaxIdentifier           = "max_w";
my $G_Bracket_Open            = "{";
my $G_Bracket_Close           = "}";
my $G_SplitSignConFormula     = "=>";
my $G_Poly_Keyword            = "permanent";   #"globalassert";  #"permanent";  #"init";
my $G_InvalidKeyWord          = "kennwerteblock";

my $G_PartString_Arith;
my $G_AllFound = 0;
# used with access $G_PolynomPara
my @G_PolynomPara;

my $G_VariableName = "NoVariable";     my $G_CalcFormulaName;
my $G_CalculationFormula;              my $G_CalculationMethod;
my $G_TestWert;                        my $G_TestWertP;
my $G_MinValuePhys = 0;                my $G_MaxValuePhys = 0;
my $G_MinValue = 0;                    my $G_MaxValue = 0;
my $G_ErrorAvailable = "No Error";

# read the kgtfilelist.kgl from DAMOS as Input with all kgt files (located in project folder)
open (DATEI, '<', $InputFile_kgtfilelist) || die "Can't open $InputFile_kgtfilelist";
my @KGT_FileList = <DATEI>;
close (DATEI);

# read conversion formula from file in the project folder
open (DATEI, '<', $InputDamosXmoFile) || die "Can't open $InputDamosXmoFile";
my @DAMOS_XMO_File = <DATEI>;
close (DATEI);

print "Extract Conversion Formula from $InputDamosXmoFile \n";
print LOGFILE "Extract Conversion Formula from $InputDamosXmoFile \n";
ReadDamosFile();

# write Date and Time in DRS File
push (@DRS_File, "# File created @ $Time_Stamp\n");
push (@DRS_File, "# Skript Version: $G_ScriptVersion\n");
push (@DRS_File, "# Global part for all KGT Files which are in file list $InputFile_kgtfilelist\n");
push (@DRS_File, "# ************************************************************************************\n");

# extract "Rom"
# *************
print "Extract ROM Variables and Values from kgt Files\n";
print LOGFILE "Extract ROM Variables and Values from kgt Files\n";
CheckKGTFile("kennwert", $SearchParameter);

# extract "Ram"
# *************
# print ("Extract RAM Variables and Values from kgt Files\n");
# CheckKgtForDRS ("ram_groesse", $SearchParameter);

# extract from the existing module DRS files
# ******************************************
print "Searching for files in Path $DRSFilesPath with ending $G_ModuleDRSextension\n";
print LOGFILE "Searching for files in Path $DRSFilesPath with ending $G_ModuleDRSextension\n";
SearchDrsFiles();

# write all values from array into DRS file
open (DATEI, '>', $DRSDestPathAndFileName) || die "Can't open $DRSDestPathAndFileName";
print DATEI @DRS_File;
close (DATEI);

close (LOGFILE);
# *****************************************************************************************
# MAIN Programm finished here
# *****************************************************************************************


# Call: ReadDamosOSP();
# *********************
# The function reads the file damos.xmo which is located in the project path
# This file is a result from the DAMOS process and contains the conversion factors.
# Only the conversion factors will be elected and stored in an array.
# There are two ways for calculation of the conversion (internal value "int").
# Arithmetic (Arith) or with a Polynom (Poly) can be used. Therefor different sub functions are called.
# 
# Call of other function: ReadDamosFile_Arith, ReadDamosFile_Poly, PrintXMOElements
# *****************************************************************************
sub ReadDamosFile()
{
   my $f_Arith = "none";

   # for all lines in the file
   foreach(@DAMOS_XMO_File)
   {
      # the Arithmetic-Block in the conversion factors are selected
      if (  (index ($_, "<Arith>") >= 0)
          ||($f_Arith eq "Arith"))
      {
         $f_Arith = "Arith";
         ReadDamosFile_Arith($_);
      }

      if (  (index ($_, "<Poly>") >= 0)
          ||($f_Arith eq "Poly"))
      {
         # the Polynom-Block in the conversion factors are selected
         $f_Arith = "Poly";
         ReadDamosFile_Poly($_);
      }

      if(   (index ($_, "</Arith>" ) >= 0)
         || (index ($_, "</Poly>" ) >= 0) )
      {
         # Neither Arith nor Poly is selected.
         $f_Arith = "none";

         # no "finishing" signal if all polynom found, max5 but it could be also only 3!
         # because of this, the "finished" is selected ith /Poly and so the last Polynoms must be saved now. 
         if(  (index ($_, "</Poly>" ) >= 0)
            &&($G_AllFound == 1))
         {
            PrintXMOElements();
         }
      }
   } # END foreach(@DAMOS_XMO_File)
   return;
}

# Call: ReadDamosOSP_Arith($_);
# *****************************
# The function extraxts from the given String ($f_ActualString) the Name and the Formula of the Conversion Factor.
# The result is stored in a new "File". The result is stored in "one" line in the file, added with an parameter
# which distinguish the arithmetic formula. 
# 
# Call of other function: none
# *****************************************************************************
sub ReadDamosFile_Arith()
{
   my $f_ActualString = shift;
   my $f_TempString;
   my $f_position;
   my $f_StringStart;
   my $f_StringEnd;

   # <Umr><Arith><obj n="CS_ADC_3V3_q2EXP10">
   # <obj n="CS_ADC_3V3_q2EXP12">
   # extract only lines which contains the following sting <obj n=
   $f_position = index ($f_ActualString, "<obj n=");

   if ($f_position  >= 0)
   {
      # Teil string ab Position X
      # the string looks like: <obj n="CS_ADC_3V3_q2EXP10">
      if ($f_position > 0)
      {
         $f_TempString = substr($f_ActualString, 8 + $f_position);
      }
      else
      {
         $f_TempString = substr($f_ActualString, 8); # <obj n="
      }

      # extract the part string
      $G_PartString_Arith = substr($f_TempString, 0, length($f_TempString)-3);
      
      # add "=>""
      substr($G_PartString_Arith, length($G_PartString_Arith)) = $G_SplitSignConFormula;

      # remove laste sign in the string
      chomp($G_PartString_Arith);

      # $f_PartString contains the string like
      # CS_VOLTAGE_q2EXP6=>
   }

   # extract only lines which contains the following sting <FktH>
   if (-1 ne index ($f_ActualString, "<FktH>") )
   {
      # the string in variable $_ looks like:
      # <FktH>1023.0/3.3 * phys + 0.0</FktH></obj>
      # <FktH>64.0 * phys + 0.0</FktH></obj></Arith></Umr></GlobaleObjekte></XOsp>
      # <FktH>64.0 * phys + 0.0</FktH></obj></Arith></Umr>
      $f_StringStart = index($f_ActualString,"<FktH>");
      $f_StringEnd = index($f_ActualString,"</FktH>");
      $f_TempString = substr($f_ActualString, $f_StringStart + 6, $f_StringEnd-$f_StringStart-6);

      #store data for future use
      push (@XMO_File, "Arith".$G_PartString_Arith.$f_TempString."\n");
   }
   return;
}

# Call: ReadDamosOSP_Poly($_);
# *****************************
# The function extraxts from the given String ($f_ActualString) the Name and the Formula of the Conversion Factor.
# The result is stored in a new "File". The result is stored in "one" line in the file, added with an parameter
# which distinguish the polynomal formula.
# The polynom factors are given in the form <P1>(1.)</P1>
# 
# Call of other function: PrintXMOElements
# *****************************************************************************
sub ReadDamosFile_Poly()
{
   my $f_ActualString = shift;
   my $f_TempString;                   my $f_TempValue;
   my $f_position;                     my $f_StringStart;
   my $f_StringEnd;                    my $f_PolynomStart = "none";
   my $f_PolynomEnd = "none";          my $f_Parameter = 0;

   # the parameter from the Polynom are given in the way like:
   # <P1>(1.)</P1>
   # <P4>(1.)</P4>
   # upto 5 Polynom's are possible
   # The Formular for the Polynom looks:
   #         P1 * phys + P2
   # int = ------------------ + P5
   #         P3 * phys + P4

   # **************************
   # extract VARIABLE name
   # **************************
   # actual strings are given like:
   # <Poly><obj n="CS_FACTOR_qFLOAT"><ADisFm>12.12f</ADisFm>
   # <obj n="CS_FACTOR_qFLOAT">....
   # ===>> extract only lines which contains the following sting <obj n=
   $f_position = index ($f_ActualString, "<obj n=");

   if ($f_position >= 0)
   {
      # if a new variable name was found and not 5 parameter in the name before
      # store the old name with the corresponding parameter.
      if($G_AllFound == 1 )
      {
         PrintXMOElements();
      }
      $G_AllFound = 1;
      
      # part string from Position X
      # the string looks now like: <obj n="CS_ADC_3V3_q2EXP10">
      # remove leading signs and store in a "global" variable, because several function calls for the parameter 
      $f_TempValue = substr($f_ActualString, 8 + $f_position);
      $G_PolynomPara[0] = substr($f_TempValue, 0, index($f_TempValue, ">")-1);
      
      # reset the Polynom Parameter, becasue new variable name was found
      $G_PolynomPara[1] = 0;
      $G_PolynomPara[2] = 0;
      $G_PolynomPara[3] = 0;
      $G_PolynomPara[4] = 0;
      $G_PolynomPara[5] = 0;
   }
   
   # **************************
   # extract the Polynom Parameters
   # **************************
   # no elsif used, because it could be possible the polynoms will be written in one line!
   if (-1 ne index($f_ActualString, "<P1>"))
   {
      $f_PolynomStart = "<P1>";
      $f_PolynomEnd = "</P1>";
      $f_Parameter = 1;
   }

   if (-1 ne index($f_ActualString, "<P2>"))
   {
      $f_PolynomStart = "<P2>";
      $f_PolynomEnd = "</P2>";
      $f_Parameter = 2;
   }

   if (-1 ne index($f_ActualString, "<P3>"))
   {
      $f_PolynomStart = "<P3>";
      $f_PolynomEnd = "</P3>";
      $f_Parameter = 3;
   }

   if (-1 ne index($f_ActualString, "<P4>"))
   {
      $f_PolynomStart = "<P4>";
      $f_PolynomEnd = "</P4>";
      $f_Parameter = 4;
   }

   if (-1 ne index($f_ActualString, "<P5>"))
   {
      $f_PolynomStart = "<P5>";
      $f_PolynomEnd = "</P5>";
      $f_Parameter = 5;
   }

   if ($f_PolynomStart ne "none")
   { 
      # Polynom P1 found <P1>(1.)</P1>
      # extract the parameter value
      $f_StringStart = index($f_ActualString, $f_PolynomStart);
      $f_StringEnd = index($f_ActualString, $f_PolynomEnd);
      $f_TempString = substr($f_ActualString, $f_StringStart + 4, $f_StringEnd-$f_StringStart - 4);
 
      #string looks (1.) remove brackets
      $f_TempString =~ s/\(//g;
      $f_TempString =~ s/\)//g;

      # check the last sign of the parameter, add zerro if necessary, because 1. is not possible to calculate
      # index: starts counting with zero
      if( (index($f_TempString, ".") +1 ) == length($f_TempString) )
      {
         $f_TempString = $f_TempString."0";
      }

      $G_PolynomPara[$f_Parameter] = $f_TempString;
   }
   return;
}

# Call: CheckKGTFile ("kennwert", $SearchParameter);
# ***********************************************
# This function is the "main" function of the process and only RAM variables are extracted.
# All KGT files are opend and searched for the identifier ram_groesse. Then the
# variable name will be extracted as well the conversion formula and the min/max value of the variable.
# For a physical min/max value a sub function is called for calculation of the inteager value.
# A file for the DRS of PloySpace is wirtten with the following information:
# - variable name, min and max value, DRS check, and additional informatin as comment from the variable.
#
# Call of other function: CalculateValues, PrintKgtElements, ResetValues
# *****************************************************************************
sub CheckKGTFile()
{
   #"kennwert", $SearchParameter
   # function local variables
   my $f_RamRomIdentifier     = shift;    # search identifer if Rom (kennwert) or Ram (ram_groesse) 
   my $f_SearchString         = shift;    # contains test_wert or minmax
   my $f_RamRomIdentLength    = length($f_RamRomIdentifier);
   
   my $f_ActualKgtFile;    my $f_VariableName = "none";
   my $f_Position;         my $f_String;
   my $f_CalcString;       my $f_CalcMethod;
   my $f_FirstTimeLock;

   # repeate for all kgt files
   foreach (@KGT_FileList)
   {
      # on actual line, remove last elemen, normaly '\n'
      # copy into new variable to keep the original list in original layout
      $f_ActualKgtFile = $_;
      chomp($f_ActualKgtFile);

      # open aktual kgt file, copy contents, close kgt file
      open (DATEI, '<', $f_ActualKgtFile) || die "can't open File $f_ActualKgtFile";
      my @KgtFile = <DATEI>;
      close (DATEI);
      
      $f_FirstTimeLock = 0;
      
      # check the contents of the kgt file
      # checking line by line
      foreach(@KgtFile)
      {
         # remove last sign \n
         chomp($_);

         # remove spaces before first sign
         $_ =~ s/^\s+//;
         
         # check for the exact keyword of Ram/Rom is found
         if(  (-1 ne index($_, $f_RamRomIdentifier))           # ne => found keyword
            &&(-1 eq index($_, $G_InvalidKeyWord))    )        # eq => not found keyword
         {
            # keyword found => new variable found
            # store the data in the DRS output file
            
            # for the first time, the next part must be steped over
            if ($f_FirstTimeLock == 1)
            {
               # was there an error before?
               if ($G_ErrorAvailable eq "No Error")
               {
                  # calculate and print the values
                  CalculateValues();
                  PrintKgtElements();
               }

               # New Variable Name, reset all strings
               ResetValues();
            }
            else
            {
               # reset all strings               
               ResetValues();
               $f_FirstTimeLock = 1;
            }

            # the actual line cotains the keyword => variable name
            # remove all blanks in the string
            $f_VariableName = substr($_,$f_RamRomIdentLength);
            $f_VariableName =~ s/\s//g;
            chomp($f_VariableName);
            
            # store variable name
            $G_VariableName = $f_VariableName;
         }

         # check for other details only if variable name was found
         if ($G_VariableName ne "NoVariable")
         {
            # **********************
            # Check for "umrechnung"
            # **********************
            if (-1 ne index ($_, $G_ConversionIdentifier))
            {
               $f_Position = index ($_, $G_ConversionIdentifier);          # check position of the keyword        
               $f_String = substr($_, length($G_ConversionIdentifier));    # extract the variable name from string
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"
               $f_String =~ s/\;//g;                                       # remove ;
               $f_String =~ s/\{//g;                                       # remove {
               $f_String =~ s/\}//g;                                       # remove }
               $G_CalcFormulaName = $f_String;                             # store string

               # name of conversion formular now available
               # get the conversion formula and the method (poly/arith)
               ($f_CalcString, $f_CalcMethod) = FindConversionFormula($f_String);
               $G_CalculationFormula = $f_CalcString;                      # store string
               $G_CalculationMethod = $f_CalcMethod;                       # store string
            }
            
            # **********************
            # Check for "test_wert"
            # **********************
            if(  (-1 ne index ($_, $G_TestWertIdendifier))
               &&(-1 eq index ($_, $G_TestWertPhyIdendifier)))
            {
               $f_Position = index ($_, $G_TestWertIdendifier);            # check position of the keyword
               $f_String = substr($_, length($G_TestWertIdendifier));      # extract the variable name from string 
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"
               $f_String =~ s/\;//g;                                       # remove ;
               $f_String =~ s/\{//g;                                       # remove {
               $f_String =~ s/\}//g;                                       # remove }
               chomp($f_String);                                           # remove last sign
               $G_TestWert = $f_String;                                    # store string 
            }
   
            # **********************
            # Check for "test_wertp"
            # **********************
            if (-1 ne index ($_, $G_TestWertPhyIdendifier))
            {
               $f_Position = index ($_, $G_TestWertPhyIdendifier);         # check position of the keyword        
               $f_String = substr($_, length($G_TestWertPhyIdendifier));   # extract the variable name from string 
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"   
               $f_String =~ s/\;//g;                                       # remove ;        
               $f_String =~ s/\{//g;                                       # remove {        
               $f_String =~ s/\}//g;                                       # remove }        
               chomp($f_String);                                           # remove last sign
               $G_TestWertP = $f_String;                                   # store string
            }
            
            # **********************
            # Check for "minp_w"
            # **********************
            if (-1 ne index ($_, $G_MinPhysIdentifier))
            {
               $f_Position = index ($_, $G_MinPhysIdentifier);             # check position of the keyword        
               $f_String = substr($_, length($G_MinPhysIdentifier));       # extract the variable name from string
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"
               $f_String =~ s/\;//g;                                       # remove ;
               $f_String =~ s/\{//g;                                       # remove {        
               $f_String =~ s/\}//g;                                       # remove }
               $G_MinValuePhys = $f_String;                                # store value
            }
            
            # **********************
            # Check for "maxp_w"
            # **********************
            if (-1 ne index ($_, $G_MaxPhysIdentifier))
            {
               $f_Position = index ($_, $G_MaxPhysIdentifier);             # check position of the keyword        
               $f_String = substr($_, length($G_MaxPhysIdentifier));       # extract the variable name from string
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"
               $f_String =~ s/\;//g;                                       # remove ;
               $f_String =~ s/\{//g;                                       # remove {        
               $f_String =~ s/\}//g;                                       # remove }
               $G_MaxValuePhys = $f_String;                                # store value
            }
            
            # **********************
            # Check for "min"
            # **********************
            if (-1 ne index ($_, $G_MinIdentifier))
            {
               $f_Position = index ($_, $G_MinIdentifier);                 # check position of the keyword        
               $f_String = substr($_, length($G_MinIdentifier));           # extract the variable name from string
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"
               $f_String =~ s/\;//g;                                       # remove ;
               $f_String =~ s/\{//g;                                       # remove {        
               $f_String =~ s/\}//g;                                       # remove }
               $G_MinValue = $f_String;                                    # store value
            }
            
            # **********************
            # Check for "max"
            # **********************
            if (-1 ne index ($_, $G_MaxIdentifier))
            {
               $f_Position = index ($_, $G_MaxIdentifier);                 # check position of the keyword        
               $f_String = substr($_, length($G_MaxIdentifier));           # extract the variable name from string
               $f_String =~ s/\s//g;                                       # remove blanks
               $f_String = substr($f_String, 0, index ($f_String, ";"));   # remove all signes behind the ";"
               $f_String =~ s/\;//g;                                       # remove ;
               $f_String =~ s/\{//g;                                       # remove {        
               $f_String =~ s/\}//g;                                       # remove }
               $G_MaxValue = $f_String;                                    # store value
            }
         } # End: if ($G_VariableName ne "NoVariable")

         # check if "kennwerteblock" found and variabel is found before
         if(  ($G_VariableName ne "NoVariable")
            &&(-1 ne index($_, $G_InvalidKeyWord)) )
         {
            CalculateValues();
            PrintKgtElements();
            $f_FirstTimeLock = 0;
         }
      } # End: foreach(@KgtFile)
      
      # check if a element was found in KGT which was not printed so far
      if ($G_VariableName ne "NoVariable")    # variable name
      {
         # Calculate and print the values into DRS output file
         CalculateValues();
         PrintKgtElements();
      }

      # reset all parameters
      ResetValues();
   } # End: foreach (@KGT_FileList)
   return;
}

# Call: ResetValues();
# ********************
# The function resets the global values for defining a variable (conversion formula, phys value(s)).
# 
# Call of other function: none
# *****************************************************************************
sub ResetValues()
{
      $G_VariableName = "NoVariable";
      $G_CalcFormulaName = "No Formula Name";
      $G_CalculationFormula = "Not Found";
      $G_CalculationMethod = "NoMethod";
      $G_TestWert = "min";
      $G_TestWertP = "min";
      $G_MinValuePhys = "min";
      $G_MaxValuePhys = "max";
      $G_MinValue = "min";
      $G_MaxValue = "max";
      $G_ErrorAvailable = "No Error";
  
}

# Call: CalculateValues();
# ******************
# The function basicaly calculates from the physical value the min/max/test_wert the inteager value.
# The calculation formula and the corresponding physical value is taken over to the ValueCalculation.
# The result value of the called function is the corresponding inteager value.
# A test method is given to distinguish, if the conversion formula is given as Poylnom or as Arithmetic.
# In case  ther was noch conversion formula found, the given min/max or minp/maxp values are
# used was written in the kgt file. Same as DAMOS does.
#
# Call of other function: ValueCalculation_Arith and ValueCalculation_Poly
# *****************************************************************************
sub CalculateValues()
{
   # check if a conversion formula was found
   if ($G_CalculationFormula ne "Not Found")
   {
      # check if min/max or test_wert shall be found
      if ($SearchParameter eq $G_TestWertIdendifier)
      {
         # ********************
         # search for test_wert
         # ********************
         # check if Element "test_wert" was found
         # **************************************

         if ($G_TestWert eq "min")
         {
            if ($G_TestWertP ne "min")
            {
               # call calculation method for Arithmetic
               if ($G_CalculationMethod eq "Arith")
               {
                  # call the calculation for aritmetic with conversion formular and value
                  # calculate min value
                  $G_TestWert = ValueCalculation_Arith($G_CalculationFormula, $G_TestWertP); #formel, value
               }
            
               # call calculation method for Polynom
               if($G_CalculationMethod eq "Poly")
               {
                  # call the calculation for polynom with conversion formular and value
                  $G_TestWert = ValueCalculation_Poly($G_CalculationFormula, $G_TestWertP); #formel, value
               }
            }
         }
         else
         {
            # nothing to do
            # test_wert found in inteager.
         }
      }
      else
      {
         # ********************
         # search for min/max
         # ********************
         # check if Element "min" was found
         # ********************************
         if ($G_MinValue eq "min")
         {
            if ($G_MinValuePhys ne "min")
            {
               # call calculation method for Arithmetic
               if ($G_CalculationMethod eq "Arith")
               {
                  # call the calculation for aritmetic with conversion formular and value
                  # calculate min value
                  $G_MinValue = ValueCalculation_Arith($G_CalculationFormula, $G_MinValuePhys); #formel, value
               }
               
               # call calculation method for Polynom
               if($G_CalculationMethod eq "Poly")
               {
                  # call the calculation for polynom with conversion formular and value
                  $G_MinValue = ValueCalculation_Poly($G_CalculationFormula, $G_MinValuePhys); #formel, value
               }
            }
            else
            {
               # no min value was found, so keep the keyword "min"
               $G_MinValue = $G_MinValuePhys;
            }
         }
         else
         {
            # nothing to do
            # min found as inteager.
         }
   
         # check if Element "max" was found
         # ********************************
         if ($G_MaxValue eq "max")
         {
            if ($G_MaxValuePhys ne "max")
            {
               # call calculation method for Arithmetic
               if ($G_CalculationMethod eq "Arith")
               {
                  # call the calculation for aritmetic with conversion formular and value
                  # calculate max value
                  $G_MaxValue = ValueCalculation_Arith($G_CalculationFormula, $G_MaxValuePhys); #formel, value
               }
               
               # call calculation method for Polynom
               if($G_CalculationMethod eq "Poly")
               {
                  # call the calculation for polynom with conversion formular and value
                  $G_MaxValue = ValueCalculation_Poly($G_CalculationFormula, $G_MaxValuePhys); #formel, value
               }
            }
            else
            {
               # no maxvalue was found, so keep the keyword "max"
               $G_MaxValue = $G_MaxValuePhys;
            }
         }
         else
         {
            # nothing to do
            # max found in inteager.
         }
      } # End: if ($SearchParameter eq $G_TestWertIdendifier)
   }
   else
   {
      # Conversion Formula not given, in this case Damos uses the Value "as it is"
      # check if Phys Value was given, if phys value is set, use them.
      if ($G_MaxValuePhys ne "max")
      {
         $G_MaxValue = $G_MaxValuePhys;
      }

      if ($G_MinValuePhys ne "min")
      {
         $G_MinValue = $G_MinValuePhys;
      }

      if ($G_TestWertP ne "min")
      {
         $G_TestWert = $G_TestWertP;
      }

      $G_ErrorAvailable = "Element not fully described";
   } # End: if ($G_CalculationFormula ne "Not Found")
   return;
}

# Call: PrintXMOElements();
# *************************
# The function prints the value to the XMO file which is only used inetrnal
# Called from two different functions, so only a centralized function for "printing" out.
# Call of other function: none
# *****************************************************************************
sub PrintXMOElements()
{
   push (@XMO_File, "Poly".$G_PolynomPara[0].$G_SplitSignConFormula.$G_PolynomPara[1]." ".$G_PolynomPara[2]." ".$G_PolynomPara[3]." ".$G_PolynomPara[4]." ".$G_PolynomPara[5]."\n");
   return;
}

# Call: PrintKgtElements();
# *************************
# The function prints the value to the DRS output file.
# There is a distinguish between test_wert or MinMax Value.
# Different output between minmax and test_wert as well to if an Error is detected.
# Called from two different functions, so only a centralized function for "printing" out.
# 
# Call of other function: none
# *****************************************************************************
sub PrintKgtElements()
{
   # check if the test_wert or min/max was searched
   if ($SearchParameter eq $G_TestWertIdendifier)
   {
      # ********************
      # output for test_wert
      # ********************
      # print all values 
      push (@DRS_File, $G_VariableName.$G_KeywordSeperator);         # Variable name
      push (@DRS_File, $G_TestWert.$G_KeywordSeperator);             # test_wert
      push (@DRS_File, $G_TestWert.$G_KeywordSeperator);             # test_wert
      push (@DRS_File, $G_Poly_Keyword.$G_KeywordSeperator);         # Polyspace keyword
      
      # Comments
      # ********
      # check if a physical value was found
      push (@DRS_File, "### Test_Wert: ".$G_TestWert." ".$G_SplitSignConFormula." ");     # comment test_wert
      push (@DRS_File, "Forumla: ".$G_CalcFormulaName." ".$G_SplitSignConFormula." ");       # comment Conversion Formula Name
      push (@DRS_File, $G_CalculationFormula."\n");                                          # comment Conversion Formula

      # all values set to DRS output, rest values
      ResetValues();
   }
   else
   {
      # ******************
      # output for min/max
      # ******************
      # no Error was found before
      # print all values 
      push (@DRS_File, $G_VariableName.$G_KeywordSeperator);         # Variable name
      push (@DRS_File, $G_MinValue.$G_KeywordSeperator);             # min value
      push (@DRS_File, $G_MaxValue.$G_KeywordSeperator);             # max value
      push (@DRS_File, $G_Poly_Keyword.$G_KeywordSeperator);         # polyspace keyword
      
      # Comments
      # ********
      # check if a physical value was found 
      push (@DRS_File, "### Min: ".$G_MinValue." ".$G_SplitSignConFormula." ");          # comment min value phys
      push (@DRS_File, "Max: ".$G_MaxValue." ".$G_SplitSignConFormula." ");              # comment max value phys
      push (@DRS_File, "Forumla: ".$G_CalcFormulaName." ".$G_SplitSignConFormula." ");       # comment Conversion Formula Name
      push (@DRS_File, $G_CalculationFormula."\n");                                          # comment Conversion Formula

      # all values set to DRS output, rest values
      ResetValues();

   } #End: if ($SearchParameter eq $G_TestWertIdendifier)
   return;
}

# Call: FindConversionFormula($f_ConversionFormula);
# **************************************************
# This function searches in the array @XMO_File for the conversion formula, which is given from the calling function.
# The conversion forumla is search line by line and returned to the calling function
# The conversion formular method "arithmetic" or "polynom" will be returned.
#
# Call of other function: none
# *****************************************************************************
sub FindConversionFormula
{
   my $f_ActualCodesyntax = shift;
   my @f_SplitString = 0;
   my @f_ConversionFormula = 0;
   my $f_TempString = "Not Found";
   my $f_StringPointer = 0;
   my $f_ActualString;
   my $f_CalcMethod;

   # search the complete list for the conversion formula
   foreach (@XMO_File)
   {
      # reset variables
      $f_StringPointer = 0;
      @f_SplitString = ();

      # copy actual string to temporary string
      $f_ActualString = $_;
      chomp($f_ActualString);

      # remove leading parameter Arith
      if (-1 ne index($f_ActualString, "Arith"))
      {
         $f_CalcMethod = "Arith";
         substr($f_ActualString, 0, 5, "");
      }

      # remove leading parameter Poly
      if (-1 ne index($f_ActualString, "Poly"))
      {
         $f_CalcMethod = "Poly";
         substr($f_ActualString, 0, 4, "");
      }

      # check the actual string for the code syntax
      # index returns position of the start from $f_ActualCodesyntax
      # not found, return -1
      if (index ($f_ActualString, $f_ActualCodesyntax) >= 0)
      {
         # code syntax found in the string $_
         # now detect if it is the exact code syntax and not a "part" of a code syntax
         # e.g. CS_RSH15 is part of CS_RSH15_GRAD
         # CS_ADC_3V3_q2EXP10=>1023.0/3.3 * phys + 0.0
         # split the string: splitsign is ':'
         chomp($f_ActualString);
         @f_SplitString = split(/$G_SplitSignConFormula/,$f_ActualString);

         # set referenz pointer
         $f_StringPointer = \@f_SplitString;

         # is it the correct code syntax?
         if ( $f_StringPointer->[0] eq $f_ActualCodesyntax)
         {
            # definite code syntax found
            $f_TempString = $f_StringPointer->[1];

            # remove '\n'
            chomp($f_TempString);

            # store conversion formula
            push (@f_ConversionFormula, $f_TempString."\n");

            # stop loop, because forumla is available
            last;
         }
      }
   } # end: foreach(@XMO_File)

   # return in first string Conversion forumlar: 1.0 * phys + 0.0 
   # return sechodn string with Calculation Method: Arith
   return ($f_TempString, $f_CalcMethod);
}


# Call: ValueCalculation_Poly($f_ConFormel, $f_PhysParameter);
# ************************************************************
# This function calculates the physical min/max into inteager value with a polynom.
# Therefor the conversion formula is used, which is handed over to this function.
# The value is calculated and returned to the calling function.
#
# Call of other function: none
# *****************************************************************************
sub ValueCalculation_Poly
{
   my $f_ConFormel      = shift;    # contains the conversion formula
   my $f_PhysParameter  = shift;    # contains the physical value
   my $f_TempValue;
   my $f_ValueNumerator;
   my $f_ValueDenominator;
   my $f_ConversionResult;
   my $f_Parameter;
   my @Poylnoms;
   
   # Conversion formular (polynom paramater) looks like: 
   # $f_ConFormel: 1.0 0 0 1.0 0
   
   # The polynom looks like the folowing
   #         P1 * phys + P2              numerator
   # int = ------------------ + P5      -----------
   #         P3 * phys + P4             denominator

   # split the parameter, to access each polynom parameter
   @Poylnoms = split(/ /,$f_ConFormel);
   $f_Parameter =  \@Poylnoms;

   # calculate the numerator
   # P1 * phys + P2
   $f_TempValue = $f_Parameter->[0] * $f_PhysParameter;
   $f_ValueNumerator = $f_TempValue + $f_Parameter->[1];
   
   # calculate the denominator
   # P3 * phys + P4
   $f_TempValue = $f_Parameter->[2] * $f_PhysParameter;
   $f_ValueDenominator = $f_TempValue + $f_Parameter->[3];
   
   # divide numerator with denominator
   $f_ConversionResult = ($f_ValueNumerator / $f_ValueDenominator) + $f_Parameter->[4];

   return $f_ConversionResult;
}

# Call: ValueCalculation_Arith($f_ConFormel, $f_PhysParameter);
# *************************************************************
# This function calculates the physical min/max into inteager value with aritmetic.
# Therefor the conversion formula is used, which is handed over to this function.
# The value is calculated and returned to the calling function.
#
# Call of other function: none
# *****************************************************************************
sub ValueCalculation_Arith
{
   my $f_ConFormel      = shift;    # contains the conversion formula
   my $f_PhysParameter  = shift;    # contains the physical value
   my $f_StringLength   = length ($f_ConFormel);
   
   my $f_TempSign;                     my $f_ArrayNbrElements;
   my $f_Length_Parameter;             my $f_Length_Parameter1;
   my $f_FirstRun = "First";           my $f_ConversionParameter;
   my $f_ConversionParameterLength;    my $f_ConversionResult;

   my @f_PosArithmeticOperator_a;      my @f_ArithmeticOperator_a;
   my @f_ConversionParameter_a;        my @f_TempArray;

   # Conversion formular (arithmetic paramater) looks like:
   # $f_ConFormel: 1.0 * phys + 0.0
   # $f_PhysParameter: -2

   # first element should be zero
   push (@f_PosArithmeticOperator_a,"0");

   for (my $f_forcount = 0; $f_forcount < $f_StringLength; $f_forcount ++)
   {
      $f_TempSign = substr($f_ConFormel, $f_forcount, 1);

      # extract each arithmetic operand in the conversion formula
      if (  ($f_TempSign =~ /\//)
          ||($f_TempSign =~ /\*/)
          ||($f_TempSign =~ /\-/)
          ||($f_TempSign =~ /\+/) )
      {
         push (@f_PosArithmeticOperator_a,$f_forcount);
         push (@f_ArithmeticOperator_a,$f_TempSign);
      }
   } # END for (...)

   # last element should be the lentgh of the string for further use
   push (@f_PosArithmeticOperator_a, $f_StringLength);

   # number of array elements (array length)
   $f_ArrayNbrElements = @f_PosArithmeticOperator_a;

   # extract the conversion parameter (e.g. 1024 phys 0)
   for (my $f_forcount = 0; $f_forcount < $f_ArrayNbrElements-1; $f_forcount ++)
   {
      $f_Length_Parameter    = $f_PosArithmeticOperator_a[$f_forcount];
      $f_Length_Parameter1   = $f_PosArithmeticOperator_a[$f_forcount+1];

      # only from the second loop
      if ($f_FirstRun eq "SecondAndMore")
      {
         $f_Length_Parameter += 1;
      }

      # keep the extracted value
      $f_TempSign = substr($f_ConFormel, $f_Length_Parameter, $f_Length_Parameter1 - $f_Length_Parameter);
      push (@f_ConversionParameter_a, $f_TempSign);

      $f_FirstRun = "SecondAndMore";
   } # END: for (my $f_forcount =...)

   # @f_ConversionParameter_a contains the conversion parameters e.g. 1024.0 phys 0.0 (as elements!)
   # @f_ArithmeticOperator_a contains the conversion operands e.g. * +
   # the element order corresponds each other => 1024.0 * phys + 0.0

   # set the first run sign
   $f_FirstRun = "First";

   # for all elements of the conversion parameters
   for (my $f_forcount_out = 0; $f_forcount_out < $f_ArrayNbrElements-1; $f_forcount_out ++)
   {
      # extract the first conversion parameter (e.g. 1024)
      $f_ConversionParameter = $f_ConversionParameter_a[$f_forcount_out];

      # conversion parameter length
      $f_ConversionParameterLength = length ($f_ConversionParameter);

      # cancel blanks around the "real" conversion parameter
      for (my $f_forcount_inner = 0; $f_forcount_inner < $f_ConversionParameterLength; $f_forcount_inner ++)
      {
         # extract sign for sign
         $f_TempSign = substr($f_ConversionParameter, $f_forcount_inner, 1);

         # is it a blank?
         if ($f_TempSign !~ / /)
         {
            # its not a blank, so keep it
            push(@f_TempArray, $f_TempSign);
         }
      }

      # parameter without blanks
      $f_ConversionParameter = join ("", @f_TempArray);

      # clear the array
      @f_TempArray = ();

      # only at the first loop
      # save the parameter
      if ($f_FirstRun eq "First")
      {
         # first run, set the conversion parameter as result value
         $f_ConversionResult = $f_ConversionParameter;
         $f_FirstRun = "SecondAndMore";
      }
      else
      {
         # check if the conversion parameter contains the key word "phys"
         if ($f_ConversionParameter eq "phys")
         {
            # contains "phys" set the hand over parameter as conversion parameter
            $f_ConversionParameter = $f_PhysParameter;
         }

         # check the conversion arithmetic operand for the calculation
         if ($f_ArithmeticOperator_a[$f_forcount_out-1] eq "*")
         {
            # multiplication
            $f_ConversionResult = $f_ConversionResult * $f_ConversionParameter;
         }
         elsif ($f_ArithmeticOperator_a[$f_forcount_out-1] eq "/")
         {
            # Division
            $f_ConversionResult = $f_ConversionResult / $f_ConversionParameter;
         }
         elsif ($f_ArithmeticOperator_a[$f_forcount_out-1] eq "+")
         {
            # Addition
            $f_ConversionResult = $f_ConversionResult + $f_ConversionParameter;
         }
         elsif ($f_ArithmeticOperator_a[$f_forcount_out-1] eq "-")
         {
            # Subtraction
            $f_ConversionResult = $f_ConversionResult - $f_ConversionParameter;
         }
      } # END if ($f_FirstRun eq "SecondAndMore")
   } # END for (my $f_forcount_out = 1; ...)

   return $f_ConversionResult;
}


# Call: WriteActualTime();
# ************************
# function calculates the actual date and time
#
# Call of other function: none
# *****************************************************************************
sub WriteActualTime
{
   my ($Sekunden, $Minuten, $Stunden, $Monatstag, $Monat, $Jahr, $Wochentag, $Jahrestag, $Sommerzeit) = localtime(time);
   $Monat += 1;
   $Monat = $Monat < 10 ? $Monat = "0".$Monat : $Monat;
   $Monatstag = $Monatstag < 10 ? $Monatstag = "0".$Monatstag : $Monatstag;
   $Stunden = $Stunden < 10 ? $Stunden = "0".$Stunden : $Stunden;
   $Minuten = $Minuten < 10 ? $Minuten = "0".$Minuten : $Minuten;
   $Sekunden = $Sekunden < 10 ? $Sekunden = "0".$Sekunden : $Sekunden;
   $Jahr += 1900;

   # return value looks like:
   # Date: 29.06.2010 Time: 13:38:18
   return ("Date: $Monatstag.$Monat.$Jahr Time: $Stunden:$Minuten:$Sekunden");
}


# Call: SearchDrsFiles();
# ***********************
# search the existing module DRS files within the test folder.
# the search is done recursive from the starting folder given at $DRSFilesPath
# searched for file with string: $G_ModuleDRSextension (_pd.txt)
# if a file is found, the content is written into the global DRS file [@DRS_File)
#
# Call of other function: call of tool find.exe
# *****************************************************************************
sub SearchDrsFiles
{
   my $Tool = "$CygPath.\\find.exe";
   my $TempResultFile = "$OBJPath.\\DRS_Temp.txt";

   # start System programm and pipe the result in a file
   # Example call:   `V:\\SWTOOLS\\cygwin\\bin\\find.exe O:\\TestSet\\Module -name '*_pd.txt' > U:\\Ergebnis.txt`;
   `$Tool $DRSFilesPath -name $G_ModuleDRSextension > $TempResultFile`;

   # open temp file
   open (DATEI, '<', "$TempResultFile") || die "Can't open $TempResultFile";
   my @myFiles = <DATEI>;
   close (DATEI);

   # remove temp file
   unlink($TempResultFile);

   # repeate for all found files
   foreach (@myFiles)
   {
      # change "/" into "\"
      $_ =~ s/\//\\/g;

      # remove \n
      chomp($_);

      # open DRS File
      open (DATEI, '<', $_) || die "Can't open $_";
      my @DRS_ModuleFile = <DATEI>;
      close (DATEI);

      # copy the DRS module file into global DRS file
      push (@DRS_File, "# ************************************************************************************\n");
      push (@DRS_File, "# ".$_."\n");
      push (@DRS_File, @DRS_ModuleFile);
      push (@DRS_File, "\n");
   }
   return;
}

