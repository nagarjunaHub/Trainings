#!/usr/bin/perl
use strict;
use warnings;

my $CHKSUM_TXT = $ARGV[0];
my $CHKSUM_MAK = $ARGV[1];
my $CHKSUM_LABEL = $ARGV[2];

open( my $CHKSUM_TXT_HANDLER, "<", $CHKSUM_TXT ) or die $!;
open( my $CHKSUM_MAK_HANDLER,    ">", $CHKSUM_MAK )    or die $!;

my $CHKSUM_TXT_CONTENT = <$CHKSUM_TXT_HANDLER>; 
close $CHKSUM_TXT_HANDLER;
print $CHKSUM_MAK_HANDLER "$CHKSUM_LABEL=$CHKSUM_TXT_CONTENT";
close $CHKSUM_MAK_HANDLER;
# if ( -e $CHKSUM_TXT ) {
        # unlink($CHKSUM_TXT) or die "$CHKSUM_TXT: $!"
# }
