#**************************************************************************** *
#*  FILENAME:    cc_ls_co_spec_dir.pl                                         *
#*                                                                            *
#*  PROGRAMMTYP: Perl-Script-File                                             *
#*                                                                            *
#*  AUTOR:       ZFLS/ZEEF Rohmann 01.07.2004                                 *
#*                                                                            *
#*  Aufgabe:     + Abfrage, ob per Parameter uebergebenes Verzeichnis         *
#*                 exisisitert                                                *
#*               + Check, ob spez. Verzeichnis durch akt. User in akt. View   *
#*                 ausgecheckt ist. Ausgabe einer Warnung je nach Parameter   *
#*                                                                            *
#*  Parameter:   ARGV[0] - enthaelt Lister der Parameter mit                  *
#*               - -dirVerzeichnis : Pad Verzeichnis                          *
#*               - logLogdatei     : Pfad und Name der Log-Datei              *
#*                                                                            *
#*  In/Output:                                                                *
#*                                                                            *
#*  AUFRUF:      ccperl 
#*               (Skript-Parameter sind in Anfuehrungszeichen zu setzten)     *
#*                                                                            *
#*  Kommentare:  
#*                                                                            *
#******************************************************************************

###############################################################################
# Uebergabeparameter

$TRUE = 1;
$FALSE = 0;

$RC_SUCCESS = 0;
$RC_ERR_FILE_OPEN = 1;
$RC_ERR_DIR_NO_FOUND = 2;
$RC_ERR_STOP = 3;


@tmp_argv = split ' ', $ARGV[0];

print "Uebergabeliste= @tmp_argv\n\n";

# Eingangsdatei
@tmp1 = grep /-dir/i, @tmp_argv;
$search_dir = $tmp1[0];
substr ($search_dir, 0, 4) = "";

# "Log-Liste"
@tmp1 = grep /-log/i, @tmp_argv;
$log_file = $tmp1[0];
substr ($log_file, 0, 4) = "";

###############################################################################
# 
unless (open (LOGFILE, ">$log_file"))
{
  exit ($RC_ERR_FILE_OPEN);
}

###############################################################################
# Parameter-Check:
#   - Verzeichnis-Wert: muss mindestens zwei Ebenen enthalten (LW und 1. Ver-
#          zeichnisebene)
@tmp_path = split /\\/, $search_dir;
$len_path_layer = scalar (@tmp_path);

print LOGFILE "Parameter: \n\n";
print LOGFILE "   Such-Pfad:                $search_dir\n";

if (3 > $len_path_layer)
{
  print LOGFILE "FEHLER Parameter \"-dir\"";
  close LOGFILE;
  exit $RC_ERR_FILE_OPEN;
} # end IF (len_path_layer, exist_switch)


###############################################################################
# Check, ob Pfad vorhanden
unless (opendir(TESTDIR, $search_dir))
{
  system ("clearprompt proceed -type ok -prompt \"FEHLER: Verzeichnis\n $search_dir \nnicht gefunden\n\n -> Bel. Button druecken\" -newline");
  close LOGFILE;
  exit $RC_ERR_DIR_NO_FOUND;
}

closedir TESTDIR;

###############################################################################
# Check, ob Pfad ausgecheckt ist ...

# Liste der f�r diesen View und diesen User ausgecheckten Versionen
#   Tool-Parameter:
#     -me  :  only my checkouts
#     -cvi :  only current view
#     -dir :  directory itself only
#     -fmt :  mit "%Rf" -> Nur CO-Status abfragen
$co_result = `cleartool lsc -me -cvi -fmt \"%Rf\" -dir $search_dir` ;

print "Check Verzeichnis, Ergebnis:\n  $co_result\n";
print LOGFILE "Check Verzeichnis, Ergebnis:\n  $co_result\n";

# "reserved" ausgechecked ?
$rc = $RC_SUCCESS;
if ($co_result ne "reserved")
{ # Nein -> Fehler
  $tmp_rc = system ("clearprompt proceed -type ok -prompt \"FEHLER: Verzeichnis <$search_dir> nicht RESERVED ausgecheckt !\" -newline");
  $rc = $RC_ERR_STOP;
} # end IF (co_result)

###############################################################################
# Ende...
print "... Ende ... \n";
print LOGFILE "... Ende ... \n";

close LOGFILE;

exit($rc);
