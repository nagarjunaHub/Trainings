#
#  This script reads the REF file as input and creates a new adl file by modifying the Array elements names as per a2l merger tool requirement . For example, if the array element in REF file is CS_SplyV_uSCMThdUb12_XDF32_0____A  the same variable in adl file will be CS_SplyV_uSCMThdUb12_XDF32[0]
#
#  The correct command looks like:
#  <path of the perl.exe>\perl.exe REF2ADL.pl REF_FilePath ADL_File_Path
#
#  For example:
#  C:\Users\nbd5kor\rtc_sandbox\rbd_invrPPC_tools-swBuild-briBk1_integration_RWS_NBD5KOR\rbd\invrPPC\tools\swBuild\SWTOOLS\perl\v5_8_8_817\bin\perl.exe C:\Users\nbd5kor\rtc_sandbox\rbd_invrPPC_tools-swBuild-briBk1_integration_RWS_NBD5KOR\rbd\invrPPC\tools\swBuild\SWTOOLS\skripte\Perl\REF2ADL.pl $(DEPLOY)\$(VAR_NAME).REF $(DEPLOY)\$(VAR_NAME).adl
#
#
#  Does not work? Then you should check the next points.
#  1. Did you chose the right path for your perl.exe?
#  2. Is it really available?
#  3. Are the case of the letters in the paths correct?
#
#  AUTOR:   Nagarjuna Badigunchala
#  DATE:    2016.12.19
#  FILE:    REF2ADL.pl
#  VERSION: 1.0
#

#!/usr/bin/perl

use strict;
use warnings;
my $REF_file = $ARGV[0];
my $ADL_file = $ARGV[1];
my $File_content = "";
open ADLFILE, ">$ADL_file" or die $!;
open (REFFILE, $REF_file);
 while (<REFFILE>) {
	my $line = $_;
	my @ary_elements = split(/\s+/, $line, 0);
	if ($ary_elements[0] =~ /_(\d+)____([A-Za-z]+)/i ) {
		(my $new = $line) =~ s/_(\d+)____([A-Za-z]+)/[$1]/;
		print ADLFILE "$new";
	}
	else {
		print ADLFILE "$line";
	}
 }
close REFFILE;
close ADLFILE;
__END__