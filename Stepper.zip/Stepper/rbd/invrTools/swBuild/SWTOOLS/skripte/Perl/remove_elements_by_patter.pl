# $ZFLSHEADER$ ----------------------------------------------------------------
# -----------------------------------------------------------------------------  
#                                                                            
#  Copyright (c) ZF Lenksysteme GmbH, Germany                                
#                All rights reserved                                         
#                                                                            
# ----------------------------------------------------------------------------- 
#                                                                            
#   Dateiname:       remove_elements_by_patter.pl  
# 
#   Zustaendigkeit:  ZFLS-ZEEx Rohmann, Thomas (ZEEF
# 
#   Beschreibung:    Loescht Elemente in CC-Verzeichnisse aufgrund eines
#                    als Parameter uebergebenen Patters.
#                    Es wird nur das angegebene Verzeichnis durchsucht !
#
#   Parameter:       -dir<Zu durhsuchendes Verzeichnis>
#                    -fp<Dateipatter (ohne Verzeichnis)>
#                    -pat[REMOVE|NOREM]
#                    -log<Pfad und Name Log-Datei>
#                                                                                                    
# -----------------------------------------------------------------------------                                                                           
# $END_ZFLSHEADER$ ------------------------------------------------------------ 

use strict;

###############################################
# "main"
###############################################
{
  ############################################################################
  # Vorbelegungen

  my $RC_SUCCCESS = 0;
  my $RC_ERROR = 1;
  my $RC_ERR_FILE_OPEN = 2;
  my $RC_ERR_OPEN_DIR = 3;
  my $RC_ERR_CHDIR = 4;
  my $RC_ERR_CC_CO = 5;
  my $RC_ERR_CC_CI = 6;
  my $RC_ERR_CC_RM = 7;

  my $TRUE = 0;
  my $FALSE = $TRUE + 1;

  ############################################################################
  # Parameter auswerten

  my @tmp_argv = split ' ', $ARGV[0];

  # View-Verzeichnis, das zu durchsuchen ist
  my $act_path = "";
  my @tmp1 = grep /-dir/i, @tmp_argv;
  $act_path = $tmp1[0];
  substr ($act_path, 0, 4) = "";

  # Datei-Patter
  my $file_patter = "";
  @tmp1 = grep /-fp/i, @tmp_argv;
  $file_patter = $tmp1[0];
  substr ($file_patter, 0, 3) = "";

  # Datei-Patter: Remove or not removed
  my $remove_patter = "";
  @tmp1 = grep /-pat/i, @tmp_argv;
  $remove_patter = $tmp1[0];
  substr ($remove_patter, 0, 4) = "";
  $remove_patter = uc $remove_patter;

  # "Log-Liste"
  my $log_file = "";
  @tmp1 = grep /-log/i, @tmp_argv;
  $log_file = $tmp1[0];
  substr ($log_file, 0, 4) = "";

  if (($act_path eq "") || ($file_patter eq "") ||
      (($remove_patter ne "REMOVE") && ($remove_patter ne "NOREM")) ||
      ($log_file eq ""))
  {
    print "FEHLER: Parameter nicht in Ordnung, bitte kontrollieren: \n";
    print "        -dir<Zu durhsuchendes Verzeichnis\n";
    print "        -patter<Dateipatter (ohne Verzeichnis)>\n";
    print "        -pat[REMOVE|NOREM]\n";
    print "        -log<Pfad und Name Log-Datei>\n\n";
    exit ($RC_ERROR);
  } # end IF (<Uebergabeparameter nicht leer>)


  ############################################################################
  # Eine Log-Datei wird zum Schreiben ge�ffnet

  my $rc = $RC_SUCCCESS;
  unless (open (LOGFILE, ">$log_file"))
  {
    exit ($RC_ERR_FILE_OPEN);
  } # end UNLESS (open Logfile)
 
  print LOGFILE "Parameterliste:\n";
  print LOGFILE "--------------\n";
  print LOGFILE "  Verzeichnis: $act_path\n";
  print LOGFILE "  Dateipatter: $file_patter\n";
  print LOGFILE "    rem ja/n : $remove_patter\n\n";

  ############################################################################
  # Gesamtliste des Verzeichnisses anlegen
    # 1. Akt. Arbeitsverzeichnis = UebergabevVerzeichnis ...
  my $act_drive = substr ($act_path, 0, 2);
  my $act_tmp_path = substr ($act_path, 2);
  
    # ... 2. Change Directory auf Drive und Pfad ...
  unless (chdir ($act_drive))
  {
    print "FEHLER: kann nicht auf View-Laufwerk wechseln - $act_drive !\n\n";
    print LOGFILE "FEHLER: kann nicht auf View-Laufwerk wechseln - $act_drive !\n\n";
    exit ($RC_ERR_CHDIR);
  } # end UNLESS (chdir)
  unless (chdir ($act_tmp_path))
  {
    print LOGFILE "FEHLER: kann nicht auf View-Laufwerk wecheslen - $act_drive !\n\n";
    exit ($RC_ERR_CHDIR);
  } # end UNLESS (chdir)
  
    # ... 3. Einlesen des Verzeichnis-Inhaltes ueber CC Commando ...
  my @file_list = `cleartool ls  -s -nxn`;
  print LOGFILE "Liste aller gefundenen Elemente in Verzeichnis:\n@file_list\n";

    # ... 4. Selektieren je nach Aufgabe
  my @sel_file_list = "";
  if ($remove_patter eq "REMOVE")
  { # Neue Liste: Files entsprechend Patter sind zu loeschen
    @sel_file_list = grep { /$file_patter/ } @file_list;
  } # end IF (remove_patter)
  else
  { # Neue Liste: Files <> Patter zu loeschen
    # @sel_file_list =! grep /$file_patter/, @file_list;
    @sel_file_list = grep { !/$file_patter/ } @file_list;
  } # end IF (remove_patter)
  print LOGFILE "  -> Selektierte Liste:\n@sel_file_list\n";
  
    # ... 5. Ist verzeichnis ausgecheckt oder muss ausgecheckt werden?
  my $cc_co_dir = `cleartool lscheckout -dir -s $act_path`;
  chomp $cc_co_dir;
  print LOGFILE "CC Checked-Out Verzeichnis= $cc_co_dir\n";
  my $cc_dir_co = $FALSE;
  if (( $cc_co_dir ne $act_path ) && ( $cc_co_dir ne "" ) &&
       (scalar(@sel_file_list) > 0 ))
  { # ... Verzeichnis auschecken
    print LOGFILE "...Vezeichnis auschecken ...\n";
    $rc = system ("cleartool co -res -nc -q $act_path");
    if ( $rc != 0 )
    { # .. Fehler !
       print LOGFILE "FEHLER: Verzeichnis\n   $act_path\nkann nicht ausgecheckt werden !\n";
       return ($RC_ERR_CC_CO);
    } # end IF (rc)
    $cc_dir_co = $TRUE;
  } # end IF (cc_co_dir)
  else
  { # Verzeichnis bereits ausgecheckt ..
    print LOGFILE "Verzeichnis bereits ausgecheckt oder mu� nicht ausgecheckt werden !\n";
  }

    # ... 6. Elemente loeschen ...
  print LOGFILE " ... loeschen der einzelnen Elemente der Liste\n";
  foreach my $elem (@sel_file_list)
  { # ... loeschen des Elementes
    chomp $elem;
    print LOGFILE "Element $elem wird geloescht ..\n";
    $rc = system ("cleartool rmname $elem");
    if ( $rc != 0 )
    { # .. Fehler !
       print LOGFILE "FEHLER: Element\n  $elem\nkann nicht geloescht werden !\n";
       return ($RC_ERR_CC_RM);
    } # end IF (rc)
  } # end FOREACH (elem)

    # muss Verzeichnis wieder eingecheckt werden ?
  if ( $cc_dir_co == $TRUE )
  { # ... Verzeichnis einchecken
    print LOGFILE "...Vezeichnis einchecken ...\n";
    $rc = system ("cleartool ci -nc -ide $act_path");
    if ( $rc != 0 )
    { # .. Fehler !
       print LOGFILE "FEHLER: Kann Verzeichnis $act_path nicht einchecken !\n";
       return ($RC_ERR_CC_CI);
    } # end IF (rc)
  } # end IF (cc_dir_co)

  exit ($rc);
  
} # Ende MAIN


