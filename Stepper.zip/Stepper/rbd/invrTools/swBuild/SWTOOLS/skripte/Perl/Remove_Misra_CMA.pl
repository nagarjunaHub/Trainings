use strict;
use warnings;
use File::Basename;

my $summary_report=$ARGV[0];
my($filename, $dirs, $suffix) = fileparse($summary_report,qr/\Q.txt\E/);
my $modified_report=$dirs.$filename."_mr".$suffix;


open my $fh, "<", $summary_report or die $!;
open my $fh1, ">", $modified_report or die $!;
my @lines = <$fh>;
foreach my $lines (@lines){

    next if ($lines =~ m/^CMA/i || $lines =~ m/^Multi-Location/i );
      if( $lines =~ s/File Name/FileName/g) {
           print $fh1 "$lines";
        }
      else{
    print $fh1 "$lines";
	    }
    }

close $fh1;
