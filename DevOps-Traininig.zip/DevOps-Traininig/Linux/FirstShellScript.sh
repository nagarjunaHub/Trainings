#!/bin/bash
clear
ls -l ~
df -h | grep root | cut -d " " -f 10
free -h | grep "^Mem"

